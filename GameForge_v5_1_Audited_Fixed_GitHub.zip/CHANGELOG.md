# Changelog

## 5.0 — GameForge Local Model Swarm MAX
- Added model-agnostic local specialist catalog.
- Added per-task GGUF switching.
- Added RAM-aware heavy-model gating.
- Added DeepSeek-Coder 6.7B specialist profile.
- Added Qwen3-4B Instruct/Thinking-2507 specialist profiles.
- Added Qwen2.5-VL-3B vision profile with explicit native-multimodal boundary.
- Connected supervised, unsupervised, semi-supervised, self-supervised and reinforcement learning to routing experience.
- Made native chat prompting model-agnostic via exported GGUF chat templates.
