# 5.1 LOCAL-SWARM MAX audited release checks

## Static/source checks

- [x] Version and documentation are aligned to 5.1 audited release.
- [x] JNI Kotlin/native method names match.
- [x] Native generation caps output to the remaining context window.
- [x] Model load/import uses atomic temp-file finalization and GGUF header validation.
- [x] Model and adapter switching is serialized against generation.
- [x] MediaProjection registers a callback and uses the media-projection foreground-service type.
- [x] Godot workspace packager retains legitimate generated `gameforge/` files while excluding caches/checkpoints.
- [x] Generated-game launch failures are surfaced as playtest failures rather than being treated as successful boots.
- [x] Tool shell surface excludes Gradle/build-script execution and destructive git operations.
- [x] JSON manifests/configuration parse successfully.
- [x] No private keystore, signing key, PEM, or certificate secret is shipped in the source archive.
- [x] Release signing is configurable through user-supplied Gradle properties/environment variables; no secret is embedded.
- [x] Godot starter files are repaired individually when missing.
- [x] VLM image MIME is inferred from the captured file extension.

## Environment limits

- [ ] Final Android Gradle/NDK link in this container.
- [ ] APK installation/execution on the Galaxy M33.
- [ ] Real GGUF inference on the target device from this container.
- [ ] Real native multimodal Qwen2.5-VL execution through an image-capable runtime.
- [ ] On-device Qwen gradient training.

Those require the Android SDK/NDK, target hardware and/or optional model backends.
