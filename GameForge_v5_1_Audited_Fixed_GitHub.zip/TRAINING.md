# Training and continuous learning — 5.1 LOCAL-SWARM MAX AUDITED

```text
experience
   |
   +--> memory retrieval
   |
   +--> RL transition store
   |
   +--> skill extraction
   |
   +--> dataset curation
             |
      +------+------+
      |             |
    train         holdout
      |             |
      +------+------+
             |
        LoRA candidate
             |
        evaluation lab
             |
       promote / reject
```

GameForge prioritizes high-quality trajectories:

- complete mission
- actual tool result
- fresh playtest evidence
- diagnosed failure
- targeted repair
- verified outcome

The phone is a continuous data collector and inference engine. Heavy adapter training remains a separate workload unless a capable local trainer is explicitly integrated and verified.
