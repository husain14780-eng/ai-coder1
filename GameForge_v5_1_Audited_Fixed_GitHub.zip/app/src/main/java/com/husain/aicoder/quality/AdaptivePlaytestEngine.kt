package com.husain.aicoder.quality

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.arm.aichat.ReasoningMode
import com.husain.aicoder.agent.ToolExecutor
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import org.json.JSONObject

/**
 * Model-driven playtester. It uses the same local Qwen brain as the coding
 * agent, but constrains actions to the safe gameplay grammar.
 */
class AdaptivePlaytestEngine(
    private val tools: ToolExecutor,
    private val engine: InferenceEngine?,
    private val actionGrammar: String?
) {
    data class Result(
        val report: JSONObject,
        val policyTurns: Int
    )

    suspend fun run(iterations: Int = 3, maxStepsPerRun: Int = 18): Result {
        val n = iterations.coerceIn(1, 12)
        val steps = maxStepsPerRun.coerceIn(4, 40)
        val loaded = tools.execute("run_generated_game", JSONObject().put("main_scene", "main.tscn"))
        if (!loaded.optBoolean("ok")) {
            val report = JSONObject()
                .put("mode", if (engine != null) "qwen_adaptive" else "deterministic_fallback")
                .put("iterations", n)
                .put("max_steps_per_run", steps)
                .put("successful_boots", 0)
                .put("boot_rate", 0.0)
                .put("pass_rate", 0.0)
                .put("ok", false)
                .put("policy_turns", 0)
                .put("runtime_load", loaded)
                .put("runs", org.json.JSONArray())
                .put("generated_at_ms", System.currentTimeMillis())
            return Result(report, 0)
        }
        val runs = org.json.JSONArray()
        var successfulBoots = 0
        var policyTurns = 0

        repeat(n) { runIndex ->
            val boot = tools.execute("run_godot_test", JSONObject())
            val actionRows = org.json.JSONArray()
            if (!boot.optBoolean("ok")) {
                runs.put(JSONObject().put("iteration", runIndex + 1).put("boot", boot).put("actions", actionRows))
                return@repeat
            }
            successfulBoots++
            var observation = boot.optJSONObject("observation") ?: JSONObject()
            var completed = false
            var stopped = false

            repeat(steps) { stepIndex ->
                if (completed || stopped) return@repeat
                val action = chooseAction(observation, runIndex, stepIndex)
                policyTurns++
                val result = tools.execute("game_action", action.put("settle_ms", 160))
                actionRows.put(
                    JSONObject()
                        .put("step", stepIndex + 1)
                        .put("action", action)
                        .put("result", result)
                )
                observation = result.optJSONObject("observation") ?: observation
                completed = observation.optBoolean("finished", false) || observation.optBoolean("goal_reached", false)
                stopped = action.optString("type") == "stop"
                delay(60)
            }

            runs.put(
                JSONObject()
                    .put("iteration", runIndex + 1)
                    .put("boot", boot)
                    .put("completed", completed)
                    .put("final_observation", observation)
                    .put("actions", actionRows)
            )
        }

        val bootRate = successfulBoots.toDouble() / n
        val report = JSONObject()
            .put("mode", if (engine != null) "qwen_adaptive" else "deterministic_fallback")
            .put("iterations", n)
            .put("max_steps_per_run", steps)
            .put("successful_boots", successfulBoots)
            .put("boot_rate", bootRate)
            .put("pass_rate", if (n == 0) 0.0 else successfulBoots.toDouble() / n)
            .put("ok", successfulBoots == n)
            .put("policy_turns", policyTurns)
            .put("runtime_load", loaded)
            .put("runs", runs)
            .put("generated_at_ms", System.currentTimeMillis())
        return Result(report, policyTurns)
    }

    private suspend fun chooseAction(observation: JSONObject, runIndex: Int, stepIndex: Int): JSONObject {
        val qwen = engine
        val grammar = actionGrammar
        if (qwen == null || grammar.isNullOrBlank()) return fallbackAction(stepIndex)

        val prompt = """
            You are the GameForge autonomous playtester.
            Choose the next player action for this game.
            Use only the allowed JSON action schema from the grammar.
            Prefer actions that explore the core gameplay loop and reach the goal.
            Do not explain. Return exactly one action JSON.

            TEST RUN: $runIndex
            STEP: $stepIndex
            OBSERVATION:
            ${observation.toString()}
        """.trimIndent()

        val out = StringBuilder()
        qwen.sendUserPrompt(
            prompt,
            GenerationConfig(ReasoningMode.FAST, 96, 0.65f, 0.85f, 20, 0f, 1.03f, grammar = grammar, grammarRoot = "root")
        ).collect { out.append(it) }

        return parseAction(out.toString()) ?: fallbackAction(stepIndex)
    }

    private fun parseAction(raw: String): JSONObject? {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        return runCatching {
            val o = JSONObject(raw.substring(start, end + 1))
            require(o.optString("type") in setOf("move", "jump", "restart", "stop"))
            o.put("x", o.optDouble("x", 0.0).coerceIn(-1.0, 1.0))
            o.put("jump", o.optBoolean("jump", o.optString("type") == "jump"))
            o
        }.getOrNull()
    }

    private fun fallbackAction(step: Int): JSONObject = when (step % 6) {
        0 -> JSONObject().put("type", "move").put("x", 0.65).put("jump", false)
        1 -> JSONObject().put("type", "jump").put("x", 0.0).put("jump", true)
        2 -> JSONObject().put("type", "move").put("x", -0.65).put("jump", false)
        3 -> JSONObject().put("type", "jump").put("x", 0.4).put("jump", true)
        4 -> JSONObject().put("type", "move").put("x", -0.25).put("jump", false)
        else -> JSONObject().put("type", "idle").put("x", 0.0).put("jump", false).apply {
            put("type", "move")
        }
    }
}
