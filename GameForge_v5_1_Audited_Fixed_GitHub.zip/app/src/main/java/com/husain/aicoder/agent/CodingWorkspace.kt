package com.husain.aicoder.agent

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

class CodingWorkspace(context: Context) {
    val root: File = File(context.filesDir, "workspace").apply { mkdirs() }
    private val checkpointRoot = File(context.filesDir, "checkpoints").apply { mkdirs() }

    private fun resolve(relative: String): File {
        val clean = relative.trimStart('/').replace('\\', '/')
        val f = File(root, clean).canonicalFile
        val rootPath = root.canonicalPath
        check(f.path == rootPath || f.path.startsWith(rootPath + File.separator)) { "Path escapes workspace" }
        return f
    }

    fun read(path: String): String {
        val f = resolve(path)
        require(f.isFile) { "File not found: $path" }
        return f.readText().take(30000)
    }

    fun write(path: String, content: String): String {
        val f = resolve(path)
        f.parentFile?.mkdirs()
        val temp = File(f.parentFile, ".${f.name}.part")
        FileOutputStream(temp).use { output ->
            output.write(content.toByteArray(Charsets.UTF_8))
            output.fd.sync()
        }
        runCatching {
            Files.move(temp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        }.recoverCatching {
            Files.move(temp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }.getOrElse { throw IllegalStateException("Cannot finalize workspace file: $path", it) }
        return f.relativeTo(root).path
    }

    fun listAllFiles(limit: Int = 20000): List<String> = root.walkTopDown()
        .onEnter { it.name != ".git" && it.name != ".godot" && it.name != "checkpoints" }
        .filter { it.isFile }
        .take(limit.coerceIn(1, 100000))
        .map { it.relativeTo(root).path.replace(File.separatorChar, '/') }
        .toList()

    fun replaceText(path: String, old: String, new: String, expectedCount: Int = 1): String {
        require(old.isNotEmpty()) { "old text must not be empty" }
        val f = resolve(path)
        require(f.isFile) { "File not found: $path" }
        val original = f.readText()
        val actual = countOccurrences(original, old)
        require(actual == expectedCount) { "replace_text expected $expectedCount match(es), found $actual" }
        f.writeText(original.replace(old, new))
        return f.relativeTo(root).path
    }

    fun append(path: String, content: String): String {
        val f = resolve(path)
        f.parentFile?.mkdirs()
        f.appendText(content)
        return f.relativeTo(root).path
    }

    fun list(path: String = ""): List<String> = resolve(path)
        .walkTopDown().filter { it.isFile }.take(500)
        .map { it.relativeTo(root).path }.toList()

    fun search(query: String, path: String = ""): List<String> {
        val q = query.lowercase(); require(q.isNotBlank())
        return resolve(path).walkTopDown().filter { it.isFile }.take(1000).mapNotNull { f ->
            val text = runCatching { f.readText() }.getOrNull() ?: return@mapNotNull null
            if (text.lowercase().contains(q)) f.relativeTo(root).path else null
        }.take(160).toList()
    }

    fun sha256(path: String): String {
        val bytes = resolve(path).readBytes()
        return MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    }

    @Synchronized fun checkpoint(label: String): File {
        val safe = label.replace(Regex("[^A-Za-z0-9_.-]+"), "_").take(80)
        val out = File(checkpointRoot, "${System.currentTimeMillis()}_$safe").apply { mkdirs() }
        copyTree(root, out)
        return out
    }

    fun listCheckpoints(): List<File> = checkpointRoot.listFiles()?.filter { it.isDirectory }
        ?.sortedByDescending { it.name } ?: emptyList()

    @Synchronized fun restoreCheckpoint(name: String): Boolean {
        val source = checkpointRoot.listFiles()?.firstOrNull { it.name == name && it.isDirectory } ?: return false
        root.deleteRecursively(); root.mkdirs(); copyTree(source, root); return true
    }

    private fun copyTree(from: File, to: File) {
        if (from.isDirectory) {
            to.mkdirs()
            from.listFiles()?.forEach { child -> copyTree(child, File(to, child.name)) }
        } else if (from.isFile) {
            to.parentFile?.mkdirs(); from.copyTo(to, overwrite = true)
        }
    }

    private fun countOccurrences(haystack: String, needle: String): Int {
        var count = 0; var at = 0
        while (true) {
            val i = haystack.indexOf(needle, at)
            if (i < 0) return count
            count++; at = i + needle.length
        }
    }
}
