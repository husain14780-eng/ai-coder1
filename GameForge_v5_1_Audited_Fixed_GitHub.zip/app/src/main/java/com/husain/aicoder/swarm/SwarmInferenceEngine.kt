package com.husain.aicoder.swarm

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow

/**
 * Drop-in InferenceEngine that transparently switches the local GGUF model before
 * each generation. Existing GameForge agents therefore become model-agnostic without
 * each agent knowing about files, RAM, or llama.cpp.
 */
class SwarmInferenceEngine(
    private val base: InferenceEngine,
    private val swarm: LocalModelSwarmManager,
    private val router: SwarmTaskRouter,
    private val learning: SwarmLearningManager
) : InferenceEngine {
    @Volatile private var loadedId: String? = null
    @Volatile private var loadedPath: String? = null
    @Volatile private var manualProfileId: String? = null
    @Volatile private var adapterPath: String? = null
    @Volatile private var adapterScale: Float = 1.0f
    @Volatile private var adapterBasePath: String? = null
    @Volatile private var adapterLoadedForPath: String? = null
    private val modelMutex = Mutex()

    override val state get() = base.state

    override suspend fun loadModel(pathToModel: String, contextSize: Int, threads: Int, batchSize: Int) = modelMutex.withLock {
        base.loadModel(pathToModel, contextSize, threads, batchSize)
        loadedPath = pathToModel
        loadedId = LocalModelCatalog.matchFileName(java.io.File(pathToModel).name)?.id
        adapterLoadedForPath = null
        if (adapterPath != null && adapterBasePath == pathToModel) {
            base.loadLoraAdapter(adapterPath!!, adapterScale)
            adapterLoadedForPath = pathToModel
        }
    }

    override suspend fun setSystemPrompt(systemPrompt: String) = base.setSystemPrompt(systemPrompt)
    override suspend fun loadLoraAdapter(path: String, scale: Float) = modelMutex.withLock {
        base.loadLoraAdapter(path, scale)
        adapterPath = path
        adapterScale = scale
        adapterBasePath = loadedPath
        adapterLoadedForPath = loadedPath
    }
    override suspend fun clearLoraAdapter() = modelMutex.withLock {
        base.clearLoraAdapter()
        adapterPath = null
        adapterScale = 1.0f
        adapterBasePath = null
        adapterLoadedForPath = null
    }

    override fun sendUserPrompt(message: String, config: GenerationConfig): Flow<String> = flow {
        modelMutex.withLock {
        val decision = runCatching {
            manualProfileId?.let { id ->
                LocalModelCatalog.byId(id)?.let { p -> swarm.installedProfile(p.id)?.let { SwarmTaskRouter.Decision("manual", p, "manual model") } }
            } ?: router.decide(message)
        }.getOrElse { throw IllegalStateException("Local model swarm has no usable installed specialist: ${it.message}", it) }

        val installed = swarm.installedProfile(decision.profile.id)
            ?: error("Model ${decision.profile.displayName} is not installed")

        if (loadedId != decision.profile.id || loadedPath != installed.file.absolutePath) {
            base.cleanUp()
            val snap = swarm.deviceSnapshot()
            val allowHeavy = snap.availableRamMb >= (decision.profile.estimatedRamGb * 1024 + 300).toLong()
            if (decision.profile.experimentalHeavy && !allowHeavy) {
                val fallback = swarm.bestInstalled(LocalModelProfile.Role.CODING, emptyMap(), allowHeavy = false)
                    ?: swarm.bestInstalled(LocalModelProfile.Role.GENERAL, emptyMap(), allowHeavy = false)
                    ?: error("Heavy specialist ${decision.profile.displayName} rejected by RAM guard and no fallback is installed")
                base.loadModel(fallback.file.absolutePath, fallback.profile.contextTokens)
                loadedId = fallback.profile.id
                loadedPath = fallback.file.absolutePath
            } else {
                base.loadModel(installed.file.absolutePath, decision.profile.contextTokens)
                loadedId = decision.profile.id
                loadedPath = installed.file.absolutePath
            }
        }

        if (adapterPath != null && adapterLoadedForPath != loadedPath && adapterBasePath == loadedPath) {
            base.loadLoraAdapter(adapterPath!!, adapterScale)
            adapterLoadedForPath = loadedPath
        }

        val started = System.currentTimeMillis()
        val maxTokens = decision.profile.maxOutputTokens.coerceAtMost(config.maxTokens.coerceAtLeast(16))
        var full = ""
        try {
            base.sendUserPrompt(message, config.copy(maxTokens = maxTokens)).collect { token ->
                full += token
                emit(token)
            }
            val quality = qualityHeuristic(full)
            learning.record(decision.task, loadedId ?: decision.profile.id, success = full.isNotBlank(), quality = quality, latencyMs = System.currentTimeMillis() - started)
        } catch (t: Throwable) {
            learning.record(decision.task, loadedId ?: decision.profile.id, success = false, quality = 0.0, latencyMs = System.currentTimeMillis() - started)
            throw t
        }
        }
    }

    fun setManualProfile(id: String?) { manualProfileId = id }
    fun activeProfileId(): String? = loadedId
    fun clearManualProfile() { manualProfileId = null }

    override fun abort() = base.abort()
    override fun modelInfo(): String = base.modelInfo()
    override fun cleanUp() {
        base.cleanUp()
        loadedId = null
        loadedPath = null
        adapterLoadedForPath = null
    }
    override fun destroy() = base.destroy()

    private fun qualityHeuristic(text: String): Double {
        if (text.isBlank()) return 0.0
        var s = 0.35
        if (text.length > 160) s += 0.15
        if (text.contains("```")) s += 0.15
        if (text.contains("test", ignoreCase = true) || text.contains("verify", ignoreCase = true)) s += 0.15
        if (text.length > 700) s += 0.10
        return s.coerceIn(0.0, 1.0)
    }
}
