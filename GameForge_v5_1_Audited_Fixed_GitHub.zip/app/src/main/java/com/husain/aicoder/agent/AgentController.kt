package com.husain.aicoder.agent

import android.content.Context
import com.arm.aichat.AiChat
import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.arm.aichat.ReasoningMode
import com.husain.aicoder.MainActivity
import com.husain.aicoder.godot.AICoderGodotBridge
import com.husain.aicoder.game.GameDesignEngine
import com.husain.aicoder.game.GameForgeEngine
import com.husain.aicoder.game.ProceduralAssetFactory
import com.husain.aicoder.memory.EpisodeStore
import com.husain.aicoder.memory.MemoryRetriever
import com.husain.aicoder.mission.AutonomousCodingEngine
import com.husain.aicoder.mission.GameForgeApexEngine
import com.husain.aicoder.mission.GameBuildStore
import com.husain.aicoder.mission.MissionStore
import com.husain.aicoder.skills.SkillLibrary
import com.husain.aicoder.ml.ContinuousLearningManager
import com.husain.aicoder.ml.CodingEvalSuite
import com.husain.aicoder.ml.UltimateBenchmarkSuite
import com.husain.aicoder.ml.MLTrainingCoordinator
import com.husain.aicoder.model.ModelManager
import com.husain.aicoder.swarm.LocalModelSwarmManager
import com.husain.aicoder.swarm.SwarmInferenceEngine
import com.husain.aicoder.swarm.SwarmLearningManager
import com.husain.aicoder.swarm.SwarmTaskRouter
import com.husain.aicoder.swarm.LocalSwarmBenchmarkRunner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class AgentController(private val context: Context) {
    private val scope = CoroutineScope(Job() + Dispatchers.Default)
    private val memoryLog = EpisodeStore(context)
    private val learning = MLTrainingCoordinator(context)
    private val continuous = ContinuousLearningManager(context)
    private val workspace = CodingWorkspace(context)
    private val baseEngine: InferenceEngine = AiChat.getInferenceEngine(context)
    private val modelManager = ModelManager(context)
    private val swarmManager = LocalModelSwarmManager(context, modelManager)
    private val swarmLearning = SwarmLearningManager(context)
    private val swarmRouter = SwarmTaskRouter(swarmManager, swarmLearning)
    private val swarmEngine = SwarmInferenceEngine(baseEngine, swarmManager, swarmRouter, swarmLearning)
    private val engine: InferenceEngine = swarmEngine
    private val swarmBenchmark = LocalSwarmBenchmarkRunner(swarmManager, swarmEngine, swarmLearning)
    private val missions = MissionStore(context)
    private val memories = MemoryRetriever(context)
    private val skills = SkillLibrary(context)
    private val maxCoding = AutonomousCodingEngine(engine, workspace, continuous, missions, memories, skills) { message ->
        (context as? MainActivity)?.setStatus(message)
    }
    private val evalSuite = CodingEvalSuite()
    private val ultimateBench = UltimateBenchmarkSuite(workspace)
    private val gameDesign = GameDesignEngine(engine)
    private val gameBuildStore = GameBuildStore(context)
    private var gameForge: GameForgeEngine? = null
    private var apexForge: GameForgeApexEngine? = null
    private var gameplayJob: Job? = null
    private val running = AtomicBoolean(false)
    @Volatile private var latestObservation: String? = null
    private var godotBridge: AICoderGodotBridge? = null
    private lateinit var toolExecutor: ToolExecutor
    private val gameplayGrammar: String by lazy { context.assets.open("grammars/action.gbnf").bufferedReader().use { it.readText() } }

    fun attachGodot(bridge: AICoderGodotBridge) {
        godotBridge = bridge
        toolExecutor = ToolExecutor(workspace, bridge) { missions.list().firstOrNull()?.summary ?: "no resumable mission summary" }
        maxCoding.attachTools(toolExecutor)
        ProceduralAssetFactory(workspace).writeHelpers()
        gameForge = GameForgeEngine(gameDesign, workspace, maxCoding, toolExecutor, continuous, skills, engine, gameplayGrammar, gameBuildStore) { message ->
            (context as? MainActivity)?.setStatus(message)
        }
        apexForge = GameForgeApexEngine(workspace, toolExecutor, gameForge!!, maxCoding) { message ->
            (context as? MainActivity)?.setStatus(message)
        }
        scope.launch {
            bridge.observations.collect { observation ->
                latestObservation = observation
                toolExecutor.observe(observation)
                memoryLog.append("observation", observation)
                learning.experience().recordObservation(observation)
            }
        }
    }

    suspend fun loadQwen(modelPath: String, contextSize: Int = 8192) = withContext(Dispatchers.IO) {
        engine.loadModel(modelPath, contextSize)
        engine.setSystemPrompt(
            "You are GameForge v5.1 Audited Local Model Swarm: a local-only game engineering agent. Use tools, demand evidence, preserve user work, and never claim a test passed without fresh evidence. You are one specialist inside a cooperating model team."
        )
        (context as? MainActivity)?.setStatus("Local model ready • ${engine.modelInfo().take(220)}")
    }

    suspend fun loadAdapter(path: String, scale: Float = 1f) {
        engine.loadLoraAdapter(path, scale)
        continuous.markAdapterLoaded(path, scale)
        (context as? MainActivity)?.setStatus("LoRA adapter loaded • ${File(path).name}")
    }

    suspend fun clearAdapter() { engine.clearLoraAdapter(); continuous.markAdapterCleared() }

    suspend fun runCodingMission(goal: String, maxSteps: Int = 60, onStatus: (String) -> Unit = {}) {
        check(::toolExecutor.isInitialized) { "Attach the Godot/tools bridge first" }
        val state = maxCoding.run(goal, maxSteps)
        onStatus("Mission ${state.id}: ${if (state.completed) "verified" else "stopped"}; ${state.summary.take(300)}")
        continuous.curate(); learning.periodicTraining()
    }


    suspend fun buildGame(goal: String, onStatus: (String) -> Unit = {}): String {
        val forge = gameForge ?: error("Godot/tools bridge must be attached first")
        val result = forge.build(goal)
        onStatus(result.summary)
        continuous.curate()
        learning.periodicTraining()
        return result.reportPath
    }

    suspend fun buildGameApex(goal: String, onStatus: (String) -> Unit = {}): String {
        val forge = apexForge ?: error("Godot/tools bridge must be attached first")
        val path = forge.build(goal)
        onStatus("FINAL MAX release report: ${path.substringAfterLast('/')}" )
        continuous.curate()
        learning.periodicTraining()
        return path
    }

    suspend fun optimizeGameApex(onStatus: (String) -> Unit = {}): String {
        val forge = apexForge ?: error("Godot/tools bridge must be attached first")
        val path = forge.optimize()
        onStatus("Optimization report: ${path.substringAfterLast('/')}" )
        continuous.curate()
        return path
    }

    suspend fun verifyReleaseApex(onStatus: (String) -> Unit = {}): String {
        val forge = apexForge ?: error("Godot/tools bridge must be attached first")
        val path = forge.verifyRelease()
        onStatus("Final verification: ${path.substringAfterLast('/')}" )
        return path
    }

    suspend fun benchmarkGame(onStatus: (String) -> Unit = {}): File {
        // The legacy benchmark remains available through its persisted artifacts; the button uses the final release gate.
        val result = ultimateBench.run()
        onStatus("Ultimate benchmark score=${"%.3f".format(result.score)} accepted=${result.accepted}")
        return result.report
    }

    suspend fun benchmarkLocalSwarm(onStatus: (String) -> Unit = {}): String = swarmBenchmark.run(onStatus).toString(2)

    fun swarmStatus(): String = swarmManager.statusText()

    fun swarmDiagnostics(): String = swarmLearning.exportDiagnostics().toString(2)

    fun clearManualSwarmModel() { (engine as? SwarmInferenceEngine)?.clearManualProfile() }

    fun setManualSwarmModel(id: String?) { (engine as? SwarmInferenceEngine)?.setManualProfile(id) }

    fun installedSwarmProfiles(): List<String> = swarmManager.installed().map { it.profile.id }

    suspend fun inspectGame(onStatus: (String) -> Unit = {}): File {
        check(::toolExecutor.isInitialized) { "Attach the Godot/tools bridge first" }
        val graph = toolExecutor.execute("write_project_graph", JSONObject())
        val profile = toolExecutor.execute("write_profile_report", JSONObject())
        val out = File(continuous.root(), "game_inspection_${System.currentTimeMillis()}.json")
        out.writeText(JSONObject().put("architecture", graph).put("performance", profile).toString(2))
        onStatus("Game inspection saved: ${out.name}")
        return out
    }

    suspend fun resumeLatestMission(onStatus: (String) -> Unit = {}) {
        check(::toolExecutor.isInitialized) { "Attach the Godot/tools bridge first" }
        val state = maxCoding.resumeLatest() ?: run { onStatus("No incomplete mission to resume"); return }
        onStatus("Resumed ${state.id}: ${if (state.completed) "already complete" else "stopped at step ${state.step}"}")
    }

    suspend fun benchmarkLoadedModel(onStatus: (String) -> Unit = {}): File = withContext(Dispatchers.Default) {
        val report = File(continuous.root(), "benchmarks").apply { mkdirs() }
        val out = File(report, "run_${System.currentTimeMillis()}.jsonl")
        val results = evalSuite.run(engine, out, onStatus)
        continuous.registerEvaluation(out, results.score, results.summary)
        out
    }

    fun start(bridge: AICoderGodotBridge) {
        if (!running.compareAndSet(false, true)) return
        gameplayJob?.cancel()
        gameplayJob = scope.launch {
            try {
                var iteration = 0
                while (isActive && running.get()) {
                    iteration++
                    bridge.restartTest(); delay(180)
                    latestObservation = null
                    repeat(160) {
                        if (!running.get()) return@repeat
                        bridge.requestObservation()
                        val state = awaitObservation(1200) ?: return@repeat
                        val output = generateGameplayAction(state)
                        val action = parseAction(output)
                        memoryLog.append("qwen_action", output)
                        bridge.sendAction(action.toString())
                        delay(100)
                        bridge.requestObservation()
                        val nextState = awaitObservation(900) ?: state
                        val reward = estimateGameplayReward(nextState, action)
                        val done = action.optString("type") == "stop" || nextState.contains("finish", true)
                        learning.experience().recordTransition(state.take(3000), action.toString(), reward, nextState.take(3000), done)
                        continuous.recordExperience("autonomous_gameplay", state, action.toString(), "reward=$reward nextState=${nextState.take(1200)}", reward > 0.5)
                        if (done) return@repeat
                    }
                    if (iteration % 8 == 0) { learning.periodicTraining(); continuous.curate() }
                    (context as? MainActivity)?.setStatus("Gameplay iteration $iteration • ${learning.experience().status()}")
                }
            } catch (t: Throwable) {
                memoryLog.append("error", t.toString())
                (context as? MainActivity)?.setStatus("Agent error: ${t.message}")
            } finally { running.set(false) }
        }
    }

    private suspend fun generateGameplayAction(observation: String): String {
        val out = StringBuilder()
        engine.sendUserPrompt(
            "Current gameplay observation:\n$observation\nChoose exactly one action JSON and nothing else.",
            GenerationConfig(ReasoningMode.FAST, 96, 0.7f, 0.8f, 20, 0f, 1.03f, grammar = gameplayGrammar, grammarRoot = "root")
        ).collect { out.append(it) }
        return out.toString()
    }

    private fun estimateGameplayReward(observation: String, action: JSONObject): Double = when {
        observation.contains("finish", true) || observation.contains("goal", true) -> 2.0
        observation.contains("dead", true) || observation.contains("fall", true) || observation.contains("reset", true) -> -1.0
        action.optString("type") == "stop" -> -0.05
        action.optString("type") == "jump" -> 0.05
        else -> 0.02
    }

    private suspend fun awaitObservation(timeoutMs: Long): String? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            latestObservation?.let { latestObservation = null; return it }
            delay(20)
        }
        return null
    }

    private fun parseAction(raw: String): JSONObject {
        val start = raw.indexOf('{'); val end = raw.lastIndexOf('}')
        if (start >= 0 && end > start) runCatching {
            val obj = JSONObject(raw.substring(start, end + 1))
            require(obj.optString("type", "move") in setOf("move", "jump", "restart", "stop"))
            return obj
        }
        return JSONObject().put("type", "move").put("x", 0).put("jump", false)
    }

    fun shutdown() {
        running.set(false); gameplayJob?.cancel(); engine.cleanUp(); engine.destroy(); scope.coroutineContext[Job]?.cancel()
    }
}
