package com.husain.aicoder.swarm

/**
 * The curated local-only GameForge model roster.
 *
 * We deliberately do not ship tiny 0.3B/1B helper models. Every entry is a serious
 * specialist. Quantization is a deployment format, not a separate weak model.
 */
object LocalModelCatalog {
    const val DEFAULT_GENERAL = "qwen3-4b-instruct-2507-q6"
    const val DEFAULT_REASONING = "qwen3-4b-thinking-2507-q6"
    const val DEFAULT_CODER = "deepseek-coder-6.7b-instruct-q4km"
    const val DEFAULT_VISION = "qwen2.5-vl-3b-q6"

    val profiles: List<LocalModelProfile> = listOf(
        LocalModelProfile(
            id = DEFAULT_GENERAL,
            displayName = "Qwen3-4B-Instruct-2507 Q6_K",
            family = "qwen3",
            roles = setOf(LocalModelProfile.Role.GENERAL, LocalModelProfile.Role.CRITIC, LocalModelProfile.Role.GAME_DESIGN),
            filenamePatterns = listOf(
                Regex("(?i).*qwen3.*4b.*instruct.*2507.*\\.gguf"),
                Regex("(?i).*qwen3.*4b.*instruct.*\\.gguf")
            ),
            preferredQuant = "Q6_K",
            estimatedModelGb = 3.1,
            estimatedRamGb = 4.7,
            contextTokens = 6144,
            maxOutputTokens = 4096,
            sourceUrl = "https://huggingface.co/DhruvalLabs/Qwen3-4B-Instruct-2507-GGUF",
            notes = "Primary general/director model. Uses the newest 4B Instruct-2507 family."
        ),
        LocalModelProfile(
            id = DEFAULT_REASONING,
            displayName = "Qwen3-4B-Thinking-2507 Q6_K",
            family = "qwen3-thinking",
            roles = setOf(LocalModelProfile.Role.REASONING, LocalModelProfile.Role.CRITIC, LocalModelProfile.Role.GAME_DESIGN),
            filenamePatterns = listOf(
                Regex("(?i).*qwen3.*4b.*thinking.*2507.*\\.gguf"),
                Regex("(?i).*qwen3.*4b.*thinking.*\\.gguf")
            ),
            preferredQuant = "Q6_K",
            estimatedModelGb = 3.3,
            estimatedRamGb = 4.9,
            contextTokens = 6144,
            maxOutputTokens = 4096,
            sourceUrl = "https://huggingface.co/DhruvalLabs/Qwen3-4B-Thinking-2507-GGUF",
            notes = "Dedicated thinking model; use for architecture, root-cause analysis, difficult planning and final critique."
        ),
        LocalModelProfile(
            id = DEFAULT_CODER,
            displayName = "DeepSeek-Coder-6.7B-Instruct Q4_K_M",
            family = "deepseek-coder",
            roles = setOf(LocalModelProfile.Role.CODING),
            filenamePatterns = listOf(
                Regex("(?i).*deepseek.*coder.*6.?7b.*instruct.*q4_k_m.*\\.gguf"),
                Regex("(?i).*deepseek-coder-6.7b-instruct.*q4_k_m.*\\.gguf")
            ),
            preferredQuant = "Q4_K_M",
            estimatedModelGb = 4.1,
            estimatedRamGb = 6.6,
            contextTokens = 4096,
            maxOutputTokens = 3072,
            experimentalHeavy = true,
            sourceUrl = "https://huggingface.co/TheBloke/deepseek-coder-6.7B-instruct-GGUF",
            notes = "Strong specialized coding model, but heavy for an 8 GB phone. Auto-use is gated by live RAM."
        ),
        LocalModelProfile(
            id = DEFAULT_VISION,
            displayName = "Qwen2.5-VL-3B-Instruct Q6_K",
            family = "qwen2.5-vl",
            roles = setOf(LocalModelProfile.Role.VISION),
            filenamePatterns = listOf(
                Regex("(?i).*qwen2.*5.*vl.*3b.*q6.*\\.gguf"),
                Regex("(?i).*qwen2.5-vl-3b.*q6_k.*\\.gguf")
            ),
            preferredQuant = "Q6_K",
            estimatedModelGb = 2.4,
            estimatedRamGb = 3.9,
            contextTokens = 4096,
            maxOutputTokens = 2048,
            supportsVision = true,
            sourceUrl = "https://huggingface.co/DhruvalLabs/Qwen2.5-VL-3B-Instruct-GGUF",
            notes = "Reserved for native multimodal runtime. Current v5 text engine will not silently pretend text-only inference is vision."
        )
    )

    fun byId(id: String): LocalModelProfile? = profiles.firstOrNull { it.id == id }

    fun matchFileName(name: String): LocalModelProfile? = profiles.firstOrNull { profile ->
        profile.filenamePatterns.any { it.matches(name) }
    }

    fun forRole(role: LocalModelProfile.Role): List<LocalModelProfile> =
        profiles.filter { role in it.roles }
}
