from pathlib import Path
import json, sys, xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
required = [
    ROOT/'app/src/main/java/com/husain/aicoder/swarm/LocalModelProfile.kt',
    ROOT/'app/src/main/java/com/husain/aicoder/swarm/LocalModelCatalog.kt',
    ROOT/'app/src/main/java/com/husain/aicoder/swarm/LocalModelSwarmManager.kt',
    ROOT/'app/src/main/java/com/husain/aicoder/swarm/SwarmTaskRouter.kt',
    ROOT/'app/src/main/java/com/husain/aicoder/swarm/SwarmLearningManager.kt',
    ROOT/'app/src/main/java/com/husain/aicoder/swarm/SwarmInferenceEngine.kt',
    ROOT/'app/src/main/java/com/husain/aicoder/model/ModelManager.kt',
    ROOT/'app/src/main/java/com/husain/aicoder/agent/AgentController.kt',
    ROOT/'llamaAndroid/src/main/cpp/ai_chat_jni.cpp',
]
missing=[str(p.relative_to(ROOT)) for p in required if not p.is_file()]
if missing:
    print('MISSING', missing); sys.exit(1)
ET.parse(ROOT/'app/src/main/res/layout/activity_main.xml')
manifest=json.loads((ROOT/'RELEASE_MANIFEST.json').read_text())
assert manifest['versionCode']==51
assert manifest['local_only_runtime'] is True
assert len(manifest['learning_modes'])==5
catalog=(ROOT/'app/src/main/java/com/husain/aicoder/swarm/LocalModelCatalog.kt').read_text()
for needle in ['Qwen3-4B-Instruct-2507','Qwen3-4B-Thinking-2507','DeepSeek-Coder-6.7B-Instruct','Qwen2.5-VL-3B-Instruct']:
    assert needle in catalog
router=(ROOT/'app/src/main/java/com/husain/aicoder/swarm/SwarmTaskRouter.kt').read_text()
assert 'LocalModelProfile.Role.CODING' in router and 'LocalModelProfile.Role.REASONING' in router
learning=(ROOT/'app/src/main/java/com/husain/aicoder/swarm/SwarmLearningManager.kt').read_text()
for needle in ['supervised', 'unsupervised', 'semi-supervised', 'self-supervised', 'reinforcement']:
    assert needle in learning or needle.replace('-', ' ') in learning
jni=(ROOT/'llamaAndroid/src/main/cpp/ai_chat_jni.cpp').read_text()
assert 'genericPrompt' in jni and 'qwenPrompt' not in jni
print('V5 LOCAL SWARM CHECK: PASS')
print('files=', sum(1 for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.pyc')))
