# GameForge v5 — Local Model Swarm MAX

## What changed

GameForge is no longer architected around one permanent language model. The existing agents now consume a model-agnostic inference interface backed by a local specialist router.

### Specialist roster

- **Qwen3-4B-Instruct-2507 Q6_K** — general/director/critic/game-design work.
- **Qwen3-4B-Thinking-2507 Q6_K** — architecture, difficult reasoning, root-cause analysis and quality critique.
- **DeepSeek-Coder-6.7B-Instruct Q4_K_M** — coding specialist, RAM-gated because its published GGUF footprint is substantially heavier than the Qwen 4B models.
- **Qwen2.5-VL-3B-Instruct Q6_K** — vision profile. The v5 text-only JNI backend does not pretend it can accept image tensors, so this profile remains reserved until the native multimodal projector backend is connected.

### Learning

The router accumulates verified task outcomes and uses all five requested learning modes: supervised, unsupervised, semi-supervised, self-supervised and reinforcement learning. The base model files are not mutated after each task; model-weight improvement remains a separately gated training/adapter process.

### Local-only promise

No cloud model endpoint is required by the runtime. Internet access is only relevant when the user chooses to obtain/update model files or build dependencies.
