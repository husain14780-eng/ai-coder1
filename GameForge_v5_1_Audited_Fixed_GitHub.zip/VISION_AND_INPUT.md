# Vision and input — 5.1 LOCAL-SWARM MAX AUDITED

## Vision layers

1. ScreenCaptureService obtains frames.
2. Pixel perception provides cheap numeric signals.
3. WorldModel keeps compact current state.
4. `VisionBackend` allows a local VLM later.

## Device interaction

Accessibility actions remain bounded and explicit. They are for software interaction, not code injection into a game.

## Game development usage

The primary consumer is the game being developed by GameForge: screenshots/telemetry are evidence for QA, debugging and polish.
