# GameForge V7.2 Model Import Contract

V7.2 is import-only for model weights. It never downloads model weights on first launch or through a model button.

## Slots

- Manager / Reasoning: Qwen3-4B-Thinking-2507 Q6_K GGUF
- Coding Specialist: Qwen2.5-Coder-7B-Instruct Q4_K_M GGUF
- General / Director: Qwen3-4B-Instruct-2507 Q6_K GGUF (optional)
- Vision: Qwen2.5-VL-3B-Instruct Q6_K GGUF
- Vision projector: matching `mmproj` / projector GGUF for the selected Qwen-VL build

The filename is used only for slot classification. Native llama.cpp loads the GGUF metadata/weights; a renamed file is not accepted for a role-specific import unless its filename still identifies the expected model family.

## Error handling

Native model loading now reports bounded llama.cpp/GGML diagnostics instead of only `rc=-2`. The loader checks the path, file size and GGUF magic before calling llama.cpp. If the native diagnostic specifically indicates an Android mmap failure, it retries once without mmap. Other failures are reported without masking them with a fallback.

## Asset generator

The 2D procedural asset generator is built into the APK and is not an imported/downloaded model. It remains available through `GameForge2DAssetFactory` and the existing ToolExecutor/GameProjectScaffolder pipeline.

## Important vision limitation

The V7.2 import UI stores both the Qwen-VL base GGUF and its projector GGUF separately. The existing text JNI engine does not silently pretend to perform multimodal inference. Embedded Godot pixel vision remains the immediate local visual fallback. A future native MTMD/VLM backend can consume the imported pair without changing the model registry contract.
