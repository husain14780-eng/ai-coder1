GameForge V7.2 final internal release.

# GameForge V7 final release contract

A generated game is considered **accepted** only after fresh evidence supports:

- valid GameSpec and compiled design contract
- genre blueprint coverage
- static project verification
- successful fresh Godot boots/actions, including the generated 2D bot swarm path
- no gameplay error signals in fresh observations
- performance profile captured
- 2D asset factory validation: runtime PNGs, animation wiring, generated maps and bot navigation contract
- repair/regression pass completed after the final change
- package creation succeeded
- final report written to `gameforge/FINAL_GAME_REPORT.json`

The system preserves non-accepted builds with explicit failure evidence. It does not silently label an unverified game as finished.


## Final V7.2 hardening

The Qwen coding path is single-script scoped: one `.gd` target is claimed, edited, tested and repaired until fresh runtime evidence passes before focus is released. Generic file mutators cannot switch to another file while that focus is active. Checkpoint/version restore and workspace reset are also blocked during the cycle.

Memory/runtime hardening includes bounded 4,096-state Q-learning, bounded bot-memory startup/payload handling, streamed/hash-based release/version manifests, ephemeral observation cleanup, prompt compaction, native sampler cleanup on generation-start failures, and abort-before-unload native teardown.
