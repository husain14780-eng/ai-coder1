# GameForge V7 Full Game Factory build

## Android toolchain

- Android SDK API 36
- Build Tools 36.0.0
- NDK 29.0.13113456
- CMake 3.31.6
- JDK 17
- Gradle 8.13 / Android Gradle Plugin 8.13.0

Godot is resolved as `org.godotengine:godot:4.7.2.stable`; the source archive does not ship a standalone editor executable.

## GitHub Actions

`.github/workflows/build-apk.yml` is designed around the release ZIP itself. It finds `GameForge_V72_2D_RPG_FINAL_MAX_INTERNAL.zip`, extracts it into a clean temporary source directory, locates `settings.gradle.kts`, validates the source, builds `:app:assembleDebug`, checks the generated APK, and uploads the APK plus SHA-256.

## Local model files

Model weights are intentionally not bundled. Import trusted local GGUFs through the Android app:

- Qwen2.5-Coder-7B-Instruct Q4_K_M — primary coding model
- Qwen3-4B-Thinking-2507 — reasoning model
- Qwen3-4B-Instruct-2507 — general/director model
- Qwen2.5-VL-3B-Instruct — optional vision specialist with a reserved multimodal profile

## Generated-game runtime

GameForge writes the generated Godot workspace to app-private storage, packages it as a resource pack, loads it into embedded Godot, observes fresh runtime state, and uses that evidence during repair/regression. This is different from claiming that the Android app is itself a standalone Godot editor/export pipeline.

## Signing

Debug CI does not require a keystore. Production release signing stays user-supplied through the properties/environment documented in `RELEASE_SIGNING.md`.
