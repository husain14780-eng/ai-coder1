
## V7.2 Final single-script/runtime hardening

- Qwen coding missions now enforce one active `.gd` script from claim through runtime verification; checkpoint/reset/version restore paths are blocked until the focused script finishes.
- QLearning operations are synchronized and the 4096-state bound remains enforced.
- Bot-memory startup rejects unexpectedly oversized persisted JSON instead of materializing it into RAM.
- JNI generation-start failure paths immediately release temporary sampler/token state.
- Native model cleanup now runs even from error/loading states, after generation abort, to reduce replacement/shutdown leaks and teardown races.
- Release/version manifests remain streamed/hash-based rather than materializing large file lists in memory.
## V7.2 — Single-script coding/runtime hardening

- Qwen2.5-Coder coding/debugging tasks now use a strict persisted single-`.gd` focus: inspect dependencies, claim one script, edit only that script, runtime-test it, repair it on failure, and verify it before the next script is selected.
- Mission state stores the focused script path plus baseline/current SHA-256 and last runtime evidence so a stopped mission resumes on the same script instead of guessing.
- Checkpoint/version restore and Git mutation paths are blocked while a `.gd` script is focused, preventing accidental multi-script rollbacks or shell bypasses during a coding cycle.
- Non-script project files remain editable so scene/config/metadata generation is not unnecessarily reduced; the single-file restriction applies specifically to Qwen-directed `.gd` edits.
- Final and adaptive playtest verification now count only fully successful runs; a partial run cannot increase the pass count or satisfy the completion gate.
- Coroutine cancellation is rethrown through tool/gameplay boundaries, avoiding shutdown/teardown races being converted into fake tool failures.
- The legacy CodingAgent now releases script focus in `finally` and cannot accept `DONE` without fresh test evidence.
- Optional localhost VLM HTTP requests are capped for image/response size and reject non-local endpoints.

## V7.2 — 2D RPG/MMORPG Max Factory

- AI-directed procedural sprite generation with request-driven prompts, archetypes, palettes, seeds and animation profiles.
- Native PNG frame generation plus editable SVG sources and animation manifests.
- 8-direction player animation support, enemy/NPC animation sets, VFX sequences, icons and generated tilesets.
- Procedural multi-map generation with previews, JSON data, collision and AStarGrid2D navigation.
- Auto-bot swarm testing preserved and upgraded to use map-aware goal seeking/pathfinding.
- Final acceptance now requires 2D asset validation as well as static verification, runtime regression and packaging.
- Added deterministic binary asset writes and release-time factory validation.

# Changelog

## 7.0 — 2D RPG/MMORPG Final Max Internal

- Replaced the 3D-only procedural asset path for 2D projects with an AI-directed 2D asset compiler.
- Added request-driven sprite generation with editable visual recipes, motion recipes, seeded palettes and direction/frame control.
- Added generated PNG runtime frames, animation sheets/manifests, per-animation controllers, VFX sequences, icons and tilesets.
- Added AI-authored ASCII map layouts plus seeded procedural maps, previews, collision and AStarGrid2D navigation.
- Preserved and strengthened automatic bot swarm testing; the generated bots use the same map pathfinder and can be explicitly triggered through `bot_test`.
- Added final asset validation, deterministic binary writes, custom animation alias resolution, one-shot animation detection and fallback animation handling.


## 6.0 — Legacy GameForge Full Game Factory

- Added the V7 full-game autonomous generation pipeline.
- Added GameSpec compilation before implementation.
- Added deterministic genre blueprint and level-design contracts.
- Added a robust playable Godot vertical-slice bootstrap with movement, jump, checkpoints, hazards, coins, goal, pause UI, touch controls and persistence.
- Added static generated-project verification before runtime acceptance.
- Added genre-contract coverage checks and richer final evidence.
- Added repair passes that combine static failures, playtest evidence, performance hotspots and change-impact analysis.
- Added final regression and package gating before release artifacts are declared accepted.
- Added explicit `TASK_ROLE` model routing so reasoning/design prompts cannot be mistaken for coding prompts.
- Qwen2.5-Coder-7B Q4_K_M is now the primary implementation specialist; DeepSeek-Coder is not required.
- Fixed model-roster file-name mismatch, observation polling early-stop logic, adaptive playtest loop termination, and several non-atomic persistence paths.
- Fixed a missing closing brace in `EpisodeStore` discovered by a compiler syntax pass.
- Coding roles now force deliberate agent-level THINKING mode around Qwen2.5-Coder rather than silently falling back to routine FAST generation.
- Qwen3-4B-Thinking is now the explicit game-design/reasoning specialist; Qwen3-4B-Instruct is reserved for general/director/critic work.
- Fresh V7 builds checkpoint and reset the prior generated workspace so an old game cannot accidentally survive into a new build.
- Final acceptance now requires both the regression gate and successful runtime packaging; a packaging failure cannot be reported as a successful release.
- Added a V7 GitHub workflow that extracts the exact source ZIP before building.


## V7.2 in-app-only vision/research patch

- GameForge bot/playtest screenshots now come from the embedded Godot viewport, not the phone-wide screen.
- Each viewport screenshot is ephemeral: decode/analyze, enrich the observation, then delete it.
- Device MediaProjection/accessibility have been removed; GameForge is internal-only.
- Added in-app `web_search` and `web_open` tools; they never launch an external browser.

## V7.2 — Single-flight RAM / persistence optimization
- Added a re-entrant global `HeavyTaskCoordinator` so model inference, heavyweight tools/Godot QA, and on-device learning never execute concurrently.
- Model loading now uses adaptive context and bounded batch/CPU settings; only physical RAM is considered for admission and RAM Plus is never treated as model memory.
- Reworked append-only recovery paths to use bounded streaming tail reads instead of materializing entire JSONL files.
- Bounded Q-learning state, bot-memory statistics, in-memory self-supervised samples, and lexical retrieval working sets.
- Serialized vision observation processing to protect temporal vision state and avoid overlapping bitmap work.
- Added `tools/check_memory_safety.py` to CI.

## V7.2 final Kotlin compilation fix
- Fixed Q-table compaction type inference by materializing the exported entries as a typed list before taking the bounded 4,096-state tail.
- Fixed research redirect URL typing by explicitly resolving to `URI` and converting to `String` at the URL validation boundary.
- Re-audited the affected source paths after the fixes; no additional `takeLast`/URI mismatch pattern was found in the affected code.
