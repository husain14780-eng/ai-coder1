package com.husain.aicoder.ml

import android.content.Context
import org.json.JSONObject
import java.io.File

class ModelRegistry(context: Context) {
    private val root = File(context.filesDir, "model_registry").apply { mkdirs() }
    private val registryFile = File(root, "models.jsonl")
    private val adaptersDir = File(root, "adapters").apply { mkdirs() }
    private val evalDir = File(root, "evaluations").apply { mkdirs() }

    @Synchronized fun rememberModel(file: File) {
        append(JSONObject().put("type", "base_model").put("path", file.absolutePath)
            .put("name", file.name).put("size", file.length()).put("time", System.currentTimeMillis()))
    }

    @Synchronized fun rememberAdapter(file: File, scale: Float = 1f) {
        adaptersDir.mkdirs()
        append(JSONObject().put("type", "lora_adapter").put("path", file.absolutePath)
            .put("name", file.name).put("size", file.length()).put("scale", scale).put("time", System.currentTimeMillis()))
    }

    @Synchronized fun rememberVisionProjector(file: File) {
        append(JSONObject().put("type", "vision_projector").put("path", file.absolutePath)
            .put("name", file.name).put("size", file.length()).put("time", System.currentTimeMillis()))
    }

    @Synchronized fun rememberEvaluation(file: File, score: Double, summary: String) {
        evalDir.mkdirs()
        append(JSONObject().put("type", "evaluation").put("path", file.absolutePath)
            .put("score", score).put("summary", summary).put("time", System.currentTimeMillis()))
    }

    fun adapterDirectory(): File = adaptersDir
    fun evaluationDirectory(): File = evalDir
    fun bestCandidateAdapter(): File? = adaptersDir.listFiles { f -> f.isFile && f.extension.equals("gguf", true) }
        ?.maxByOrNull { it.lastModified() }

    private fun append(obj: JSONObject) {
        registryFile.appendText(obj.toString() + "\n")
    }
}
