# GameForge 5.3 audit record

The 5.3 release adds a stronger local model admission/fallback path, profile-aware context sizing, atomic workspace mutations, stricter runtime-observation polling, and a verified coding loop.

The definitive audit is executed by `tools/audit_v5_3.py` and the Android build is executed by `.github/workflows/build-apk.yml`.
