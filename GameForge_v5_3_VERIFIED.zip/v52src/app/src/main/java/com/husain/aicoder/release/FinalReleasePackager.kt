package com.husain.aicoder.release

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Produces a reproducible ship pack with manifest + hashes, excluding transient checkpoints and caches. */
class FinalReleasePackager(private val workspace: CodingWorkspace) {
    fun packageRelease(goal: String, accepted: Boolean): File {
        val releaseDir = File(workspace.root.parentFile, "final_releases").apply { mkdirs() }
        val stamp = System.currentTimeMillis()
        val files = JSONArray()
        val candidates = workspace.root.walkTopDown().filter { it.isFile }.toList()
        candidates.filterNot { excluded(it) }.forEach { f ->
            val rel = f.relativeTo(workspace.root).path.replace(File.separatorChar, '/')
            files.put(JSONObject().put("path", rel).put("bytes", f.length()).put("sha256", sha256(f)))
        }
        val manifest = JSONObject()
            .put("release_version", "5.3-LOCAL-SWARM-MAX-AUDITED")
            .put("goal", goal)
            .put("accepted", accepted)
            .put("generated_at_ms", stamp)
            .put("file_count_excluding_manifest", files.length())
            .put("manifest_is_self_excluded_from_hash_index", true)
            .put("files", files)
        workspace.write("gameforge/FINAL_RELEASE_MANIFEST.json", manifest.toString(2))

        val zip = File(releaseDir, "GameForge_FINAL_MAX_$stamp.zip")
        ZipOutputStream(zip.outputStream().buffered()).use { out ->
            val include = workspace.root.walkTopDown().filter { it.isFile && !excluded(it) }.toList()
            include.forEach { f ->
                val rel = f.relativeTo(workspace.root).path.replace(File.separatorChar, '/')
                out.putNextEntry(ZipEntry(rel))
                f.inputStream().use { it.copyTo(out, 1024 * 1024) }
                out.closeEntry()
            }
        }
        return zip
    }

    private fun excluded(file: File): Boolean {
        val rel = file.relativeTo(workspace.root).path.replace(File.separatorChar, '/')
        return rel.startsWith(".git/") || rel.startsWith("gameforge/runtime/cache/") ||
            rel.startsWith("checkpoints/") || rel.endsWith(".part") ||
            rel.contains("/tmp/") || rel.contains("/cache/")
    }

    private fun sha256(file: File): String = MessageDigest.getInstance("SHA-256").let { md ->
        file.inputStream().use { input ->
            val buf = ByteArray(1024 * 1024)
            while (true) { val n = input.read(buf); if (n <= 0) break; md.update(buf, 0, n) }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }
}
