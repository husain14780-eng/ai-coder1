package com.husain.aicoder.agent

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.arm.aichat.ReasoningMode
import com.husain.aicoder.godot.AICoderGodotBridge
import com.husain.aicoder.ml.ContinuousLearningManager
import kotlinx.coroutines.flow.collect
import org.json.JSONObject

/**
 * Long-horizon coding agent. The base model stays immutable; experience is persisted separately.
 */
class CodingAgent(
    private val engine: InferenceEngine,
    private val workspace: CodingWorkspace,
    private val learning: ContinuousLearningManager
) {
    private var tools: ToolExecutor? = null

    fun attachTools(bridge: AICoderGodotBridge?) {
        tools = ToolExecutor(workspace, bridge)
    }

    fun observe(json: String) {
        tools?.observe(json)
    }

    suspend fun configure() {
        engine.setSystemPrompt(
            """
            You are GameForge 5.3 VERIFIED LOCAL-SWARM MAX / GameForge Apex, a rigorous local game-engineering agent running on the selected local specialist (Qwen2.5-Coder-7B for coding, Qwen3-4B-Thinking for deep reasoning).
            Goal: produce working software, not plausible text.

            Rules:
            1. Inspect relevant files before editing.
            2. Prefer small, reversible edits. Never overwrite unrelated work.
            3. Use tools to inspect, edit and test. Do not invent tool results.
            4. After an edit, run the narrowest useful test; after a successful narrow test, run a broader test when practical.
            5. Treat compiler/runtime/test failures as evidence. Diagnose from the actual error before changing code.
            6. For tool use emit exactly one call in this format and nothing else in that turn:
               <tool_call>{"name":"read_file","arguments":{"path":"..."}}</tool_call>
            7. Available tools: read_file, write_file, replace_text, append_file, list_files, search_text,
               get_last_observation, run_godot_test.
            8. When the mission is genuinely complete, emit: DONE: <concise verified summary>.
            9. Never say a test passed unless the tool returned evidence of success.
            10. Never expose hidden chain-of-thought. Summarize decisions and evidence instead.
            """.trimIndent()
        )
    }

    suspend fun run(goal: String, maxSteps: Int = 30, onStatus: (String) -> Unit = {}) {
        val executor = tools ?: error("Tools not attached")
        var transcript = "Goal: $goal\n"
        var failures = 0
        var toolCalls = 0
        var successfulTests = 0

        for (step in 1..maxSteps) {
            // Coding is deliberately run in THINKING mode. For Qwen2.5-Coder this is
            // an agent-level deliberate-planning mode, not a claim that the base model
            // has Qwen3-style native thinking tokens.
            val thinking = true
            val mode = if (thinking) ReasoningMode.THINKING else ReasoningMode.FAST
            val maxTokens = if (thinking) 1800 else 900
            val prompt = buildPrompt(transcript, step, maxSteps, failures, toolCalls, successfulTests)
            val output = generate(prompt, mode, maxTokens)
            learning.recordAgentTurn(goal, mode.name, output)
            onStatus("step=$step/$maxSteps mode=${mode.name} tools=$toolCalls failures=$failures ${output.take(180)}")

            val call = parseToolCall(output)
            if (call == null) {
                if (output.contains("DONE", ignoreCase = true)) {
                    learning.recordOutcome(goal, true, output)
                    return
                }
                failures++
                transcript += "\nAssistant: ${output.take(4000)}\n"
                continue
            }

            toolCalls++
            val result = executor.execute(call.first, call.second)
            val ok = result.optBoolean("ok", false)
            if (!ok) failures++ else if (failures > 0) failures--
            if (ok && call.first == "run_godot_test") successfulTests++

            transcript += "\nTool ${call.first} args=${call.second}\nResult=${result.toString().take(14000)}\n"
            if (toolCalls >= 2 && successfulTests == 0 && step >= 4) {
                transcript += "\nVerifier reminder: no successful test evidence yet. Do not declare DONE.\n"
            }
        }

        learning.recordOutcome(goal, false, "max steps reached; toolCalls=$toolCalls successfulTests=$successfulTests")
    }

    private fun buildPrompt(
        transcript: String,
        step: Int,
        maxSteps: Int,
        failures: Int,
        toolCalls: Int,
        successfulTests: Int
    ): String = buildString {
        append(transcript)
        append("\nStep ").append(step).append('/').append(maxSteps)
        append(" | failures=").append(failures)
        append(" | tool_calls=").append(toolCalls)
        append(" | verified_tests=").append(successfulTests)
        append("\nChoose exactly one next action. Inspect before editing. ")
        append("If a tool is required, emit exactly one <tool_call> JSON block. ")
        append("Otherwise emit DONE only when the available evidence supports completion.")
    }

    private suspend fun generate(prompt: String, mode: ReasoningMode, maxTokens: Int): String {
        val out = StringBuilder()
        engine.sendUserPrompt(
            prompt,
            GenerationConfig(
                mode = mode,
                maxTokens = maxTokens,
                temperature = if (mode == ReasoningMode.THINKING) 0.6f else 0.7f,
                topP = if (mode == ReasoningMode.THINKING) 0.95f else 0.8f,
                topK = 20,
                minP = 0f,
                repeatPenalty = 1.05f
            )
        ).collect { out.append(it) }
        return stripReasoning(out.toString())
    }

    private fun stripReasoning(text: String): String {
        val closed = text.lastIndexOf("</think>")
        return if (closed >= 0) text.substring(closed + "</think>".length).trim() else text.trim()
    }

    private fun parseToolCall(text: String): Pair<String, JSONObject>? {
        val s = text.indexOf("<tool_call>")
        val e = text.indexOf("</tool_call>", s + 11)
        if (s < 0 || e <= s) return null
        val body = text.substring(s + 11, e).trim()
        val obj = runCatching { JSONObject(body) }.getOrNull() ?: return null
        val name = obj.optString("name").trim()
        if (name.isBlank()) return null
        val args = obj.optJSONObject("arguments") ?: JSONObject()
        return name to args
    }
}
