# Changelog

## 5.3 — Verified Local Model Swarm
- Strengthened the Qwen3-Thinking → Qwen2.5-Coder planning/implementation workflow.
- Made task routing resilient when the optional Qwen3 Instruct general model is not installed.
- Added phone-aware model context sizing and a Q4-coder soft admission rule for mmap-backed GGUFs on <=10 GB devices.
- Made native model-load failures recoverable so the swarm can try another installed specialist.
- Fixed non-atomic workspace replacement/append paths.
- Fixed Godot observation polling that kept sleeping after fresh evidence had already arrived.
- Fixed adaptive playtest action loops that did not actually break early.
- Removed an unsafe nullable assertion in artifact provenance generation.
- Fixed the native no-chat-template fallback so deliberate THINKING mode is preserved there too.
- Updated release metadata and GitHub Actions to version 5.3.

## 5.2
- Replaced the required coding specialist with Qwen2.5-Coder-7B-Instruct Q4_K_M.
- Added deliberate agent-level THINKING mode for the coder.
- Added native generic chat-template handling and concurrency protections.
