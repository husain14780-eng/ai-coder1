# GameForge 5.3 Architecture — verified

```text
User Goal
   ↓
Game Director / Mission Manager
   ↓
GameSpec + dependency graph + evidence ledger
   ↓
MODEL-SWARM ROUTER
   ├─ Qwen3-4B-Instruct-2507 → general/director/critic/design
   ├─ Qwen3-4B-Thinking-2507  → architecture/root-cause/reasoning
   ├─ Qwen2.5-Coder-7B Q4_K_M → coding (deliberate THINKING mode)
   └─ Qwen2.5-VL-3B → future/native multimodal backend
   ↓
Tool Engine
   ↓
Embedded Godot Android runtime + filesystem/project tools
   ↓
Resource-pack game load → build/runtime errors → observation/telemetry
   ↓
Playtest → visual/performance checks → failure analysis
   ↓
Repair → regression → quality gate → provenance/release
   ↓
Experience memory → five learning modes + routing policy improvement
   ↺
```

Only one text model is intended to be resident at a time. The model wrapper unloads the current GGUF before switching specialists and applies a live RAM guard before heavy profiles.

## Godot reality

Godot is not copied as an editor executable into the ZIP. The Android application embeds the Godot runtime through its Maven dependency and loads generated projects as resource packs. This is the mechanism that lets GameForge create and run complete Godot project contents without shipping a second standalone editor process. A final Android build still requires the Android SDK/NDK and will resolve the Godot AAR during Gradle build.
