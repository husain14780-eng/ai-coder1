# GameForge v5.3 — Verified Local Model Swarm

## Model behavior

The recommended pair is **Qwen2.5-Coder-7B-Instruct Q4_K_M** for implementation and **Qwen3-4B-Thinking-2507** for planning/reasoning. DeepSeek-Coder is not required.

The coder's THINKING mode is explicitly an agent/runtime planning instruction. It does not claim that Qwen2.5-Coder has Qwen3's native thinking head.

## Engineering upgrades

### Swarm reliability
- Task routing no longer requires a general model to be installed.
- Model switching uses a profile-aware context budget.
- Recoverable native model-load failures no longer leave the inference singleton stuck in `Error`.
- Automatic fallback can try another installed text specialist when a selected model cannot load.

### Coding reliability
- The long-horizon GameForge planner already performs a separate architecture/planning pass; 5.3 strengthens the downstream implementation path and verification evidence handling.
- Workspace mutations are serialized and atomically finalized.
- Runtime observation polling exits immediately after fresh data arrives.
- Adaptive playtesting stops its action loop immediately when the goal is reached or the run is stopped.

### Release/build reliability
- Release version is `5.3-VERIFIED-LOCAL-SWARM` / Android versionCode `53`.
- The GitHub workflow extracts the newest `GameForge_v*.zip`, locates `settings.gradle.kts` deterministically, runs the 5.3 audits, builds the debug APK, and records its SHA-256.
