# 5.3 VERIFIED LOCAL-SWARM MAX — Release contract

## Ship gate

A game is accepted only when fresh evidence supports the relevant task and no hard blocker remains.

### Hard blockers
- implementation not verified
- regression below the release threshold
- playtest below the release threshold
- gameplay error signals
- high-severity visual defects
- invalid GameSpec
- design contract inconsistency
- insufficient fresh evidence
- no usable local text specialist for the selected task

### Recommended local models
- Qwen2.5-Coder-7B-Instruct Q4_K_M — primary coding model
- Qwen3-4B-Thinking-2507 — primary deep planner/reasoner
- Qwen3-4B-Instruct-2507 — optional general/director specialist
- Qwen2.5-VL-3B-Instruct — optional reserved vision specialist

DeepSeek-Coder is not required.

### Release artifacts
- `GAME_SPEC.json`
- `GAME_DESIGN.md`
- `ASSET_MANIFEST.json`
- `gameforge/GAMEPLAY_SCENARIOS.json`
- `gameforge/DESIGN_CONSISTENCY.json`
- `gameforge/PROJECT_INDEX.json`
- `gameforge/ARCHITECTURE_GRAPH.json`
- `gameforge/REGRESSION_MATRIX.json`
- `gameforge/GAME_BENCHMARK_V3.json`
- `gameforge/VISUAL_DEFECTS.json`
- `gameforge/PERFORMANCE_AUTOTUNE.json`
- `gameforge/FINAL_MAX_REPORT.json`
- `gameforge/FINAL_RELEASE_MANIFEST.json`

Accepted and non-accepted builds are preserved with explicit evidence; the system does not silently call an unverified build “finished”.
