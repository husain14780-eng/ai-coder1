# AI Coder 5.3 — GameForge Verified Local Model Swarm

GameForge 5.3 keeps the local-only GameForge architecture and tightens the engineering loop around the two models that matter most on the target phone:

- **Qwen3-4B-Thinking-2507** — planning, architecture, difficult debugging and critique when installed.
- **Qwen2.5-Coder-7B-Instruct Q4_K_M** — primary coding specialist, run with deliberate agent-level THINKING mode.
- **Qwen3-4B-Instruct-2507** — optional general/director/critic specialist.
- **Qwen2.5-VL-3B-Instruct** — optional/reserved vision profile; the text JNI bridge does not pretend to accept multimodal tensors.

### What is better in 5.3

- Two-stage reasoning is reinforced: mission planning is routed toward the reasoning specialist, then implementation is routed toward the coding specialist.
- The router now falls back across reasoning/coding/general roles, so the app remains usable when only the recommended Qwen2.5-Coder + Qwen3-Thinking pair is installed.
- Qwen2.5-Coder gets a phone-aware context cap instead of blindly requesting a larger context.
- The Q4 coder has a soft Android RAM admission rule appropriate for mmap-backed GGUFs; the native loader remains the final safety check.
- A failed model load returns the native engine to a recoverable state instead of permanently poisoning the singleton, allowing another installed specialist to be attempted.
- Workspace writes, replacements, appends and telemetry snapshots use atomic file replacement rather than direct in-place writes.
- Godot observation waits stop as soon as fresh evidence arrives instead of continuing the full polling loop.
- Playtesting stops cleanly when a run finishes and aborts immediately when the generated game cannot boot.
- Release checks are versioned for 5.3 and the GitHub build extracts the release ZIP using a deterministic project-root lookup.

The runtime remains local-only at inference time. Model weights are not bundled into the source archive; import trusted GGUFs locally.
