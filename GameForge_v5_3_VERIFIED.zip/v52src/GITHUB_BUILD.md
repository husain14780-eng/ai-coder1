# Build GameForge 5.3 on GitHub

The repository includes `.github/workflows/build-apk.yml` so you do not need to write the GitHub Actions workflow yourself.

## What it does

1. Installs JDK 17.
2. Installs Android API 36, Build Tools 36.0.0, NDK 29.0.13113456 and CMake 3.31.6.
3. Installs Gradle 8.13, matching AGP 8.13.0.
4. Runs the release/source checks and the v5.3 audit.
5. Builds `app-debug.apk`.
6. Uploads the APK and its SHA-256 as a workflow artifact.

The first native build also downloads the pinned llama.cpp source commit from CMake because llama.cpp is intentionally not vendored into this ZIP.

## GitHub steps

Upload this project to the `main` branch of your repository. Then open **Actions → Build GameForge APK → Run workflow**. When it finishes, download the `gameforge-v5.3-verified-debug-apk` artifact.

## Release signing

The debug workflow does not require a keystore. For a production release, use the signing variables documented in `RELEASE_SIGNING.md`; never commit the private keystore or passwords.
