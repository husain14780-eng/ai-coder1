package com.husain.aicoder.model

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.BufferedInputStream
import java.net.HttpURLConnection
import java.net.URL
import com.husain.aicoder.ml.ModelRegistry
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import com.husain.aicoder.swarm.LocalModelCatalog
import com.husain.aicoder.swarm.LocalModelProfile

class ModelManager(private val context: Context) {

    private val modelDir = File(context.filesDir, "models").apply { mkdirs() }
    private val adapterDir = File(context.filesDir, "model_registry/adapters").apply { mkdirs() }
    private val registry = ModelRegistry(context)

    companion object {
        const val QWEN4_Q4_NAME = "Qwen3-4B-Q4_K_M.gguf"
        const val AUTO_CODER_NAME = "qwen2.5-coder-7b-instruct-q4_k_m.gguf"
        const val AUTO_CODER_URL = "https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct-GGUF/resolve/main/qwen2.5-coder-7b-instruct-q4_k_m.gguf?download=true"
        const val AUTO_CODER_SHA256 = "509287f78cb4d4cf6b3843734733b914b2c158e43e22a7f4bf5e963800894d3c"
        const val AUTO_CODER_MIN_FREE_BYTES = 5_500_000_000L
    private val autoDownloadMutex = Mutex()
    }

    suspend fun ensureDefaultCoderDownloaded(onProgress: (String) -> Unit = {}): String = autoDownloadMutex.withLock {
        withContext(Dispatchers.IO) {
        val outputFile = File(modelDir, AUTO_CODER_NAME)
        if (outputFile.isFile && outputFile.length() > 100L * 1024L * 1024L) {
            val existingHash = runCatching { sha256(outputFile) }.getOrNull()
            if (existingHash.equals(AUTO_CODER_SHA256, ignoreCase = true)) {
                registry.rememberModel(outputFile)
                onProgress("Qwen2.5-Coder 7B Q4_K_M already installed")
                return@withContext outputFile.absolutePath
            }
            outputFile.delete()
        }

        require(isNetworkAvailable()) { "Internet connection is required for the first model download" }
        val stat = StatFs(modelDir.absolutePath)
        require(stat.availableBytes >= AUTO_CODER_MIN_FREE_BYTES) {
            "Not enough free storage for Qwen2.5-Coder 7B Q4_K_M; need at least 5.5 GB free"
        }

        val partFile = File(modelDir, "$AUTO_CODER_NAME.part")
        var downloaded = if (partFile.isFile) partFile.length() else 0L
        var connection: HttpURLConnection? = null
        try {
            connection = openWithRedirects(AUTO_CODER_URL, downloaded)
            val code = connection.responseCode
            if (downloaded > 0L && code == HttpURLConnection.HTTP_OK) {
                // Server ignored Range; restart safely rather than corrupting the partial file.
                partFile.delete()
                downloaded = 0L
                connection.disconnect()
                connection = openWithRedirects(AUTO_CODER_URL, 0L)
            }
            require(connection.responseCode == HttpURLConnection.HTTP_OK || connection.responseCode == HttpURLConnection.HTTP_PARTIAL) {
                "Model download failed: HTTP ${connection.responseCode}"
            }

            val contentLength = connection.getHeaderFieldLong("Content-Length", -1L)
            val total = if (connection.responseCode == HttpURLConnection.HTTP_PARTIAL && downloaded > 0L) {
                val range = connection.getHeaderField("Content-Range")
                range?.substringAfterLast('/')?.toLongOrNull()?.takeIf { it > 0L } ?: (downloaded + contentLength)
            } else contentLength

            if (connection.responseCode == HttpURLConnection.HTTP_OK) downloaded = 0L
            FileOutputStream(partFile, connection.responseCode == HttpURLConnection.HTTP_PARTIAL && downloaded > 0L).use { output ->
                BufferedInputStream(connection.inputStream, 4 * 1024 * 1024).use { input ->
                    val buffer = ByteArray(4 * 1024 * 1024)
                    var lastPercent = -1
                    var lastUpdate = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        if (n == 0) continue
                        output.write(buffer, 0, n)
                        downloaded += n
                        val now = System.currentTimeMillis()
                        val percent = if (total > 0L) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else -1
                        if (percent != lastPercent && (now - lastUpdate >= 750L || percent == 100)) {
                            lastPercent = percent
                            lastUpdate = now
                            onProgress(if (percent >= 0) "Downloading Qwen2.5-Coder 7B Q4_K_M… $percent%" else "Downloading Qwen2.5-Coder 7B Q4_K_M… ${"%.2f".format(downloaded / 1_000_000_000.0)} GB")
                        }
                    }
                    output.fd.sync()
                }
            }

            require(partFile.isFile && partFile.length() > 100L * 1024L * 1024L) { "Downloaded model is incomplete" }
            val actualHash = sha256(partFile)
            require(actualHash.equals(AUTO_CODER_SHA256, ignoreCase = true)) {
                "Downloaded model checksum mismatch"
            }
            if (outputFile.exists()) outputFile.delete()
            require(partFile.renameTo(outputFile)) { "Cannot finalize downloaded model" }
            registry.rememberModel(outputFile)
            onProgress("Qwen2.5-Coder 7B Q4_K_M download complete")
            outputFile.absolutePath
        } finally {
            connection?.disconnect()
        }
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun openWithRedirects(url: String, rangeStart: Long): HttpURLConnection {
        var current = url
        repeat(6) {
            val c = (URL(current).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 20_000
                readTimeout = 60_000
                useCaches = false
                setRequestProperty("User-Agent", "GameForge-V71")
                if (rangeStart > 0L) setRequestProperty("Range", "bytes=$rangeStart-")
            }
            when (c.responseCode) {
                HttpURLConnection.HTTP_MOVED_PERM, HttpURLConnection.HTTP_MOVED_TEMP, 307, 308 -> {
                    val location = c.getHeaderField("Location") ?: error("Model server returned a redirect without Location")
                    c.disconnect()
                    current = URL(URL(current), location).toString()
                }
                else -> return c
            }
        }
        error("Too many redirects while downloading the model")
    }

    suspend fun importVisionProjector(uri: Uri): String = withContext(Dispatchers.IO) {
        val visionDir = File(context.filesDir, "model_registry/vision").apply { mkdirs() }
        val safeName = sanitizeName(queryDisplayName(uri), "mmproj-model.gguf").let {
            if (it.endsWith(".gguf", true)) it else "$it.gguf"
        }
        require(safeName.contains("mmproj", true) || safeName.contains("projector", true)) {
            "This file does not look like a VL projector. Choose the mmproj/projector GGUF."
        }
        val outputFile = File(visionDir, safeName)
        val tempFile = File(visionDir, "$safeName.part")
        runCatching { tempFile.delete() }
        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Cannot open selected file" }
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output, 4 * 1024 * 1024)
                    output.fd.sync()
                }
            }
            require(tempFile.isFile && tempFile.length() > 1024L) { "VL projector file is empty or incomplete" }
            require(hasGgufHeader(tempFile)) { "VL projector does not start with a valid GGUF header" }
            if (outputFile.exists()) require(outputFile.delete()) { "Cannot replace existing projector" }
            require(tempFile.renameTo(outputFile)) { "Cannot finalize imported projector" }
            outputFile.absolutePath
        } finally {
            if (tempFile.exists()) tempFile.delete()
        }
    }

    suspend fun importModel(uri: Uri): String {
        val safeName = sanitizeName(queryDisplayName(uri), QWEN4_Q4_NAME).let {
            if (it.endsWith(".gguf", true)) it else "$it.gguf"
        }
        val outputFile = File(modelDir, safeName)
        val tempFile = File(modelDir, "$safeName.part")
        runCatching { tempFile.delete() }
        try {
            copyUri(uri, tempFile)
            verifyKnownOrBasic(tempFile)
            if (outputFile.exists()) require(outputFile.delete()) { "Cannot replace existing model" }
            require(tempFile.renameTo(outputFile)) { "Cannot finalize imported model" }
            registry.rememberModel(outputFile)
            return outputFile.absolutePath
        } finally {
            if (tempFile.exists()) tempFile.delete()
        }
    }

    fun profileFor(file: File): LocalModelProfile? = LocalModelCatalog.matchFileName(file.name)

    fun installedModelNames(): List<String> = modelDir.listFiles()?.filter { it.isFile && it.extension.equals("gguf", true) }?.map { it.name }?.sorted() ?: emptyList()

    fun estimateFreeStorageGb(): Double {
        val stat = StatFs(modelDir.absolutePath)
        return stat.availableBytes.toDouble() / 1_000_000_000.0
    }

    suspend fun importAdapter(uri: Uri): String {
        val safeName = sanitizeName(queryDisplayName(uri), "coder_adapter.gguf")
            .let { if (it.endsWith(".gguf", true)) it else "$it.gguf" }
        val outputFile = File(adapterDir, safeName)
        val tempFile = File(adapterDir, "$safeName.part")
        runCatching { tempFile.delete() }
        try {
            copyUri(uri, tempFile)
            require(tempFile.length() > 1024L) { "Adapter file is too small" }
            require(hasGgufHeader(tempFile)) { "Adapter file does not start with a GGUF header" }
            if (outputFile.exists()) require(outputFile.delete()) { "Cannot replace existing adapter" }
            require(tempFile.renameTo(outputFile)) { "Cannot finalize imported adapter" }
            registry.rememberAdapter(outputFile)
            return outputFile.absolutePath
        } finally {
            if (tempFile.exists()) tempFile.delete()
        }
    }

    private fun copyUri(uri: Uri, outputFile: File) {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open selected file" }
            FileOutputStream(outputFile).use { output ->
                input.copyTo(output, 4 * 1024 * 1024)
                output.fd.sync()
            }
        }
    }

    private fun sanitizeName(input: String, fallback: String): String {
        val base = input.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (base.isBlank()) fallback else base
    }

    private fun queryDisplayName(uri: Uri): String {
        context.contentResolver.query(
            uri,
            arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) ?: "model.gguf" }
        return uri.lastPathSegment ?: "model.gguf"
    }

    fun verifyKnownOrBasic(file: File) {
        require(file.isFile && file.length() > 100L * 1024L * 1024L) { "Not a plausible GGUF model file" }
        require(hasGgufHeader(file)) { "File does not start with a valid GGUF header" }
        // v2 does not ship or hard-code an unverified model checksum.
        // Consumers may optionally verify a trusted SHA-256 before import.
    }

    private fun hasGgufHeader(file: File): Boolean = file.inputStream().use { input ->
        val h = ByteArray(4)
        if (input.read(h) != 4) return@use false
        h.contentEquals(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte()))
    }

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(4 * 1024 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                digest.update(buf, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun chooseDefaultContext(): Int {
        val info = ActivityManager.MemoryInfo()
        context.getSystemService(ActivityManager::class.java).getMemoryInfo(info)
        val freeGb = info.availMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
        return when {
            freeGb >= 5.0 -> 12288
            freeGb >= 3.5 -> 8192
            freeGb >= 2.0 -> 6144
            else -> 4096
        }
    }

    fun detectProfile(file: File): String = profileFor(file)?.id ?: "unknown-gguf"

    fun modelsDirectory(): File = modelDir
    fun adaptersDirectory(): File = adapterDir
}
