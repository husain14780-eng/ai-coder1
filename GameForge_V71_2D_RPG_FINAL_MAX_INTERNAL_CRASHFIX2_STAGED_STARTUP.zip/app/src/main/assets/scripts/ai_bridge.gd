extends Node

var plugin = null
var world = null

func _ready():
    _cleanup_observation_files()
    world = get_parent()

    plugin = Engine.get_singleton("AICoderGodotBridge")

    if plugin:
        plugin.ai_action.connect(_on_ai_action)
        plugin.request_observation.connect(_on_request_observation)
        plugin.restart_test.connect(_on_restart_test)
        plugin.load_workspace_pack.connect(_on_load_workspace_pack)
        # Never force a GPU->CPU framebuffer readback during native renderer startup.
        # The first boot observation is metadata-only; screenshots are captured only when
        # the Android side explicitly requests a vision/playtest observation. This avoids a
        # known-sensitive path on some mobile GPU drivers while preserving internal vision.
        call_deferred("_send_boot_observation")

func _send_boot_observation():
    _send_observation(false)

func _on_ai_action(action_json: String):
    var parsed = JSON.parse_string(action_json)

    if typeof(parsed) == TYPE_DICTIONARY and world.has_method("apply_action"):
        world.apply_action(parsed)
    elif typeof(parsed) == TYPE_DICTIONARY:
        _post_error("world has no apply_action method")
        return

    # The Android tool executor explicitly requests the post-action observation.
    # Avoid an immediate second screenshot; duplicate captures waste memory and disk I/O.

func _on_request_observation():
    _send_observation(true)

func _on_restart_test():
    if world.has_method("reset_test"):
        world.reset_test()
    # The Android tool executor explicitly requests the fresh post-reset observation.

func _on_load_workspace_pack(pack_path: String, main_scene: String):
    var loaded := ProjectSettings.load_resource_pack(pack_path, true)
    if not loaded:
        plugin.postObservation(JSON.stringify({"errors": ["failed to load workspace pack", pack_path]}))
        return
    var target := "res://" + main_scene.trim_prefix("res://")
    var scene_err := get_tree().change_scene_to_file(target)
    if scene_err != OK:
        _post_error("failed to change to generated scene: %s" % scene_err)

func _send_observation(include_screenshot: bool):
    if plugin == null:
        return

    var data: Dictionary
    if world.has_method("get_gameforge_observation"):
        data = world.get_gameforge_observation()
    elif world.has_method("get_observation"):
        data = world.get_observation()
    else:
        data = {"errors": ["world has no observation method"]}
    if include_screenshot:
        data["screenshot_path"] = _capture_screenshot()
        data["screenshot_ephemeral"] = true
    else:
        data["screenshot_path"] = ""
        data["screenshot_ephemeral"] = false

    data["observation_version"] = Time.get_ticks_msec()
    plugin.postObservation(JSON.stringify(data))

func _post_error(message: String):
    if plugin:
        plugin.postObservation(JSON.stringify({"errors": [message], "observation_version": Time.get_ticks_msec()}))

func _cleanup_observation_files() -> void:
    var dir_path = OS.get_user_data_dir().path_join("observations")
    if not DirAccess.dir_exists_absolute(dir_path):
        return
    var dir = DirAccess.open(dir_path)
    if dir == null:
        return
    for file_name in dir.get_files():
        if file_name.ends_with(".jpg") or file_name.ends_with(".png"):
            dir.remove(file_name)

func _capture_screenshot() -> String:
    var image = get_viewport().get_texture().get_image()
    var dir_path = OS.get_user_data_dir().path_join("observations")
    DirAccess.make_dir_recursive_absolute(dir_path)

    var file_path = dir_path.path_join(
        "ephemeral_%d.jpg" % Time.get_ticks_usec()
    )

    var err = image.save_jpg(file_path, 72)
    if err != OK:
        return ""
    return file_path
