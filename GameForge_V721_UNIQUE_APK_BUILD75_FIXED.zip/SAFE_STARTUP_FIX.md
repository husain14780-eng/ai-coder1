# V7.2.1 Safe Startup Fix

This release keeps the V7.1 runtime/native code path and import-only model provisioning, but changes one high-risk startup behavior:

- `getHostPlugins()` no longer constructs `AgentController` while Godot is registering native plugins.
- `AgentController` is created lazily only after a real user action/import.
- No model is loaded or downloaded during Activity/Godot startup.
- The GitHub workflow refuses stale V7.2 archives and requires `VERSION.txt` to be exactly `7.2.1-2D-RPG-FINAL-MAX-INTERNAL-SAFE-STARTUP`.
