package com.husain.aicoder.model

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.StatFs
import com.husain.aicoder.ml.ModelRegistry
import com.husain.aicoder.swarm.LocalModelCatalog
import com.husain.aicoder.swarm.LocalModelProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * V7.2 import-only model manager.
 *
 * No model weights are downloaded by the APK. Users import the Manager/Reasoning,
 * Coding Specialist, General/Director and VL GGUFs. The procedural asset generator
 * remains built into the app and does not require a model download.
 */
class ModelManager(private val context: Context) {
    private val modelDir = File(context.filesDir, "models").apply { mkdirs() }
    private val adapterDir = File(context.filesDir, "model_registry/adapters").apply { mkdirs() }
    private val visionDir = File(context.filesDir, "model_registry/vision").apply { mkdirs() }
    private val registry = ModelRegistry(context)

    suspend fun importModel(uri: Uri): String = importModel(uri, null)

    suspend fun importModel(uri: Uri, expectedProfileId: String?): String = withContext(Dispatchers.IO) {
        val displayName = queryDisplayName(uri)
        val safeName = sanitizeName(displayName, "model.gguf").let {
            if (it.endsWith(".gguf", true)) it else "$it.gguf"
        }
        val outputFile = File(modelDir, safeName)
        val tempFile = File(modelDir, "$safeName.part")
        tempFile.delete()
        try {
            copyUri(uri, tempFile)
            verifyKnownOrBasic(tempFile)
            val profile = LocalModelCatalog.matchFileName(safeName)
            if (expectedProfileId != null) {
                val expected = LocalModelCatalog.byId(expectedProfileId)
                    ?: error("Unknown model slot: $expectedProfileId")
                require(profile?.id == expected.id) {
                    "Wrong model for ${expected.displayName}. Selected file: $displayName"
                }
            }
            if (outputFile.exists()) require(outputFile.delete()) { "Cannot replace existing model" }
            require(tempFile.renameTo(outputFile)) { "Cannot finalize imported model" }
            registry.rememberModel(outputFile)
            outputFile.absolutePath
        } finally {
            if (tempFile.exists()) tempFile.delete()
        }
    }

    suspend fun importVisionProjector(uri: Uri): String = withContext(Dispatchers.IO) {
        val displayName = queryDisplayName(uri)
        val safeName = sanitizeName(displayName, "mmproj-model.gguf").let {
            if (it.endsWith(".gguf", true)) it else "$it.gguf"
        }
        val outputFile = File(visionDir, safeName)
        val tempFile = File(visionDir, "$safeName.part")
        tempFile.delete()
        try {
            copyUri(uri, tempFile)
            verifyKnownOrBasic(tempFile)
            require(safeName.contains("mmproj", true) || safeName.contains("projector", true)) {
                "This file does not look like a VL projector. Choose the mmproj/projector GGUF."
            }
            if (outputFile.exists()) require(outputFile.delete()) { "Cannot replace existing projector" }
            require(tempFile.renameTo(outputFile)) { "Cannot finalize imported projector" }
            outputFile.absolutePath
        } finally {
            if (tempFile.exists()) tempFile.delete()
        }
    }

    fun profileFor(file: File): LocalModelProfile? = LocalModelCatalog.matchFileName(file.name)

    fun installedModelNames(): List<String> = modelDir.listFiles()
        ?.filter { it.isFile && it.extension.equals("gguf", true) }
        ?.map { it.name }
        ?.sorted()
        ?: emptyList()

    fun installedModels(): List<File> = modelDir.listFiles()
        ?.filter { it.isFile && it.extension.equals("gguf", true) }
        ?.sortedBy { it.name.lowercase() }
        ?: emptyList()

    fun installedVisionProjectors(): List<File> = visionDir.listFiles()
        ?.filter { it.isFile && it.extension.equals("gguf", true) }
        ?.sortedBy { it.name.lowercase() }
        ?: emptyList()

    fun estimateFreeStorageGb(): Double {
        val stat = StatFs(modelDir.absolutePath)
        return stat.availableBytes.toDouble() / 1_000_000_000.0
    }

    suspend fun importAdapter(uri: Uri): String = withContext(Dispatchers.IO) {
        val safeName = sanitizeName(queryDisplayName(uri), "coder_adapter.gguf")
            .let { if (it.endsWith(".gguf", true)) it else "$it.gguf" }
        val outputFile = File(adapterDir, safeName)
        val tempFile = File(adapterDir, "$safeName.part")
        tempFile.delete()
        try {
            copyUri(uri, tempFile)
            require(tempFile.length() > 1024L) { "Adapter file is too small" }
            require(hasGgufHeader(tempFile)) { "Adapter file does not start with a GGUF header" }
            if (outputFile.exists()) require(outputFile.delete()) { "Cannot replace existing adapter" }
            require(tempFile.renameTo(outputFile)) { "Cannot finalize imported adapter" }
            registry.rememberAdapter(outputFile)
            outputFile.absolutePath
        } finally {
            if (tempFile.exists()) tempFile.delete()
        }
    }

    private fun copyUri(uri: Uri, outputFile: File) {
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open selected file" }
            FileOutputStream(outputFile).use { output ->
                input.copyTo(output, 4 * 1024 * 1024)
                output.fd.sync()
            }
        }
    }

    private fun sanitizeName(input: String, fallback: String): String {
        val base = input.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
        return if (base.isBlank()) fallback else base
    }

    private fun queryDisplayName(uri: Uri): String {
        context.contentResolver.query(
            uri,
            arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) ?: "model.gguf" }
        return uri.lastPathSegment ?: "model.gguf"
    }

    fun verifyKnownOrBasic(file: File) {
        require(file.isFile && file.canRead()) { "Imported model is not readable" }
        require(file.length() > 100L * 1024L * 1024L) {
            "Not a plausible GGUF model file (${file.length()} bytes)"
        }
        require(hasGgufHeader(file)) { "File does not start with a valid GGUF header" }
    }

    private fun hasGgufHeader(file: File): Boolean = file.inputStream().use { input ->
        val h = ByteArray(4)
        if (input.read(h) != 4) return@use false
        h.contentEquals(byteArrayOf('G'.code.toByte(), 'G'.code.toByte(), 'U'.code.toByte(), 'F'.code.toByte()))
    }

    fun sha256(file: File): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(4 * 1024 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                digest.update(buf, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun chooseDefaultContext(): Int {
        val info = ActivityManager.MemoryInfo()
        context.getSystemService(ActivityManager::class.java).getMemoryInfo(info)
        val freeGb = info.availMem.toDouble() / (1024.0 * 1024.0 * 1024.0)
        return when {
            freeGb >= 5.0 -> 8192
            freeGb >= 3.5 -> 6144
            freeGb >= 2.0 -> 4096
            else -> 3072
        }
    }

    fun modelsDirectory(): File = modelDir
    fun adaptersDirectory(): File = adapterDir
    fun visionProjectorsDirectory(): File = visionDir
}
