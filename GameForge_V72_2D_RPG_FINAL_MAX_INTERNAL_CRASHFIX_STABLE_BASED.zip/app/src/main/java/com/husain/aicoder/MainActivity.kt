package com.husain.aicoder

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.husain.aicoder.agent.AgentController
import com.husain.aicoder.godot.AICoderGodotBridge
import com.husain.aicoder.model.ModelManager
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.godotengine.godot.Godot
import org.godotengine.godot.GodotFragment
import org.godotengine.godot.GodotHost
import org.godotengine.godot.plugin.GodotPlugin

class MainActivity : AppCompatActivity(), GodotHost {
    private val scope = MainScope()
    private lateinit var status: TextView
    private lateinit var goalInput: EditText
    private var agent: AgentController? = null
    private lateinit var modelManager: ModelManager
    private var godotFragment: GodotFragment? = null
    private var bridge: AICoderGodotBridge? = null
    private var importedModel: String? = null
    private var importedAdapter: String? = null
    private fun importTextModel(uri: android.net.Uri, profileId: String, label: String) {
        scope.launch {
            try {
                setStatus("Importing $label GGUF…")
                val path = modelManager.importModel(uri, profileId)
                importedModel = path
                requireAgent().loadQwen(path, modelManager.chooseDefaultContext())
                setStatus("$label imported + loaded • ${java.io.File(path).name}")
            } catch (t: Throwable) {
                setStatus("$label import/load error: ${t.message ?: t.javaClass.simpleName}")
            }
        }
    }

    private val pickReasoning = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importTextModel(uri, com.husain.aicoder.swarm.LocalModelCatalog.DEFAULT_REASONING, "Manager / Reasoning")
    }

    private val pickCoder = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importTextModel(uri, com.husain.aicoder.swarm.LocalModelCatalog.DEFAULT_CODER, "Coding Specialist")
    }

    private val pickGeneral = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importTextModel(uri, com.husain.aicoder.swarm.LocalModelCatalog.DEFAULT_GENERAL, "General / Director")
    }

    private val pickVision = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        scope.launch {
            try {
                setStatus("Importing local VL GGUF…")
                val path = modelManager.importModel(uri, com.husain.aicoder.swarm.LocalModelCatalog.DEFAULT_VISION)
                setStatus("Local VL model imported • ${java.io.File(path).name} • projector still required for image inference")
            } catch (t: Throwable) {
                setStatus("VL import error: ${t.message ?: t.javaClass.simpleName}")
            }
        }
    }

    private val pickVisionProjector = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        scope.launch {
            try {
                setStatus("Importing local VL projector…")
                val path = modelManager.importVisionProjector(uri)
                setStatus("Local VL projector imported • ${java.io.File(path).name}")
            } catch (t: Throwable) {
                setStatus("VL projector import error: ${t.message ?: t.javaClass.simpleName}")
            }
        }
    }

    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        scope.launch {
            try {
                setStatus("Importing GGUF…")
                importedModel = modelManager.importModel(uri)
                requireAgent().loadQwen(importedModel!!, modelManager.chooseDefaultContext())
                setStatus("Local model loaded • ${modelManager.profileFor(java.io.File(importedModel!!))?.displayName ?: java.io.File(importedModel!!).name}")
            } catch (t: Throwable) {
                setStatus("Model import/load error: ${t.message ?: t.javaClass.simpleName}")
            }
        }
    }

    private val pickAdapter = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        scope.launch {
            try {
                if (importedModel == null) {
                    setStatus("Import at least one supported local GGUF first")
                    return@launch
                }
                setStatus("Importing LoRA adapter…")
                importedAdapter = modelManager.importAdapter(uri)
                requireAgent().loadAdapter(importedAdapter!!)
                setStatus("LoRA adapter loaded")
            } catch (t: Throwable) {
                setStatus("Adapter error: ${t.message}")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        goalInput = findViewById(R.id.goalInput)
        modelManager = ModelManager(this)

        val current = supportFragmentManager.findFragmentById(R.id.godot_fragment_container)
        godotFragment = if (current is GodotFragment) current else GodotFragment().also {
            supportFragmentManager.beginTransaction()
                .replace(R.id.godot_fragment_container, it)
                .commitNowAllowingStateLoss()
        }

        // Let Android UI + embedded Godot finish their first native startup frame before we
        // construct the agent graph or touch the large Qwen download. llama.cpp is now lazy, so
        // the native inference backend is not loaded during Activity startup.
        scope.launch {
            kotlinx.coroutines.delay(1800)
            if (isFinishing || isDestroyed) return@launch
            runCatching { ensureAgent() }
                .onFailure { setStatus("AI agent startup deferred: ${it.message ?: "unknown error"}") }
            try {
                val installed = modelManager.installedModels()
                val firstText = installed.firstOrNull { modelManager.profileFor(it)?.roles?.any { role -> role != com.husain.aicoder.swarm.LocalModelProfile.Role.VISION } == true }
                if (firstText != null) importedModel = firstText.absolutePath
                setStatus(if (installed.isEmpty()) "Import Manager, Coder and VL models to arm the local swarm" else "Local models ready • ${installed.size} GGUF(s) imported")
            } catch (t: Throwable) {
                setStatus("Local model scan error: ${t.message ?: "failed"} • use an IMPORT button to retry")
            }
        }

        findViewById<Button>(R.id.importReasoningButton).setOnClickListener { pickReasoning.launch(arrayOf("application/octet-stream", "application/*", "*/*")) }
        findViewById<Button>(R.id.importCoderButton).setOnClickListener { pickCoder.launch(arrayOf("application/octet-stream", "application/*", "*/*")) }
        findViewById<Button>(R.id.importGeneralButton).setOnClickListener { pickGeneral.launch(arrayOf("application/octet-stream", "application/*", "*/*")) }
        findViewById<Button>(R.id.importVisionButton).setOnClickListener { pickVision.launch(arrayOf("application/octet-stream", "application/*", "*/*")) }
        findViewById<Button>(R.id.importVisionProjectorButton).setOnClickListener { pickVisionProjector.launch(arrayOf("application/octet-stream", "application/*", "*/*")) }
        findViewById<Button>(R.id.modelButton).setOnClickListener { pickModel.launch(arrayOf("application/octet-stream", "application/*", "*/*")) }
        findViewById<Button>(R.id.adapterButton).setOnClickListener {
            pickAdapter.launch(arrayOf("application/octet-stream", "application/*", "*/*"))
        }
        findViewById<Button>(R.id.swarmStatusButton).setOnClickListener {
            setStatus(requireAgent().swarmStatus())
        }
        findViewById<Button>(R.id.swarmBenchmarkButton).setOnClickListener {
            scope.launch {
                runCatching { requireAgent().benchmarkLocalSwarm { msg -> setStatus(msg) } }
                    .onSuccess { report -> setStatus("Local swarm benchmark complete • ${report.replace("\n", " ").take(1100)}") }
                    .onFailure { setStatus("Swarm benchmark error: ${it.message}") }
            }
        }
        findViewById<Button>(R.id.swarmDiagnosticsButton).setOnClickListener {
            setStatus(requireAgent().swarmDiagnostics().replace("\n", " ").take(1100))
        }
        findViewById<Button>(R.id.useSwarmButton).setOnClickListener {
            setStatus("Local Model Swarm armed • model choice is now per-task")
            requireAgent().clearManualSwarmModel()
        }
        findViewById<Button>(R.id.benchmarkButton).setOnClickListener {
            if (importedModel == null) {
                setStatus("Import at least one supported local GGUF first")
                return@setOnClickListener
            }
            scope.launch {
                runCatching { requireAgent().benchmarkLoadedModel { s -> setStatus(s) } }
                    .onSuccess { setStatus("Benchmark saved: ${it.name}") }
                    .onFailure { setStatus("Benchmark error: ${it.message}") }
            }
        }
        findViewById<Button>(R.id.codeButton).setOnClickListener {
            val goal = goalInput.text.toString().trim()
            if (goal.isBlank()) {
                setStatus("Enter a coding mission")
                return@setOnClickListener
            }
            if (importedModel == null) {
                setStatus("Import at least one supported local GGUF first")
                return@setOnClickListener
            }
            scope.launch {
                setStatus("Coding agent running…")
                runCatching { requireAgent().runCodingMission(goal) { s -> setStatus(s) } }
                    .onFailure { setStatus("Coding error: ${it.message}") }
                    .onSuccess { setStatus("Coding mission finished; experience queued for curation") }
            }
        }
        findViewById<Button>(R.id.gameBuildButton).setOnClickListener {
            val goal = goalInput.text.toString().trim()
            if (goal.isBlank()) { setStatus("Describe the game you want built"); return@setOnClickListener }
            if (importedModel == null) { setStatus("Import at least one supported local GGUF first"); return@setOnClickListener }
            scope.launch {
                setStatus("GameForge MAX starting…")
                runCatching { requireAgent().buildGame(goal) { s -> setStatus(s) } }
                    .onFailure { setStatus("GameForge error: ${it.message}") }
                    .onSuccess { setStatus("GameForge finished • report: ${it.substringAfterLast('/')}" ) }
            }
        }
        findViewById<Button>(R.id.v6BuildButton).setOnClickListener {
            val goal = goalInput.text.toString().trim()
            if (goal.isBlank()) { setStatus("Describe the game you want built"); return@setOnClickListener }
            if (importedModel == null) { setStatus("Import at least one supported local GGUF first"); return@setOnClickListener }
            scope.launch {
                setStatus("GameForge legacy compatibility factory started…")
                runCatching { requireAgent().buildGameV6(goal) { msg -> setStatus(msg) } }
                    .onFailure { setStatus("Legacy build error: ${it.message}") }
                    .onSuccess { setStatus("Legacy factory complete • report: ${it.substringAfterLast('/')}") }
            }
        }
        findViewById<Button>(R.id.apexBuildButton).setOnClickListener {
            val goal = goalInput.text.toString().trim()
            if (goal.isBlank()) { setStatus("Describe the game you want built"); return@setOnClickListener }
            if (importedModel == null) { setStatus("Import at least one supported local GGUF first"); return@setOnClickListener }
            scope.launch {
                setStatus("GameForge FINAL MAX starting autonomous build…")
                runCatching { requireAgent().buildGameApex(goal) { msg -> setStatus(msg) } }
                    .onFailure { setStatus("Apex build error: ${it.message}") }
                    .onSuccess { setStatus("FINAL MAX complete • report: ${it.substringAfterLast('/')}") }
            }
        }
        findViewById<Button>(R.id.optimizeGameButton).setOnClickListener {
            if (importedModel == null) { setStatus("Import at least one supported local GGUF first"); return@setOnClickListener }
            scope.launch {
                runCatching { requireAgent().optimizeGameApex { msg -> setStatus(msg) } }
                    .onFailure { setStatus("Optimization error: ${it.message}") }
                    .onSuccess { setStatus("Optimization cycle complete") }
            }
        }
        findViewById<Button>(R.id.finalVerifyButton).setOnClickListener {
            scope.launch {
                runCatching { requireAgent().verifyReleaseApex { msg -> setStatus(msg) } }
                    .onFailure { setStatus("Final verification error: ${it.message}") }
                    .onSuccess { setStatus("Final release verification saved") }
            }
        }
        findViewById<Button>(R.id.inspectGameButton).setOnClickListener {
            scope.launch {
                runCatching { requireAgent().inspectGame { s -> setStatus(s) } }
                    .onFailure { setStatus("Inspection error: ${it.message}") }
            }
        }
        findViewById<Button>(R.id.gameBenchmarkButton).setOnClickListener {
            scope.launch {
                runCatching { requireAgent().benchmarkGame { s -> setStatus(s) } }
                    .onFailure { setStatus("Game benchmark error: ${it.message}") }
                    .onSuccess { setStatus("Game benchmark saved: ${it.name}") }
            }
        }
        findViewById<Button>(R.id.resumeButton).setOnClickListener {
            if (importedModel == null) { setStatus("Import at least one supported local GGUF first"); return@setOnClickListener }
            scope.launch { runCatching { requireAgent().resumeLatestMission { s -> setStatus(s) } }.onFailure { setStatus("Resume error: ${it.message}") } }
        }
        findViewById<Button>(R.id.runButton).setOnClickListener {
            val b = bridge
            when {
                b == null -> setStatus("Godot bridge not ready")
                importedModel == null -> setStatus("Import at least one supported local GGUF first")
                else -> {
                    startForegroundService(Intent(this, AutonomousRunService::class.java))
                    requireAgent().start(b)
                    setStatus("Autonomous gameplay started")
                }
            }
        }

        findViewById<Button>(R.id.internalVisionButton).setOnClickListener {
            scope.launch {
                runCatching { requireAgent().runInternalVisionCheck { msg -> setStatus(msg) } }
                    .onSuccess { setStatus("Internal local vision analyzed the embedded Godot viewport") }
                    .onFailure { setStatus("Internal vision error: ${it.message}") }
            }
        }
        findViewById<Button>(R.id.massiveQaButton).setOnClickListener {
            scope.launch {
                runCatching { requireAgent().runMassiveQA { msg -> setStatus(msg) } }
                    .onSuccess { setStatus("Massive QA complete • ${it.take(700)}") }
                    .onFailure { setStatus("Massive QA error: ${it.message}") }
            }
        }
        findViewById<Button>(R.id.worldPlanButton).setOnClickListener {
            scope.launch {
                runCatching { requireAgent().planWorld { msg -> setStatus(msg) } }
                    .onSuccess { setStatus("Procedural MMORPG world plan generated") }
                    .onFailure { setStatus("World planner error: ${it.message}") }
            }
        }
        findViewById<Button>(R.id.assetAuditButton).setOnClickListener {
            scope.launch {
                runCatching { requireAgent().auditAssets { msg -> setStatus(msg) } }
                    .onSuccess { setStatus("Asset quality pipeline complete") }
                    .onFailure { setStatus("Asset audit error: ${it.message}") }
            }
        }
    }

    override fun getActivity() = this
    override fun getGodot(): Godot? = godotFragment?.godot

    override fun getHostPlugins(godot: Godot): Set<GodotPlugin> {
        if (bridge == null) bridge = AICoderGodotBridge(godot)
        // Godot owns this callback during its native startup. Attach the larger GameForge agent
        // graph on the next UI turn so plugin registration is not racing application construction.
        runOnUiThread {
            if (!isFinishing && !isDestroyed) ensureAgent()
        }
        bridge?.let { existing -> agent?.attachGodot(existing) }
        return setOf(bridge!!)
    }

    private fun ensureAgent(): AgentController {
        val existing = agent
        if (existing != null) {
            bridge?.let { existing.attachGodot(it) }
            return existing
        }
        val created = AgentController(this)
        agent = created
        bridge?.let { created.attachGodot(it) }
        return created
    }

    private fun requireAgent(): AgentController = try {
        ensureAgent()
    } catch (t: Throwable) {
        setStatus("AI agent unavailable: ${t.message ?: "initializing"}")
        throw t
    }

    fun setStatus(message: String) = runOnUiThread { if (::status.isInitialized) status.text = message.take(700) }

    override fun onDestroy() {
        agent?.shutdown()
        agent = null
        scope.cancel()
        super.onDestroy()
    }
}
