extends Node
class_name GameForgeTelemetry

@export var sample_interval := 0.5
var _accum := 0.0
var latest := {}

func _process(delta: float) -> void:
    _accum += delta
    if _accum < sample_interval:
        return
    _accum = 0.0
    latest = {
        "fps": Performance.get_monitor(Performance.TIME_FPS),
        "frame_ms": Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0,
        "physics_ms": Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0,
        "object_count": Performance.get_monitor(Performance.OBJECT_COUNT),
        "node_count": Performance.get_monitor(Performance.OBJECT_NODE_COUNT),
        "timestamp_ms": Time.get_ticks_msec()
    }

func snapshot() -> Dictionary:
    return latest.duplicate(true)
