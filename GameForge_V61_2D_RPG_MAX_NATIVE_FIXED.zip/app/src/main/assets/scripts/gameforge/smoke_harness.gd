extends Node
class_name GameForgeSmokeHarness

## Generated projects can attach this node and call run_suite() from a test scene.
func run_suite(world: Node) -> Dictionary:
    var result := {
        "boot": true,
        "has_observation": false,
        "has_reset": world.has_method("reset_test"),
        "has_gameplay_action": world.has_method("apply_action"),
        "has_game_observation": world.has_method("get_observation") or world.has_method("get_gameforge_observation"),
        "errors": []
    }
    if world.has_method("get_gameforge_observation"):
        var observation = world.get_gameforge_observation()
        result["has_observation"] = typeof(observation) == TYPE_DICTIONARY
    elif world.has_method("get_observation"):
        var observation = world.get_observation()
        result["has_observation"] = typeof(observation) == TYPE_DICTIONARY
    return result
