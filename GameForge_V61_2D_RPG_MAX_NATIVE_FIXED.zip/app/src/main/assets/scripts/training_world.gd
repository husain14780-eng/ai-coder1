extends Node3D

var deaths := 0
var finished := false
var last_error := ""
var last_action := ""

@onready var player: CharacterBody3D = $Player
@onready var status: Label = $UI/Status

func _ready():
    build_course()

func _physics_process(delta):
    if not player.is_on_floor():
        player.velocity.y -= 18.0 * delta
    else:
        player.velocity.y = 0.0

    player.move_and_slide()

    if player.global_position.y < -5.0:
        deaths += 1
        player.global_position = Vector3(0, 1.5, 0)
        player.velocity = Vector3.ZERO

    if player.global_position.z < -48.0:
        finished = true

    status.text = (
        "deaths=%d  pos=%s  v=%s  grounded=%s  finish=%s"
        % [
            deaths,
            str(player.global_position.round()),
            str(player.velocity.round()),
            str(player.is_on_floor()),
            str(finished)
        ]
    )

func build_course():
    for child in get_children():
        if child.name.begins_with("Platform_"):
            child.queue_free()

    for i in range(1, 14):
        var body := StaticBody3D.new()
        body.name = "Platform_%02d" % i
        body.position = Vector3(
            sin(float(i) * 0.75) * 3.5,
            float(i) * 0.62,
            -float(i) * 4.0
        )

        var mesh_instance := MeshInstance3D.new()
        var box := BoxMesh.new()
        box.size = Vector3(4.2, 0.5, 3.0)
        mesh_instance.mesh = box
        body.add_child(mesh_instance)

        var collision := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = box.size
        collision.shape = shape
        body.add_child(collision)

        add_child(body)

func reset_test():
    finished = false
    last_error = ""
    last_action = ""
    player.global_position = Vector3(0, 1.5, 0)
    player.velocity = Vector3.ZERO

func apply_action(action: Dictionary):
    last_action = JSON.stringify(action)

    var x := float(action.get("x", 0.0))
    var jump := bool(action.get("jump", false))

    player.velocity.x = clamp(x, -1.0, 1.0) * 5.0

    if jump and player.is_on_floor():
        player.velocity.y = 7.5

func get_observation() -> Dictionary:
    return {
        "player_position": [
            player.global_position.x,
            player.global_position.y,
            player.global_position.z
        ],
        "velocity": [
            player.velocity.x,
            player.velocity.y,
            player.velocity.z
        ],
        "grounded": player.is_on_floor(),
        "deaths": deaths,
        "finished": finished,
        "last_action": last_action,
        "errors": [last_error] if last_error != "" else []
    }

func get_gameforge_observation() -> Dictionary:
    var base := get_observation()
    base["fps"] = Performance.get_monitor(Performance.TIME_FPS)
    base["frame_ms"] = Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0
    base["physics_ms"] = Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0
    base["node_count"] = Performance.get_monitor(Performance.OBJECT_NODE_COUNT)
    base["current_scene"] = get_tree().current_scene.scene_file_path if get_tree().current_scene else ""
    base["player_state"] = "alive" if player.global_position.y > -5.0 else "dead"
    return base
