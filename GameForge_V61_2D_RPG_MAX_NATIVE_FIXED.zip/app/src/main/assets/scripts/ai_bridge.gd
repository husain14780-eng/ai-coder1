extends Node

var plugin = null
var world = null

func _ready():
    world = get_parent()

    plugin = Engine.get_singleton("AICoderGodotBridge")

    if plugin:
        plugin.ai_action.connect(_on_ai_action)
        plugin.request_observation.connect(_on_request_observation)
        plugin.restart_test.connect(_on_restart_test)
        plugin.load_workspace_pack.connect(_on_load_workspace_pack)
        _send_observation()

func _on_ai_action(action_json: String):
    var parsed = JSON.parse_string(action_json)

    if typeof(parsed) == TYPE_DICTIONARY and world.has_method("apply_action"):
        world.apply_action(parsed)
    elif typeof(parsed) == TYPE_DICTIONARY:
        _post_error("world has no apply_action method")
        return

    _send_observation()

func _on_request_observation():
    _send_observation()

func _on_restart_test():
    if world.has_method("reset_test"):
        world.reset_test()
    _send_observation()

func _on_load_workspace_pack(pack_path: String, main_scene: String):
    var loaded := ProjectSettings.load_resource_pack(pack_path, true)
    if not loaded:
        plugin.postObservation(JSON.stringify({"errors": ["failed to load workspace pack", pack_path]}))
        return
    var target := "res://" + main_scene.trim_prefix("res://")
    var scene_err := get_tree().change_scene_to_file(target)
    if scene_err != OK:
        _post_error("failed to change to generated scene: %s" % scene_err)

func _send_observation():
    if plugin == null:
        return

    var data: Dictionary
    if world.has_method("get_gameforge_observation"):
        data = world.get_gameforge_observation()
    elif world.has_method("get_observation"):
        data = world.get_observation()
    else:
        data = {"errors": ["world has no observation method"]}
    data["screenshot_path"] = _capture_screenshot()

    data["observation_version"] = Time.get_ticks_msec()
    plugin.postObservation(JSON.stringify(data))

func _post_error(message: String):
    if plugin:
        plugin.postObservation(JSON.stringify({"errors": [message], "observation_version": Time.get_ticks_msec()}))

func _capture_screenshot() -> String:
    var image = get_viewport().get_texture().get_image()
    var dir_path = OS.get_user_data_dir().path_join("observations")
    DirAccess.make_dir_recursive_absolute(dir_path)

    var file_path = dir_path.path_join(
        "obs_%d.jpg" % Time.get_ticks_msec()
    )

    image.save_jpg(file_path, 70)
    var files = Array(DirAccess.get_files_at(dir_path))
    files.sort()
    while files.size() > 60:
        DirAccess.remove_absolute(dir_path.path_join(files.pop_front()))
    return file_path
