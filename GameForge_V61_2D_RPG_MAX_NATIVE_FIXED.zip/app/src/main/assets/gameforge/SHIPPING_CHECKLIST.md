# GameForge Shipping Checklist

## Core loop
- [ ] Game boots without a blocking error.
- [ ] Player can start, play, fail, recover and finish.
- [ ] Restart path is deterministic.

## Content
- [ ] Core mechanics are implemented before optional content.
- [ ] Level progression communicates the intended next action.
- [ ] Visual/audio feedback makes important state changes readable.

## Engineering
- [ ] Architecture graph is current.
- [ ] Save data is versioned/validated where used.
- [ ] Fresh playtest evidence exists.
- [ ] Performance report has no unresolved high-risk hotspot.

## Quality
- [ ] Regression tests pass.
- [ ] Unseen/smoke scenario passes.
- [ ] Final GameForge report says accepted=true.
