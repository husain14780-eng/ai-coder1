package com.husain.aicoder.quality

import org.json.JSONObject

/** Evidence-based V6 release gate for generated games. */
class GameQualityGate {
    private val gameplay = GameplayQualityJudge()
    data class Verdict(val accepted: Boolean, val reasons: List<String>, val risk: Double)

    fun evaluate(playtest: JSONObject, profile: JSONObject, missionCompleted: Boolean, staticVerificationOk: Boolean = true, genreContractOk: Boolean = true): Verdict {
        val reasons = mutableListOf<String>()
        val passRate = playtest.optDouble("pass_rate", 0.0)
        if (passRate < 0.80) reasons += "Smoke/playtest pass rate is below 0.80"
        if (!missionCompleted) reasons += "Autonomous implementation mission lacks a verified completion state"
        if (!staticVerificationOk) reasons += "Static generated-project verification failed"
        if (!genreContractOk) reasons += "Genre contract does not have enough fresh evidence"
        val hotspots = profile.optInt("hotspot_count", 0)
        if (hotspots > 8) reasons += "Source hotspot count is high; run a performance-focused pass"
        if (!playtest.has("results")) reasons += "No fresh playtest evidence"
        val gameplayReport = gameplay.evaluate(playtest)
        val gameplayErrors = gameplayReport.optInt("error_signal_count", 0)
        if (gameplayErrors > 0) reasons += "Playtest reported $gameplayErrors gameplay error signal(s)"
        val risk = (1.0 - passRate).coerceIn(0.0, 1.0) * 0.40 +
            (hotspots / 10.0).coerceAtMost(1.0) * 0.15 +
            (gameplayErrors / 5.0).coerceAtMost(1.0) * 0.15 +
            if (missionCompleted) 0.0 else 0.15 +
            if (staticVerificationOk) 0.0 else 0.10 +
            if (genreContractOk) 0.0 else 0.05
        return Verdict(reasons.isEmpty(), reasons, risk.coerceIn(0.0, 1.0))
    }
}
