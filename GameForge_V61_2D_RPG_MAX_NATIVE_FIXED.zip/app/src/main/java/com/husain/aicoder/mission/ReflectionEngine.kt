package com.husain.aicoder.mission

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.arm.aichat.ReasoningMode
import kotlinx.coroutines.flow.collect
import org.json.JSONObject

class ReflectionEngine(private val engine: InferenceEngine) {
    suspend fun summarize(goal: String, transcript: String): String {
        val out = StringBuilder()
        engine.sendUserPrompt(
            "Goal: $goal\nBelow is an engineering episode. Produce a compact factual reflection with: root_cause, successful_pattern, failed_pattern, next_rule. Do not invent evidence.\n$transcript",
            GenerationConfig(ReasoningMode.THINKING, 900, 0.4f, 0.9f, 20, 0f, 1.05f)
        ).collect { out.append(it) }
        return out.toString().replace(Regex("</?think>"), "").trim()
    }

    fun parse(text: String): JSONObject = JSONObject().put("reflection", text.take(8000))
}
