package com.husain.aicoder.quality

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max

/** Offline/project-side profiler: combines telemetry files, Godot observations and coarse source heuristics. */
class PerformanceProfiler(private val workspace: CodingWorkspace) {
    fun profile(): JSONObject {
        val codeFiles = workspace.list().filter { it.endsWith(".gd") || it.endsWith(".kt") || it.endsWith(".java") }
        var chars = 0L
        var risky = 0
        val hotspots = JSONArray()
        codeFiles.forEach { p ->
            val text = runCatching { workspace.read(p) }.getOrNull() ?: return@forEach
            chars += text.length
            val score = listOf("process(", "_physics_process", "while ", "queue_free", "get_nodes_in_group", "instantiate()").count { text.contains(it) }
            if (score >= 3) {
                risky++
                hotspots.put(JSONObject().put("file", p).put("risk_score", score))
            }
        }
        val telemetry = latestTelemetry()
        return JSONObject()
            .put("code_files", codeFiles.size)
            .put("code_chars", chars)
            .put("hotspot_count", risky)
            .put("hotspots", hotspots)
            .put("telemetry", telemetry)
            .put("recommendations", recommendations(risky, telemetry))
            .put("generated_at_ms", System.currentTimeMillis())
    }

    fun writeReport(): String = workspace.write("gameforge/PERFORMANCE_REPORT.json", profile().toString(2))

    private fun latestTelemetry(): JSONObject {
        val candidates = listOf(
            File(workspace.root.parentFile, "vision/latest_observation.json"),
            File(workspace.root, "gameforge/telemetry/latest.json")
        )
        val f = candidates.firstOrNull { it.isFile } ?: return JSONObject().put("available", false)
        return runCatching { JSONObject(f.readText()).put("available", true) }.getOrDefault(JSONObject().put("available", false))
    }

    private fun recommendations(hotspots: Int, telemetry: JSONObject): JSONArray {
        val out = JSONArray()
        if (hotspots > 0) out.put("Inspect high-risk runtime loops and repeated allocations.")
        val fps = telemetry.optDouble("fps", -1.0)
        if (fps > 0 && fps < 50) out.put("Profile frame-time before adding more visual effects.")
        if (telemetry.optDouble("memory_mb", -1.0) > 0 && telemetry.optDouble("memory_mb") > 700) out.put("Investigate texture/resource lifetime and cache pressure.")
        if (out.length() == 0) out.put("No coarse profiler alarm detected; still run a real device benchmark before shipping.")
        return out
    }
}
