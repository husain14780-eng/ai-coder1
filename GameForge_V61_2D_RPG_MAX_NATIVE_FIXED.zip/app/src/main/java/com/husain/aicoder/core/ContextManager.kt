package com.husain.aicoder.core

import org.json.JSONArray
import org.json.JSONObject

/** Context packing with hard bounds; it prefers current evidence and unresolved failures. */
class ContextManager(private val maxChars: Int = 52000) {
    data class Item(val kind: String, val text: String, val priority: Int, val timestamp: Long = System.currentTimeMillis())
    private val items = mutableListOf<Item>()

    @Synchronized fun add(kind: String, text: String, priority: Int = 5) {
        items += Item(kind, text.take(14000), priority)
        if (items.size > 180) items.subList(0, items.size - 180).clear()
    }

    @Synchronized fun pack(): String {
        val ordered = items.sortedWith(compareByDescending<Item> { it.priority }.thenByDescending { it.timestamp })
        val out = StringBuilder()
        for (i in ordered) {
            val block = "[${i.kind}] ${i.text}\n"
            if (out.length + block.length > maxChars) continue
            out.append(block)
        }
        return out.toString()
    }

    fun snapshot(): JSONArray = JSONArray().apply {
        items.takeLast(100).forEach { put(JSONObject().put("kind", it.kind).put("text", it.text).put("priority", it.priority).put("timestamp_ms", it.timestamp)) }
    }
}
