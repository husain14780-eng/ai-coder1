package com.husain.aicoder.ml

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class BenchmarkHistory(context: Context) {
    private val file = File(context.filesDir, "learning/benchmark_history.jsonl").apply { parentFile?.mkdirs() }
    @Synchronized fun append(name: String, score: Double, passed: Boolean, details: String) {
        file.appendText(JSONObject().put("timestamp_ms", System.currentTimeMillis()).put("name", name).put("score", score).put("passed", passed).put("details", details.take(8000)).toString() + "\n")
    }
    fun recent(limit: Int = 30): JSONArray = if (!file.isFile) JSONArray() else JSONArray(file.readLines().takeLast(limit.coerceIn(1, 200)))
}
