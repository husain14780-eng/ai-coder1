package com.husain.aicoder.vision

import android.graphics.Bitmap
import android.graphics.Color
import org.json.JSONObject
import kotlin.math.abs

/** Pixel-level perception that works without an image model. Semantic VLM understanding is pluggable. */
class ScreenPerception {
    private var previousLuma = 0.0

    fun analyze(bitmap: Bitmap): JSONObject {
        val w = bitmap.width; val h = bitmap.height
        val stepX = (w / 32).coerceAtLeast(1); val stepY = (h / 32).coerceAtLeast(1)
        var sum = 0.0; var edges = 0.0; var count = 0
        var previousPixel = -1
        var edgeTransitions = 0
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val p = bitmap.getPixel(x, y)
                val l = (0.2126 * Color.red(p) + 0.7152 * Color.green(p) + 0.0722 * Color.blue(p)) / 255.0
                sum += l; count++
                val rgb = p and 0x00ffffff
                if (previousPixel >= 0) {
                    val dr = abs(Color.red(p) - Color.red(previousPixel))
                    val dg = abs(Color.green(p) - Color.green(previousPixel))
                    val db = abs(Color.blue(p) - Color.blue(previousPixel))
                    if (dr + dg + db > 120) edgeTransitions++
                }
                previousPixel = p
                x += stepX
            }
            y += stepY
        }
        val luma = if (count == 0) 0.0 else sum / count
        val edgeDensity = if (count == 0) 0.0 else edgeTransitions.toDouble() / count
        val motion = abs(luma - previousLuma)
        previousLuma = luma
        return JSONObject()
            .put("type", "screen_perception")
            .put("width", w).put("height", h)
            .put("mean_luminance", luma)
            .put("edge_density", edgeDensity)
            .put("motion_estimate", motion)
            .put("timestamp_ms", System.currentTimeMillis())
    }
}
