package com.husain.aicoder.quality

import android.graphics.BitmapFactory
import com.husain.aicoder.agent.CodingWorkspace
import com.husain.aicoder.vision.ScreenPerception
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Lightweight game-visual QA. It prefers screenshots emitted by the embedded
 * Godot bridge and falls back to captured screen metrics when no screenshot is
 * available. Semantic understanding remains a pluggable VLM concern.
 */
class VisualQualityAnalyzer(private val workspace: CodingWorkspace) {
    private val perception = ScreenPerception()

    fun analyze(): JSONObject {
        val observationFile = File(workspace.root.parentFile, "vision/latest_observation.json")
        if (!observationFile.isFile) {
            return JSONObject()
                .put("available", false)
                .put("mode", "no_observation")
                .put("recommendations", JSONArray().put("Run the game and collect a fresh observation for visual QA."))
        }

        val o = runCatching { JSONObject(observationFile.readText()) }.getOrElse {
            return JSONObject().put("available", false).put("mode", "invalid_observation")
        }
        val screenshotPath = o.optString("screenshot_path").takeIf { it.isNotBlank() }
        val screenshot = screenshotPath?.let { File(it) }?.takeIf { it.isFile }
        val visual = screenshot?.let { file ->
            BitmapFactory.decodeFile(file.absolutePath)?.let { bitmap ->
                try {
                    perception.analyze(bitmap).put("source", file.absolutePath)
                } finally {
                    bitmap.recycle()
                }
            }
        }

        val metrics = visual ?: o
        val luma = metrics.optDouble("mean_luminance", -1.0)
        val edges = metrics.optDouble("edge_density", -1.0)
        val motion = metrics.optDouble("motion_estimate", -1.0)
        val recommendations = JSONArray()
        if (luma >= 0 && luma < 0.08) recommendations.put("Scene may be visually too dark; inspect lighting/exposure.")
        if (luma >= 0 && luma > 0.97) recommendations.put("Scene may be overexposed; inspect lighting/background values.")
        if (edges >= 0 && edges < 0.005) recommendations.put("Very low edge density; inspect whether the game viewport rendered correctly.")
        if (motion >= 0 && motion < 0.0005) recommendations.put("Low frame-to-frame visual motion; verify the game is interactive rather than stalled.")
        if (recommendations.length() == 0) recommendations.put("No coarse visual alarm detected; semantic visual review remains optional.")

        return JSONObject()
            .put("available", true)
            .put("mode", if (visual != null) "game_viewport_pixels" else "observation_metrics")
            .put("source", visual?.optString("source", screenshotPath ?: observationFile.absolutePath) ?: observationFile.absolutePath)
            .put("mean_luminance", luma)
            .put("edge_density", edges)
            .put("motion_estimate", motion)
            .put("recommendations", recommendations)
            .put("captured_at_ms", o.optLong("timestamp_ms", 0L))
    }

    fun writeReport(): String = workspace.write("gameforge/VISUAL_QUALITY_REPORT.json", analyze().toString(2))
}
