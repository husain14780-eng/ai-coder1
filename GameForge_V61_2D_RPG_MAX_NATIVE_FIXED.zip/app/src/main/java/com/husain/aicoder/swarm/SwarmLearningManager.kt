package com.husain.aicoder.swarm

import android.content.Context
import com.husain.aicoder.ml.KMeans
import com.husain.aicoder.ml.LogisticRegression
import com.husain.aicoder.ml.QLearning
import com.husain.aicoder.ml.RLTransition
import com.husain.aicoder.ml.Sample
import com.husain.aicoder.ml.SemiSupervisedLabeler
import com.husain.aicoder.ml.SelfSupervisedMasker
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max

/**
 * Five-learning-mode model-router learner. It learns routing, not model weights.
 * The base LLM weights remain immutable unless an externally trained adapter is promoted.
 */
class SwarmLearningManager(context: Context) {
    private val root = File(context.filesDir, "swarm_learning").apply { mkdirs() }
    private val logFile = File(root, "routing_experience.jsonl")
    private val qFile = File(root, "routing_q.json")
    private val q = QLearning(alpha = 0.16, gamma = 0.96, epsilon = 0.10)
    private val supervised = LogisticRegression(learningRate = 0.03, epochs = 120)
    private val semi = SemiSupervisedLabeler(0.80)
    private val masker = SelfSupervisedMasker(0.12)
    @Volatile private var lastRefresh = 0L

    init { loadQ() }

    fun record(task: String, modelId: String, success: Boolean, quality: Double, latencyMs: Long) {
        val reward = (if (success) 1.0 else -1.0) + quality.coerceIn(0.0, 1.0) * 0.8 - (latencyMs / 120_000.0).coerceAtMost(0.7)
        val state = "$task|${difficultyBucket(quality)}"
        q.update(RLTransition(state, modelId, reward, "$task|next", true))
        saveQ()
        val obj = JSONObject()
            .put("time", System.currentTimeMillis())
            .put("task", task)
            .put("model", modelId)
            .put("success", success)
            .put("quality", quality.coerceIn(0.0, 1.0))
            .put("latency_ms", latencyMs)
            .put("reward", reward)
        synchronized(this) { logFile.appendText(obj.toString() + "\n") }
        refreshLightweightLearning()
    }

    fun score(modelId: String, task: String): Double = q.export().entries
        .filter { it.key.startsWith("$task|") }
        .sumOf { it.value[modelId] ?: 0.0 }

    /** Supervised + unsupervised + semi-supervised + self-supervised diagnostics. */
    fun refreshLightweightLearning() {
        val now = System.currentTimeMillis()
        if (now - lastRefresh < 15_000L) return
        lastRefresh = now
        val rows = synchronized(this) { if (!logFile.isFile) emptyList() else logFile.readLines().takeLast(500) }
        if (rows.isEmpty()) return

        // 1) Supervised learning: success label from verified task outcomes.
        val labeled = rows.mapNotNull { runCatching { JSONObject(it) }.getOrNull() }.mapNotNull { o ->
            val qv = o.optDouble("quality", -1.0)
            if (qv < 0.0) null else Sample(doubleArrayOf(qv, if (o.optBoolean("success")) 1.0 else 0.0), if (o.optBoolean("success")) 1.0 else 0.0)
        }
        if (labeled.size >= 4) runCatching { supervised.fit(labeled) }

        // 2) Unsupervised clustering of outcomes.
        val points = rows.mapNotNull { runCatching { JSONObject(it) }.getOrNull() }.map {
            doubleArrayOf(it.optDouble("quality", 0.0), (it.optLong("latency_ms", 1L) / 1000.0).coerceAtMost(600.0) / 600.0)
        }
        if (points.size >= 6) runCatching { KMeans(k = 2).fit(points) }

        // 3) Semi-supervised pseudo-labeling for unknown/uncertain outcomes.
        if (labeled.size >= 4) runCatching { semi.pseudoLabel(labeled, points.take(32)) }

        // 4) Self-supervised dataset shaping for future adapter training.
        val tokenSample = rows.takeLast(16).flatMap { it.split(Regex("\\s+")) }.take(800)
        if (tokenSample.isNotEmpty()) runCatching { masker.makeMasked(tokenSample, now.toInt()) }

        // 5) Reinforcement learning is updated online in record().
    }

    fun exportDiagnostics(): JSONObject {
        val out = JSONObject()
            .put("five_learning_modes", JSONArray(listOf("supervised", "unsupervised", "semi-supervised", "self-supervised", "reinforcement")))
            .put("experience_rows", synchronized(this) { if (logFile.isFile) logFile.readLines().size else 0 })
            .put("q_states", q.export().size)
            .put("last_refresh_ms", lastRefresh)
        return out
    }

    @Synchronized
    private fun saveQ() {
        val rootJson = JSONObject()
        q.export().forEach { (state, actions) ->
            val obj = JSONObject()
            actions.forEach { (action, value) -> obj.put(action, value) }
            rootJson.put(state, obj)
        }
        qFile.writeText(rootJson.toString())
    }

    private fun loadQ() {
        if (!qFile.isFile) return
        runCatching {
            val obj = JSONObject(qFile.readText())
            val table = buildMap<String, Map<String, Double>> {
                val it = obj.keys()
                while (it.hasNext()) {
                    val state = it.next()
                    val actionsJson = obj.optJSONObject(state) ?: continue
                    val actions = buildMap<String, Double> {
                        val ai = actionsJson.keys()
                        while (ai.hasNext()) { val a = ai.next(); put(a, actionsJson.optDouble(a, 0.0)) }
                    }
                    put(state, actions)
                }
            }
            q.importTable(table)
        }
    }

    private fun difficultyBucket(quality: Double): String = when {
        quality >= 0.85 -> "high"
        quality >= 0.60 -> "mid"
        else -> "low"
    }
}
