package com.husain.aicoder.router

import com.arm.aichat.ReasoningMode

/** Routes work to the least expensive mode that can plausibly solve it. */
class ModelRouter {
    data class Route(val mode: ReasoningMode, val maxTokens: Int, val temperature: Float, val reason: String)

    fun route(kind: String, risk: Double, evidence: Boolean, complexity: Int): Route {
        val hard = risk >= 0.55 || complexity >= 7 || !evidence
        return when {
            kind in setOf("architecture", "design", "root_cause", "quality", "performance") && hard -> Route(ReasoningMode.THINKING, 2600, 0.58f, "high-value reasoning task")
            kind == "code" && complexity <= 3 && evidence -> Route(ReasoningMode.FAST, 1000, 0.68f, "routine implementation")
            hard -> Route(ReasoningMode.THINKING, 2200, 0.60f, "uncertainty or high impact")
            else -> Route(ReasoningMode.FAST, 1200, 0.68f, "bounded execution")
        }
    }
}
