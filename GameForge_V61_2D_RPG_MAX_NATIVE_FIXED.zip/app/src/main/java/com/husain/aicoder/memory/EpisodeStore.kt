package com.husain.aicoder.memory

import android.content.Context
import java.io.File

class EpisodeStore(context: Context) {

    private val file = File(context.filesDir, "episodes.jsonl")

    @Synchronized
    fun append(type: String, payload: String) {
        val safeType = escape(type)
        val safePayload = escape(payload)

        file.appendText(
            """{"timestamp_ms":${System.currentTimeMillis()},"type":"$safeType","payload":"$safePayload"}""" +
                "\n"
        )
    }

    private fun escape(value: String): String =
        value
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")

}
