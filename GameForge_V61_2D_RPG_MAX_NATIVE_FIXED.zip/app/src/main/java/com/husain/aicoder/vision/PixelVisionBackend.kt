package com.husain.aicoder.vision

import android.graphics.Bitmap
import org.json.JSONObject

class PixelVisionBackend : VisionBackend {
    private val perception = ScreenPerception()
    override suspend fun analyze(bitmap: Bitmap, hint: String): JSONObject = perception.analyze(bitmap)
        .put("backend", name())
        .put("hint", hint.take(500))
    override fun name(): String = "pixel_telemetry"
}
