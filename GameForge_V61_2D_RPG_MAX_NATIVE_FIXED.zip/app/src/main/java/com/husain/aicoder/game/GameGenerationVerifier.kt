package com.husain.aicoder.game

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONObject

/** Static, device-independent checks used before the runtime playtest. */
class GameGenerationVerifier(private val workspace: CodingWorkspace) {
    data class Result(val ok: Boolean, val checks: List<String>, val errors: List<String>)

    fun verify(): Result {
        val checks = mutableListOf<String>()
        val errors = mutableListOf<String>()
        fun requireFile(path: String) {
            val f = java.io.File(workspace.root, path)
            if (!f.isFile || f.length() == 0L) errors += "Missing/empty file: $path" else checks += "file:$path"
        }
        requireFile("project.godot")
        requireFile("main.tscn")
        requireFile("GAME_SPEC.json")
        requireFile("GAMEFORGE_CONTRACT.md")
        requireFile("scripts/game_root.gd")
        requireFile("gameforge/GENRE_BLUEPRINT.json")
        requireFile("gameforge/LEVEL_PLAN.json")
        requireFile("gameforge/ai_bridge.gd")
        requireFile("gameforge/procedural_asset_factory.gd")
        val specFile = java.io.File(workspace.root, "GAME_SPEC.json")
        var parsedSpec: GameSpec? = null
        if (specFile.isFile) {
            runCatching { GameSpec.fromJson(JSONObject(specFile.readText())) }
                .onSuccess { parsedSpec = it; checks += "game_spec:parse" }
                .onFailure { errors += "GameSpec parse: ${it.message}" }
        }
        val is2D = parsedSpec?.let { it.camera.contains("2d", true) || it.genre.contains("rpg", true) || it.genre.contains("mmorpg", true) } == true
        if (is2D) {
            listOf(
                "gameforge/2d/STYLE.json",
                "gameforge/2d/ASSET_REQUEST_SCHEMA.json",
                "generated/player.tscn",
                "generated/player.gd",
                "generated/world_map.tscn",
                "generated/world_map.gd",
                "generated/world_map.json",
                "generated/town_map.tscn",
                "generated/dungeon_map.tscn"
            ).forEach(::requireFile)
            val generatedFiles = workspace.listAllFiles(40000).filter { it.startsWith("generated/") }
            if (generatedFiles.none { it.endsWith(".png", true) }) errors += "2D asset pipeline produced no runtime PNG assets" else checks += "2d:png_assets"
            if (generatedFiles.none { it.endsWith("animation_manifest.json", true) }) errors += "2D animation manifests missing" else checks += "2d:animation_manifests"
            if (generatedFiles.none { it.contains("vfx/") && it.endsWith(".png", true) }) errors += "2D VFX frame sequence missing" else checks += "2d:vfx"
            if (generatedFiles.none { it.contains("maps/") && it.endsWith("_preview.png", true) }) errors += "2D map preview missing" else checks += "2d:map_preview"
            if (generatedFiles.none { it.endsWith(".gd") && runCatching { workspace.read(it) }.getOrDefault("").contains("AStarGrid2D") }) errors += "2D runtime map pathfinding missing" else checks += "2d:pathfinding"
            val styleText = runCatching { workspace.read("gameforge/2d/STYLE.json") }.getOrDefault("")
            if ("ai_directed" !in styleText && "request-driven" !in styleText && "request_driven" !in styleText) errors += "2D style does not declare AI-directed request generation" else checks += "2d:ai_directed"
            val worldRoot = runCatching { workspace.read("scripts/game_root.gd") }.getOrDefault("")
            if ("bot_testing" !in worldRoot || "get_path_direction" !in worldRoot) errors += "2D bootstrap does not expose auto-bot navigation evidence" else checks += "2d:bot_navigation"
        }
        val project = java.io.File(workspace.root, "project.godot")
        if (project.isFile) {
            val text = project.readText()
            if (!text.contains("run/main_scene=\"res://main.tscn\"")) errors += "project.godot does not point at main.tscn" else checks += "project:main_scene"
            if (!text.contains("renderer/rendering_method")) errors += "project.godot has no renderer configuration" else checks += "project:renderer"
        }
        val scene = java.io.File(workspace.root, "main.tscn")
        if (scene.isFile) {
            val text = scene.readText()
            if (!text.contains("res://scripts/game_root.gd")) errors += "main.tscn missing game_root.gd reference" else checks += "scene:root_script"
            if (!text.contains("res://gameforge/ai_bridge.gd")) errors += "main.tscn missing GameForge bridge reference" else checks += "scene:bridge"
        }
        val rootScript = runCatching { workspace.read("scripts/game_root.gd") }.getOrDefault("")
        for (symbol in listOf("func apply_action", "func reset_test", "func get_gameforge_observation", "func get_observation")) {
            if (symbol !in rootScript) errors += "game_root.gd missing automation contract: $symbol" else checks += "automation:${symbol.substringAfterLast(' ')}"
        }
        workspace.listAllFiles(20000).filter { it.endsWith(".gd") }.forEach { path ->
            val text = runCatching { workspace.read(path) }.getOrElse { "" }
            if ('\t' in text) errors += "GDScript uses tabs: $path"
            if (text.count { it == '(' } != text.count { it == ')' }) errors += "Unbalanced parentheses heuristic: $path"
            if (text.count { it == '{' } != text.count { it == '}' }) errors += "Unbalanced braces heuristic: $path"
        }
        return Result(errors.isEmpty(), checks, errors)
    }
}
