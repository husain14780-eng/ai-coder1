package com.husain.aicoder.ml

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Final release-oriented benchmark: combines implementation evidence, quality-gate state and reproducible artifacts. */
class UltimateBenchmarkSuite(private val workspace: CodingWorkspace) {
    data class Result(val accepted: Boolean, val report: File, val score: Double)

    fun run(): Result {
        val checks = JSONArray()
        fun check(id: String, ok: Boolean, evidence: String) {
            checks.put(JSONObject().put("id", id).put("ok", ok).put("evidence", evidence.take(2000)))
        }
        fun file(path: String) = File(workspace.root, path)

        check("game_spec", file("GAME_SPEC.json").isFile, "GAME_SPEC.json")
        check("design", file("GAME_DESIGN.md").isFile, "GAME_DESIGN.md")
        check("assets", file("ASSET_MANIFEST.json").isFile, "ASSET_MANIFEST.json")
        check("scenarios", file("gameforge/GAMEPLAY_SCENARIOS.json").isFile, "generated gameplay scenarios")
        check("genre_blueprint", file("gameforge/GENRE_BLUEPRINT.json").isFile, "genre system contract")
        check("balance_contract", file("gameforge/BALANCE_CONTRACT.json").isFile, "gameplay balance contract")
        check("design_consistency", file("gameforge/DESIGN_CONSISTENCY.json").isFile, "design consistency artifact")
        check("index", file("gameforge/PROJECT_INDEX.json").isFile, "project index")
        check("regression", file("gameforge/REGRESSION_MATRIX.json").isFile, "regression matrix")
        check("benchmark_v3", file("gameforge/GAME_BENCHMARK_V3.json").isFile, "base quality benchmark")
        check("benchmark_v4", file("gameforge/GAME_BENCHMARK_V4.json").isFile, "final max quality benchmark")
        check("visual_defects", file("gameforge/VISUAL_DEFECTS.json").isFile, "visual defects")
        check("performance", file("gameforge/PERFORMANCE_AUTOTUNE.json").isFile, "performance autotune")
        check("final_report", file("gameforge/FINAL_MAX_REPORT.json").isFile, "FINAL_MAX_REPORT")
        check("failure_memory", file("gameforge/failure_memory.jsonl").isFile, "persistent failure memory")
        check("release_manifest", file("gameforge/FINAL_RELEASE_MANIFEST.json").isFile, "release manifest")
        check("provenance", file("gameforge/ARTIFACT_PROVENANCE.json").isFile, "artifact provenance")

        val v3 = if (file("gameforge/GAME_BENCHMARK_V3.json").isFile) runCatching { JSONObject(file("gameforge/GAME_BENCHMARK_V3.json").readText()) }.getOrElse { JSONObject() } else JSONObject()
        val v4 = if (file("gameforge/GAME_BENCHMARK_V4.json").isFile) runCatching { JSONObject(file("gameforge/GAME_BENCHMARK_V4.json").readText()) }.getOrElse { JSONObject() } else JSONObject()
        val final = if (file("gameforge/FINAL_MAX_REPORT.json").isFile) runCatching { JSONObject(file("gameforge/FINAL_MAX_REPORT.json").readText()) }.getOrElse { JSONObject() } else JSONObject()
        val hardPassed = v4.optBoolean("passed", false) && final.optBoolean("accepted", false)
        val total = checks.length()
        val passed = (0 until total).count { checks.optJSONObject(it)?.optBoolean("ok", false) == true }
        val artifactScore = if (total == 0) 0.0 else passed.toDouble() / total
        val qualityScore = (v4.optDouble("score", v3.optDouble("score", 0.0)) / 100.0)
        val score = (artifactScore * 0.35 + qualityScore.coerceIn(0.0, 1.0) * 0.65).coerceIn(0.0, 1.0)
        val accepted = hardPassed && score >= 0.85
        val out = file("gameforge/ULTIMATE_BENCHMARK.json")
        out.parentFile?.mkdirs()
        out.writeText(JSONObject()
            .put("suite", "GameForge Apex Ultimate Benchmark")
            .put("benchmark_version", "4.0-final-max-ultimate")
            .put("artifact_checks_passed", passed)
            .put("artifact_checks_total", total)
            .put("artifact_score", artifactScore)
            .put("quality_score", qualityScore)
            .put("score", score)
            .put("quality_gate_passed", hardPassed)
            .put("accepted", accepted)
            .put("checks", checks)
            .put("generated_at_ms", System.currentTimeMillis())
            .toString(2))
        return Result(accepted, out, score)
    }
}
