package com.husain.aicoder.agent

import android.os.SystemClock
import com.husain.aicoder.godot.AICoderGodotBridge
import com.husain.aicoder.godot.GodotWorkspacePackager
import com.husain.aicoder.input.DeviceInputBridge
import com.husain.aicoder.project.ArchitectureGraph
import com.husain.aicoder.project.ChangeImpactAnalyzer
import com.husain.aicoder.project.ProjectIndexer
import com.husain.aicoder.agent.ToolPolicy
import com.husain.aicoder.quality.PerformanceProfiler
import com.husain.aicoder.quality.VisualQualityAnalyzer
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/** Bounded tool boundary. Every tool returns explicit evidence and never silently claims success. */
class ToolExecutor(
    private val workspace: CodingWorkspace,
    private val godot: AICoderGodotBridge?,
    private val missionContext: () -> String = { "" }
) {
    @Volatile private var lastObservation: JSONObject? = null
    private val observationVersion = AtomicLong(0L)
    private val visionFile = File(workspace.root.parentFile, "vision/latest_observation.json")
    private val graph = ArchitectureGraph(workspace)
    private val profiler = PerformanceProfiler(workspace)
    private val visual = VisualQualityAnalyzer(workspace)
    private val impact = ChangeImpactAnalyzer(workspace, graph)
    private val packager = GodotWorkspacePackager(workspace)
    private val runtimeDir = File(workspace.root.parentFile, "gameforge/runtime")
    private val indexer = ProjectIndexer(workspace)
    private val assetFactory2D = com.husain.aicoder.game.GameForge2DAssetFactory(workspace)

    fun observe(json: String) {
        val parsed = runCatching { JSONObject(json) }.getOrNull() ?: return
        parsed.put("tool_observation_version", observationVersion.incrementAndGet())
        lastObservation = parsed
        persistTelemetry(parsed)
    }

    private fun observationHealthy(observation: JSONObject?): Boolean {
        if (observation == null) return false
        val errors = observation.optJSONArray("errors")
        if (errors != null && errors.length() > 0) return false
        if (observation.optBoolean("crashed", false)) return false
        if (observation.optBoolean("runtime_error", false)) return false
        return true
    }

    suspend fun execute(name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "read_file" -> JSONObject().put("ok", true).put("content", workspace.read(args.getString("path"))).put("evidence", "fresh file read")
            "write_file" -> JSONObject().put("ok", true).put("path", workspace.write(args.getString("path"), args.getString("content"))).put("evidence", "file write completed")
            "replace_text" -> JSONObject().put("ok", true).put("path", workspace.replaceText(args.getString("path"), args.getString("old"), args.getString("new"), args.optInt("expected_count", 1))).put("evidence", "targeted replacement completed")
            "append_file" -> JSONObject().put("ok", true).put("path", workspace.append(args.getString("path"), args.getString("content"))).put("evidence", "file append completed")
            "list_files" -> JSONObject().put("ok", true).put("files", JSONArray(workspace.list(args.optString("path", "")))).put("evidence", "fresh workspace listing")
            "search_text" -> JSONObject().put("ok", true).put("matches", JSONArray(workspace.search(args.getString("query"), args.optString("path", "")))).put("evidence", "fresh text search")
            "hash_file" -> JSONObject().put("ok", true).put("sha256", workspace.sha256(args.getString("path"))).put("evidence", "fresh SHA-256")
            "checkpoint" -> JSONObject().put("ok", true).put("checkpoint", workspace.checkpoint(args.optString("label", "mission")).name).put("evidence", "workspace checkpoint created")
            "list_checkpoints" -> JSONObject().put("ok", true).put("checkpoints", JSONArray(workspace.listCheckpoints().map { it.name })).put("evidence", "fresh checkpoint list")
            "restore_checkpoint" -> JSONObject().put("ok", workspace.restoreCheckpoint(args.getString("name"))).put("evidence", "checkpoint restore attempted")
            "get_last_observation" -> JSONObject().put("ok", true).put("observation", lastObservation ?: JSONObject()).put("evidence", "latest Godot observation cache")
            "get_screen_observation" -> screenObservation()
            "get_mission_context" -> JSONObject().put("ok", true).put("context", missionContext()).put("evidence", "mission context")
            "inspect_project_graph" -> JSONObject().put("ok", true).put("graph", graph.scan()).put("evidence", "fresh architecture scan")
            "write_project_graph" -> JSONObject().put("ok", true).put("path", graph.writeReport()).put("evidence", "architecture graph persisted")
            "write_project_index" -> JSONObject().put("ok", true).put("path", indexer.write()).put("evidence", "fresh project symbol/file index persisted")
            "analyze_change_impact" -> JSONObject().put("ok", true).put("analysis", impact.analyze(jsonArrayStrings(args.optJSONArray("changed_paths")))).put("evidence", "fresh impact analysis")
            "profile_project" -> JSONObject().put("ok", true).put("profile", profiler.profile()).put("evidence", "fresh project performance heuristic profile")
            "write_profile_report" -> JSONObject().put("ok", true).put("path", profiler.writeReport()).put("evidence", "performance report persisted")
            "analyze_visual_quality" -> JSONObject().put("ok", true).put("visual", visual.analyze()).put("evidence", "fresh visual QA analysis")
            "write_visual_quality_report" -> JSONObject().put("ok", true).put("path", visual.writeReport()).put("evidence", "visual quality report persisted")
            "read_game_spec" -> readGameSpec()
            "generate_2d_asset" -> assetFactory2D.generateAsset(args)
            "generate_2d_map" -> assetFactory2D.generateMap(args)
            "validate_2d_assets" -> assetFactory2D.validate()
            "package_game" -> packageGame(args.optString("main_scene", "main.tscn"))
            "run_generated_game" -> runGeneratedGame(args.optString("main_scene", "main.tscn"))
            "run_godot_test" -> runGodotTest()
            "game_action" -> sendGameAction(args)
            "run_playtest" -> runPlaytest(args.optInt("iterations", 5))
            "device_tap" -> JSONObject().put("ok", DeviceInputBridge.tap(args.getDouble("x").toFloat(), args.getDouble("y").toFloat())).put("evidence", "accessibility tap dispatched")
            "device_swipe" -> JSONObject().put("ok", DeviceInputBridge.swipe(args.getDouble("x1").toFloat(), args.getDouble("y1").toFloat(), args.getDouble("x2").toFloat(), args.getDouble("y2").toFloat(), args.optLong("duration_ms", 350))).put("evidence", "accessibility swipe dispatched")
            "device_back" -> JSONObject().put("ok", DeviceInputBridge.back()).put("evidence", "accessibility back dispatched")
            "device_home" -> JSONObject().put("ok", DeviceInputBridge.home()).put("evidence", "accessibility home dispatched")
            "device_type" -> JSONObject().put("ok", DeviceInputBridge.typeText(args.getString("text"))).put("evidence", "accessibility text action dispatched")
            "wait" -> { delay(args.optLong("ms", 250).coerceIn(0, 5000)); JSONObject().put("ok", true).put("evidence", "wait completed") }
            "run_command" -> runSafeCommand(args.getString("command"), args.optLong("timeout_ms", 20000))
            else -> JSONObject().put("ok", false).put("error", "Unknown tool: $name")
        }
    } catch (t: Throwable) {
        JSONObject().put("ok", false).put("error", t.message ?: t::class.java.simpleName).put("evidence", "tool exception")
    }

    private fun screenObservation(): JSONObject {
        val available = visionFile.isFile
        return JSONObject()
            .put("ok", available)
            .put("observation", if (available) runCatching { JSONObject(visionFile.readText()) }.getOrDefault(JSONObject()) else JSONObject())
            .put("evidence", if (available) "latest captured screen metrics" else "no captured screen file")
    }

    private fun readGameSpec(): JSONObject {
        val file = File(workspace.root, "GAME_SPEC.json")
        return JSONObject().put("ok", file.isFile)
            .put("spec", if (file.isFile) runCatching { JSONObject(file.readText()) }.getOrDefault(JSONObject()) else JSONObject())
            .put("evidence", if (file.isFile) "fresh GameSpec read" else "GameSpec missing")
    }

    private suspend fun sendGameAction(args: JSONObject): JSONObject {
        val bridge = godot ?: return JSONObject().put("ok", false).put("error", "Godot bridge unavailable").put("evidence", "no bridge")
        val before = observationVersion.get()
        bridge.sendAction(args.toString())
        delay(args.optLong("settle_ms", 180).coerceIn(40, 1000))
        bridge.requestObservation()
        var waited = 0
        while (observationVersion.get() <= before && waited < 30) {
            delay(50)
            waited++
        }
        val obs = if (observationVersion.get() > before) lastObservation else null
        obs?.let { persistTelemetry(it) }
        return JSONObject()
            .put("ok", observationHealthy(obs))
            .put("action", args)
            .put("observation", obs ?: JSONObject())
            .put("observation_fresh", obs != null)
            .put("evidence", if (obs != null) "fresh post-action observation received" else "no fresh observation received after action")
    }

    private suspend fun packageGame(mainScene: String): JSONObject {
        val pack = packager.packageProject(runtimeDir, mainScene)
        return JSONObject().put("ok", true).put("pack", pack.absolutePath).put("main_scene", mainScene).put("evidence", "workspace packaged for embedded Godot")
    }

    private suspend fun runGeneratedGame(mainScene: String): JSONObject {
        val bridge = godot ?: return JSONObject().put("ok", false).put("error", "Godot bridge unavailable").put("evidence", "no bridge")
        val pack = runCatching { packager.packageProject(runtimeDir, mainScene) }.getOrElse {
            return JSONObject().put("ok", false).put("error", it.message ?: "packaging failed").put("evidence", "workspace packager rejected the generated project")
        }
        val before = observationVersion.get()
        lastObservation = null
        bridge.loadWorkspacePack(pack.absolutePath, mainScene)
        var waited = 0
        while (observationVersion.get() <= before && waited < 40) {
            delay(100)
            waited++
        }
        val obs = if (observationVersion.get() > before) lastObservation else null
        obs?.let { persistTelemetry(it) }
        return JSONObject()
            .put("ok", observationHealthy(obs))
            .put("pack", pack.absolutePath)
            .put("main_scene", mainScene)
            .put("observation", obs ?: JSONObject())
            .put("observation_fresh", obs != null)
            .put("evidence", if (obs != null) "generated workspace pack loaded and observed" else "workspace pack load gave no fresh observation")
    }

    private suspend fun runGodotTest(): JSONObject {
        val bridge = godot ?: return JSONObject().put("ok", false).put("error", "Godot bridge unavailable").put("evidence", "no bridge")
        val before = observationVersion.get()
        lastObservation = null
        bridge.restartTest()
        bridge.requestObservation()
        var waited = 0
        while (observationVersion.get() <= before && waited < 30) {
            delay(50)
            waited++
        }
        val obs = if (observationVersion.get() > before) lastObservation else null
        obs?.let { persistTelemetry(it) }
        return JSONObject()
            .put("ok", observationHealthy(obs))
            .put("observation", obs ?: JSONObject())
            .put("observation_fresh", obs != null)
            .put("evidence", if (obs != null) "fresh Godot observation received" else "no fresh observation received")
    }

    private suspend fun runPlaytest(iterations: Int): JSONObject {
        val n = iterations.coerceIn(1, 20)
        val loaded = runGeneratedGame("main.tscn")
        val results = JSONArray()
        var passes = 0
        val actions = listOf(
            JSONObject().put("type", "move").put("x", 0.65).put("y", 0.10).put("jump", false),
            JSONObject().put("type", "attack"),
            JSONObject().put("type", "skill"),
            JSONObject().put("type", "move").put("x", -0.65).put("y", -0.10).put("jump", false),
            JSONObject().put("type", "interact"),
            JSONObject().put("type", "bot_test")
        )
        repeat(n) { i ->
            val boot = runGodotTest()
            val actionRows = JSONArray()
            var actionsOk = boot.optBoolean("ok")
            if (actionsOk) {
                for (action in actions) {
                    val row = sendGameAction(action)
                    actionRows.put(row)
                    if (!row.optBoolean("ok")) actionsOk = false
                }
            }
            val result = JSONObject()
                .put("iteration", i + 1)
                .put("boot", boot)
                .put("actions", actionRows)
                .put("passed", actionsOk)
            if (actionsOk) passes++
            results.put(result)
        }
        return JSONObject()
            .put("ok", loaded.optBoolean("ok") && passes > 0)
            .put("runtime_load", loaded)
            .put("iterations", n)
            .put("passes", passes)
            .put("pass_rate", passes.toDouble() / n)
            .put("results", results)
            .put("generated_at_ms", System.currentTimeMillis())
            .put("evidence", "fresh boot and post-action observations from generated Godot runtime")
    }

    private fun persistTelemetry(observation: JSONObject) {
        val telemetry = JSONObject(observation.toString())
            .put("captured_at_ms", System.currentTimeMillis())
        val file = File(workspace.root, "gameforge/telemetry/latest.json")
        file.parentFile?.mkdirs()
        runCatching { file.writeText(telemetry.toString(2)) }
    }

    private fun jsonArrayStrings(a: JSONArray?): List<String> = if (a == null) emptyList() else buildList {
        for (i in 0 until a.length()) add(a.optString(i))
    }

    private fun runSafeCommand(command: String, timeoutMs: Long): JSONObject {
        val tokens = splitArgs(command)
        val executable = tokens.firstOrNull()?.lowercase() ?: return JSONObject().put("ok", false).put("error", "empty command")
        ToolPolicy.validateCommand(command).getOrElse { return JSONObject().put("ok", false).put("error", it.message ?: "blocked command") }
        val allowed = setOf("ls", "pwd", "find", "grep", "cat", "wc", "git")
        if (executable !in allowed) return JSONObject().put("ok", false).put("error", "command not allow-listed: $executable")
        val process = ProcessBuilder(tokens).directory(workspace.root).redirectErrorStream(true).start()
        val deadline = SystemClock.uptimeMillis() + timeoutMs.coerceIn(250, 60000)
        while (process.isAlive && SystemClock.uptimeMillis() < deadline) Thread.sleep(40)
        if (process.isAlive) { process.destroyForcibly(); return JSONObject().put("ok", false).put("error", "command timed out").put("evidence", "process exceeded timeout") }
        val output = process.inputStream.bufferedReader().readText().take(16000)
        return JSONObject().put("ok", process.exitValue() == 0).put("exit_code", process.exitValue())
            .put("output", output).put("evidence", "process exit code=${process.exitValue()}")
    }

    private fun splitArgs(input: String): List<String> {
        val out = mutableListOf<String>()
        val current = StringBuilder()
        var quote: Char? = null
        var escaped = false
        for (ch in input.trim()) {
            if (escaped) { current.append(ch); escaped = false; continue }
            if (ch == '\\') { escaped = true; continue }
            if (quote != null) {
                if (ch == quote) quote = null else current.append(ch)
                continue
            }
            when {
                ch == '\'' || ch == '"' -> quote = ch
                ch.isWhitespace() -> if (current.isNotEmpty()) { out += current.toString(); current.setLength(0) }
                else -> current.append(ch)
            }
        }
        if (escaped) current.append('\\')
        if (quote != null) throw IllegalArgumentException("Unclosed command quote")
        if (current.isNotEmpty()) out += current.toString()
        return out
    }
}
