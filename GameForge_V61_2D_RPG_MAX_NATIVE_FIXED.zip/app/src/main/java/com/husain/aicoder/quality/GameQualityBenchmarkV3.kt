package com.husain.aicoder.quality

import org.json.JSONArray
import org.json.JSONObject

/** Final objective-oriented release gate. Every dimension stays visible and every blocker is explicit. */
class GameQualityBenchmarkV3 {
    data class Result(val passed: Boolean, val score: Double, val report: JSONObject)

    fun evaluate(
        missionCompleted: Boolean,
        regression: JSONObject,
        playtest: JSONObject,
        profile: JSONObject,
        visual: JSONObject,
        gameplay: JSONObject,
        designConsistency: JSONObject,
        specValid: Boolean,
        evidenceCount: Int,
        scenarioCount: Int
    ): Result {
        val dimensions = JSONArray()
        fun add(name: String, value: Double, weight: Double) {
            val v = value.coerceIn(0.0, 1.0)
            dimensions.put(JSONObject().put("name", name).put("value", v).put("weight", weight).put("weighted", v * weight))
        }

        val visualDefects = visual.optJSONArray("defects")
        val highVisual = visualDefects?.let { arr -> (0 until arr.length()).count { arr.optJSONObject(it)?.optString("severity") == "high" } } ?: 0
        val fps = profile.optJSONObject("telemetry")?.optDouble("fps", -1.0) ?: -1.0
        val fpsValue = if (fps < 0) 0.65 else (fps / 60.0).coerceIn(0.0, 1.0)
        val gameplayErrors = gameplay.optInt("error_signal_count", 0)
        val finishSignals = gameplay.optInt("finish_signal_count", 0)

        add("implementation", if (missionCompleted) 1.0 else 0.0, 0.18)
        add("regression", regression.optDouble("pass_rate", 0.0), 0.18)
        add("playability", playtest.optDouble("pass_rate", 0.0), 0.16)
        add("gameplay_health", if (gameplayErrors == 0) 1.0 else (1.0 - gameplayErrors / 10.0), 0.10)
        add("goal_evidence", if (finishSignals > 0) 1.0 else 0.5, 0.05)
        val visualAvailable = visual.optJSONObject("visual")?.optBoolean("available", false) == true
        val visualRecommendations = visual.optJSONObject("visual")?.optJSONArray("recommendations")?.length() ?: 0
        add("visual", if (!visualAvailable) 0.55 else (1.0 - highVisual / 3.0 - visualRecommendations / 12.0), 0.10)
        add("performance", if (profile.optInt("hotspot_count", 0) <= 2) maxOf(0.0, fpsValue) else maxOf(0.0, fpsValue - 0.15), 0.10)
        add("design_consistency", designConsistency.optDouble("score", 0.0), 0.06)
        add("spec", if (specValid) 1.0 else 0.0, 0.04)
        add("evidence", (evidenceCount / 12.0).coerceAtMost(1.0), 0.04)
        add("scenario_coverage", (scenarioCount / 8.0).coerceAtMost(1.0), 0.03)

        var score = 0.0
        for (i in 0 until dimensions.length()) score += dimensions.optJSONObject(i)?.optDouble("weighted", 0.0) ?: 0.0

        val blockers = mutableListOf<String>()
        if (!missionCompleted) blockers += "implementation_not_verified"
        if (regression.optDouble("pass_rate", 0.0) < 0.95) blockers += "regression_below_0.95"
        if (playtest.optDouble("pass_rate", 0.0) < 0.85) blockers += "playtest_below_0.85"
        if (gameplayErrors > 0) blockers += "gameplay_error_signals=$gameplayErrors"
        if (highVisual > 0) blockers += "high_visual_defects=$highVisual"
        if (!specValid) blockers += "invalid_game_spec"
        if (!designConsistency.optBoolean("passed", false)) blockers += "design_contract_inconsistent"
        if (evidenceCount < 5) blockers += "insufficient_fresh_evidence"
        val passed = blockers.isEmpty() && score >= 0.86

        val report = JSONObject()
            .put("benchmark_version", "3.0-final")
            .put("score", score * 100.0)
            .put("passed", passed)
            .put("dimensions", dimensions)
            .put("blockers", JSONArray(blockers))
            .put("performance_fps_observed", fps)
            .put("visual_high_defects", highVisual)
            .put("design_consistency", designConsistency)
            .put("scenario_count", scenarioCount)
            .put("generated_at_ms", System.currentTimeMillis())
        return Result(passed, report.optDouble("score"), report)
    }
}
