package com.husain.aicoder.quality

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** Persistent failure memory: clusters recurring failures so repairs can reuse prior verified fixes. */
class FailureFingerprintStore(private val workspace: CodingWorkspace) {
    private val file = File(workspace.root, "gameforge/failure_memory.jsonl").apply { parentFile?.mkdirs() }

    @Synchronized
    fun record(phase: String, report: JSONObject): JSONObject {
        val signature = normalize(report)
        val fingerprint = sha256(signature).take(20)
        val row = JSONObject()
            .put("timestamp_ms", System.currentTimeMillis())
            .put("phase", phase)
            .put("fingerprint", fingerprint)
            .put("signature", signature.take(3000))
            .put("blockers", report.optJSONArray("blockers") ?: JSONArray())
            .put("score", report.optDouble("score", 0.0))
            .put("passed", report.optBoolean("passed", false))
        file.appendText(row.toString() + "\n")
        return row
    }

    fun similar(report: JSONObject, limit: Int = 5): JSONArray {
        val target = tokens(normalize(report))
        val rows = if (!file.isFile) emptyList() else file.readLines().takeLast(500).mapNotNull { line -> runCatching { JSONObject(line) }.getOrNull() }
        return JSONArray(rows.map { row ->
            val score = similarity(target, tokens(row.optString("signature")))
            JSONObject(row.toString()).put("similarity", score)
        }.sortedByDescending { it.optDouble("similarity", 0.0) }.take(limit.coerceIn(1, 12)))
    }

    private fun normalize(report: JSONObject): String = buildString {
        append("blockers=").append(report.optJSONArray("blockers")?.toString() ?: "[]").append('\n')
        append("score=").append(report.optDouble("score", 0.0)).append('\n')
        append("performance=").append(report.optJSONObject("performance")?.toString() ?: "{}").append('\n')
        append("visual=").append(report.optJSONArray("visual_defects")?.toString() ?: report.optJSONObject("visual")?.toString() ?: "{}").append('\n')
        append("gameplay=").append(report.optJSONObject("gameplay")?.toString() ?: "{}").append('\n')
    }

    private fun tokens(value: String): Set<String> = value.lowercase()
        .split(Regex("[^a-z0-9_]+"))
        .filter { it.length >= 3 }
        .toSet()

    private fun similarity(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val intersection = a.intersect(b).size.toDouble()
        val union = a.union(b).size.toDouble()
        return intersection / union
    }

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray())
        .joinToString("") { "%02x".format(it) }
}
