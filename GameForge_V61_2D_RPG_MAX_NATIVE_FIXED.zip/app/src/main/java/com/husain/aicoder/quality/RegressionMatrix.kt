package com.husain.aicoder.quality

import com.husain.aicoder.agent.ToolExecutor
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** Replays a compact regression matrix after each risky repair. */
class RegressionMatrix(private val tools: ToolExecutor) {
    suspend fun run(): JSONObject {
        val results = JSONArray()
        var passed = 0
        val tests = listOf("boot", "restart", "playtest", "visual_observation")
        for (name in tests) {
            val row = when (name) {
                "boot" -> tools.execute("run_godot_test", JSONObject())
                "restart" -> tools.execute("run_godot_test", JSONObject())
                "playtest" -> tools.execute("run_playtest", JSONObject().put("iterations", 2))
                else -> tools.execute("analyze_visual_quality", JSONObject())
            }
            val ok = row.optBoolean("ok", false) || (name == "visual_observation" && row.has("visual"))
            if (ok) passed++
            results.put(JSONObject().put("test", name).put("ok", ok).put("result", row))
            delay(40)
        }
        return JSONObject().put("tests", results).put("passed", passed).put("total", tests.size).put("pass_rate", passed.toDouble() / tests.size)
    }
}
