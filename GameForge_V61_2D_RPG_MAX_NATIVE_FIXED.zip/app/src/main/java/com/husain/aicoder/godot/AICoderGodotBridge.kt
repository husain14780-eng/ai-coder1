package com.husain.aicoder.godot

import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

class AICoderGodotBridge(godot: Godot) : GodotPlugin(godot) {

    companion object {
        val AI_ACTION = SignalInfo("ai_action", String::class.java)
        val REQUEST_OBSERVATION = SignalInfo("request_observation")
        val RESTART_TEST = SignalInfo("restart_test")
        val LOAD_WORKSPACE_PACK = SignalInfo("load_workspace_pack", String::class.java, String::class.java)
    }

    private val observationMutable = MutableSharedFlow<String>(replay = 1, extraBufferCapacity = 32)
    val observations = observationMutable.asSharedFlow()

    override fun getPluginName(): String = "AICoderGodotBridge"

    override fun getPluginSignals(): Set<SignalInfo> = setOf(AI_ACTION, REQUEST_OBSERVATION, RESTART_TEST, LOAD_WORKSPACE_PACK)

    fun sendAction(json: String) { emitSignal(AI_ACTION.name, json) }
    fun requestObservation() { emitSignal(REQUEST_OBSERVATION.name) }
    fun restartTest() { emitSignal(RESTART_TEST.name) }
    fun loadWorkspacePack(path: String, mainScene: String = "main.tscn") { emitSignal(LOAD_WORKSPACE_PACK.name, path, mainScene) }

    @UsedByGodot
    fun postObservation(json: String) { observationMutable.tryEmit(json) }
}
