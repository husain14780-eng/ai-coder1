package com.husain.aicoder.skills

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Reusable procedural memory distilled from verified episodes. */
class SkillLibrary(context: Context) {
    private val root = File(context.filesDir, "skills").apply { mkdirs() }
    private val file = File(root, "skills.jsonl")

    @Synchronized
    fun upsert(name: String, trigger: String, procedure: List<String>, evidence: String, failureModes: List<String>) {
        val skill = JSONObject()
            .put("name", name).put("trigger", trigger)
            .put("procedure", JSONArray(procedure)).put("evidence", evidence)
            .put("failure_modes", JSONArray(failureModes))
            .put("updated_at_ms", System.currentTimeMillis())
        file.appendText(skill.toString() + "\n")
    }

    fun retrieve(query: String, k: Int = 5): List<JSONObject> {
        val terms = query.lowercase().split(Regex("[^a-z0-9_+#.-]+"))
            .filter { it.length >= 3 }.toSet()
        if (!file.isFile) return emptyList()
        return file.useLines { lines ->
            lines.mapNotNull { runCatching { JSONObject(it) }.getOrNull() }
                .map { o -> o to terms.count { token -> o.toString().lowercase().contains(token) } }
                .filter { it.second > 0 }
                .sortedByDescending { it.second }
                .take(k).map { it.first }.toList()
        }
    }
}
