package com.husain.aicoder.game

import org.json.JSONArray
import org.json.JSONObject

/** Validates and normalizes the game contract before code generation. */
class GameSpecCompiler {
    data class Result(val ok: Boolean, val spec: GameSpec, val errors: List<String>, val warnings: List<String>)

    fun compile(spec: GameSpec): Result {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        if (spec.title.isBlank()) errors += "Game title is empty"
        if (spec.coreLoop.size < 2) warnings += "Core loop has fewer than two phases"
        if (spec.mechanics.isEmpty()) errors += "No mechanics defined"
        if (spec.scenes.isEmpty()) errors += "No scenes defined"
        if (spec.performanceTargets.isEmpty()) warnings += "No explicit performance target"
        if (spec.ui.isEmpty()) warnings += "No UI states specified"
        if (spec.audio.isEmpty()) warnings += "No audio plan specified"
        return Result(errors.isEmpty(), spec, errors, warnings)
    }

    fun write(result: Result, workspace: com.husain.aicoder.agent.CodingWorkspace): String =
        workspace.write("gameforge/GAME_SPEC_COMPILE.json", JSONObject()
            .put("ok", result.ok)
            .put("errors", JSONArray(result.errors))
            .put("warnings", JSONArray(result.warnings))
            .put("spec", result.spec.toJson()).toString(2))
}
