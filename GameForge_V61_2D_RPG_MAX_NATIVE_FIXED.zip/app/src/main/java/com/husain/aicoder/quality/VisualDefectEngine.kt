package com.husain.aicoder.quality

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject

/** Converts coarse visual metrics into explicit defects for repair prompts. */
class VisualDefectEngine(private val workspace: CodingWorkspace) {
    private val analyzer = VisualQualityAnalyzer(workspace)
    fun analyze(): JSONObject {
        val visual = analyzer.analyze()
        val defects = JSONArray()
        val luma = visual.optDouble("mean_luminance", -1.0)
        val edges = visual.optDouble("edge_density", -1.0)
        val motion = visual.optDouble("motion_estimate", -1.0)
        if (luma in 0.0..0.06) defects.put(JSONObject().put("type", "dark_scene").put("severity", "medium"))
        if (luma > 0.98) defects.put(JSONObject().put("type", "overexposed").put("severity", "medium"))
        if (edges in 0.0..0.004) defects.put(JSONObject().put("type", "low_structure").put("severity", "high"))
        if (motion in 0.0..0.0003) defects.put(JSONObject().put("type", "low_motion").put("severity", "medium"))
        return JSONObject().put("visual", visual).put("defects", defects).put("semantic_vlm_required", true)
    }

    fun write(): String = workspace.write("gameforge/VISUAL_DEFECTS.json", analyze().toString(2))
}
