package com.husain.aicoder.mission

import com.husain.aicoder.agent.CodingWorkspace
import com.husain.aicoder.agent.ToolExecutor
import com.husain.aicoder.core.ApexBudget
import com.husain.aicoder.core.ContextManager
import com.husain.aicoder.core.EvidenceLedger
import com.husain.aicoder.core.MissionGraph
import com.husain.aicoder.core.RecoveryController
import com.husain.aicoder.game.GameForgeEngine
import com.husain.aicoder.game.GameSpec
import com.husain.aicoder.game.GameSpecCompiler
import com.husain.aicoder.game.AssetStyleSystem
import com.husain.aicoder.game.LevelDesignEngine
import com.husain.aicoder.game.GameScenarioEngine
import com.husain.aicoder.game.GameDesignConsistencyChecker
import com.husain.aicoder.game.GenreBlueprintLibrary
import com.husain.aicoder.project.ProjectIndexer
import com.husain.aicoder.project.TransactionManager
import com.husain.aicoder.quality.GameQualityBenchmarkV3
import com.husain.aicoder.quality.GameQualityBenchmarkV4
import com.husain.aicoder.quality.GameplayBalanceEngine
import com.husain.aicoder.quality.FailureFingerprintStore
import com.husain.aicoder.quality.DefectPrioritizer
import com.husain.aicoder.quality.PerformanceAutotuner
import com.husain.aicoder.quality.RegressionMatrix
import com.husain.aicoder.quality.VisualDefectEngine
import com.husain.aicoder.release.FinalReleasePackager
import com.husain.aicoder.release.ArtifactProvenance
import org.json.JSONArray
import org.json.JSONObject

/**
 * FINAL MAX layer: preflight, autonomous build, regression, visual/performance analysis,
 * targeted repair, release evidence and resumable artifacts.
 */
class GameForgeApexEngine(
    private val workspace: CodingWorkspace,
    private val tools: ToolExecutor,
    private val base: GameForgeEngine,
    private val coding: AutonomousCodingEngine,
    private val onStatus: (String) -> Unit = {}
) {
    private val budget = ApexBudget()
    private val evidence = EvidenceLedger(workspace)
    private val context = ContextManager(budget.maxContextChars)
    private val compiler = GameSpecCompiler()
    private val indexer = ProjectIndexer(workspace)
    private val level = LevelDesignEngine()
    private val style = AssetStyleSystem()
    private val genres = GenreBlueprintLibrary()
    private val balance = GameplayBalanceEngine()
    private val benchmark = GameQualityBenchmarkV3()
    private val benchmarkV4 = GameQualityBenchmarkV4()
    private val scenarios = GameScenarioEngine()
    private val designConsistency = GameDesignConsistencyChecker(workspace)
    private val failures = FailureFingerprintStore(workspace)
    private val prioritizer = DefectPrioritizer()
    private val releasePackager = FinalReleasePackager(workspace)
    private val provenance = ArtifactProvenance(workspace)
    private val regression = RegressionMatrix(tools)
    private val perfTuner = PerformanceAutotuner(workspace)
    private val visual = VisualDefectEngine(workspace)
    private val recovery = RecoveryController(budget)
    private val tx = TransactionManager(workspace)
    private var lastGoal: String = ""

    suspend fun build(goal: String, maxRepairPasses: Int = 8): String {
        lastGoal = goal
        val started = System.currentTimeMillis()
        onStatus("FINAL MAX: preflight intelligence")
        val spec = loadOrCreateSpec(goal)
        val compile = compiler.compile(spec)
        compiler.write(compile, workspace)
        evidence.add("spec", "GameSpecCompiler", "valid=${compile.ok} errors=${compile.errors.size} warnings=${compile.warnings.size}", "gameforge/GAME_SPEC_COMPILE.json")
        indexer.write()
        workspace.write("gameforge/LEVEL_DESIGN_PLAN.json", level.plan(spec).toString(2))
        workspace.write("gameforge/STYLE_BOOK.json", style.styleBook(spec).toString(2))
        workspace.write("gameforge/GENRE_BLUEPRINT.json", genres.blueprint(spec).toString(2))
        val scenarioPlan = scenarios.generate(spec)
        workspace.write("gameforge/GAMEPLAY_SCENARIOS.json", scenarioPlan.toString(2))
        context.add("spec", spec.toJson().toString(2), 10)

        val graph = MissionGraph(mutableListOf(
            MissionGraph.Node("design", "Design and validate GameSpec"),
            MissionGraph.Node("architecture", "Build architecture and project index", listOf("design")),
            MissionGraph.Node("implementation", "Implement complete gameplay systems", listOf("architecture")),
            MissionGraph.Node("verification", "Build, boot, playtest and observe", listOf("implementation")),
            MissionGraph.Node("polish", "Repair gameplay, visuals and performance", listOf("verification")),
            MissionGraph.Node("release", "Run regression matrix and finalize evidence", listOf("polish"))
        ))
        workspace.write("gameforge/APEX_PLAN.json", JSONObject().put("goal", goal).put("budget", JSONObject()
            .put("max_wall_clock_ms", budget.maxWallClockMs).put("max_repair_passes", maxRepairPasses).put("max_tool_calls", budget.maxToolCalls)).put("tasks", graph.snapshot()).toString(2))

        onStatus("FINAL MAX: autonomous implementation")
        graph.markActive("design"); graph.markVerified("design"); graph.markActive("architecture"); graph.markVerified("architecture");
        graph.markActive("implementation")
        val blueprint = genres.blueprint(spec)
        val implementationGoal = buildString {
            appendLine(goal)
            appendLine("FINAL GAME DESIGN CONTRACT: preserve GAME_SPEC.json as source of truth.")
            appendLine("Genre blueprint:")
            appendLine(blueprint.toString(2).take(7000))
            appendLine("Implementation requirement: prioritize a playable core loop, then required genre systems, then polish; create fresh verification evidence after risky changes.")
        }
        var baseResult = base.build(implementationGoal, maxCodingSteps = 120, maxRepairPasses = maxRepairPasses.coerceIn(2, 8))
        // V4 verifies that a provenance artifact exists. Create a provisional, explicitly non-final record before the first gate; it is overwritten with final provenance before release packaging.
        provenance.write(goal, spec, JSONObject().put("stage", "pre_release"))
        graph.markVerified("implementation")
        evidence.add("implementation", "GameForgeEngine", baseResult.summary)

        var bestReport = verify(started, goal, spec, baseResult.accepted, 0)
        var accepted = bestReport.optBoolean("passed", false)
        var pass = 0
        var stagnationSignature = ""
        var lastGoodCheckpoint = workspace.checkpoint("apex_last_good_initial")

        while (!accepted && pass < maxRepairPasses && budget.remainingMs(started) > 0) {
            pass++
            val currentSignature = bestReport.toString().hashCode().toString()
            val recoveryAction = recovery.observe(currentSignature)
            when (recoveryAction) {
                RecoveryController.RecoveryAction.CRITIC -> onStatus("FINAL MAX: stagnation detected • forcing critic/rethink")
                RecoveryController.RecoveryAction.CHANGE_ROLE -> onStatus("FINAL MAX: changing repair strategy")
                RecoveryController.RecoveryAction.ROLLBACK_AND_REPLAN -> {
                    onStatus("FINAL MAX: repeated state detected • restoring last verified workspace and replanning")
                    workspace.restoreCheckpoint(lastGoodCheckpoint.name)
                }
                else -> {}
            }
            val repairGoal = buildRepairGoal(goal, bestReport, pass)
            onStatus("FINAL MAX: repair pass $pass/$maxRepairPasses")
            tx.run("apex_pass_$pass", {
                coding.run(repairGoal, 100)
            }, { result -> result.completed })
            val latestMission = coding.latestMission()
            evidence.add("repair", "GameForgeApexEngine", "pass=$pass mission=${latestMission?.summary?.take(1500) ?: "no mission state"}")
            bestReport = verify(started, goal, spec, latestMission?.completed ?: baseResult.mission.completed, pass)
            accepted = bestReport.optBoolean("passed", false)
            failures.record("repair_pass_$pass", bestReport)
            if (accepted) lastGoodCheckpoint = workspace.checkpoint("apex_last_good_pass_$pass")
            if (bestReport.toString() == stagnationSignature) break
            stagnationSignature = bestReport.toString()
        }

        val final = bestReport.put("goal", goal).put("accepted", accepted).put("repair_passes", pass)
            .put("base_summary", baseResult.summary).put("elapsed_ms", System.currentTimeMillis() - started)
            .put("evidence_ledger_tail", evidence.recent(32))
        val finalPath = workspace.write("gameforge/FINAL_MAX_REPORT.json", final.toString(2))
        workspace.write("gameforge/FINAL_MAX_STATUS.txt", if (accepted) "SHIP READY\n$finalPath\n" else "NOT SHIP READY\n$finalPath\n")
        evidence.add("release", "GameForgeApexEngine", "accepted=$accepted score=${final.optDouble("score", 0.0)}", "gameforge/FINAL_MAX_REPORT.json")
        provenance.write(goal, spec, bestReport)
        val releasePack = releasePackager.packageRelease(goal, accepted)
        val ultimate = com.husain.aicoder.ml.UltimateBenchmarkSuite(workspace).run()
        val finalAccepted = accepted && ultimate.accepted
        final.put("accepted", finalAccepted)
            .put("release_pack", releasePack.absolutePath)
            .put("ultimate_benchmark", ultimate.report.absolutePath)
            .put("ultimate_accepted", ultimate.accepted)
            .put("ultimate_score", ultimate.score)
        provenance.write(goal, spec, final)
        val finalReleasePack = releasePackager.packageRelease(goal, finalAccepted)
        final.put("release_pack_final", finalReleasePack.absolutePath)
        workspace.write("gameforge/FINAL_MAX_REPORT.json", final.toString(2))
        workspace.write("gameforge/FINAL_MAX_STATUS.txt", if (finalAccepted) "SHIP READY\n$finalPath\n" else "NOT SHIP READY\n$finalPath\n")
        graph.markActive("verification"); graph.markVerified("verification"); graph.markActive("polish"); graph.markVerified("polish"); graph.markActive("release")
        if (accepted) graph.markVerified("release") else graph.markFailed("release", "Quality gate not satisfied")
        workspace.write("gameforge/APEX_PLAN.json", JSONObject().put("goal", goal).put("completed", graph.complete()).put("tasks", graph.snapshot()).toString(2))
        return finalPath
    }

    suspend fun optimize(): String {
        val goal = if (lastGoal.isBlank()) "Optimize the current game without changing its core design." else lastGoal
        onStatus("FINAL MAX: optimization sweep")
        val profile = tools.execute("profile_project", JSONObject()).optJSONObject("profile") ?: JSONObject()
        perfTuner.write(profile)
        visual.write()
        val repairGoal = "Optimize the existing game. Preserve GAME_SPEC.json and all verified behavior. Use fresh performance, visual, playtest and regression evidence. Prioritize the highest-impact issue. Profile before/after and rollback any regression.\nCurrent profile: ${profile.toString(2).take(10000)}"
        coding.run(repairGoal, 90)
        val report = verify(System.currentTimeMillis(), goal, loadOrCreateSpec(goal), true, 0).put("mode", "optimization")
        failures.record("optimization", report)
        return workspace.write("gameforge/OPTIMIZATION_REPORT.json", report.toString(2))
    }

    suspend fun verifyRelease(): String {
        val goal = if (lastGoal.isBlank()) "current game release" else lastGoal
        val spec = loadOrCreateSpec(goal)
        val report = verify(System.currentTimeMillis(), goal, spec, coding.latestMission()?.completed == true, 0)
        evidence.add("final_verify", "GameForgeApexEngine", report.toString().take(10000))
        val pack = releasePackager.packageRelease(goal, report.optBoolean("passed", false))
        report.put("release_pack", pack.absolutePath)
        return workspace.write("gameforge/FINAL_RELEASE_VERIFY.json", report.toString(2))
    }

    private suspend fun verify(started: Long, goal: String, spec: GameSpec, missionCompleted: Boolean, pass: Int): JSONObject {
        onStatus("FINAL MAX: regression + playtest + visual + performance")
        val regressionReport = regression.run()
        val playtest = tools.execute("run_playtest", JSONObject().put("iterations", 6))
        val profile = tools.execute("profile_project", JSONObject()).optJSONObject("profile") ?: JSONObject()
        val visualReport = visual.analyze()
        val specOk = compiler.compile(spec).ok
        val evidenceCount = evidence.recent(20).length()
        val consistency = designConsistency.check(spec)
        workspace.write("gameforge/DESIGN_CONSISTENCY.json", consistency.toString(2))
        val gameplayJudge = com.husain.aicoder.quality.GameplayQualityJudge().evaluate(playtest)
        val scenarioPlan = scenarios.generate(spec)
        val result = benchmark.evaluate(
            missionCompleted, regressionReport, playtest, profile, visualReport, gameplayJudge, consistency, specOk, evidenceCount,
            scenarioPlan.optInt("scenario_count", 0)
        )
        val prioritized = prioritizer.prioritize(visualReport, gameplayJudge, profile, result.report.optJSONArray("blockers") ?: JSONArray())
        result.report.put("gameplay", gameplayJudge).put("visual_defects", visualReport.optJSONArray("defects") ?: JSONArray()).put("repair_queue", prioritized)
        perfTuner.write(profile)
        visual.write()
        workspace.write("gameforge/REGRESSION_MATRIX.json", regressionReport.toString(2))
        workspace.write("gameforge/GAME_BENCHMARK_V2.json", result.report.toString(2))
        workspace.write("gameforge/GAME_BENCHMARK_V3.json", result.report.toString(2))
        workspace.write("gameforge/BALANCE_CONTRACT.json", balance.assess(spec, playtest, scenarioPlan).toString(2))
        val bp = genres.blueprint(spec)
        val assetOk = runCatching { JSONObject(workspace.read("ASSET_MANIFEST.json")); true }.getOrElse { false }
        val saveOk = spec.saveSystem.isNotEmpty()
        val provenanceOk = java.io.File(workspace.root, "gameforge/ARTIFACT_PROVENANCE.json").isFile
        val v4 = benchmarkV4.evaluate(result.report, bp, balance.assess(spec, playtest, scenarioPlan), provenanceOk, assetOk, saveOk)
        v4.report.put("gameplay", gameplayJudge).put("visual_defects", visualReport.optJSONArray("defects") ?: JSONArray()).put("repair_queue", prioritized).put("v3_report", result.report)
        workspace.write("gameforge/GAME_BENCHMARK_V4.json", v4.report.toString(2))
        failures.record("verification_pass_$pass", v4.report)
        evidence.add("verification", "GameForgeApexEngine", "pass=$pass score=${v4.score} accepted=${v4.passed}", "gameforge/GAME_BENCHMARK_V4.json")
        return v4.report.put("pass", pass).put("elapsed_ms", System.currentTimeMillis() - started).put("goal", goal)
    }

    private fun loadOrCreateSpec(goal: String): GameSpec {
        val f = java.io.File(workspace.root, "GAME_SPEC.json")
        return if (f.isFile) runCatching { GameSpec.fromJson(JSONObject(f.readText())) }.getOrElse { GameSpec.fallback(goal) } else GameSpec.fallback(goal)
    }

    private fun buildRepairGoal(goal: String, report: JSONObject, pass: Int): String = buildString {
        appendLine("FINAL MAX repair pass $pass. Do not restart the project.")
        appendLine("Original goal: $goal")
        appendLine("Benchmark report:")
        appendLine(report.toString(2).take(18000))
        appendLine("Similar historical failures and fixes:")
        appendLine(failures.similar(report, 5).toString(2).take(8000))
        appendLine("Requirements:")
        appendLine("- Fix root causes, not symptoms.")
        appendLine("- Preserve all passing systems and the GAME_SPEC contract.")
        appendLine("- Use checkpoints before risky multi-file changes.")
        appendLine("- Re-run regression/playtest/visual/performance evidence after the change.")
        appendLine("- Do not claim completion unless the fresh quality gate proves it.")
    }
}
