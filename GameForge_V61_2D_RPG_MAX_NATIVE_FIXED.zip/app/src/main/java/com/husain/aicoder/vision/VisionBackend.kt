package com.husain.aicoder.vision

import android.graphics.Bitmap
import org.json.JSONObject

/** Pluggable vision contract. The default backend is pixel/telemetry based; a local VLM can implement this contract later. */
interface VisionBackend {
    suspend fun analyze(bitmap: Bitmap, hint: String = ""): JSONObject
    fun name(): String
}
