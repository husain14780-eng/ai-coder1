package com.husain.aicoder.core

import org.json.JSONArray
import org.json.JSONObject

/** Dependency-aware task graph for long-horizon game development. */
class MissionGraph(private val tasks: MutableList<Node>) {
    data class Node(
        val id: String,
        val title: String,
        val dependencies: List<String> = emptyList(),
        var status: Status = Status.PENDING,
        var attempts: Int = 0,
        var lastError: String = ""
    )
    enum class Status { PENDING, READY, ACTIVE, VERIFIED, BLOCKED, FAILED }

    fun ready(): List<Node> {
        val verified = tasks.filter { it.status == Status.VERIFIED }.map { it.id }.toSet()
        return tasks.filter { it.status == Status.PENDING && it.dependencies.all { d -> d in verified } }
            .onEach { it.status = Status.READY }
    }

    fun next(): Node? = ready().firstOrNull()

    fun markActive(id: String) { tasks.firstOrNull { it.id == id }?.let { it.status = Status.ACTIVE; it.attempts++ } }
    fun markVerified(id: String) { tasks.firstOrNull { it.id == id }?.let { it.status = Status.VERIFIED; it.lastError = "" } }
    fun markFailed(id: String, error: String, blockDependents: Boolean = false) {
        tasks.firstOrNull { it.id == id }?.let { it.status = Status.FAILED; it.lastError = error }
        if (blockDependents) {
            tasks.filter { id in it.dependencies && it.status == Status.PENDING }.forEach { it.status = Status.BLOCKED }
        }
    }

    fun complete(): Boolean = tasks.all { it.status == Status.VERIFIED }
    fun failed(): Boolean = tasks.any { it.status == Status.FAILED }
    fun snapshot(): JSONArray = JSONArray().apply {
        tasks.forEach { t -> put(JSONObject().put("id", t.id).put("title", t.title).put("dependencies", JSONArray(t.dependencies)).put("status", t.status.name).put("attempts", t.attempts).put("last_error", t.lastError)) }
    }
}
