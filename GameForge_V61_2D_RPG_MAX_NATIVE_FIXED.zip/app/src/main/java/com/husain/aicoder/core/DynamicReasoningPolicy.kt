package com.husain.aicoder.core

import com.arm.aichat.ReasoningMode

/** Routes expensive thinking to high-leverage game-engineering decisions. */
class DynamicReasoningPolicy {
    data class Decision(val mode: ReasoningMode, val maxTokens: Int, val temperature: Float, val reason: String)

    fun choose(phase: String, failures: Int, toolCalls: Int, verifiedTests: Int, hasFreshEvidence: Boolean): Decision {
        val risky = phase in setOf("planning", "design", "architecture", "debugging", "critique", "quality", "performance", "reflection", "polish")
        val uncertain = !hasFreshEvidence || verifiedTests == 0
        return when {
            failures >= 2 -> Decision(ReasoningMode.THINKING, 2800, 0.58f, "repeated failure requires root-cause reasoning")
            phase in setOf("design", "planning", "architecture") -> Decision(ReasoningMode.THINKING, 2600, 0.58f, "game/system architecture")
            phase in setOf("quality", "performance", "polish") && uncertain -> Decision(ReasoningMode.THINKING, 2400, 0.58f, "quality evidence gap")
            risky && uncertain -> Decision(ReasoningMode.THINKING, 2300, 0.60f, "high-risk / evidence gap")
            toolCalls % 6 == 0 && toolCalls > 0 -> Decision(ReasoningMode.THINKING, 1900, 0.60f, "periodic strategic review")
            else -> Decision(ReasoningMode.FAST, 1200, 0.69f, "routine execution")
        }
    }
}
