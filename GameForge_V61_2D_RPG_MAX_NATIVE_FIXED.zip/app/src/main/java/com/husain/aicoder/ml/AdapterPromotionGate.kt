package com.husain.aicoder.ml

import org.json.JSONObject
import java.io.File
import kotlin.math.max

/**
 * Gate for candidate adapters. The gate is intentionally conservative: a new adapter is never
 * promoted from a recent-training score alone.
 */
object AdapterPromotionGate {
    data class Metrics(
        val overall: Double,
        val holdout: Double,
        val unseen: Double,
        val regressionDelta: Double,
        val testEvidenceRate: Double
    )

    fun decide(candidate: Metrics, previous: Metrics?): Decision {
        val minimum = 0.55
        val minDelta = 0.01
        val maxRegression = 0.03
        val problems = mutableListOf<String>()
        if (candidate.overall < minimum) problems += "overall score below gate"
        if (candidate.holdout < minimum) problems += "holdout score below gate"
        if (candidate.unseen < minimum) problems += "unseen score below gate"
        if (candidate.testEvidenceRate < 0.5) problems += "insufficient test evidence"
        if (previous != null) {
            val delta = candidate.overall - previous.overall
            if (delta < minDelta) problems += "no meaningful improvement over previous adapter"
            if (candidate.regressionDelta > maxRegression) problems += "regression threshold exceeded"
        }
        return Decision(problems.isEmpty(), problems)
    }

    fun writeReport(file: File, candidate: Metrics, previous: Metrics?, decision: Decision) {
        file.parentFile?.mkdirs()
        file.writeText(
            JSONObject()
                .put("candidate", JSONObject()
                    .put("overall", candidate.overall)
                    .put("holdout", candidate.holdout)
                    .put("unseen", candidate.unseen)
                    .put("regression_delta", candidate.regressionDelta)
                    .put("test_evidence_rate", candidate.testEvidenceRate))
                .put("previous", previous?.let {
                    JSONObject().put("overall", it.overall).put("holdout", it.holdout).put("unseen", it.unseen)
                } ?: JSONObject.NULL)
                .put("promote", decision.promote)
                .put("reasons", decision.reasons)
                .toString(2)
        )
    }

    data class Decision(val promote: Boolean, val reasons: List<String>)
}
