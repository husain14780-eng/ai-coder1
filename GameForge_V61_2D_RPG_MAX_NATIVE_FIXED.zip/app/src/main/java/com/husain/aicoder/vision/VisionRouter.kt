package com.husain.aicoder.vision

import android.graphics.Bitmap
import org.json.JSONObject

/** Selects the strongest available local perception backend without pretending text Qwen is image-native. */
class VisionRouter(private val pixel: VisionBackend = PixelVisionBackend()) {
    @Volatile var multimodalBackend: VisionBackend? = null

    suspend fun analyze(bitmap: Bitmap, hint: String = ""): JSONObject {
        val backend = multimodalBackend ?: pixel
        return backend.analyze(bitmap, hint).put("router_backend", backend.name())
    }
}
