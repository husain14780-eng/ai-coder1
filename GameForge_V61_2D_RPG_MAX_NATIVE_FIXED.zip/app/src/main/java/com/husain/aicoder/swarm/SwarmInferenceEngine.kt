package com.husain.aicoder.swarm

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Model-switching inference wrapper with RAM admission, prompt budgeting and recovery. */
class SwarmInferenceEngine(
    private val base: InferenceEngine,
    private val swarm: LocalModelSwarmManager,
    private val router: SwarmTaskRouter,
    private val learning: SwarmLearningManager
) : InferenceEngine {
    @Volatile private var loadedId: String? = null
    @Volatile private var loadedPath: String? = null
    @Volatile private var manualProfileId: String? = null
    @Volatile private var adapterPath: String? = null
    @Volatile private var adapterScale: Float = 1.0f
    @Volatile private var adapterBasePath: String? = null
    @Volatile private var adapterLoadedForPath: String? = null
    private val modelMutex = Mutex()

    override val state get() = base.state

    override suspend fun loadModel(pathToModel: String, contextSize: Int, threads: Int, batchSize: Int) = modelMutex.withLock {
        base.loadModel(pathToModel, contextSize, threads, batchSize)
        loadedPath = pathToModel
        loadedId = LocalModelCatalog.matchFileName(java.io.File(pathToModel).name)?.id
        adapterLoadedForPath = null
        if (adapterPath != null && adapterBasePath == pathToModel) {
            base.loadLoraAdapter(adapterPath!!, adapterScale)
            adapterLoadedForPath = pathToModel
        }
    }

    override suspend fun setSystemPrompt(systemPrompt: String) = base.setSystemPrompt(systemPrompt)

    override suspend fun loadLoraAdapter(path: String, scale: Float) = modelMutex.withLock {
        base.loadLoraAdapter(path, scale)
        adapterPath = path
        adapterScale = scale
        adapterBasePath = loadedPath
        adapterLoadedForPath = loadedPath
    }

    override suspend fun clearLoraAdapter() = modelMutex.withLock {
        base.clearLoraAdapter()
        adapterPath = null
        adapterScale = 1.0f
        adapterBasePath = null
        adapterLoadedForPath = null
    }

    override fun sendUserPrompt(message: String, config: GenerationConfig): Flow<String> = flow {
        modelMutex.withLock {
            require(message.isNotBlank())
            val decision = runCatching {
                manualProfileId?.let { id ->
                    LocalModelCatalog.byId(id)?.let { p -> swarm.installedProfile(p.id)?.let { SwarmTaskRouter.Decision("manual", p, "manual model") } }
                } ?: router.decide(message)
            }.getOrElse { throw IllegalStateException("Local model swarm has no usable installed specialist: ${it.message}", it) }

            var installed = swarm.installedProfile(decision.profile.id)
                ?: error("Model ${decision.profile.displayName} is not installed")
            val snap = swarm.deviceSnapshot()
            if (!swarm.canAutoLoad(decision.profile, allowHeavy = true)) {
                installed = swarm.bestFallbackFor(decision.profile.roles, allowHeavy = false)
                    ?: error("Model ${decision.profile.displayName} rejected by RAM guard and no fallback is installed")
            }

            if (loadedId != installed.profile.id || loadedPath != installed.file.absolutePath) {
                base.cleanUp()
                loadedId = null
                loadedPath = null
                val context = swarm.contextFor(installed.profile, snap.availableRamMb)
                val loadResult = runCatching { base.loadModel(installed.file.absolutePath, context) }
                if (loadResult.isFailure) {
                    val fallback = swarm.bestFallbackFor(installed.profile.roles, allowHeavy = false)
                    if (fallback == null || fallback.file.absolutePath == installed.file.absolutePath) {
                        throw loadResult.exceptionOrNull()!!
                    }
                    base.cleanUp()
                    base.loadModel(fallback.file.absolutePath, swarm.contextFor(fallback.profile, swarm.deviceSnapshot().availableRamMb))
                    installed = fallback
                }
                loadedId = installed.profile.id
                loadedPath = installed.file.absolutePath
            }

            if (adapterPath != null && adapterLoadedForPath != loadedPath && adapterBasePath == loadedPath) {
                base.loadLoraAdapter(adapterPath!!, adapterScale)
                adapterLoadedForPath = loadedPath
            }

            val started = System.currentTimeMillis()
            val budgeted = PromptBudgeter.fit(message, installed.profile.contextTokens)
            val maxTokens = PromptBudgeter.outputBudget(budgeted, installed.profile.contextTokens, config.maxTokens, installed.profile.maxOutputTokens)
            var full = ""
            try {
                base.sendUserPrompt(budgeted, config.copy(maxTokens = maxTokens)).collect { token ->
                    full += token
                    emit(token)
                }
                learning.record(decision.task, loadedId ?: installed.profile.id, success = full.isNotBlank(), quality = qualityHeuristic(full), latencyMs = System.currentTimeMillis() - started)
            } catch (t: Throwable) {
                learning.record(decision.task, loadedId ?: installed.profile.id, success = false, quality = 0.0, latencyMs = System.currentTimeMillis() - started)
                throw t
            }
        }
    }

    fun setManualProfile(id: String?) { manualProfileId = id }
    fun activeProfileId(): String? = loadedId
    fun clearManualProfile() { manualProfileId = null }

    override fun abort() = base.abort()
    override fun modelInfo(): String = base.modelInfo()
    override fun cleanUp() { base.cleanUp(); loadedId = null; loadedPath = null; adapterLoadedForPath = null }
    override fun destroy() = base.destroy()

    private fun qualityHeuristic(text: String): Double {
        if (text.isBlank()) return 0.0
        var s = 0.35
        if (text.length > 160) s += 0.15
        if (text.contains("<tool_call>") || text.contains("```")) s += 0.15
        if (text.contains("test", ignoreCase = true) || text.contains("verify", ignoreCase = true)) s += 0.15
        if (text.length > 700) s += 0.10
        return s.coerceIn(0.0, 1.0)
    }
}

private object PromptBudgeter {
    fun fit(prompt: String, contextTokens: Int): String {
        val charBudget = (contextTokens * 3.4).toInt().coerceAtLeast(6000)
        if (prompt.length <= charBudget) return prompt
        val head = (charBudget * 0.74).toInt()
        val tail = charBudget - head - 180
        return prompt.take(head) + "\n\n[CONTEXT COMPACTED BY GAMEFORGE V6]\n\n" + prompt.takeLast(tail.coerceAtLeast(500))
    }

    fun outputBudget(prompt: String, contextTokens: Int, requested: Int, profileMax: Int): Int {
        val approxPromptTokens = (prompt.length / 3.4).toInt()
        val remaining = (contextTokens - approxPromptTokens - 256).coerceAtLeast(256)
        return minOf(requested.coerceAtLeast(16), profileMax, remaining).coerceAtLeast(16)
    }
}
