package com.husain.aicoder.quality

import org.json.JSONArray
import org.json.JSONObject

/** Merges static, gameplay, visual and performance defects into a deterministic repair queue. */
class DefectPrioritizer {
    fun prioritize(visual: JSONObject, gameplay: JSONObject, profile: JSONObject, blockers: JSONArray = JSONArray()): JSONArray {
        val rows = mutableListOf<JSONObject>()
        visual.optJSONArray("defects")?.let { arr ->
            for (i in 0 until arr.length()) {
                val d = arr.optJSONObject(i) ?: continue
                rows += JSONObject(d.toString()).put("source", "visual").put("priority", severity(d.optString("severity")))
            }
        }
        val gameplayErrors = gameplay.optInt("error_signal_count", 0)
        repeat(minOf(gameplayErrors, 8)) { rows += JSONObject().put("source", "gameplay").put("type", "gameplay_error_signal").put("priority", 90 - it * 2) }
        val fps = profile.optJSONObject("telemetry")?.optDouble("fps", -1.0) ?: -1.0
        if (fps in 0.0..44.9) rows += JSONObject().put("source", "performance").put("type", "low_fps").put("fps", fps).put("priority", 80)
        if (profile.optInt("hotspot_count", 0) > 2) rows += JSONObject().put("source", "performance").put("type", "static_hotspots").put("count", profile.optInt("hotspot_count")).put("priority", 65)
        for (i in 0 until blockers.length()) rows += JSONObject().put("source", "benchmark").put("type", blockers.optString(i)).put("priority", 100)
        return JSONArray(rows.sortedByDescending { it.optInt("priority") }.take(24))
    }

    private fun severity(s: String): Int = when (s.lowercase()) { "critical" -> 100; "high" -> 92; "medium" -> 70; else -> 40 }
}
