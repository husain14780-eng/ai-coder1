package com.husain.aicoder.quality

import org.json.JSONArray
import org.json.JSONObject

/** Evidence-weighted benchmark for game builds; dimensions remain individually visible. */
class GameQualityBenchmarkV2 {
    data class Result(val passed: Boolean, val score: Double, val report: JSONObject)

    fun evaluate(
        missionCompleted: Boolean,
        regression: JSONObject,
        playtest: JSONObject,
        profile: JSONObject,
        visual: JSONObject,
        specValid: Boolean,
        evidenceCount: Int
    ): Result {
        val dimensions = JSONArray()
        fun add(name: String, value: Double, weight: Double) { dimensions.put(JSONObject().put("name", name).put("value", value.coerceIn(0.0, 1.0)).put("weight", weight).put("weighted", value.coerceIn(0.0, 1.0) * weight)) }
        add("implementation", if (missionCompleted) 1.0 else 0.0, 0.18)
        add("regression", regression.optDouble("pass_rate", 0.0), 0.20)
        add("playability", playtest.optDouble("pass_rate", 0.0), 0.18)
        add("performance", (1.0 - profile.optInt("hotspot_count", 0) / 12.0).coerceIn(0.0, 1.0), 0.12)
        val visualBase = if (!visual.optBoolean("available", false)) 0.55 else 1.0 - (visual.optJSONArray("recommendations")?.length() ?: 0) / 6.0
        add("visual", visualBase, 0.10)
        add("spec", if (specValid) 1.0 else 0.0, 0.10)
        add("evidence", (evidenceCount / 10.0).coerceAtMost(1.0), 0.07)
        add("freshness", if (evidenceCount >= 3) 1.0 else 0.4, 0.05)
        var score = 0.0
        for (i in 0 until dimensions.length()) score += dimensions.optJSONObject(i)?.optDouble("weighted", 0.0) ?: 0.0
        val blockers = mutableListOf<String>()
        if (!missionCompleted) blockers += "implementation_not_verified"
        if (regression.optDouble("pass_rate", 0.0) < 0.9) blockers += "regression_below_0.90"
        if (playtest.optDouble("pass_rate", 0.0) < 0.8) blockers += "playtest_below_0.80"
        if (!specValid) blockers += "invalid_game_spec"
        val report = JSONObject().put("benchmark_version", "2.0-final").put("score", score * 100.0).put("passed", blockers.isEmpty() && score >= 0.82).put("dimensions", dimensions).put("blockers", JSONArray(blockers)).put("generated_at_ms", System.currentTimeMillis())
        return Result(report.optBoolean("passed"), report.optDouble("score"), report)
    }
}
