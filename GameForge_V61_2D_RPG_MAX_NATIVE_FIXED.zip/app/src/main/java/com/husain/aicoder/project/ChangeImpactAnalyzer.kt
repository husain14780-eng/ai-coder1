package com.husain.aicoder.project

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject

/** Conservative change-impact analysis using the architecture graph and text references. */
class ChangeImpactAnalyzer(private val workspace: CodingWorkspace, private val graph: ArchitectureGraph) {
    fun analyze(changedPaths: List<String>): JSONObject {
        val g = graph.scan()
        val direct = JSONArray(changedPaths)
        val impacted = linkedSetOf<String>()
        val edges = g.optJSONArray("edges") ?: JSONArray()
        for (i in 0 until edges.length()) {
            val e = edges.optJSONObject(i) ?: continue
            if (changedPaths.contains(e.optString("to"))) impacted += e.optString("from")
        }
        // Add filename searches as a second, intentionally conservative pass.
        changedPaths.forEach { changed ->
            val base = changed.substringAfterLast('/').substringBeforeLast('.')
            if (base.isBlank()) return@forEach
            workspace.search(base).forEach { impacted += it }
        }
        changedPaths.forEach { impacted.remove(it) }
        return JSONObject()
            .put("changed", direct)
            .put("impacted", JSONArray(impacted.toList().take(250)))
            .put("impact_count", impacted.size)
    }
}
