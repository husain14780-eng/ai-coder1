package com.husain.aicoder.input

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.atomic.AtomicReference

/** Singleton bridge populated only when the user explicitly enables the accessibility service. */
object DeviceInputBridge {
    private val serviceRef = AtomicReference<AICoderAccessibilityService?>(null)

    internal fun attach(service: AICoderAccessibilityService) { serviceRef.set(service) }
    internal fun detach(service: AICoderAccessibilityService) { serviceRef.compareAndSet(service, null) }

    fun available(): Boolean = serviceRef.get() != null
    fun tap(x: Float, y: Float): Boolean = serviceRef.get()?.tap(x, y) ?: false
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): Boolean =
        serviceRef.get()?.swipe(x1, y1, x2, y2, durationMs) ?: false
    fun back(): Boolean = serviceRef.get()?.backAction() ?: false
    fun home(): Boolean = serviceRef.get()?.homeAction() ?: false
    fun typeText(text: String): Boolean = serviceRef.get()?.typeText(text) ?: false
}
