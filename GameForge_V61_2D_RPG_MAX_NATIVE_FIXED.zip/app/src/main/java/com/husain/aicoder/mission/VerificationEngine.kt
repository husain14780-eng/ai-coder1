package com.husain.aicoder.mission

import org.json.JSONObject

class VerificationEngine {
    data class Verdict(val accepted: Boolean, val reason: String, val evidence: List<String>)

    fun evaluate(results: List<JSONObject>, priorFailures: Int): Verdict {
        val evidence = results.filter { it.optBoolean("ok") }
            .mapNotNull { r -> r.optString("evidence").takeIf { it.isNotBlank() } }
        val freshTest = results.any { it.optBoolean("ok") && it.optString("evidence").contains("pass", true) }
        val runtime = results.any { it.optBoolean("ok") && it.has("observation") }
        val accepted = (freshTest || runtime) && evidence.isNotEmpty() && priorFailures < 3
        val reason = when {
            accepted -> "fresh evidence supports completion"
            evidence.isEmpty() -> "no fresh evidence"
            priorFailures >= 3 -> "too many unresolved failures"
            else -> "verification incomplete"
        }
        return Verdict(accepted, reason, evidence)
    }
}
