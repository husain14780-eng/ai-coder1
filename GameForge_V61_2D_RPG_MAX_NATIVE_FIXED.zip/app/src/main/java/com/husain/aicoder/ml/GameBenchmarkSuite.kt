package com.husain.aicoder.ml

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Deterministic game-project benchmark that grades evidence, not generated prose. */
class GameBenchmarkSuite(private val workspace: CodingWorkspace) {
    data class Result(val accepted: Boolean, val report: File, val summary: String, val score: Double)

    fun run(): Result {
        val checks = JSONArray()
        fun check(id: String, ok: Boolean, evidence: String) {
            checks.put(JSONObject().put("id", id).put("ok", ok).put("evidence", evidence.take(1200)))
        }
        check("spec_exists", File(workspace.root, "GAME_SPEC.json").isFile, "GAME_SPEC.json")
        check("design_exists", File(workspace.root, "GAME_DESIGN.md").isFile, "GAME_DESIGN.md")
        check("asset_manifest", File(workspace.root, "ASSET_MANIFEST.json").isFile, "ASSET_MANIFEST.json")
        check("architecture_graph", File(workspace.root, "gameforge/ARCHITECTURE_GRAPH.json").isFile, "architecture graph")
        check("performance_report", File(workspace.root, "gameforge/PERFORMANCE_REPORT.json").isFile, "performance report")
        check("visual_quality_report", File(workspace.root, "gameforge/VISUAL_QUALITY_REPORT.json").isFile, "visual QA report")
        check("final_report", File(workspace.root, "gameforge/FINAL_GAME_REPORT.json").isFile, "final report")
        val finalReport = File(workspace.root, "gameforge/FINAL_GAME_REPORT.json")
        val accepted = if (finalReport.isFile) runCatching { JSONObject(finalReport.readText()).optBoolean("accepted") }.getOrDefault(false) else false
        check("quality_gate", accepted, "gameforge FINAL_GAME_REPORT accepted=$accepted")

        val total = checks.length()
        val passed = (0 until total).count { checks.optJSONObject(it)?.optBoolean("ok") == true }
        val score = if (total == 0) 0.0 else passed.toDouble() / total
        val out = File(workspace.root, "gameforge/GAME_BENCHMARK.json")
        out.parentFile?.mkdirs()
        out.writeText(JSONObject()
            .put("suite", "GameForge 4.0 FINAL MAX (legacy compatibility suite)")
            .put("passed", passed)
            .put("total", total)
            .put("score", score)
            .put("accepted", accepted && score >= 0.85)
            .put("checks", checks)
            .put("generated_at_ms", System.currentTimeMillis())
            .toString(2))
        val summary = "Game benchmark: $passed/$total checks passed (score=${"%.3f".format(score)}) accepted=${accepted && score >= 0.85}"
        return Result(accepted && score >= 0.85, out, summary, score)
    }
}
