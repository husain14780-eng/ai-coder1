package com.husain.aicoder.game

import org.json.JSONObject

/** Canonical telemetry fields that generated games can publish for automated QA. */
object GameTelemetryContract {
    fun sample(): JSONObject = JSONObject()
        .put("fps", 60.0)
        .put("frame_ms", 16.6)
        .put("memory_mb", 0.0)
        .put("draw_calls", 0)
        .put("physics_ms", 0.0)
        .put("active_nodes", 0)
        .put("player_state", "unknown")
        .put("current_scene", "unknown")
        .put("test_id", "smoke")
        .put("timestamp_ms", System.currentTimeMillis())
}
