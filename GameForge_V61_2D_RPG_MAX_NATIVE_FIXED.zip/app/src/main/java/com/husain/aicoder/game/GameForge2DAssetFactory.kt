package com.husain.aicoder.game

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.CRC32
import java.util.zip.Deflater
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * V6.1 AI-directed 2D asset compiler.
 *
 * The model does not pick from a shipped art pack. It supplies a request, description/style,
 * palette/features and seed; this factory synthesizes new PNG frames, source SVGs, animation
 * manifests, runtime SpriteFrames and procedural maps. The generated assets are editable and
 * reproducible, while PNG keeps the embedded Godot runtime independent from editor import caches.
 */
class GameForge2DAssetFactory(private val workspace: CodingWorkspace) {
    private data class Vec2(val x: Double, val y: Double) {
        operator fun plus(other: Vec2): Vec2 = Vec2(x + other.x, y + other.y)
        operator fun minus(other: Vec2): Vec2 = Vec2(x - other.x, y - other.y)
        operator fun times(scale: Double): Vec2 = Vec2(x * scale, y * scale)
    }
    fun generateAll(spec: GameSpec): List<String> {
        val written = mutableListOf<String>()
        written += workspace.write("gameforge/2d/STYLE.json", styleFor(spec).toString(2))
        written += workspace.write("gameforge/2d/PIPELINE.md", pipelineMarkdown(spec))
        written += workspace.write("gameforge/2d/ASSET_REQUEST_SCHEMA.json", requestSchema().toString(2))

        fun collect(result: JSONObject) {
            result.optJSONArray("written")?.let { rows ->
                for (i in 0 until rows.length()) written += rows.optString(i)
            }
        }

        val style = styleFor(spec)
        val directions = if (spec.camera.contains("top_down", true) || spec.genre.contains("mmorpg", true)) 8 else 4
        val playerAnimations = listOf("idle", "walk", "run", "attack", "cast", "hurt", "death")
        collect(generateAsset(JSONObject()
            .put("asset_type", "character")
            .put("name", "player")
            .put("role", "hero")
            .put("archetype", inferArchetype(spec.player.joinToString(" ") + " " + spec.title))
            .put("art_prompt", spec.player.joinToString(", "))
            .put("style", style.optString("style"))
            .put("palette", style.optJSONArray("palette"))
            .put("seed", stableSeed(spec.title + ":player"))
            .put("size", 64)
            .put("directions", directions)
            .put("frame_count", 6)
            .put("fps", 12)
            .put("animations", JSONArray(playerAnimations))))

        spec.enemies.take(8).forEachIndexed { index, enemy ->
            collect(generateAsset(JSONObject()
                .put("asset_type", "enemy")
                .put("name", "enemy_${index + 1}")
                .put("display_name", enemy)
                .put("role", "enemy")
                .put("archetype", inferArchetype(enemy))
                .put("art_prompt", enemy)
                .put("style", style.optString("style"))
                .put("palette", style.optJSONArray("palette"))
                .put("seed", stableSeed(spec.title + ":enemy:" + enemy + ":" + index))
                .put("size", 64)
                .put("directions", 4)
                .put("frame_count", 5)
                .put("fps", 10)
                .put("animations", JSONArray(listOf("idle", "walk", "attack", "hurt", "death")))))
        }

        val npcRequests = listOf(
            "merchant" to "merchant shopkeeper NPC",
            "questgiver" to "quest giver NPC"
        )
        npcRequests.forEachIndexed { index, pair ->
            collect(generateAsset(JSONObject()
                .put("asset_type", "npc")
                .put("name", pair.first)
                .put("role", "npc")
                .put("archetype", "humanoid")
                .put("art_prompt", pair.second)
                .put("style", style.optString("style"))
                .put("palette", style.optJSONArray("palette"))
                .put("seed", stableSeed(spec.title + ":npc:" + pair.first + ":" + index))
                .put("size", 64)
                .put("directions", 4)
                .put("frame_count", 4)
                .put("fps", 8)
                .put("animations", JSONArray(listOf("idle", "walk", "interact")))))
        }

        listOf("sword", "armor", "potion", "skill_orb").forEachIndexed { index, item ->
            collect(generateAsset(JSONObject()
                .put("asset_type", "item")
                .put("name", item)
                .put("art_prompt", item)
                .put("style", style.optString("style"))
                .put("palette", style.optJSONArray("palette"))
                .put("seed", stableSeed(spec.title + ":item:" + item + ":" + index))
                .put("size", 64)))
        }

        collect(generateAsset(JSONObject()
            .put("asset_type", "tileset")
            .put("name", "generated_tiles")
            .put("style", style.optString("style"))
            .put("palette", style.optJSONArray("palette"))
            .put("seed", stableSeed(spec.title + ":tileset"))
            .put("tile_size", 48)
            .put("theme", themeFor(spec))))

        listOf("hit", "slash", "heal", "level_up", "teleport", "fireball").forEachIndexed { index, effect ->
            collect(generateAsset(JSONObject()
                .put("asset_type", "vfx")
                .put("name", effect)
                .put("art_prompt", effect)
                .put("style", style.optString("style"))
                .put("palette", style.optJSONArray("palette"))
                .put("seed", stableSeed(spec.title + ":vfx:" + effect + ":" + index))
                .put("size", 96)
                .put("frame_count", 10)
                .put("fps", 18)))
        }

        val maps = listOf(
            Triple("world_map", themeFor(spec), 7),
            Triple("town_map", "town", 4),
            Triple("dungeon_map", "dungeon", 9)
        )
        maps.forEachIndexed { index, row ->
            collect(generateMap(JSONObject()
                .put("asset_type", "map")
                .put("name", row.first)
                .put("theme", row.second)
                .put("seed", stableSeed(spec.title + ":map:" + row.first + ":" + index))
                .put("width", if (row.first == "world_map") 36 else 28)
                .put("height", if (row.first == "world_map") 22 else 18)
                .put("rooms", row.third)
                .put("style", style.optString("style"))
                .put("landmarks", JSONArray(listOf("spawn", "goal", "encounter", "loot")))))
        }

        return written
    }

    fun generateAsset(request: JSONObject): JSONObject {
        val type = request.optString("asset_type", request.optString("type", "character")).lowercase()
        return when (type) {
            "character", "enemy", "npc", "player" -> generateCharacter(request)
            "effect", "vfx", "particle" -> generateEffect(request)
            "icon", "item" -> generateIcon(request)
            "tileset", "tile_set" -> generateTileset(request)
            else -> JSONObject().put("ok", false).put("error", "Unsupported 2D asset_type: $type")
        }
    }

    fun generateMap(request: JSONObject): JSONObject {
        val name = safeName(request.optString("name", "world_map"))
        var width = request.optInt("width", 32).coerceIn(12, 96)
        var height = request.optInt("height", 20).coerceIn(10, 64)
        val rooms = request.optInt("rooms", 7).coerceIn(2, 20)
        val seed = request.optLong("seed", stableSeed(name)).toInt()
        val theme = request.optString("theme", "forest").lowercase()
        val style = request.optString("style", "pixel_rpg")
        val authoredLayout = parseAuthoredLayout(request.optJSONArray("layout"))
        if (authoredLayout != null) {
            width = authoredLayout.grid[0].size
            height = authoredLayout.grid.size
        }
        val grid = authoredLayout?.grid ?: carveMap(width, height, rooms, seed, theme)
        val spawn = authoredLayout?.spawn?.let { findNearestWalkable(grid, it.first, it.second) }
            ?: findNearestWalkable(grid, 2, height - 3)
        val goal = authoredLayout?.goal?.let { findNearestWalkable(grid, it.first, it.second) }
            ?: findNearestWalkable(grid, width - 3, 2)
        val data = JSONObject()
            .put("name", name)
            .put("width", width)
            .put("height", height)
            .put("tile_size", 48)
            .put("seed", seed)
            .put("theme", theme)
            .put("style", style)
            .put("spawn", JSONArray(listOf(spawn.first, spawn.second)))
            .put("goal", JSONArray(listOf(goal.first, goal.second)))
            .put("grid", JSONArray(grid.map { JSONArray(it) }))
            .put("landmarks", request.optJSONArray("landmarks") ?: JSONArray(listOf("spawn", "goal", "encounter")))
            .put("layout_source", if (authoredLayout != null) "ai_authored_ascii" else "seeded_procedural")

        val written = mutableListOf<String>()
        val dataPath = "generated/$name.json"
        val scriptPath = "generated/$name.gd"
        val scenePath = "generated/$name.tscn"
        val previewPath = "generated/maps/${name}_preview.png"
        written += workspace.write(dataPath, data.toString(2))
        written += workspace.write(scriptPath, mapScript(name, theme))
        written += workspace.write(scenePath, mapScene(name, scriptPath))
        written += workspace.writeBytes(previewPath, mapPreviewPng(grid, 48, theme, spawn, goal))
        written += workspace.write("generated/maps/$name.meta.json", JSONObject()
            .put("source", "ai_directed_procedural")
            .put("seed", seed)
            .put("theme", theme)
            .put("dimensions", JSONArray(listOf(width, height)))
            .put("spawn", JSONArray(listOf(spawn.first, spawn.second)))
            .put("goal", JSONArray(listOf(goal.first, goal.second)))
            .put("layout_source", if (authoredLayout != null) "ai_authored_ascii" else "seeded_procedural")
            .toString(2))

        return JSONObject()
            .put("ok", true)
            .put("asset_type", "map")
            .put("name", name)
            .put("seed", seed)
            .put("dimensions", JSONArray(listOf(width, height)))
            .put("layout_source", if (authoredLayout != null) "ai_authored_ascii" else "seeded_procedural")
            .put("written", JSONArray(written))
            .put("evidence", "new AI-authored/procedural 2D map compiled from request")
    }

    fun validate(): JSONObject {
        val required = listOf(
            "generated/player.tscn",
            "generated/player.gd",
            "generated/world_map.tscn",
            "generated/world_map.gd",
            "generated/world_map.json",
            "generated/town_map.tscn",
            "generated/dungeon_map.tscn",
            "gameforge/2d/STYLE.json",
            "gameforge/2d/ASSET_REQUEST_SCHEMA.json"
        )
        val missing = required.filter { !File(workspace.root, it).isFile }
        val files = workspace.listAllFiles(40000)
        val pngCount = files.count { it.startsWith("generated/") && it.endsWith(".png", true) }
        val animationManifests = files.count { it.endsWith("animation_manifest.json", true) }
        val mapMeta = files.count { it.startsWith("generated/maps/") && it.endsWith(".meta.json", true) }
        val generatedScripts = files.count { it.startsWith("generated/") && it.endsWith(".gd", true) }
        val pngFiles = files.filter { it.startsWith("generated/") && it.endsWith(".png", true) }
        val invalidPng = pngFiles.count { path ->
            val bytes = runCatching { java.io.File(workspace.root, path).inputStream().use { it.readNBytes(8) } }.getOrDefault(ByteArray(0))
            bytes.size != 8 || !bytes.contentEquals(byteArrayOf(137.toByte(), 80, 78, 71, 13, 10, 26, 10))
        }
        val controllerText = files.filter { it.startsWith("generated/") && it.endsWith(".gd", true) }
            .joinToString("\n") { runCatching { workspace.read(it) }.getOrDefault("") }
        val runtimeAnimationWiring = "SpriteFrames.new()" in controllerText && "d%d_f%d.png" in controllerText
        return JSONObject()
            .put("ok", missing.isEmpty() && pngCount >= 30 && invalidPng == 0 && animationManifests >= 6 && mapMeta >= 3 && generatedScripts >= 10 && runtimeAnimationWiring)
            .put("invalid_png_count", invalidPng)
            .put("runtime_animation_wiring", runtimeAnimationWiring)
            .put("missing", JSONArray(missing))
            .put("png_count", pngCount)
            .put("animation_manifest_count", animationManifests)
            .put("map_metadata_count", mapMeta)
            .put("generated_script_count", generatedScripts)
            .put("asset_count", files.count { it.startsWith("generated/") })
            .put("evidence", "fresh 2D asset filesystem and generation-contract validation")
    }

    private fun generateCharacter(request: JSONObject): JSONObject {
        val name = safeName(request.optString("name", "character"))
        val role = request.optString("role", "hero").lowercase()
        val archetype = inferArchetype(request.optString("archetype", request.optString("art_prompt", "humanoid")))
        val artPrompt = request.optString("art_prompt", archetype)
        val size = request.optInt("size", 64).coerceIn(32, 128)
        val directions = request.optInt("directions", 4).coerceIn(1, 8)
        val frameCount = request.optInt("frame_count", 6).coerceIn(2, 16)
        val fps = request.optInt("fps", 12).coerceIn(4, 30)
        val seed = request.optLong("seed", stableSeed(name)).toInt()
        val animations = request.optJSONArray("animations")?.let { a ->
            (0 until a.length()).map { normalizeAnimationName(a.optString(it)) }.filter { it.isNotBlank() }
        } ?: listOf("idle", "walk", "attack", "hurt", "death")
        val safeAnimations = (if (animations.isEmpty()) listOf("idle") else animations).distinct()
        val palette = paletteFromRequest(request, role, archetype)
        val visualRecipe = request.optJSONObject("visual_recipe")
        val written = mutableListOf<String>()
        val manifestAnimations = JSONArray()

        for (animation in safeAnimations) {
            val framePaths = mutableListOf<String>()
            val sheet = Raster(size * frameCount, size * directions)
            for (direction in 0 until directions) {
                for (frame in 0 until frameCount) {
                    val rgba = characterRaster(size, animation, frame, frameCount, direction, directions, seed, palette, role, archetype, artPrompt, visualRecipe, request.optJSONObject("motion"))
                    val pngPath = "generated/$name/$animation/d${direction}_f${frame}.png"
                    val svgPath = "generated/$name/$animation/d${direction}_f${frame}.svg"
                    written += workspace.writeBytes(pngPath, encodePng(rgba.width, rgba.height, rgba.pixels))
                    written += workspace.write(svgPath, characterSvg(size, animation, frame, frameCount, direction, directions, palette, role, archetype, artPrompt, visualRecipe))
                    sheet.blit(rgba, frame * size, direction * size)
                    framePaths += pngPath
                }
            }
            val sheetPath = "generated/$name/${animation}_sheet.png"
            written += workspace.writeBytes(sheetPath, encodePng(sheet.width, sheet.height, sheet.pixels))
            manifestAnimations.put(JSONObject()
                .put("name", animation)
                .put("directions", directions)
                .put("frames", frameCount)
                .put("fps", fps)
                .put("loop", animation !in setOf("attack", "hurt", "death", "interact"))
                .put("frame_paths", JSONArray(framePaths))
                .put("sheet", sheetPath))
        }

        val manifest = JSONObject()
            .put("asset_type", "character")
            .put("name", name)
            .put("role", role)
            .put("archetype", archetype)
            .put("art_prompt", artPrompt)
            .put("seed", seed)
            .put("directions", directions)
            .put("frame_count", frameCount)
            .put("fps", fps)
            .put("style", request.optString("style", "pixel_rpg"))
            .put("palette", JSONArray(palette))
            .put("animations", manifestAnimations)
            .put("generation_mode", "ai_directed_seeded_raster")
        visualRecipe?.let { recipe ->
            written += workspace.write("generated/$name/visual_recipe.json", recipe.toString(2))
        }
        written += workspace.write("generated/$name/animation_manifest.json", manifest.put("visual_recipe", visualRecipe != null).toString(2))
        written += workspace.write("generated/$name.gd", generatedCharacterScript(name, directions, frameCount, fps, safeAnimations, role == "hero"))
        written += workspace.write("generated/$name.tscn", characterScene(name, role, archetype, seed))

        return JSONObject()
            .put("ok", true)
            .put("asset_type", "character")
            .put("name", name)
            .put("role", role)
            .put("archetype", archetype)
            .put("directions", directions)
            .put("frame_count", frameCount)
            .put("fps", fps)
            .put("animations", JSONArray(safeAnimations))
            .put("written", JSONArray(written))
            .put("evidence", "new AI-directed raster sprite frames, sprite sheets and runtime animation controller compiled from request")
    }

    private fun generateEffect(request: JSONObject): JSONObject {
        val name = safeName(request.optString("name", "effect"))
        val size = request.optInt("size", 96).coerceIn(32, 192)
        val frameCount = request.optInt("frame_count", 10).coerceIn(4, 24)
        val fps = request.optInt("fps", 18).coerceIn(6, 30)
        val seed = request.optLong("seed", stableSeed(name)).toInt()
        val palette = paletteFromRequest(request, "vfx", name)
        val written = mutableListOf<String>()
        val framePaths = mutableListOf<String>()
        val sheet = Raster(size * frameCount, size)
        for (frame in 0 until frameCount) {
            val raster = effectRaster(size, name, frame, frameCount, seed, palette)
            val png = "generated/vfx/$name/f$frame.png"
            val svg = "generated/vfx/$name/f$frame.svg"
            written += workspace.writeBytes(png, encodePng(raster.width, raster.height, raster.pixels))
            written += workspace.write(svg, effectSvg(size, name, frame, frameCount, palette))
            sheet.blit(raster, frame * size, 0)
            framePaths += png
        }
        written += workspace.writeBytes("generated/vfx/${name}_sheet.png", encodePng(sheet.width, sheet.height, sheet.pixels))
        written += workspace.write("generated/vfx_$name.gd", generatedEffectScript(name, fps, frameCount))
        written += workspace.write("generated/vfx_$name.tscn", effectScene(name))
        written += workspace.write("generated/vfx/$name/animation_manifest.json", JSONObject()
            .put("asset_type", "vfx")
            .put("name", name)
            .put("seed", seed)
            .put("frames", frameCount)
            .put("fps", fps)
            .put("frame_paths", JSONArray(framePaths))
            .put("generation_mode", "ai_directed_seeded_raster")
            .toString(2))
        return JSONObject()
            .put("ok", true)
            .put("asset_type", "effect")
            .put("name", name)
            .put("frames", frameCount)
            .put("written", JSONArray(written))
            .put("evidence", "new AI-directed procedural VFX sprite sequence compiled from request")
    }

    private fun generateTileset(request: JSONObject): JSONObject {
        val name = safeName(request.optString("name", "generated_tiles"))
        val tile = request.optInt("tile_size", 48).coerceIn(16, 96)
        val columns = 8
        val rows = 4
        val seed = request.optLong("seed", stableSeed(name)).toInt()
        val theme = request.optString("theme", "forest").lowercase()
        val palette = paletteFromRequest(request, "tileset", theme)
        val raster = Raster(tile * columns, tile * rows)
        for (y in 0 until rows) for (x in 0 until columns) {
            val tileType = when ((x + y * columns + abs(seed)) % 8) {
                0 -> 1
                1 -> 2
                2 -> 3
                else -> 0
            }
            val base = when (tileType) {
                1 -> palette[4 % palette.size]
                2 -> palette[2 % palette.size]
                3 -> palette[1 % palette.size]
                else -> palette[0]
            }
            raster.fillRect((x * tile).toDouble(), (y * tile).toDouble(), tile.toDouble(), tile.toDouble(), hexColor(base))
            raster.fillRect((x * tile + tile / 5).toDouble(), (y * tile + tile / 5).toDouble(), (tile / 8).toDouble(), (tile / 8).toDouble(), hexColor(palette[(x + y + 2) % palette.size]))
            raster.line((x * tile).toDouble(), (y * tile).toDouble(), ((x + 1) * tile - 1).toDouble(), (y * tile).toDouble(), hexColor(palette.last()), 2.0)
        }
        val pngPath = "generated/tilesets/$name.png"
        val svgPath = "generated/tilesets/$name.svg"
        val written = listOf(
            workspace.writeBytes(pngPath, encodePng(raster.width, raster.height, raster.pixels)),
            workspace.write(svgPath, tilesetSvg(tile, columns, rows, palette)),
            workspace.write("generated/tilesets/$name.json", JSONObject()
                .put("asset_type", "tileset")
                .put("name", name)
                .put("tile_size", tile)
                .put("columns", columns)
                .put("rows", rows)
                .put("theme", theme)
                .put("seed", seed)
                .put("generation_mode", "ai_directed_seeded_raster")
                .toString(2))
        )
        return JSONObject()
            .put("ok", true)
            .put("asset_type", "tileset")
            .put("name", name)
            .put("tile_size", tile)
            .put("written", JSONArray(written))
            .put("evidence", "new procedural tile atlas compiled from request")
    }

    private fun generateIcon(request: JSONObject): JSONObject {
        val name = safeName(request.optString("name", "item"))
        val size = request.optInt("size", 64).coerceIn(32, 128)
        val seed = request.optLong("seed", stableSeed(name)).toInt()
        val palette = paletteFromRequest(request, "item", request.optString("art_prompt", name))
        val raster = iconRaster(size, name, seed, palette)
        val pngPath = "generated/icons/$name.png"
        val svgPath = "generated/icons/$name.svg"
        val written = listOf(
            workspace.writeBytes(pngPath, encodePng(raster.width, raster.height, raster.pixels)),
            workspace.write(svgPath, iconSvg(size, name, palette)),
            workspace.write("generated/icons/$name.json", JSONObject()
                .put("asset_type", "icon")
                .put("name", name)
                .put("seed", seed)
                .put("generation_mode", "ai_directed_seeded_raster")
                .toString(2))
        )
        return JSONObject()
            .put("ok", true)
            .put("asset_type", "icon")
            .put("name", name)
            .put("written", JSONArray(written))
            .put("evidence", "new procedural item icon compiled from request")
    }

    private fun styleFor(spec: GameSpec): JSONObject {
        val style = when {
            spec.constraints.any { it.contains("pixel", true) } -> "pixel_rpg"
            spec.genre.contains("rpg", true) || spec.genre.contains("mmorpg", true) -> "pixel_rpg"
            else -> "stylized_2d"
        }
        val seed = stableSeed(spec.title + ":style").toInt()
        return JSONObject()
            .put("style", style)
            .put("seed", seed)
            .put("grid", 48)
            .put("sprite_size", 64)
            .put("directions", if (spec.camera.contains("top_down", true)) 8 else 4)
            .put("animation_fps", 12)
            .put("palette", JSONArray(paletteFromSeed(seed)))
            .put("rules", JSONArray(listOf(
                "crisp_edges",
                "single_outline_weight",
                "readable silhouettes",
                "high-contrast interactables",
                "consistent frame timing",
                "runtime PNGs have no editor-import dependency"
            )))
            .put("generation_policy", "ai_directed_seeded_procedural")
    }

    private fun requestSchema(): JSONObject = JSONObject()
        .put("asset_type", JSONArray(listOf("character", "enemy", "npc", "player", "effect", "vfx", "icon", "item", "tileset")))
        .put("character_fields", JSONObject()
            .put("name", "string")
            .put("role", "hero|enemy|npc")
            .put("archetype", "string (humanoid|slime|skeleton|mage|archer|goblin|robot|dragon|custom)")
            .put("art_prompt", "string")
            .put("seed", "integer")
            .put("size", "32..128")
            .put("directions", "1..8")
            .put("frame_count", "2..16")
            .put("fps", "4..30")
            .put("palette", "hex string array")
            .put("animations", "string array")
            .put("visual_recipe", "optional object: AI-authored normalized draw layers")
            .put("motion", "optional object: bob_px/sway_px/squash/attack_dx_px/attack_dy_px")
            .put("layout", "optional ASCII row array using # wall, . floor, ~ water, S spawn, G goal"))
        .put("map_fields", JSONObject()
            .put("name", "string")
            .put("seed", "integer")
            .put("width", "12..96")
            .put("height", "10..64")
            .put("rooms", "2..20")
            .put("theme", "string")
            .put("landmarks", "string array")
            .put("layout", "optional ASCII row array; width 12..96, height 10..64"))

    private fun pipelineMarkdown(spec: GameSpec): String = """
        # GameForge V6.1 2D Asset Pipeline

        Target: ${spec.title}
        Genre: ${spec.genre}
        Camera: ${spec.camera}

        This workspace does not depend on a fixed shipped art pack. The AI agent can describe a visual, choose a seed/style/palette,
        request a sprite/animation/map, inspect the generated files, run the Godot bot tester and regenerate the asset.

        ## Generation loop
        1. Read `gameforge/2d/STYLE.json` and `GAME_SPEC.json`.
        2. Call `generate_2d_asset` or `generate_2d_map` with an asset-specific `art_prompt`, archetype/features, seed and animation profile.
        3. The factory creates PNG runtime frames, editable SVG sources, manifests and Godot scenes/scripts.
        4. Validate with `validate_2d_assets` and fresh runtime evidence.
        5. Use the same seed to reproduce a successful asset or a new seed to create a genuinely different asset.

        ## Generated output
        - character sprite frames + animation sheets + animation manifests
        - NPC/enemy/player animations
        - VFX sprite sequences
        - item/icon art
        - tile atlases
        - procedural map JSON, preview PNG, runtime map scene and AStarGrid2D pathing
        - editable seeds and per-asset generation metadata

        ## Design intent
        The coding model is the art director: it decides what to generate. The factory is the renderer/compiler: it turns that request into new game assets.
    """.trimIndent() + "\n"

    private fun characterScene(name: String, role: String, archetype: String, seed: Int): String = """
        [gd_scene load_steps=4 format=3]

        [ext_resource type="Script" path="res://generated/$name.gd" id="1_character_script"]
        [sub_resource type="CircleShape2D" id="Collision_generated"]
        radius = 18.0

        [node name="GeneratedCharacter" type="CharacterBody2D"]
        script = ExtResource("1_character_script")
        metadata/_gameforge_role = "$role"
        metadata/_gameforge_archetype = "$archetype"
        metadata/_gameforge_seed = $seed

        [node name="AnimatedSprite2D" type="AnimatedSprite2D" parent="."]
        centered = true
        texture_filter = 1

        [node name="CollisionShape2D" type="CollisionShape2D" parent="."]
        shape = SubResource("Collision_generated")
    """.trimIndent() + "\n"

    private fun generatedCharacterScript(
        name: String,
        directions: Int,
        frameCount: Int,
        fps: Int,
        animations: List<String>,
        isHero: Boolean
    ): String {
        val animationLiteral = animations.joinToString(", ") { "\"${escapeGdString(it)}\"" }
        val actionList = animations.filter { animation ->
            animation in setOf("attack", "cast", "skill", "hurt", "interact", "dodge") ||
                animation.contains("attack", true) || animation.contains("cast", true) ||
                animation.contains("skill", true) || animation.contains("hurt", true) ||
                animation.contains("interact", true) || animation.contains("dodge", true)
        }
        val actionLiteral = actionList.joinToString(", ") { "\"${escapeGdString(it)}\"" }
        return """
            extends CharacterBody2D

            const ASSET_NAME := "$name"
            const DIRECTIONS := $directions
            const FRAME_COUNT := $frameCount
            const FPS := $fps
            const ANIMATIONS := [$animationLiteral]
            const ACTION_ANIMATIONS := [$actionLiteral]
            const BASE_SPEED := ${if (isHero) "210.0" else "155.0"}
            const DASH_SPEED := 440.0
            const DASH_TIME := 0.12

            @onready var sprite: AnimatedSprite2D = ${'$'}AnimatedSprite2D
            var move_vector := Vector2.ZERO
            var current_action := ""
            var action_cooldown := 0.0
            var dash_time := 0.0

            func _ready() -> void:
                _build_sprite_frames()
                current_action = _default_animation()
                _play_animation()

            func _physics_process(delta: float) -> void:
                action_cooldown = maxf(0.0, action_cooldown - delta)
                dash_time = maxf(0.0, dash_time - delta)
                velocity = Vector2.ZERO
                if move_vector.length() > 0.05:
                    var speed := DASH_SPEED if dash_time > 0.0 else BASE_SPEED
                    velocity = move_vector.normalized() * speed
                move_and_slide()
                _play_animation()
                if action_cooldown <= 0.0 and current_action != _default_animation():
                    current_action = _default_animation()

            func set_move_vector(value: Vector2) -> void:
                move_vector = value.limit_length(1.0)

            func trigger_action(action_name: String) -> void:
                var normalized := action_name.to_lower()
                if normalized == "dodge" and action_cooldown <= 0.0:
                    dash_time = DASH_TIME
                    action_cooldown = 0.35
                    var dodge_animation := _resolve_action_animation("dodge")
                    if not dodge_animation.is_empty():
                        current_action = dodge_animation
                    if move_vector.length() <= 0.05:
                        move_vector = Vector2.RIGHT
                    _play_animation()
                    return
                if action_cooldown <= 0.0:
                    var resolved := _resolve_action_animation(normalized)
                    if not resolved.is_empty():
                        current_action = resolved
                        action_cooldown = 0.38
                        _play_animation()

            func _default_animation() -> String:
                if "idle" in ANIMATIONS:
                    return "idle"
                if ANIMATIONS.size() > 0:
                    return ANIMATIONS[0]
                return ""

            func _is_one_shot_animation(animation_name: String) -> bool:
                return animation_name.contains("attack", true) or animation_name.contains("slash", true) or animation_name.contains("skill", true) or animation_name.contains("cast", true) or animation_name.contains("hurt", true) or animation_name.contains("damage", true) or animation_name.contains("death", true) or animation_name.contains("interact", true) or animation_name.contains("dodge", true)

            func _resolve_action_animation(action_name: String) -> String:
                if action_name in ANIMATIONS:
                    return action_name
                for candidate in ANIMATIONS:
                    if action_name == "attack" and candidate.contains("attack", true):
                        return candidate
                    if action_name == "skill" and candidate.contains("skill", true):
                        return candidate
                    if action_name == "cast" and candidate.contains("cast", true):
                        return candidate
                    if action_name == "hurt" and candidate.contains("hurt", true):
                        return candidate
                    if action_name == "interact" and candidate.contains("interact", true):
                        return candidate
                    if action_name == "dodge" and candidate.contains("dodge", true):
                        return candidate
                return ""

            func _direction_index() -> int:
                if move_vector.length() <= 0.05:
                    return 0
                var angle := atan2(move_vector.y, move_vector.x)
                var step := TAU / float(DIRECTIONS)
                return posmod(int(round(angle / step)), DIRECTIONS)

            func _play_animation() -> void:
                if sprite == null or sprite.sprite_frames == null:
                    return
                var dir := _direction_index()
                var candidate := current_action
                if candidate == "" or (candidate == "idle" and move_vector.length() > 0.05):
                    candidate = "walk" if move_vector.length() > 0.05 and "walk" in ANIMATIONS else _default_animation()
                if candidate not in ANIMATIONS:
                    candidate = _default_animation()
                if candidate.is_empty():
                    return
                var animation_name := "%s_d%d" % [candidate, dir]
                if sprite.sprite_frames.has_animation(animation_name) and sprite.animation != animation_name:
                    sprite.play(animation_name)

            func _build_sprite_frames() -> void:
                var frames := SpriteFrames.new()
                if frames.has_animation("default"):
                    frames.remove_animation("default")
                for animation_name in ANIMATIONS:
                    if animation_name.is_empty():
                        continue
                    for direction in range(DIRECTIONS):
                        var full_name := "%s_d%d" % [animation_name, direction]
                        frames.add_animation(full_name)
                        frames.set_animation_speed(full_name, FPS)
                        frames.set_animation_loop(full_name, not _is_one_shot_animation(animation_name))
                        for frame in range(FRAME_COUNT):
                            var path := "res://generated/%s/%s/d%d_f%d.png" % [ASSET_NAME, animation_name, direction, frame]
                            var texture := load(path) as Texture2D
                            if texture != null:
                                frames.add_frame(full_name, texture)
                sprite.sprite_frames = frames
                var default_full := "%s_d0" % _default_animation()
                var names := frames.get_animation_names()
                if names.size() > 0:
                    sprite.animation = default_full if frames.has_animation(default_full) else names[0]
                    sprite.autoplay = sprite.animation
    """.trimIndent() + "\n"
    }

    private fun generatedEffectScript(name: String, fps: Int, frameCount: Int): String = """
        extends Node2D

        const EFFECT_NAME := "$name"
        const FPS := $fps
        const FRAME_COUNT := $frameCount
        @onready var sprite: AnimatedSprite2D = ${'$'}AnimatedSprite2D

        func _ready() -> void:
            var frames := SpriteFrames.new()
            if frames.has_animation("default"):
                frames.remove_animation("default")
            frames.add_animation("default")
            frames.set_animation_speed("default", FPS)
            frames.set_animation_loop("default", false)
            for frame in range(FRAME_COUNT):
                var texture := load("res://generated/vfx/%s/f%d.png" % [EFFECT_NAME, frame]) as Texture2D
                if texture != null:
                    frames.add_frame("default", texture)
            sprite.sprite_frames = frames
            if frames.get_frame_count("default") > 0:
                sprite.play("default")
    """.trimIndent() + "\n"

    private fun effectScene(name: String): String = """
        [gd_scene load_steps=3 format=3]

        [ext_resource type="Script" path="res://generated/vfx_$name.gd" id="1_vfx_script"]

        [node name="${safeName(name)}" type="Node2D"]
        script = ExtResource("1_vfx_script")

        [node name="AnimatedSprite2D" type="AnimatedSprite2D" parent="."]
        texture_filter = 1
    """.trimIndent() + "\n"

    private fun mapScene(name: String, scriptPath: String): String = """
        [gd_scene load_steps=2 format=3]

        [ext_resource type="Script" path="res://$scriptPath" id="1_map_script"]

        [node name="${safeName(name)}" type="Node2D"]
        script = ExtResource("1_map_script")
    """.trimIndent() + "\n"

    private fun mapScript(name: String, theme: String): String = """
        extends Node2D

        const TILE_SIZE := 48.0
        const DATA_PATH := "res://generated/$name.json"
        var data: Dictionary = {}
        var grid: Array = []
        var width := 0
        var height := 0
        var spawn := Vector2(120, 120)
        var goal := Vector2.ZERO
        var walls := Node2D.new()
        var astar := AStarGrid2D.new()

        func _ready() -> void:
            process_mode = Node.PROCESS_MODE_ALWAYS
            _load_data()
            add_child(walls)
            _build_collision()
            _build_pathfinder()
            queue_redraw()

        func _load_data() -> void:
            var file := FileAccess.open(DATA_PATH, FileAccess.READ)
            if file == null:
                push_error("GameForge map JSON missing: %s" % DATA_PATH)
                return
            var parsed = JSON.parse_string(file.get_as_text())
            if typeof(parsed) != TYPE_DICTIONARY:
                push_error("GameForge map JSON is invalid")
                return
            data = parsed
            width = int(data.get("width", 16))
            height = int(data.get("height", 10))
            grid = data.get("grid", [])
            var s = data.get("spawn", [2, height - 3])
            var g = data.get("goal", [width - 3, 2])
            spawn = _cell_center(Vector2i(int(s[0]), int(s[1])))
            goal = _cell_center(Vector2i(int(g[0]), int(g[1])))

        func _build_collision() -> void:
            for y in range(height):
                for x in range(width):
                    if _tile(x, y) == 0:
                        continue
                    var body := StaticBody2D.new()
                    body.position = _cell_center(Vector2i(x, y))
                    body.set_meta("tile", _tile(x, y))
                    var shape := CollisionShape2D.new()
                    var rect := RectangleShape2D.new()
                    rect.size = Vector2(TILE_SIZE, TILE_SIZE)
                    shape.shape = rect
                    body.add_child(shape)
                    walls.add_child(body)

        func _build_pathfinder() -> void:
            astar.region = Rect2i(0, 0, width, height)
            astar.cell_size = Vector2(TILE_SIZE, TILE_SIZE)
            astar.offset = Vector2(TILE_SIZE * 0.5, TILE_SIZE * 0.5)
            astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
            astar.update()
            for y in range(height):
                for x in range(width):
                    astar.set_point_solid(Vector2i(x, y), _tile(x, y) != 0)

        func get_path_direction(from_position: Vector2, to_position: Vector2) -> Vector2:
            if not astar:
                return from_position.direction_to(to_position)
            var from_id := _world_to_cell(from_position)
            var to_id := _world_to_cell(to_position)
            if not _valid_cell(from_id) or not _valid_cell(to_id):
                return from_position.direction_to(to_position)
            var points := astar.get_id_path(from_id, to_id)
            if points.size() < 2:
                return from_position.direction_to(to_position)
            return from_position.direction_to(_cell_center(points[1]))

        func get_spawn_position() -> Vector2:
            return spawn

        func get_goal_position() -> Vector2:
            return goal

        func get_random_walkable_position(offset: int = 0) -> Vector2:
            var base_x := int(spawn.x / TILE_SIZE)
            var base_y := int(spawn.y / TILE_SIZE)
            var candidate := Vector2i(posmod(base_x + 5 + offset, max(width, 1)), posmod(base_y + 2 + offset * 2, max(height, 1)))
            for radius in range(0, max(width, height)):
                for y in range(max(0, candidate.y - radius), min(height, candidate.y + radius + 1)):
                    for x in range(max(0, candidate.x - radius), min(width, candidate.x + radius + 1)):
                        if _tile(x, y) == 0:
                            return _cell_center(Vector2i(x, y))
            return spawn

        func _world_to_cell(position: Vector2) -> Vector2i:
            return Vector2i(floori(position.x / TILE_SIZE), floori(position.y / TILE_SIZE))

        func _cell_center(cell: Vector2i) -> Vector2:
            return Vector2((cell.x + 0.5) * TILE_SIZE, (cell.y + 0.5) * TILE_SIZE)

        func _valid_cell(cell: Vector2i) -> bool:
            return cell.x >= 0 and cell.y >= 0 and cell.x < width and cell.y < height

        func _tile(x: int, y: int) -> int:
            if y < 0 or y >= grid.size():
                return 1
            var row = grid[y]
            if typeof(row) != TYPE_ARRAY or x < 0 or x >= row.size():
                return 1
            return int(row[x])

        func _draw() -> void:
            var floor_color := _theme_color("floor")
            var wall_color := _theme_color("wall")
            var water_color := _theme_color("water")
            draw_rect(Rect2(0, 0, width * TILE_SIZE, height * TILE_SIZE), Color("10141f"))
            for y in range(height):
                for x in range(width):
                    var rect := Rect2(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    var tile := _tile(x, y)
                    var c := wall_color if tile == 1 else floor_color
                    if tile == 2:
                        c = water_color
                    draw_rect(rect, c)
                    draw_line(rect.position, Vector2(rect.end.x, rect.position.y), c.lightened(0.08), 1.0)
            draw_circle(spawn, 11.0, Color("8ee8ff"))
            draw_circle(goal, 15.0, Color("ffd166"))
            draw_arc(goal, 22.0, 0.0, TAU, 24, Color("fff1a6"), 3.0)

        func _theme_color(kind: String) -> Color:
            if "$theme" == "dungeon":
                return Color("5b6174") if kind == "floor" else (Color("2b3040") if kind == "wall" else Color("344f65"))
            if "$theme" == "town":
                return Color("90795a") if kind == "floor" else (Color("45372d") if kind == "wall" else Color("406e78"))
            return Color("5e8557") if kind == "floor" else (Color("263b2b") if kind == "wall" else Color("315d78"))
    """.trimIndent() + "\n"

    private fun characterRaster(
        size: Int,
        animation: String,
        frame: Int,
        frames: Int,
        direction: Int,
        directions: Int,
        seed: Int,
        palette: List<String>,
        role: String,
        archetype: String,
        artPrompt: String,
        visualRecipe: JSONObject?,
        motion: JSONObject?
    ): Raster {
        val r = Raster(size, size)
        val t = if (frames <= 1) 0.0 else frame.toDouble() / (frames - 1).toDouble()
        val phase = t * PI * 2.0
        val sway = sin(phase) * if (animation.contains("walk", true) || animation.contains("run", true)) 4.0 else 1.2
        val bob = if (animation.contains("idle", true) || animation.contains("walk", true)) sin(phase) * 1.6 else 0.0
        val recoil = if (animation.contains("attack", true) || animation.contains("slash", true)) sin(t * PI) * 9.0 else 0.0
        val cast = if (animation.contains("cast", true) || animation.contains("skill", true)) sin(phase) * 5.0 else 0.0
        val damage = if (animation.contains("hurt", true) || animation.contains("damage", true)) sin(t * PI) * 2.0 else 0.0
        val death = if (animation.contains("death", true)) t * 18.0 else 0.0
        val cx = size / 2.0 + damage
        val scale = size / 64.0
        val body = hexColor(palette[indexFor(seed, palette.size)])
        val accent = hexColor(palette[indexFor(seed / 7 + 2, palette.size)])
        val light = hexColor(palette[indexFor(seed / 13 + 1, palette.size)])
        val dark = hexColor("#10131a")
        val skin = hexColor("#d4a17d")
        val weapon = hexColor(if (role == "hero") "#e9eef7" else palette.last())
        val angle = (direction.toDouble() / max(1, directions)) * Math.PI * 2.0
        val facing = Vec2(cos(angle), sin(angle))
        val perp = Vec2(-facing.y, facing.x)
        val centerY = size * 0.50 + bob + death * 0.45
        val headY = centerY - 14.0 * scale
        val bodyY = centerY + 3.0 * scale
        val legY = centerY + 17.0 * scale

        if (animation.contains("death", true) && t > 0.65 && visualRecipe == null) {
            r.ellipse(cx, centerY + 8 * scale, 17 * scale, 4 * scale, dark)
            return r
        }

        val drewRecipe = visualRecipe?.let { drawVisualRecipe(r, it, size, frame, frames, animation, direction, directions, motion) } == true
        if (!drewRecipe) when (archetype) {
            "slime" -> drawSlime(r, cx, centerY, scale, body, accent, light, dark, sway)
            "skeleton" -> drawSkeleton(r, cx, headY, bodyY, legY, scale, light, dark)
            "mage" -> drawMage(r, cx, headY, bodyY, legY, scale, body, accent, light, dark, cast)
            "archer" -> drawArcher(r, cx, headY, bodyY, legY, scale, body, accent, light, dark, facing, perp)
            "robot" -> drawRobot(r, cx, headY, bodyY, legY, scale, body, accent, light, dark)
            "goblin" -> drawGoblin(r, cx, headY, bodyY, legY, scale, body, accent, light, dark)
            "dragon" -> drawDragon(r, cx, headY, bodyY, legY, scale, body, accent, light, dark, facing)
            else -> drawHumanoid(r, cx, headY, bodyY, legY, scale, body, accent, light, dark, skin, sway, cast)
        }

        val weaponReach = 21.0 * scale + recoil
        val weaponStart = Vec2(cx + facing.x * 13.0 * scale, bodyY + facing.y * 13.0 * scale)
        val weaponEnd = weaponStart + facing * weaponReach
        val weaponThickness = max(2.0, 3.0 * scale)
        r.line(weaponStart.x, weaponStart.y, weaponEnd.x, weaponEnd.y, dark, weaponThickness + 3.0)
        r.line(weaponStart.x, weaponStart.y, weaponEnd.x, weaponEnd.y, weapon, weaponThickness)
        if ((animation.contains("attack", true) || animation.contains("slash", true)) && recoil > 2.0) {
            val slashStart = weaponStart + perp * 9.0 * scale
            val slashEnd = weaponStart - perp * 9.0 * scale + facing * (25.0 * scale)
            r.line(slashStart.x, slashStart.y, slashEnd.x, slashEnd.y, accent, max(2.0, 2.5 * scale))
        }
        if (animation.contains("cast", true) || animation.contains("skill", true)) {
            r.circle(cx + facing.x * 24.0 * scale, centerY + facing.y * 24.0 * scale, max(3.0, 4.5 * scale), light)
            r.circle(cx + facing.x * 24.0 * scale, centerY + facing.y * 24.0 * scale, max(1.0, 2.0 * scale), accent)
        }
        if (animation.contains("hurt", true) || animation.contains("damage", true)) {
            r.line(cx - 8 * scale, headY - 8 * scale, cx + 8 * scale, headY + 8 * scale, accent, max(2.0, 2.0 * scale))
            r.line(cx + 8 * scale, headY - 8 * scale, cx - 8 * scale, headY + 8 * scale, accent, max(2.0, 2.0 * scale))
        }
        if (artPrompt.contains("glow", true) || animation.contains("cast", true) || animation.contains("skill", true)) {
            r.circle(cx, headY - 8 * scale, max(1.0, 3.0 * scale), light)
        }
        return r
    }

    private fun drawVisualRecipe(
        r: Raster,
        recipe: JSONObject,
        size: Int,
        frame: Int,
        frames: Int,
        animation: String,
        direction: Int,
        directions: Int,
        motion: JSONObject?
    ): Boolean {
        val layers = recipe.optJSONArray("layers") ?: return false
        if (layers.length() == 0) return false
        val t = if (frames <= 1) 0.0 else frame.toDouble() / (frames - 1).toDouble()
        val phase = t * PI * 2.0
        val move = recipe.optJSONObject("motion") ?: motion
        val bob = move?.optDouble("bob_px", 1.5) ?: 1.5
        val sway = move?.optDouble("sway_px", 1.5) ?: 1.5
        val squash = move?.optDouble("squash", 0.0) ?: 0.0
        val attackDx = move?.optDouble("attack_dx_px", 0.0) ?: 0.0
        val attackDy = move?.optDouble("attack_dy_px", 0.0) ?: 0.0
        val castPulse = move?.optDouble("cast_pulse_px", 0.0) ?: 0.0
        val attackFactor = if (animation.contains("attack", true)) sin(t * PI).coerceAtLeast(0.0) else 0.0
        val castFactor = if (animation.contains("cast", true) || animation.contains("skill", true)) sin(t * PI).coerceAtLeast(0.0) else 0.0
        val globalDx = sin(phase) * sway + attackDx * attackFactor + castPulse * castFactor
        val globalDy = sin(phase) * bob + attackDy * attackFactor
        val globalScale = (1.0 + sin(phase) * squash).coerceIn(0.65, 1.35)
        val angle = direction.toDouble() / max(1, directions) * (PI * 2.0)
        val center = size / 2.0

        fun transform(x: Double, y: Double): Vec2 {
            var px = (x * size - center) * globalScale
            var py = (y * size - center) * globalScale
            val cosA = cos(angle)
            val sinA = sin(angle)
            val rx = px * cosA - py * sinA
            val ry = px * sinA + py * cosA
            px = rx + center + globalDx
            py = ry + center + globalDy
            return Vec2(px, py)
        }

        for (i in 0 until layers.length()) {
            val layer = layers.optJSONObject(i) ?: continue
            val shape = layer.optString("shape", "ellipse").lowercase()
            val color = hexColor(layer.optString("color", "#f8fafc"))
            when (shape) {
                "rect", "round_rect" -> {
                    val w = layer.optDouble("w", 0.25)
                    val h = layer.optDouble("h", 0.25)
                    val p = transform(layer.optDouble("x", 0.375), layer.optDouble("y", 0.375))
                    r.roundRect(p.x, p.y, w * size * globalScale, h * size * globalScale, layer.optDouble("radius", 0.03) * size, color)
                }
                "circle", "ellipse" -> {
                    val p = transform(layer.optDouble("cx", 0.5), layer.optDouble("cy", 0.5))
                    val rx = layer.optDouble("rx", 0.14) * size * globalScale
                    val ry = layer.optDouble("ry", if (shape == "circle") layer.optDouble("rx", 0.14) else 0.14) * size * globalScale
                    r.ellipse(p.x, p.y, rx, ry, color)
                }
                "line" -> {
                    val a = transform(layer.optDouble("x1", 0.4), layer.optDouble("y1", 0.5))
                    val b = transform(layer.optDouble("x2", 0.6), layer.optDouble("y2", 0.5))
                    r.line(a.x, a.y, b.x, b.y, color, layer.optDouble("thickness", 0.04) * size * globalScale)
                }
            }
        }
        return true
    }

    private fun drawHumanoid(r: Raster, cx: Double, headY: Double, bodyY: Double, legY: Double, scale: Double, body: Int, accent: Int, light: Int, dark: Int, skin: Int, sway: Double, cast: Double) {
        r.ellipse(cx, legY + 5 * scale, 15 * scale, 4 * scale, dark)
        r.rect(cx - 12 * scale, bodyY - 14 * scale, 24 * scale, 29 * scale, dark)
        r.rect(cx - 9 * scale, bodyY - 11 * scale, 18 * scale, 23 * scale, body)
        r.ellipse(cx, headY, 10 * scale, 10 * scale, dark)
        r.ellipse(cx, headY + 0.5 * scale, 7 * scale, 7 * scale, skin)
        r.rect(cx - 8 * scale, headY - 6 * scale, 16 * scale, 4 * scale, accent)
        r.rect(cx - 13 * scale, bodyY - 3 * scale, 7 * scale, 17 * scale, body)
        r.rect(cx + 6 * scale, bodyY - 3 * scale, 7 * scale, 17 * scale, body)
        r.rect(cx - 9 * scale + sway, legY, 7 * scale, 16 * scale, dark)
        r.rect(cx + 2 * scale - sway, legY, 7 * scale, 16 * scale, dark)
        r.line(cx - 11 * scale, bodyY, cx - 4 * scale, bodyY + cast, light, max(2.0, 2.0 * scale))
        r.line(cx + 11 * scale, bodyY, cx + 4 * scale, bodyY - cast, light, max(2.0, 2.0 * scale))
    }

    private fun drawSlime(r: Raster, cx: Double, cy: Double, scale: Double, body: Int, accent: Int, light: Int, dark: Int, sway: Double) {
        r.ellipse(cx, cy + 15 * scale, 19 * scale, 6 * scale, dark)
        r.ellipse(cx, cy + sway, 17 * scale, 16 * scale, dark)
        r.ellipse(cx, cy - 1 * scale + sway, 14 * scale, 13 * scale, body)
        r.circle(cx - 5 * scale, cy - 2 * scale, 2.5 * scale, light)
        r.circle(cx + 5 * scale, cy - 1 * scale, 2.5 * scale, light)
        r.rect(cx - 5 * scale, cy + 4 * scale, 10 * scale, 3 * scale, accent)
    }

    private fun drawSkeleton(r: Raster, cx: Double, headY: Double, bodyY: Double, legY: Double, scale: Double, light: Int, dark: Int) {
        r.ellipse(cx, legY + 5 * scale, 14 * scale, 4 * scale, dark)
        r.circle(cx, headY, 10 * scale, dark)
        r.circle(cx, headY, 7 * scale, light)
        r.circle(cx - 3 * scale, headY - 1 * scale, 1.5 * scale, dark)
        r.circle(cx + 3 * scale, headY - 1 * scale, 1.5 * scale, dark)
        r.rect(cx - 2 * scale, headY + 2 * scale, 4 * scale, 7 * scale, dark)
        r.line(cx, headY + 7 * scale, cx, bodyY + 15 * scale, dark, max(2.0, 3.0 * scale))
        for (i in -2..2) r.line(cx - 7 * scale, bodyY + i * 3 * scale, cx + 7 * scale, bodyY + i * 3 * scale, light, max(1.0, 1.5 * scale))
        r.line(cx - 6 * scale, bodyY + 12 * scale, cx - 10 * scale, legY + 12 * scale, light, max(2.0, 3.0 * scale))
        r.line(cx + 6 * scale, bodyY + 12 * scale, cx + 10 * scale, legY + 12 * scale, light, max(2.0, 3.0 * scale))
    }

    private fun drawMage(r: Raster, cx: Double, headY: Double, bodyY: Double, legY: Double, scale: Double, body: Int, accent: Int, light: Int, dark: Int, cast: Double) {
        r.ellipse(cx, legY + 5 * scale, 17 * scale, 4 * scale, dark)
        r.circle(cx, headY, 9 * scale, dark)
        r.circle(cx, headY + 1 * scale, 6 * scale, light)
        r.rect(cx - 15 * scale, bodyY - 4 * scale, 30 * scale, 26 * scale, dark)
        r.ellipse(cx, bodyY + 9 * scale, 14 * scale, 16 * scale, body)
        r.rect(cx - 10 * scale, headY - 11 * scale, 20 * scale, 5 * scale, accent)
        r.line(cx + 9 * scale, bodyY - 2 * scale, cx + 18 * scale, bodyY - 18 * scale, dark, max(2.0, 3.0 * scale))
        r.line(cx + 18 * scale, bodyY - 18 * scale, cx + 18 * scale, bodyY + cast - 24 * scale, light, max(1.0, 2.0 * scale))
    }

    private fun drawArcher(r: Raster, cx: Double, headY: Double, bodyY: Double, legY: Double, scale: Double, body: Int, accent: Int, light: Int, dark: Int, facing: Vec2, perp: Vec2) {
        drawHumanoid(r, cx, headY, bodyY, legY, scale, body, accent, light, dark, hexColor("#c99776"), 0.0, 0.0)
        val bowCenter = Vec2(cx, bodyY)
        r.line(bowCenter.x + perp.x * 11 * scale, bowCenter.y + perp.y * 11 * scale, bowCenter.x - perp.x * 11 * scale, bowCenter.y - perp.y * 11 * scale, accent, max(1.0, 2.0 * scale))
        r.line(bowCenter.x - perp.x * 11 * scale, bowCenter.y - perp.y * 11 * scale, bowCenter.x + facing.x * 18 * scale, bowCenter.y + facing.y * 18 * scale, light, max(1.0, 1.0 * scale))
    }

    private fun drawRobot(r: Raster, cx: Double, headY: Double, bodyY: Double, legY: Double, scale: Double, body: Int, accent: Int, light: Int, dark: Int) {
        r.rect(cx - 12 * scale, bodyY - 13 * scale, 24 * scale, 27 * scale, dark)
        r.rect(cx - 9 * scale, bodyY - 10 * scale, 18 * scale, 21 * scale, body)
        r.rect(cx - 10 * scale, headY - 8 * scale, 20 * scale, 16 * scale, dark)
        r.rect(cx - 7 * scale, headY - 5 * scale, 14 * scale, 10 * scale, light)
        r.circle(cx - 4 * scale, headY, 2 * scale, accent)
        r.circle(cx + 4 * scale, headY, 2 * scale, accent)
        r.rect(cx - 9 * scale, legY, 7 * scale, 16 * scale, dark)
        r.rect(cx + 2 * scale, legY, 7 * scale, 16 * scale, dark)
    }

    private fun drawGoblin(r: Raster, cx: Double, headY: Double, bodyY: Double, legY: Double, scale: Double, body: Int, accent: Int, _light: Int, dark: Int) {
        r.ellipse(cx, legY + 5 * scale, 16 * scale, 4 * scale, dark)
        r.ellipse(cx, headY, 9 * scale, 9 * scale, dark)
        r.ellipse(cx, headY + 1 * scale, 6 * scale, 6 * scale, body)
        r.line(cx - 5 * scale, headY - 4 * scale, cx - 12 * scale, headY - 10 * scale, body, max(2.0, 3.0 * scale))
        r.line(cx + 5 * scale, headY - 4 * scale, cx + 12 * scale, headY - 10 * scale, body, max(2.0, 3.0 * scale))
        r.rect(cx - 11 * scale, bodyY - 9 * scale, 22 * scale, 22 * scale, dark)
        r.rect(cx - 8 * scale, bodyY - 6 * scale, 16 * scale, 16 * scale, body)
        r.rect(cx - 8 * scale, headY - 1 * scale, 4 * scale, 3 * scale, accent)
        r.rect(cx + 4 * scale, headY - 1 * scale, 4 * scale, 3 * scale, accent)
        r.circle(cx - 3 * scale, headY + 1 * scale, max(1.0, scale), _light)
        r.circle(cx + 5 * scale, headY + 1 * scale, max(1.0, scale), _light)
        r.rect(cx - 8 * scale, legY, 6 * scale, 15 * scale, dark)
        r.rect(cx + 2 * scale, legY, 6 * scale, 15 * scale, dark)
    }

    private fun drawDragon(r: Raster, cx: Double, headY: Double, bodyY: Double, _legY: Double, scale: Double, body: Int, accent: Int, light: Int, dark: Int, facing: Vec2) {
        r.ellipse(cx, bodyY, 19 * scale, 13 * scale, dark)
        r.ellipse(cx, bodyY - 1 * scale, 15 * scale, 10 * scale, body)
        r.ellipse(cx + facing.x * 12 * scale, headY + facing.y * 2 * scale, 9 * scale, 8 * scale, dark)
        r.ellipse(cx + facing.x * 12 * scale, headY + facing.y * 2 * scale, 6 * scale, 5 * scale, accent)
        r.line(cx - 12 * scale, bodyY - 4 * scale, cx - 24 * scale, bodyY - 15 * scale, light, max(2.0, 5.0 * scale))
        r.line(cx + 12 * scale, bodyY - 4 * scale, cx + 24 * scale, bodyY - 15 * scale, light, max(2.0, 5.0 * scale))
        r.rect(cx - 14 * scale, bodyY + 7 * scale, 7 * scale, 12 * scale, dark)
        r.rect(cx + 7 * scale, bodyY + 7 * scale, 7 * scale, 12 * scale, dark)
        r.circle(cx - 10 * scale, _legY + 14 * scale, max(1.0, scale), light)
        r.circle(cx + 10 * scale, _legY + 14 * scale, max(1.0, scale), light)
        r.circle(cx + facing.x * 18 * scale, headY + facing.y * 2 * scale, 2 * scale, light)
    }

    private fun effectRaster(size: Int, name: String, frame: Int, frames: Int, seed: Int, palette: List<String>): Raster {
        val r = Raster(size, size)
        val p = if (frames <= 1) 0.0 else frame.toDouble() / (frames - 1).toDouble()
        val c = size / 2.0
        val primary = hexColor(palette[abs(seed + frame * 13) % palette.size])
        val secondary = hexColor(palette[abs(seed / 11 + 2) % palette.size])
        val radius = 6.0 + (size * 0.32) * p
        when (name.lowercase()) {
            "slash" -> {
                for (i in 0 until 7) {
                    val a = -1.2 + p * 2.0 + i * 0.07
                    val x1 = c + cos(a) * (size * 0.12)
                    val y1 = c + sin(a) * (size * 0.12)
                    val x2 = c + cos(a) * (size * 0.42)
                    val y2 = c + sin(a) * (size * 0.42)
                    r.line(x1, y1, x2, y2, if (i % 2 == 0) primary else secondary, max(1.0, size * 0.024))
                }
            }
            "heal" -> {
                r.circle(c, c, radius, secondary)
                r.rect(c - size * 0.06, c - radius * 0.95, size * 0.12, radius * 1.9, primary)
                r.rect(c - radius * 0.95, c - size * 0.06, radius * 1.9, size * 0.12, primary)
            }
            "level_up" -> {
                r.line(c, size * 0.16, c - size * 0.20, size * 0.55, primary, max(2.0, size * 0.05))
                r.line(c, size * 0.16, c + size * 0.20, size * 0.55, primary, max(2.0, size * 0.05))
                r.line(c - size * 0.20, size * 0.55, c - size * 0.08, size * 0.45, secondary, max(1.0, size * 0.025))
                r.line(c + size * 0.20, size * 0.55, c + size * 0.08, size * 0.45, secondary, max(1.0, size * 0.025))
            }
            "fireball" -> {
                r.circle(c - size * 0.14 * p, c, radius * 0.9, secondary)
                r.circle(c - size * 0.18 * p, c, radius * 0.55, primary)
                r.circle(c + size * 0.20, c, max(2.0, radius * 0.25), secondary)
            }
            "teleport" -> {
                r.circle(c, c, radius, primary)
                r.circle(c, c, radius * 0.62, secondary)
                r.circle(c, c, radius * 0.27, hexColor(palette.last()))
            }
            else -> {
                r.circle(c, c, radius, primary)
                r.circle(c, c, radius * 0.48, secondary)
                r.circle(c, c, radius * 0.22, hexColor(palette.last()))
            }
        }
        return r
    }

    private fun iconRaster(size: Int, name: String, seed: Int, palette: List<String>): Raster {
        val r = Raster(size, size)
        val main = hexColor(palette[abs(seed) % palette.size])
        val accent = hexColor(palette[abs(seed / 7) % palette.size])
        val dark = hexColor("#131722")
        r.roundRect(4.0, 4.0, size - 8.0, size - 8.0, 8.0, dark)
        when (name.lowercase()) {
            "sword" -> {
                r.line(size * .25, size * .75, size * .72, size * .28, accent, size * .12)
                r.line(size * .29, size * .79, size * .80, size * .27, main, size * .07)
                r.line(size * .20, size * .66, size * .39, size * .85, accent, size * .06)
            }
            "armor" -> r.rect(size * .26, size * .22, size * .48, size * .56, main)
            "potion" -> {
                r.rect(size * .38, size * .18, size * .24, size * .12, accent)
                r.ellipse(size * .50, size * .57, size * .22, size * .27, main)
            }
            else -> r.circle(size / 2.0, size / 2.0, size * .28, main)
        }
        r.circle(size * .50, size * .50, size * .08, accent)
        return r
    }

    private fun mapPreviewPng(grid: List<List<Int>>, tile: Int, theme: String, spawn: Pair<Int, Int>, goal: Pair<Int, Int>): ByteArray {
        val r = Raster(grid[0].size * tile, grid.size * tile)
        val floor = hexColor(if (theme == "dungeon") "#5b6174" else if (theme == "town") "#90795a" else "#5e8557")
        val wall = hexColor(if (theme == "dungeon") "#2b3040" else if (theme == "town") "#45372d" else "#263b2b")
        val water = hexColor(if (theme == "dungeon") "#344f65" else "#315d78")
        for (y in grid.indices) for (x in grid[y].indices) {
            val color = when (grid[y][x]) { 1 -> wall; 2 -> water; else -> floor }
            r.rect(x * tile.toDouble(), y * tile.toDouble(), tile.toDouble(), tile.toDouble(), color)
        }
        r.circle((spawn.first + .5) * tile, (spawn.second + .5) * tile, tile * .20, hexColor("#8ee8ff"))
        r.circle((goal.first + .5) * tile, (goal.second + .5) * tile, tile * .22, hexColor("#ffd166"))
        return encodePng(r.width, r.height, r.pixels)
    }

    private data class AuthoredLayout(val grid: List<List<Int>>, val spawn: Pair<Int, Int>?, val goal: Pair<Int, Int>?)

    private fun parseAuthoredLayout(rows: JSONArray?): AuthoredLayout? {
        if (rows == null || rows.length() < 10) return null
        val raw = (0 until rows.length()).map { rows.optString(it) }
        val width = raw.maxOfOrNull { it.length }?.coerceIn(12, 96) ?: return null
        val height = raw.size.coerceIn(10, 64)
        val grid = MutableList(height) { y ->
            MutableList(width) { x ->
                when (raw[y].getOrNull(x) ?: '#') {
                    '.', ' ', 'S', 'G', 'E', 'L' -> 0
                    '~', 'W' -> 2
                    else -> 1
                }
            }
        }
        var spawn: Pair<Int, Int>? = null
        var goal: Pair<Int, Int>? = null
        for (y in 0 until height) for (x in 0 until min(width, raw[y].length)) {
            when (raw[y][x]) {
                'S' -> spawn = x to y
                'G' -> goal = x to y
            }
        }
        return AuthoredLayout(grid, spawn, goal)
    }

    private fun carveMap(width: Int, height: Int, rooms: Int, seed: Int, theme: String): List<List<Int>> {
        val grid = MutableList(height) { MutableList(width) { 1 } }
        var x = 2
        var y = height - 3
        grid[y][x] = 0
        var state = if (seed == 0) 0x6D2B79F5 else seed
        fun nextInt(bound: Int): Int {
            state = state xor (state shl 13)
            state = state xor (state ushr 17)
            state = state xor (state shl 5)
            val positive = state and Int.MAX_VALUE
            return if (bound <= 1) 0 else positive % bound
        }
        repeat(rooms * 22) {
            grid[y][x] = 0
            if (nextInt(3) == 0) {
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = (x + dx).coerceIn(1, width - 2)
                    val ny = (y + dy).coerceIn(1, height - 2)
                    grid[ny][nx] = 0
                }
            }
            when (nextInt(4)) {
                0 -> x = (x + 1).coerceAtMost(width - 3)
                1 -> x = (x - 1).coerceAtLeast(2)
                2 -> y = (y - 1).coerceAtLeast(2)
                else -> y = (y + 1).coerceAtMost(height - 3)
            }
        }
        while (x < width - 3) { x++; grid[y][x] = 0 }
        while (y > 2) { y--; grid[y][x] = 0 }
        grid[height - 3][2] = 0
        grid[2][width - 3] = 0
        repeat(rooms * 2) {
            val rx = 2 + nextInt((width - 4).coerceAtLeast(1))
            val ry = 2 + nextInt((height - 4).coerceAtLeast(1))
            val rw = 2 + nextInt(5)
            val rh = 2 + nextInt(4)
            for (yy in ry until (ry + rh).coerceAtMost(height - 1)) {
                for (xx in rx until (rx + rw).coerceAtMost(width - 1)) grid[yy][xx] = 0
            }
        }
        for (yy in 1 until height - 1) for (xx in 1 until width - 1) {
            if (theme != "dungeon" && grid[yy][xx] == 1 && nextInt(20) == 0) grid[yy][xx] = 2
            if (grid[yy][xx] == 2 && (grid[yy - 1][xx] == 0 || grid[yy + 1][xx] == 0 || grid[yy][xx - 1] == 0 || grid[yy][xx + 1] == 0)) grid[yy][xx] = 1
        }
        return grid
    }

    private fun findNearestWalkable(grid: List<List<Int>>, startX: Int, startY: Int): Pair<Int, Int> {
        if (grid[startY][startX] == 0) return startX to startY
        val maxRadius = max(grid.size, grid[0].size)
        for (r in 1..maxRadius) {
            for (y in (startY - r)..(startY + r)) for (x in (startX - r)..(startX + r)) {
                if (y in grid.indices && x in grid[0].indices && grid[y][x] == 0) return x to y
            }
        }
        return 1 to 1
    }

    private fun paletteFromRequest(request: JSONObject, role: String, hint: String): List<String> {
        val arr = request.optJSONArray("palette")
        if (arr != null) {
            val values = (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { value -> value.matches(Regex("#[0-9a-fA-F]{6}")) } }.take(8)
            if (values.size >= 4) return values
        }
        val seed = stableSeed(role + ":" + hint)
        return paletteFromSeed(seed.toInt())
    }

    private fun paletteFromSeed(seed: Int): List<String> {
        val palettes = listOf(
            listOf("#38bdf8", "#22c55e", "#facc15", "#c084fc", "#f8fafc", "#1f2937", "#d4a17d", "#10131a"),
            listOf("#fb7185", "#f59e0b", "#fde68a", "#60a5fa", "#f8fafc", "#312e81", "#d4a17d", "#111827"),
            listOf("#34d399", "#2dd4bf", "#fbbf24", "#a78bfa", "#f1f5f9", "#334155", "#d4a17d", "#0f172a"),
            listOf("#f472b6", "#fb7185", "#fef08a", "#7dd3fc", "#fafafa", "#3f3f46", "#d4a17d", "#111111")
        )
        return palettes[indexFor(seed, palettes.size)]
    }

    private fun inferArchetype(text: String): String {
        val lower = text.lowercase()
        return when {
            "slime" in lower -> "slime"
            "skeleton" in lower || "undead" in lower -> "skeleton"
            "mage" in lower || "wizard" in lower || "sorcer" in lower -> "mage"
            "archer" in lower || "ranger" in lower -> "archer"
            "robot" in lower || "mech" in lower -> "robot"
            "goblin" in lower -> "goblin"
            "dragon" in lower -> "dragon"
            else -> "humanoid"
        }
    }

    private fun themeFor(spec: GameSpec): String = when {
        spec.genre.contains("horror", true) -> "dungeon"
        spec.genre.contains("rpg", true) || spec.genre.contains("mmorpg", true) -> "forest"
        spec.genre.contains("strategy", true) -> "dungeon"
        else -> "plains"
    }

    private fun characterSvg(size: Int, animation: String, frame: Int, frames: Int, direction: Int, directions: Int, palette: List<String>, role: String, archetype: String, artPrompt: String, visualRecipe: JSONObject? = null): String {
        if (visualRecipe != null && visualRecipe.optJSONArray("layers")?.length() ?: 0 > 0) {
            return visualRecipeSvg(size, animation, frame, frames, direction, directions, role, archetype, artPrompt, visualRecipe)
        }
        val t = if (frames <= 1) 0.0 else frame.toDouble() / (frames - 1).toDouble()
        val bob = if (animation == "idle" || animation == "walk") sin(t * PI * 2) * 1.5 else 0.0
        val angle = direction.toDouble() / max(1, directions) * 360.0
        val body = palette[0]
        val accent = palette[(palette.size / 2).coerceAtMost(palette.lastIndex)]
        val light = palette[2.coerceAtMost(palette.lastIndex)]
        return """
            <svg xmlns="http://www.w3.org/2000/svg" width="$size" height="$size" viewBox="0 0 $size $size" shape-rendering="crispEdges">
              <g transform="translate(${size / 2.0},${size / 2.0 + bob}) rotate($angle) translate(${-size / 2.0},${-size / 2.0})">
                <ellipse cx="${size / 2}" cy="${size - 10}" rx="15" ry="5" fill="#090b10" opacity="0.38"/>
                <rect x="21" y="18" width="22" height="30" rx="4" fill="#10131a"/>
                <rect x="24" y="21" width="16" height="22" rx="3" fill="$body"/>
                <circle cx="32" cy="16" r="10" fill="#10131a"/>
                <circle cx="32" cy="16" r="7" fill="#d4a17d"/>
                <rect x="24" y="7" width="16" height="4" fill="$accent"/>
                <rect x="22" y="44" width="8" height="14" fill="#10131a"/>
                <rect x="34" y="44" width="8" height="14" fill="#10131a"/>
                <path d="M43 31 L58 15" stroke="#10131a" stroke-width="7" stroke-linecap="square"/>
                <path d="M44 30 L57 16" stroke="$light" stroke-width="3" stroke-linecap="square"/>
                ${if (animation == "attack" && t > 0.25) "<path d=\"M46 20 Q60 34 46 50\" fill=\"none\" stroke=\"$accent\" stroke-width=\"3\"/>" else ""}
              </g>
              <metadata>${escapeXml("$role/$archetype/$artPrompt")}</metadata>
            </svg>
        """.trimIndent() + "\n"
    }

    private fun visualRecipeSvg(size: Int, animation: String, frame: Int, frames: Int, direction: Int, directions: Int, role: String, archetype: String, artPrompt: String, recipe: JSONObject): String {
        val t = if (frames <= 1) 0.0 else frame.toDouble() / (frames - 1).toDouble()
        val phase = t * PI * 2.0
        val motion = recipe.optJSONObject("motion")
        val bob = motion?.optDouble("bob_px", 1.5) ?: 1.5
        val sway = motion?.optDouble("sway_px", 1.5) ?: 1.5
        val scale = 1.0 + sin(phase) * (motion?.optDouble("squash", 0.0) ?: 0.0)
        val dx = sin(phase) * sway
        val dy = sin(phase) * bob
        val angle = direction.toDouble() / max(1, directions) * 360.0
        val layers = recipe.optJSONArray("layers") ?: JSONArray()
        val shapes = buildString {
            for (i in 0 until layers.length()) {
                val layer = layers.optJSONObject(i) ?: continue
                val color = escapeXml(layer.optString("color", "#f8fafc"))
                when (layer.optString("shape", "ellipse").lowercase()) {
                    "rect", "round_rect" -> {
                        val x = layer.optDouble("x", 0.375) * size
                        val y = layer.optDouble("y", 0.375) * size
                        val w = layer.optDouble("w", 0.25) * size
                        val h = layer.optDouble("h", 0.25) * size
                        val radius = layer.optDouble("radius", 0.03) * size
                        append("<rect x=\"$x\" y=\"$y\" width=\"$w\" height=\"$h\" rx=\"$radius\" fill=\"$color\"/>")
                    }
                    "circle", "ellipse" -> {
                        val cx = layer.optDouble("cx", 0.5) * size
                        val cy = layer.optDouble("cy", 0.5) * size
                        val rx = layer.optDouble("rx", 0.14) * size
                        val ry = layer.optDouble("ry", if (layer.optString("shape", "ellipse").equals("circle", true)) rx else 0.14 * size)
                        append("<ellipse cx=\"$cx\" cy=\"$cy\" rx=\"$rx\" ry=\"$ry\" fill=\"$color\"/>")
                    }
                    "line" -> {
                        val x1 = layer.optDouble("x1", 0.4) * size
                        val y1 = layer.optDouble("y1", 0.5) * size
                        val x2 = layer.optDouble("x2", 0.6) * size
                        val y2 = layer.optDouble("y2", 0.5) * size
                        val thickness = layer.optDouble("thickness", 0.04) * size
                        append("<line x1=\"$x1\" y1=\"$y1\" x2=\"$x2\" y2=\"$y2\" stroke=\"$color\" stroke-width=\"$thickness\" stroke-linecap=\"round\"/>")
                    }
                }
            }
        }
        return """
            <svg xmlns="http://www.w3.org/2000/svg" width="$size" height="$size" viewBox="0 0 $size $size" shape-rendering="crispEdges">
              <g transform="translate(${size / 2.0 + dx},${size / 2.0 + dy}) scale($scale) rotate($angle) translate(${-size / 2.0},${-size / 2.0})">$shapes</g>
              <metadata>${escapeXml("$role/$archetype/$artPrompt visual_recipe animation=$animation frame=$frame/$frames direction=$direction/$directions")}</metadata>
            </svg>
        """.trimIndent() + "\n"
    }

    private fun effectSvg(size: Int, name: String, frame: Int, frames: Int, palette: List<String>): String {
        val c = size / 2.0
        val p = if (frames <= 1) 0.0 else frame.toDouble() / (frames - 1)
        val primary = palette[0]
        val secondary = palette[min(2, palette.lastIndex)]
        val radius = 8 + size * 0.34 * p
        val body = when (name.lowercase()) {
            "slash" -> "<path d=\"M18 ${size - 18} Q$c ${18 + frame * 2} ${size - 18} 18\" fill=\"none\" stroke=\"$primary\" stroke-width=\"8\"/>"
            "heal" -> "<path d=\"M$c 18 V${size - 18} M18 $c H${size - 18}\" stroke=\"$primary\" stroke-width=\"9\"/>"
            "level_up" -> "<path d=\"M$c 18 L${c - 18} ${size - 25} M$c 18 L${c + 18} ${size - 25}\" stroke=\"$primary\" stroke-width=\"7\"/>"
            else -> "<circle cx=\"$c\" cy=\"$c\" r=\"${max(2.0, radius / 4)}\" fill=\"$secondary\"/>"
        }
        return "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"$size\" height=\"$size\" viewBox=\"0 0 $size $size\" shape-rendering=\"geometricPrecision\"><circle cx=\"$c\" cy=\"$c\" r=\"$radius\" fill=\"none\" stroke=\"$secondary\" stroke-opacity=\"${0.18 + p * 0.2}\" stroke-width=\"3\"/>$body</svg>\n"
    }

    private fun tilesetSvg(tile: Int, columns: Int, rows: Int, palette: List<String>): String {
        val cells = buildString {
            for (y in 0 until rows) for (x in 0 until columns) {
                val c = palette[(x + y * columns) % palette.size]
                append("<rect x=\"${x * tile}\" y=\"${y * tile}\" width=\"$tile\" height=\"$tile\" fill=\"$c\"/>")
            }
        }
        return "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"${columns * tile}\" height=\"${rows * tile}\" viewBox=\"0 0 ${columns * tile} ${rows * tile}\" shape-rendering=\"crispEdges\">$cells</svg>\n"
    }

    private fun iconSvg(size: Int, _name: String, palette: List<String>): String {
        val main = palette[0]
        val accent = palette[min(2, palette.lastIndex)]
        return """
            <svg xmlns="http://www.w3.org/2000/svg" width="$size" height="$size" viewBox="0 0 $size $size" shape-rendering="crispEdges">
              <rect x="4" y="4" width="${size - 8}" height="${size - 8}" rx="10" fill="#131722" stroke="$accent" stroke-width="4"/>
              <path d="M${size / 2} 12 L${size - 17} ${size - 20} L${size / 2} ${size - 12} L17 ${size - 20} Z" fill="$main"/>
              <circle cx="${size / 2}" cy="${size / 2}" r="${size / 6}" fill="$accent"/>
              <metadata>${escapeXml(_name)}</metadata>
            </svg>
        """.trimIndent() + "\n"
    }

    private fun normalizeAnimationName(value: String): String =
        safeName(value).take(32).ifBlank { "idle" }

    private fun indexFor(value: Int, size: Int): Int {
        if (size <= 1) return 0
        return ((value.toLong() and 0x7fffffffL) % size.toLong()).toInt()
    }

    private fun escapeXml(value: String): String =
        value.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")

    private fun safeName(value: String): String = value.trim().lowercase()
        .replace(Regex("[^a-z0-9_\\-]+"), "_")
        .trim('_')
        .ifBlank { "generated_asset" }
        .take(64)

    private fun stableSeed(value: String): Long {
        var h = 1125899906842597L
        for (c in value) h = 31L * h + c.code
        return h and 0x7FFFFFFFL
    }

    private fun escapeGdString(value: String): String = value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").take(120)

    private fun hexColor(hex: String): Int {
        val clean = hex.removePrefix("#")
        val value = clean.toLongOrNull(16) ?: 0xFF00FFFF
        return (((value and 0xFFFFFF) shl 8) or 0xFF).toInt()
    }


    private class Raster(val width: Int, val height: Int) {
        val pixels = IntArray(width * height) { 0x00000000 }

        fun set(x: Int, y: Int, color: Int) {
            if (x !in 0 until width || y !in 0 until height) return
            pixels[y * width + x] = color
        }

        fun rect(x: Double, y: Double, w: Double, h: Double, color: Int) {
            fillRect(x, y, w, h, color)
        }

        fun roundRect(x: Double, y: Double, w: Double, h: Double, radius: Double, color: Int) {
            val minX = x.toInt()
            val maxX = (x + w).toInt()
            val minY = y.toInt()
            val maxY = (y + h).toInt()
            for (yy in minY..maxY) for (xx in minX..maxX) {
                val dx = max(max(x - xx, 0.0), max(xx - (x + w), 0.0))
                val dy = max(max(y - yy, 0.0), max(yy - (y + h), 0.0))
                if (sqrt(dx * dx + dy * dy) <= radius) set(xx, yy, color)
            }
        }

        fun fillRect(x: Double, y: Double, w: Double, h: Double, color: Int) {
            val minX = x.toInt().coerceAtLeast(0)
            val maxX = (x + w - 1).toInt().coerceAtMost(width - 1)
            val minY = y.toInt().coerceAtLeast(0)
            val maxY = (y + h - 1).toInt().coerceAtMost(height - 1)
            if (maxX < minX || maxY < minY) return
            for (yy in minY..maxY) for (xx in minX..maxX) set(xx, yy, color)
        }

        fun ellipse(cx: Double, cy: Double, rx: Double, ry: Double, color: Int) {
            val minX = max(0, (cx - rx).toInt() - 1)
            val maxX = min(width - 1, (cx + rx).toInt() + 1)
            val minY = max(0, (cy - ry).toInt() - 1)
            val maxY = min(height - 1, (cy + ry).toInt() + 1)
            for (y in minY..maxY) for (x in minX..maxX) {
                val nx = (x + 0.5 - cx) / rx
                val ny = (y + 0.5 - cy) / ry
                if (nx * nx + ny * ny <= 1.0) set(x, y, color)
            }
        }

        fun circle(cx: Double, cy: Double, radius: Double, color: Int) = ellipse(cx, cy, radius, radius, color)

        fun line(x1: Double, y1: Double, x2: Double, y2: Double, color: Int, thickness: Double) {
            val steps = max(1, max(abs(x2 - x1), abs(y2 - y1)).toInt() * 2)
            for (i in 0..steps) {
                val t = i.toDouble() / steps.toDouble()
                circle(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t, max(0.5, thickness / 2.0), color)
            }
        }

        fun blit(other: Raster, dx: Int, dy: Int) {
            for (y in 0 until other.height) for (x in 0 until other.width) {
                val destX = x + dx
                val destY = y + dy
                if (destX in 0 until width && destY in 0 until height) {
                    pixels[destY * width + destX] = other.pixels[y * other.width + x]
                }
            }
        }
    }

    private fun encodePng(width: Int, height: Int, pixels: IntArray): ByteArray {
        require(pixels.size == width * height)
        val raw = ByteArray((width * 4 + 1) * height)
        var cursor = 0
        for (y in 0 until height) {
            raw[cursor++] = 0
            for (x in 0 until width) {
                val rgba = pixels[y * width + x]
                raw[cursor++] = ((rgba ushr 24) and 0xFF).toByte()
                raw[cursor++] = ((rgba ushr 16) and 0xFF).toByte()
                raw[cursor++] = ((rgba ushr 8) and 0xFF).toByte()
                raw[cursor++] = (rgba and 0xFF).toByte()
            }
        }
        val deflater = Deflater(6)
        deflater.setInput(raw)
        deflater.finish()
        val compressed = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (!deflater.finished()) {
            val count = deflater.deflate(buffer)
            if (count <= 0) break
            compressed.write(buffer, 0, count)
        }
        deflater.end()

        val output = ByteArrayOutputStream()
        output.write(byteArrayOf(137.toByte(), 80, 78, 71, 13, 10, 26, 10))
        writePngChunk(output, "IHDR", ByteBuffer.allocate(13).order(ByteOrder.BIG_ENDIAN)
            .putInt(width).putInt(height).put(8).put(6).put(0).put(0).put(0).array())
        writePngChunk(output, "IDAT", compressed.toByteArray())
        writePngChunk(output, "IEND", ByteArray(0))
        return output.toByteArray()
    }

    private fun writePngChunk(output: ByteArrayOutputStream, type: String, data: ByteArray) {
        val typeBytes = type.toByteArray(Charsets.US_ASCII)
        val len = ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(data.size).array()
        output.write(len)
        output.write(typeBytes)
        output.write(data)
        val crc = CRC32()
        crc.update(typeBytes)
        crc.update(data)
        output.write(ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(crc.value.toInt()).array())
    }
}
