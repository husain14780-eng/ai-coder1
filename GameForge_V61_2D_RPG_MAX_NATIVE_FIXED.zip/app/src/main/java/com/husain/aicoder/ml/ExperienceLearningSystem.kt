package com.husain.aicoder.ml

import android.content.Context
import com.husain.aicoder.memory.EpisodeStore
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/** Persistent experience layer. Qwen weights are never modified by this component. */
class ExperienceLearningSystem(context: Context) {
    private val store = EpisodeStore(context)
    private val dataset = File(context.filesDir, "learning_dataset.jsonl")
    private val qLearning = QLearning()
    private val qTableFile = File(context.filesDir, "learning_q_table.json")
    private val stepCount = AtomicLong(0)
    private val labeled = mutableListOf<Sample>()
    private val unlabeled = mutableListOf<DoubleArray>()
    private val selfSupervisedTexts = mutableListOf<List<String>>()

    init {
        restorePersistentState()
    }

    fun recordObservation(observation: String) = store.append("learning_observation", observation)

    @Synchronized
    fun recordTransition(state: String, action: String, reward: Double, nextState: String, done: Boolean) {
        qLearning.update(RLTransition(state, action, reward, nextState, done))
        persistQTable()
        val features = features(nextState)
        synchronized(labeled) { labeled += Sample(features, if (reward > 0.5) 1.0 else 0.0); trim(labeled, 4000) }
        synchronized(unlabeled) { unlabeled += features; trim(unlabeled, 4000) }
        synchronized(selfSupervisedTexts) { selfSupervisedTexts += nextState.split(Regex("\\s+")).filter { it.isNotBlank() }; trim(selfSupervisedTexts, 1000) }
        val obj = JSONObject()
            .put("type", "transition")
            .put("state", state.take(5000))
            .put("action", action.take(2000))
            .put("reward", reward)
            .put("next_state", nextState.take(5000))
            .put("done", done)
            .put("timestamp_ms", System.currentTimeMillis())
        synchronized(dataset) { dataset.appendText(obj.toString() + "\n") }
        stepCount.incrementAndGet()
    }

    fun chooseRlAction(state: String, actions: List<String>): String = qLearning.chooseAction(state, actions)
    fun steps(): Long = stepCount.get()
    fun datasetFile(): File = dataset
    fun qTable(): Map<String, Map<String, Double>> = qLearning.export()
    fun labeledSamples(): List<Sample> = synchronized(labeled) { labeled.takeLast(2000).map { Sample(it.x.copyOf(), it.y) } }
    fun unlabeledFeatures(): List<DoubleArray> = synchronized(unlabeled) { unlabeled.takeLast(2000).map { it.copyOf() } }
    fun selfSupervisedTokens(): List<List<String>> = synchronized(selfSupervisedTexts) { selfSupervisedTexts.takeLast(500).toList() }

    fun appendLesson(goal: String, observation: String, failure: String, cause: String, fix: String, result: String) {
        val obj = JSONObject()
            .put("type", "coding_lesson")
            .put("goal", goal)
            .put("observation", observation)
            .put("failure", failure)
            .put("cause", cause)
            .put("fix", fix)
            .put("result", result)
            .put("timestamp_ms", System.currentTimeMillis())
        synchronized(dataset) { dataset.appendText(obj.toString() + "\n") }
    }

    fun features(text: String): DoubleArray {
        val lower = text.lowercase()
        return doubleArrayOf(
            text.length.toDouble().coerceAtMost(20000.0) / 20000.0,
            lower.count { it == 'x' }.toDouble().coerceAtMost(100.0) / 100.0,
            lower.count { it == 'y' }.toDouble().coerceAtMost(100.0) / 100.0,
            if (lower.contains("jump")) 1.0 else 0.0,
            if (lower.contains("fall") || lower.contains("dead")) 1.0 else 0.0,
            if (lower.contains("finish") || lower.contains("goal")) 1.0 else 0.0,
            if (lower.contains("error") || lower.contains("exception")) 1.0 else 0.0,
            if (lower.contains("test") || lower.contains("pass")) 1.0 else 0.0
        )
    }

    fun status(): String = "experiences=${stepCount.get()} datasetBytes=${dataset.length()} qStates=${qLearning.export().size}"

    private fun restorePersistentState() {
        runCatching {
            if (qTableFile.isFile) {
                val root = JSONObject(qTableFile.readText())
                val table = mutableMapOf<String, Map<String, Double>>()
                val keys = root.keys()
                while (keys.hasNext()) {
                    val state = keys.next()
                    val obj = root.optJSONObject(state) ?: continue
                    val actions = mutableMapOf<String, Double>()
                    val ak = obj.keys()
                    while (ak.hasNext()) {
                        val action = ak.next()
                        actions[action] = obj.optDouble(action, 0.0)
                    }
                    table[state] = actions
                }
                qLearning.importTable(table)
            }

            if (dataset.isFile) {
                dataset.useLines { lines ->
                    lines.toList().takeLast(1200).forEach { line ->
                        val o = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
                        if (o.optString("type") == "transition") {
                            val next = o.optString("next_state")
                            if (next.isNotBlank()) {
                                val f = features(next)
                                synchronized(labeled) { labeled += Sample(f, if (o.optDouble("reward") > 0.5) 1.0 else 0.0) }
                                synchronized(unlabeled) { unlabeled += f }
                                synchronized(selfSupervisedTexts) { selfSupervisedTexts += next.split(Regex("\\s+")).filter { it.isNotBlank() } }
                                stepCount.incrementAndGet()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun persistQTable() {
        val root = JSONObject()
        qLearning.export().forEach { (state, actions) ->
            val a = JSONObject()
            actions.forEach { (action, value) -> a.put(action, value) }
            root.put(state, a)
        }
        qTableFile.writeText(root.toString())
    }

    private fun <T> trim(list: MutableList<T>, maxSize: Int) {
        val excess = list.size - maxSize
        if (excess > 0) repeat(excess) { list.removeAt(0) }
    }
}
