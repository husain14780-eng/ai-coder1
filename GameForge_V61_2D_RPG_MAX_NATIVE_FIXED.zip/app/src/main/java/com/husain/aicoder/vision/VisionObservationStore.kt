package com.husain.aicoder.vision

import android.content.Context
import org.json.JSONObject
import java.io.File

class VisionObservationStore(context: Context) {
    private val file = File(context.filesDir, "vision/latest_observation.json")
    @Synchronized fun write(observation: JSONObject) {
        file.parentFile?.mkdirs(); file.writeText(observation.toString(2))
    }
    fun read(): JSONObject = if (file.isFile) runCatching { JSONObject(file.readText()) }.getOrElse { JSONObject() } else JSONObject()
}
