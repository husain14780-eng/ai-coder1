package com.husain.aicoder.vision

import org.json.JSONArray
import org.json.JSONObject

/** Persistent compact world-state representation used between perception and planning passes. */
class WorldModel(private val maxEvents: Int = 80) {
    private val state = JSONObject()
    private val events = ArrayDeque<JSONObject>()

    @Synchronized
    fun update(observation: JSONObject, source: String) {
        val event = JSONObject().put("source", source).put("observation", observation).put("time", System.currentTimeMillis())
        events.addLast(event)
        while (events.size > maxEvents) events.removeFirst()
        state.put("last_observation", observation)
        state.put("last_source", source)
        state.put("uncertainty", estimateUncertainty(observation))
        state.put("updated_at_ms", System.currentTimeMillis())
    }

    @Synchronized
    fun snapshot(): JSONObject {
        val recent = JSONArray()
        events.forEach { recent.put(JSONObject(it.toString())) }
        return JSONObject(state.toString()).put("recent_events", recent)
    }

    private fun estimateUncertainty(o: JSONObject): Double {
        var u = 0.35
        if (o.length() <= 3) u += 0.25
        if (o.optString("player_state").isBlank()) u += 0.1
        if (o.optBoolean("semantic_understanding_missing", false)) u += 0.2
        return u.coerceIn(0.0, 1.0)
    }
}
