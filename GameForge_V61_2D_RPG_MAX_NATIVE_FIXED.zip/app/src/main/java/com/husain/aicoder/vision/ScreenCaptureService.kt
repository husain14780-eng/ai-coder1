package com.husain.aicoder.vision

import android.app.*
import android.content.pm.ServiceInfo
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.husain.aicoder.SCREEN_CAPTURE_START"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_STOP = "com.husain.aicoder.SCREEN_CAPTURE_STOP"
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var handler: Handler? = null
    private var frameNo = 0
    private lateinit var observations: VisionObservationStore
    private val perception = ScreenPerception()
    private val worldModel = WorldModel()
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { releaseCapture(stopProjection = false) }
    }

    override fun onCreate() {
        super.onCreate()
        observations = VisionObservationStore(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("vision", "AI vision", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopCapture(); stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START) {
            val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
            if (data != null) startCapture(code, data)
        }
        return START_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        releaseCapture(stopProjection = true)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(91, Notification.Builder(this, "vision").setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("AI Coder screen perception").setContentText("Screen capture active").build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(91, Notification.Builder(this, "vision").setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("AI Coder screen perception").setContentText("Screen capture active").build())
        }
        val mgr = getSystemService(MediaProjectionManager::class.java)
        projection = mgr.getMediaProjection(resultCode, data)
        val p = projection ?: error("MediaProjection unavailable")
        p.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))
        val dm = resources.displayMetrics
        val width = dm.widthPixels; val height = dm.heightPixels; val density = dm.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = p.createVirtualDisplay("AI-Coder-Vision", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
        handler = Handler(Looper.getMainLooper())
        reader?.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (frameNo++ % 3 != 0) return@setOnImageAvailableListener
                val plane = image.planes[0]
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(plane.buffer)
                saveFrame(bitmap, frameNo)
                val observation = perception.analyze(bitmap).put("frame_file", File(filesDir, "vision/frames/%08d.jpg".format(frameNo)).absolutePath)
                worldModel.update(observation, "screen_capture")
                observations.write(observation.put("world_model", worldModel.snapshot()))
                bitmap.recycle()
            } finally { image.close() }
        }, handler)
    }

    private fun saveFrame(bitmap: Bitmap, number: Int) {
        val dir = File(filesDir, "vision/frames").apply { mkdirs() }
        val out = File(dir, "%08d.jpg".format(number))
        FileOutputStream(out).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 65, it) }
        val files = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: return
        files.drop(120).forEach { it.delete() }
    }

    private fun releaseCapture(stopProjection: Boolean) {
        reader?.close(); reader = null
        display?.release(); display = null
        projection?.let { p ->
            runCatching { p.unregisterCallback(projectionCallback) }
            if (stopProjection) runCatching { p.stop() }
        }
        projection = null
        handler = null
    }

    private fun stopCapture() = releaseCapture(stopProjection = true)

    override fun onDestroy() { stopCapture(); super.onDestroy() }
    override fun onBind(intent: Intent?) = null
}
