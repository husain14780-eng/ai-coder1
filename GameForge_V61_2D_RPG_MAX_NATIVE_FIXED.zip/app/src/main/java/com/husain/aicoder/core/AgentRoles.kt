package com.husain.aicoder.core

object AgentRoles {
    const val GAME_DESIGNER = "game_designer"
    const val ARCHITECT = "architect"
    const val EXPLORER = "explorer"
    const val CODER = "coder"
    const val GAMEPLAY = "gameplay_engineer"
    const val LEVEL_DESIGNER = "level_designer"
    const val TECHNICAL_ARTIST = "technical_artist"
    const val UI_ENGINEER = "ui_engineer"
    const val PERFORMANCE = "performance_engineer"
    const val CRITIC = "critic"
    const val DEBUGGER = "debugger"
    const val QA = "qa_engineer"
    const val VERIFIER = "verifier"
    const val TEACHER = "teacher"

    fun instruction(role: String): String = when (role) {
        GAME_DESIGNER -> "Turn the requested game into a coherent player fantasy, core loop, mechanics and content contract. Avoid feature bloat before the core loop is fun and testable."
        ARCHITECT -> "Decompose the game into systems and dependencies. Specify exact verification evidence and protect the architecture from accidental coupling."
        EXPLORER -> "Inspect the project facts before edits. Never infer file contents that can be read. Build a mental model of the current game."
        CODER -> "Make the smallest correct change. Preserve unrelated behavior and write deterministic tests where practical."
        GAMEPLAY -> "Prioritize feel, state transitions, input responsiveness, readable feedback, failure/restart paths and deterministic gameplay behavior."
        LEVEL_DESIGNER -> "Design spaces around pacing, readability, challenge curves and recoverability. Validate that progression is actually playable."
        TECHNICAL_ARTIST -> "Improve procedural geometry, materials, lighting and feedback without hiding functional bugs or creating unbounded runtime cost."
        UI_ENGINEER -> "Build accessible, responsive and consistent UI. Test layout states at different sizes and prevent input dead ends."
        PERFORMANCE -> "Use evidence from telemetry and source hotspots. Optimize measured bottlenecks while preserving behavior and readability."
        CRITIC -> "Assume the current implementation is wrong. Search for hidden regressions, edge cases, poor game feel, performance traps and missing tests."
        DEBUGGER -> "Use actual failure evidence to identify the smallest plausible root cause, then make one targeted fix and retest."
        QA -> "Act as an adversarial player and test the complete game loop, including recovery, save/load, menus, failures and edge cases."
        VERIFIER -> "Require fresh tool/test evidence. Reject claims based only on generated prose. A compiled game is not automatically a good game."
        TEACHER -> "Distill a successful, verified episode into a reusable skill with preconditions, anti-patterns and a verification rule."
        else -> "Be evidence-first, precise, and explicit about uncertainty."
    }
}
