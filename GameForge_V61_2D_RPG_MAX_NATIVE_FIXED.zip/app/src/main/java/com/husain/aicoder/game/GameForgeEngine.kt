package com.husain.aicoder.game

import com.arm.aichat.InferenceEngine
import com.husain.aicoder.agent.CodingWorkspace
import com.husain.aicoder.agent.ToolExecutor
import com.husain.aicoder.mission.AutonomousCodingEngine
import com.husain.aicoder.mission.GameBuildStore
import com.husain.aicoder.mission.MissionState
import com.husain.aicoder.quality.AdaptivePlaytestEngine
import com.husain.aicoder.quality.GameQualityGate
import com.husain.aicoder.quality.GameplayQualityJudge
import com.husain.aicoder.quality.PerformanceProfiler
import com.husain.aicoder.quality.PlaytestEngine
import com.husain.aicoder.quality.VisualQualityAnalyzer
import com.husain.aicoder.project.ArchitectureGraph
import com.husain.aicoder.project.ChangeImpactAnalyzer
import com.husain.aicoder.skills.SkillLibrary
import com.husain.aicoder.ml.ContinuousLearningManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * GameForge V6.1 full-game factory with 2D-first RPG/MMORPG asset generation and bot testing.
 *
 * Pipeline:
 * design -> compile -> genre/level contracts -> deterministic bootstrap -> long-horizon coding
 * -> static verification -> runtime playtest -> profile -> repair -> regression -> package -> report.
 */
class GameForgeEngine(
    private val designEngine: GameDesignEngine,
    private val workspace: CodingWorkspace,
    private val codingEngine: AutonomousCodingEngine,
    private val tools: ToolExecutor,
    private val continuous: ContinuousLearningManager,
    private val skills: SkillLibrary,
    private val inference: InferenceEngine? = null,
    private val actionGrammar: String? = null,
    private val buildStore: GameBuildStore? = null,
    private val onStatus: (String) -> Unit = {}
) {
    private val scaffolder = GameProjectScaffolder(workspace)
    private val specCompiler = GameSpecCompiler()
    private val verifier = GameGenerationVerifier(workspace)
    private val blueprintLibrary = GenreBlueprintLibrary()
    private val graph = ArchitectureGraph(workspace)
    private val impact = ChangeImpactAnalyzer(workspace, graph)
    private val profiler = PerformanceProfiler(workspace)
    private val visual = VisualQualityAnalyzer(workspace)
    private val gate = GameQualityGate()
    private val gameplayJudge = GameplayQualityJudge()
    private val playtest = PlaytestEngine(tools)
    private val adaptivePlaytest = AdaptivePlaytestEngine(tools, inference, actionGrammar)

    suspend fun build(goal: String, maxCodingSteps: Int = 110, maxRepairPasses: Int = 5): GameForgeResult {
        require(goal.isNotBlank()) { "Game goal must not be blank" }
        val startedAt = System.currentTimeMillis()
        val latest = buildStore?.latest()
        val workspaceHasSpec = File(workspace.root, "GAME_SPEC.json").isFile
        val resume = latest != null && latest.optString("goal") == goal && latest.optString("stage") != "complete" && workspaceHasSpec
        val buildId = if (resume) latest!!.optString("id") else "v61_${System.currentTimeMillis()}"

        fun persist(stage: String, extra: JSONObject = JSONObject()) {
            buildStore?.save(
                buildId,
                JSONObject()
                    .put("id", buildId)
                    .put("version", "6.1-2D-RPG-MAX")
                    .put("goal", goal)
                    .put("stage", stage)
                    .put("updated_at_ms", System.currentTimeMillis())
                    .put("extra", extra)
            )
        }

        onStatus(if (resume) "V6.1: resuming build $buildId" else "V6.1: starting 2D-first full game factory")
        persist(if (resume) "resuming" else "designing")

        var spec = loadOrDesign(goal, resume)
        val compiled = specCompiler.compile(spec)
        specCompiler.write(compiled, workspace)
        if (!compiled.ok) {
            onStatus("V6: design contract had ${compiled.errors.size} error(s); using deterministic fallback")
            spec = GameSpec.fallback(goal)
            val fallbackCompile = specCompiler.compile(spec)
            specCompiler.write(fallbackCompile, workspace)
        }

        val blueprint = blueprintLibrary.blueprint(spec)
        workspace.write("gameforge/GENRE_BLUEPRINT.json", blueprint.toString(2))
        persist("contracted", JSONObject()
            .put("title", spec.title)
            .put("genre", spec.genre)
            .put("compiler_ok", compiled.ok)
            .put("compiler_errors", JSONArray(compiled.errors))
            .put("compiler_warnings", JSONArray(compiled.warnings)))

        if (!resume) {
            val existingFiles = workspace.listAllFiles(20000)
            if (existingFiles.isNotEmpty()) {
                onStatus("V6: checkpointing the previous workspace before starting a fresh build")
                workspace.checkpoint("before_fresh_v6_build")
                workspace.resetWorkspace()
            }
            onStatus("V6: scaffolding a deterministic playable vertical slice")
            scaffolder.scaffold(spec)
        } else {
            onStatus("V6: preserving resumable workspace")
            if (!File(workspace.root, "main.tscn").isFile || !File(workspace.root, "scripts/game_root.gd").isFile) {
                onStatus("V6: resume workspace is incomplete; restoring deterministic bootstrap files")
                scaffolder.scaffold(spec)
            }
        }
        graph.writeReport()
        workspace.write("gameforge/V6_PIPELINE.md", pipelineContract(spec))
        onStatus("V6.1: ${spec.title} • ${spec.genre} • contracts + generated visual assets locked")

        persist("implementing", JSONObject().put("title", spec.title))
        val implementationGoal = buildImplementationPrompt(goal, spec, blueprint)
        var mission = if (resume) {
            val saved = codingEngine.latestMission()?.takeIf { it.goal == implementationGoal && !it.completed }
            if (saved != null) codingEngine.run(implementationGoal, maxCodingSteps, saved)
            else codingEngine.run(implementationGoal, maxCodingSteps)
        } else {
            codingEngine.run(implementationGoal, maxCodingSteps)
        }

        var staticCheck = verifier.verify()
        var pass = 0
        var accepted = false
        var finalPlaytest = JSONObject()
        var finalProfile = JSONObject()
        var finalVerdict = gate.evaluate(JSONObject(), JSONObject(), mission.completed, staticCheck.ok, genreContractSatisfied(blueprint).optBoolean("ok"))
        val repairEvidence = JSONArray()

        if (!staticCheck.ok) {
            onStatus("V6.1: static verification found ${staticCheck.errors.size} issue(s) before runtime")
            repairEvidence.put(JSONObject()
                .put("stage", "static_preflight")
                .put("errors", JSONArray(staticCheck.errors)))
            mission = codingEngine.run(buildStaticRepairPrompt(spec, staticCheck), maxCodingSteps)
            staticCheck = verifier.verify()
        }

        while (pass < maxRepairPasses + 1 && !accepted) {
            pass++
            onStatus("V6.1: validation pass $pass • bot/AI playtest evidence")

            val playtestResult = if (inference != null && pass == 1) {
                adaptivePlaytest.run(iterations = 4, maxStepsPerRun = 24).report
            } else {
                playtest.run(if (pass == 1) 5 else 7)
            }
            finalPlaytest = playtestResult
            finalProfile = profiler.profile()
            profiler.writeReport()
            graph.writeReport()

            staticCheck = verifier.verify()
            val contract = genreContractSatisfied(blueprint)
            finalVerdict = gate.evaluate(
                finalPlaytest,
                finalProfile,
                mission.completed,
                staticCheck.ok,
                contract.optBoolean("ok")
            )

            val passRecord = JSONObject()
                .put("pass", pass)
                .put("static", JSONObject().put("ok", staticCheck.ok).put("errors", JSONArray(staticCheck.errors)))
                .put("genre_contract", contract)
                .put("playtest", finalPlaytest)
                .put("profile", finalProfile)
                .put("verdict", JSONObject()
                    .put("accepted", finalVerdict.accepted)
                    .put("risk", finalVerdict.risk)
                    .put("reasons", JSONArray(finalVerdict.reasons)))
            repairEvidence.put(passRecord)
            workspace.write("gameforge/QUALITY_GATE_PASS_$pass.json", passRecord.toString(2))
            persist("validating", JSONObject()
                .put("pass", pass)
                .put("accepted", finalVerdict.accepted)
                .put("static_ok", staticCheck.ok)
                .put("playtest_pass_rate", finalPlaytest.optDouble("pass_rate", 0.0))
                .put("risk", finalVerdict.risk))

            if (finalVerdict.accepted) {
                accepted = true
                break
            }

            if (pass >= maxRepairPasses + 1) break
            val hotspotPaths = readHotspots(finalProfile)
            val impactReport = impact.analyze(hotspotPaths)
            mission = codingEngine.run(
                buildRepairPrompt(spec, mission, finalPlaytest, finalProfile, staticCheck, finalVerdict, contract, impactReport),
                maxCodingSteps
            )
        }

        onStatus("V6.1: running final bot regression")
        val finalStatic = verifier.verify()
        val finalRegression = playtest.run(4)
        val finalContract = genreContractSatisfied(blueprint)
        val regressionVerdict = gate.evaluate(finalRegression, profiler.profile(), mission.completed, finalStatic.ok, finalContract.optBoolean("ok"))
        val assetValidation = if (spec.camera.contains("2d", true) || spec.genre.contains("rpg", true) || spec.genre.contains("mmorpg", true)) {
            tools.execute("validate_2d_assets", JSONObject())
        } else JSONObject().put("ok", true).put("mode", "3d_legacy")
        val assetValidationOk = assetValidation.optBoolean("ok", false)
        val packageResult = if (regressionVerdict.accepted && assetValidationOk) {
            tools.execute("package_game", JSONObject().put("main_scene", "main.tscn"))
        } else {
            JSONObject().put("ok", false).put("evidence", if (!regressionVerdict.accepted) {
                "package withheld because final regression gate did not pass"
            } else {
                "package withheld because final 2D asset validation did not pass"
            })
        }
        val packageOk = packageResult.optBoolean("ok", false)
        val finalAccepted = regressionVerdict.accepted && assetValidationOk && packageOk
        val finalReasons = regressionVerdict.reasons.toMutableList().apply {
            if (!assetValidationOk) add("final 2D asset validation failed")
            if (regressionVerdict.accepted && assetValidationOk && !packageOk) add("final package step failed")
        }
        val gameplayReport = gameplayJudge.evaluate(finalRegression)
        val visualReport = visual.analyze()
        val finalProfileNow = profiler.profile()

        val summary = "GameForge V6.1 ${spec.title}: accepted=$finalAccepted pass=$pass risk=${regressionVerdict.risk} reasons=${finalReasons.joinToString("; ")}"
        workspace.write("gameforge/FINAL_GATE.json", JSONObject()
            .put("accepted", finalAccepted)
            .put("regression_gate_accepted", regressionVerdict.accepted)
            .put("package_ok", packageOk)
            .put("risk", regressionVerdict.risk)
            .put("reasons", JSONArray(finalReasons))
            .put("static", JSONObject().put("ok", finalStatic.ok).put("errors", JSONArray(finalStatic.errors)).put("checks", JSONArray(finalStatic.checks)))
            .put("genre_contract", finalContract)
            .put("regression", finalRegression)
            .put("asset_validation", assetValidation)
            .put("package", packageResult)
            .toString(2))

        continuous.recordOutcome(goal, finalAccepted, summary)
        if (finalAccepted) {
            skills.upsert(
                name = "gameforge_v6_${spec.genre}_${spec.title.hashCode()}",
                trigger = "Build and validate a ${spec.genre} game in GameForge V6",
                procedure = listOf("design GameSpec", "compile contracts", "scaffold", "implement", "static verify", "playtest", "profile", "repair", "regression", "package"),
                evidence = summary,
                failureModes = regressionVerdict.reasons
            )
        }

        val finalReport = JSONObject()
            .put("version", "6.1-2D-RPG-MAX")
            .put("build_id", buildId)
            .put("goal", goal)
            .put("started_at_ms", startedAt)
            .put("finished_at_ms", System.currentTimeMillis())
            .put("duration_ms", System.currentTimeMillis() - startedAt)
            .put("spec", spec.toJson())
            .put("mission", mission.summary)
            .put("mission_completed", mission.completed)
            .put("validation_passes", pass)
            .put("accepted", finalAccepted)
            .put("regression_gate_accepted", regressionVerdict.accepted)
            .put("quality_risk", regressionVerdict.risk)
            .put("quality_reasons", JSONArray(finalReasons))
            .put("static_verification", JSONObject().put("ok", finalStatic.ok).put("checks", JSONArray(finalStatic.checks)).put("errors", JSONArray(finalStatic.errors)))
            .put("genre_contract", finalContract)
            .put("playtest", finalPlaytest)
            .put("regression", finalRegression)
            .put("gameplay_quality", gameplayReport)
            .put("profile", finalProfileNow)
            .put("visual_quality", visualReport)
            .put("asset_validation", assetValidation)
            .put("package", packageResult)
            .put("repair_history", repairEvidence)
        val reportPath = workspace.write("gameforge/FINAL_GAME_REPORT.json", finalReport.toString(2))
        persist("complete", JSONObject().put("accepted", finalAccepted).put("report", reportPath).put("risk", regressionVerdict.risk))
        return GameForgeResult(spec, mission, finalAccepted, pass, summary, reportPath)
    }

    private suspend fun loadOrDesign(goal: String, resume: Boolean): GameSpec {
        if (resume) {
            val fromDisk = runCatching {
                GameSpec.fromJson(JSONObject(File(workspace.root, "GAME_SPEC.json").readText()))
            }.getOrNull()
            if (fromDisk != null) return fromDisk
        }
        onStatus("V6: asking the local design/reasoning model for a build-ready GameSpec")
        return designEngine.design(goal)
    }

    private fun buildImplementationPrompt(goal: String, spec: GameSpec, blueprint: JSONObject): String = buildString {
        appendLine("TASK_ROLE: CODING")
        appendLine("You are the primary Qwen2.5-Coder implementation specialist inside GameForge V6.1 2D-first Full Game Factory.")
        appendLine("The separate Qwen3-Thinking reasoning specialist has already produced the contract; do not redesign it casually.")
        appendLine("Original user goal: $goal")
        appendLine("GameSpec:")
        appendLine(spec.toJson().toString(2))
        appendLine("Genre blueprint:")
        appendLine(blueprint.toString(2))
        appendLine()
        appendLine("FULL-GAME REQUIREMENTS")
        appendLine("- Build a complete, polished, playable Godot game, not a demo menu or placeholder-only scene.")
        appendLine("- Preserve the automation contract: get_gameforge_observation(), apply_action(), reset_test().")
        appendLine("- Implement the genre-defining systems from the blueprint and make them actually reachable in play.")
        appendLine("- For 2D RPG/MMORPG targets, treat the visual layer as a generated asset system: create sprites, animation frames, VFX, icons and maps from requests/seeds; do not rely on a pre-shipped character-art pack.")
        appendLine("- Use generate_2d_asset and generate_2d_map for new visual content, then validate_2d_assets and run the bot/AI playtester.")
        appendLine("- Keep 4-direction animation as the baseline and extend to 8-direction where the design calls for it.")
        appendLine("- Keep Android/mid-range-phone performance in mind: bound node counts, physics work and allocations.")
        appendLine("- Build a real core gameplay loop, progression, feedback, failure/recovery and success path.")
        appendLine("- Add UI, audio hooks, save/load and polish only after the core loop is stable.")
        appendLine("- After each significant change, run fresh Godot evidence and repair compiler/runtime errors before moving on.")
        appendLine("- Never claim the game is finished without fresh evidence.")
    }

    private fun buildStaticRepairPrompt(spec: GameSpec, staticCheck: GameGenerationVerifier.Result): String = buildString {
        appendLine("TASK_ROLE: REASONING")
        appendLine("Fix the generated Godot project before runtime testing. Do not start over.")
        appendLine("Game: ${spec.title} (${spec.genre})")
        appendLine("Static verifier errors:")
        staticCheck.errors.forEach { appendLine("- $it") }
        appendLine("Then use TASK_ROLE: CODING in the implementation work, preserve the automation contract, and run a fresh test.")
    }

    private fun buildRepairPrompt(
        spec: GameSpec,
        mission: MissionState,
        playtest: JSONObject,
        profile: JSONObject,
        staticCheck: GameGenerationVerifier.Result,
        verdict: GameQualityGate.Verdict,
        contract: JSONObject,
        impactReport: JSONObject
    ): String = buildString {
        appendLine("TASK_ROLE: REASONING")
        appendLine("Diagnose the failed GameForge V6 validation pass, then make the smallest safe repair needed to move the game toward release.")
        appendLine("Do not throw away working systems.")
        appendLine("Game: ${spec.title} (${spec.genre})")
        appendLine("Mission: completed=${mission.completed}, failures=${mission.failures}, phase=${mission.phase}")
        appendLine("Quality gate: accepted=${verdict.accepted}, risk=${verdict.risk}")
        appendLine("Quality reasons:")
        verdict.reasons.forEach { appendLine("- $it") }
        appendLine("Static verification errors:")
        staticCheck.errors.forEach { appendLine("- $it") }
        appendLine("Genre contract:")
        appendLine(contract.toString(2).take(7000))
        appendLine("Fresh playtest:")
        appendLine(playtest.toString(2).take(16000))
        appendLine("Performance:")
        appendLine(profile.toString(2).take(10000))
        appendLine("Change impact:")
        appendLine(impactReport.toString(2).take(9000))
        appendLine("Next action: implement/fix the root cause, then run fresh evidence. Do not merely describe a fix.")
    }

    private fun readHotspots(profile: JSONObject): List<String> {
        val array = profile.optJSONArray("hotspots") ?: return emptyList()
        return buildList<String> {
            for (i in 0 until array.length()) {
                array.optJSONObject(i)?.optString("file")?.takeIf { it.isNotBlank() }?.let(::add)
            }
        }.distinct().take(20)
    }

    private fun genreContractSatisfied(blueprint: JSONObject): JSONObject {
        val required = blueprint.optJSONArray("required_systems") ?: JSONArray()
        val files = workspace.listAllFiles(6000).filter { path ->
            path.endsWith(".gd") || path.endsWith(".tscn") || path.endsWith(".tres") || path.endsWith(".json") || path.endsWith(".md")
        }.take(450)
        val corpus = buildString {
            for (path in files) {
                append(path.lowercase()).append('\n')
                append(runCatching { workspace.read(path).lowercase() }.getOrDefault("")).append('\n')
            }
        }
        val covered = JSONArray()
        for (i in 0 until required.length()) {
            val id = required.optString(i)
            val matched = genreAliases(id).any { corpus.contains(it) }
            if (matched) covered.put(id)
        }
        val total = required.length()
        val coveredCount = covered.length()
        val minimum = when {
            total <= 1 -> total
            total <= 3 -> 2
            else -> (total * 0.50).toInt().coerceAtLeast(3)
        }
        val ok = total == 0 || coveredCount >= minimum
        return JSONObject()
            .put("ok", ok)
            .put("required_count", total)
            .put("covered_count", coveredCount)
            .put("minimum_coverage", minimum)
            .put("covered_systems", covered)
            .put("checked_file_count", files.size)
    }

    private fun genreAliases(system: String): List<String> {
        val normalized = system.lowercase().replace('_', ' ')
        val explicit = when (system.lowercase()) {
            "vehicle_controller" -> listOf("vehicle", "car", "steering", "accelerat")
            "checkpointing" -> listOf("checkpoint", "checkpoint_index")
            "laps" -> listOf("lap", "laps")
            "opponents" -> listOf("opponent", "rival", "enemy", "ai")
            "timing" -> listOf("timer", "best_time", "lap_time", "time")
            "weapons" -> listOf("weapon", "shoot", "ammo", "fire")
            "combat_loop" -> listOf("combat", "attack", "damage")
            "stats" -> listOf("stats", "attributes", "health")
            "inventory" -> listOf("inventory", "item")
            "dialogue" -> listOf("dialogue", "conversation")
            "quests" -> listOf("quest")
            "run_generation" -> listOf("run_seed", "procedural", "generate_room")
            "death_loop" -> listOf("death", "restart", "reset")
            "meta_progression" -> listOf("meta", "upgrade", "unlock")
            "resource_pressure" -> listOf("resource", "scarcity", "stamina")
            "build_variation" -> listOf("build", "loadout", "modifier")
            "room_rules" -> listOf("room", "rule")
            "rules" -> listOf("rule", "logic")
            "state_reset" -> listOf("reset")
            "hint_system" -> listOf("hint")
            "solution_validation" -> listOf("solution", "validate")
            "resource_economy" -> listOf("resource", "economy")
            "decision_space" -> listOf("decision", "choice", "turn")
            "map_state" -> listOf("map", "territory")
            "victory_conditions" -> listOf("victory", "win", "goal")
            "turn_or_tick_loop" -> listOf("turn", "tick")
            "exploration" -> listOf("explore", "exploration")
            "threat" -> listOf("threat", "hazard", "enemy")
            "resource_scarcity" -> listOf("scarcity", "resource")
            "sound_feedback" -> listOf("sound", "audio")
            "escape_loop" -> listOf("escape", "goal", "exit")
            "save_recovery" -> listOf("save", "load", "recovery")
            "movement" -> listOf("movement", "move", "velocity")
            "jump_consistency" -> listOf("jump", "coyote")
            "hazards" -> listOf("hazard", "danger")
            "checkpoints" -> listOf("checkpoint")
            "camera_follow" -> listOf("camera", "look_at")
            "restart" -> listOf("restart", "reset")
            else -> listOf(normalized, system.lowercase())
        }
        return explicit + normalized.split(' ').filter { it.length >= 4 }
    }

    private fun pipelineContract(spec: GameSpec) = """
        # GameForge V6 Pipeline

        Goal: ${spec.title}
        Genre: ${spec.genre}

        `Goal -> Design -> Compile -> Blueprint -> Level Plan -> Bootstrap -> Code -> Static Verify -> Playtest -> Profile -> Repair -> Regression -> Package -> Report`

        The model router uses explicit `TASK_ROLE` tags. Qwen3-Thinking handles architecture/root-cause reasoning;
        Qwen2.5-Coder-7B Q4_K_M handles implementation. The latter is given an agent-level planning pass;
        that is not native Qwen3 thinking-token support.
    """.trimIndent() + "\n"
}

/** Immutable result object returned to the UI. */
data class GameForgeResult(
    val spec: GameSpec,
    val mission: MissionState,
    val accepted: Boolean,
    val repairPasses: Int,
    val summary: String,
    val reportPath: String
)
