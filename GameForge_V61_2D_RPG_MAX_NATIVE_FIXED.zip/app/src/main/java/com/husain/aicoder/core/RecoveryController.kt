package com.husain.aicoder.core

/** Detects stagnation and recommends a different strategy instead of repeating the same action. */
class RecoveryController(private val budget: ApexBudget = ApexBudget()) {
    private var lastSignature = ""
    private var repeats = 0

    fun observe(signature: String): RecoveryAction {
        if (signature == lastSignature) repeats++ else repeats = 0
        lastSignature = signature
        return when {
            repeats >= budget.maxNoProgressSteps -> RecoveryAction.ROLLBACK_AND_REPLAN
            repeats >= 6 -> RecoveryAction.CRITIC
            repeats >= 3 -> RecoveryAction.CHANGE_ROLE
            else -> RecoveryAction.CONTINUE
        }
    }

    enum class RecoveryAction { CONTINUE, CHANGE_ROLE, CRITIC, ROLLBACK_AND_REPLAN }
}
