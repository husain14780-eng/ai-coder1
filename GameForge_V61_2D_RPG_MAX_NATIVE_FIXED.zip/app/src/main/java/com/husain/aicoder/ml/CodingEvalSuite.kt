package com.husain.aicoder.ml

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.arm.aichat.ReasoningMode
import kotlinx.coroutines.flow.collect
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Deterministic smoke/evaluation harness. It measures tool discipline and evidence, not general intelligence. */
class CodingEvalSuite {
    data class EvalCase(
        val id: String,
        val category: String,
        val task: String,
        val requiredTools: List<String>
    )

    data class Result(val score: Double, val summary: String)

    fun cases(): List<EvalCase> = listOf(
        EvalCase("bug-npe-01", "debugging", "Fix a null dependency in a Godot player controller and add a regression check.", listOf("read_file", "replace_text", "run_godot_test")),
        EvalCase("bug-state-02", "state", "Find a state-machine transition that can deadlock and make transitions total.", listOf("search_text", "read_file", "replace_text")),
        EvalCase("perf-loop-03", "performance", "Remove an avoidable per-frame allocation while preserving behavior.", listOf("read_file", "replace_text", "run_godot_test")),
        EvalCase("design-04", "architecture", "Refactor duplicated platform configuration into a reusable data structure.", listOf("list_files", "read_file", "replace_text")),
        EvalCase("test-05", "testing", "Find why a regression test is flaky and make the test deterministic.", listOf("search_text", "read_file", "replace_text", "run_godot_test")),
        EvalCase("security-06", "security", "Find an unsafe path or unchecked input boundary and harden it without changing the public contract.", listOf("search_text", "read_file", "replace_text")),
        EvalCase("novel-07", "novel", "Solve a previously unseen failure using logs and tests rather than matching a memorized fix.", listOf("search_text", "read_file", "run_godot_test")),
        EvalCase("multi-08", "long_horizon", "Inspect a small project, make a coherent multi-file change, and verify the affected behavior.", listOf("list_files", "read_file", "replace_text", "run_godot_test"))
    )

    suspend fun run(engine: InferenceEngine, outputFile: File, onStatus: (String) -> Unit = {}): Result {
        outputFile.parentFile?.mkdirs()
        val rows = mutableListOf<JSONObject>()
        var total = 0.0
        for ((index, c) in cases().withIndex()) {
            val prompt = buildString {
                append("You are being benchmarked as a coding agent. Case ${c.id}.\n")
                append("Task: ${c.task}\n")
                append("Required tools: ${c.requiredTools.joinToString(", ")}\n")
                append("Return one short plan, then at least one exact <tool_call> block if tools are needed.\n")
                append("Never claim tests passed without evidence.\n/think")
            }
            val out = StringBuilder()
            engine.sendUserPrompt(
                prompt,
                GenerationConfig(
                    mode = ReasoningMode.THINKING,
                    maxTokens = 1200,
                    temperature = 0.6f,
                    topP = 0.95f,
                    topK = 20,
                    minP = 0f,
                    repeatPenalty = 1.05f
                )
            ).collect { out.append(it) }
            val text = out.toString()
            val toolCount = c.requiredTools.count { text.contains("\"name\":\"$it\"") || text.contains("\"name\": \"$it\"") }
            val claimedPass = Regex("(?i)(test|tests).{0,40}(pass|passed|green)").containsMatchIn(text)
            val hasEvidenceLanguage = text.contains("evidence", true) || text.contains("verified", true)
            val score = (toolCount.toDouble() / c.requiredTools.size.toDouble() * 0.65) +
                (if (hasEvidenceLanguage) 0.2 else 0.0) +
                (if (!claimedPass || hasEvidenceLanguage) 0.15 else 0.0)
            total += score
            rows += JSONObject()
                .put("id", c.id)
                .put("category", c.category)
                .put("score", score)
                .put("required_tools", JSONArray(c.requiredTools))
                .put("tool_mentions", toolCount)
                .put("claimed_test_pass", claimedPass)
                .put("output", text.take(12000))
            onStatus("benchmark ${index + 1}/${cases().size} ${c.id} score=${"%.2f".format(score)}")
        }
        outputFile.writeText(rows.joinToString("\n") { it.toString() } + if (rows.isNotEmpty()) "\n" else "")
        val score = if (rows.isEmpty()) 0.0 else total / rows.size
        return Result(score, "cases=${rows.size}; heuristic_score=${"%.3f".format(score)}; this is a smoke metric, not a frontier-model comparison")
    }

    fun manifest(): JSONArray = JSONArray().apply {
        cases().forEach { c ->
            put(JSONObject().put("id", c.id).put("category", c.category).put("task", c.task).put("required_tools", JSONArray(c.requiredTools)))
        }
    }
}
