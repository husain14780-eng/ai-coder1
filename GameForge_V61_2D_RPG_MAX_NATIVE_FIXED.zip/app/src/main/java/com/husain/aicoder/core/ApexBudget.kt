package com.husain.aicoder.core

/** Hard limits that keep a long-running local agent bounded and resumable. */
data class ApexBudget(
    val maxWallClockMs: Long = 6L * 60L * 60L * 1000L,
    val maxTaskAttempts: Int = 6,
    val maxRepairPasses: Int = 8,
    val maxToolCalls: Int = 700,
    val maxNoProgressSteps: Int = 10,
    val maxContextChars: Int = 52000
) {
    fun remainingMs(startMs: Long, nowMs: Long = System.currentTimeMillis()): Long =
        (maxWallClockMs - (nowMs - startMs)).coerceAtLeast(0L)
}
