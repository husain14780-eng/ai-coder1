package com.husain.aicoder.memory

import org.json.JSONObject

/** Bounded working memory with durable summary checkpoints. */
class ContextLedger(private val maxChars: Int = 18000) {
    private val entries = ArrayDeque<String>()

    fun add(label: String, text: String) {
        entries.addLast("[$label] ${text.take(7000)}")
        trim()
    }

    fun snapshot(): String = entries.joinToString("\n")

    fun compact(): String {
        val all = snapshot()
        return if (all.length <= maxChars / 2) all else all.takeLast(maxChars / 2)
    }

    private fun trim() {
        while (snapshot().length > maxChars && entries.size > 1) entries.removeFirst()
    }

    fun toJson(): JSONObject = JSONObject().put("entries", entries.toList())
}
