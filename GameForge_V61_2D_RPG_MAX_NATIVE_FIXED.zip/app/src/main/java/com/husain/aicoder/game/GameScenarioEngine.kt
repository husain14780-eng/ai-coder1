package com.husain.aicoder.game

import org.json.JSONArray
import org.json.JSONObject

/** Generates deterministic gameplay scenarios from the GameSpec so QA covers the actual design contract. */
class GameScenarioEngine {
    fun generate(spec: GameSpec): JSONObject {
        val scenarios = JSONArray()
        add(scenarios, "boot", "Game launches into the intended first playable state", listOf("launch", "observe"))
        add(scenarios, "core_loop", "Perform the primary gameplay loop once", listOf("observe", "act", "observe", "verify_goal_state"))
        if (spec.mechanics.isNotEmpty()) add(scenarios, "mechanics", "Exercise declared mechanics", spec.mechanics.take(8).map { "exercise:$it" })
        if (spec.enemies.isNotEmpty()) add(scenarios, "combat_or_threat", "Reach and survive one declared threat interaction", listOf("navigate_to_threat", "interact", "recover"))
        if (spec.progression.isNotEmpty()) add(scenarios, "progression", "Trigger one progression event and verify persistent state", listOf("complete_subgoal", "inspect_progression"))
        if (spec.saveSystem.isNotEmpty()) add(scenarios, "save_load", "Save, restart, load and verify state continuity", listOf("save", "restart", "load", "compare_state"))
        add(scenarios, "failure_recovery", "Cause a controlled failure and verify recovery", listOf("trigger_failure", "observe", "recover", "continue"))
        if (spec.scenes.size > 1) add(scenarios, "scene_transition", "Traverse at least one scene transition", listOf("reach_transition", "transition", "verify_destination"))
        if (spec.ui.isNotEmpty()) add(scenarios, "ui_navigation", "Exercise the primary UI route", spec.ui.take(6).map { "ui:$it" })
        add(scenarios, "performance_stress", "Exercise the densest normal gameplay state", listOf("reach_dense_state", "measure_fps", "measure_memory"))
        return JSONObject()
            .put("scenario_version", "1.0")
            .put("scenario_count", scenarios.length())
            .put("scenarios", scenarios)
            .put("generated_at_ms", System.currentTimeMillis())
    }

    private fun add(target: JSONArray, id: String, intent: String, steps: List<String>) {
        target.put(JSONObject()
            .put("id", id)
            .put("intent", intent)
            .put("steps", JSONArray(steps))
            .put("pass_evidence", JSONArray(listOf("fresh_observation", "no_error_signal"))))
    }
}
