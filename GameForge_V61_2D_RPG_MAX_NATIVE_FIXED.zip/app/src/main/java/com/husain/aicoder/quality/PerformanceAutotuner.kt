package com.husain.aicoder.quality

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Turns profiler output into concrete, ranked optimization targets; it never silently changes code. */
class PerformanceAutotuner(private val workspace: CodingWorkspace) {
    fun analyze(profile: JSONObject): JSONObject {
        val suggestions = JSONArray()
        val hotspots = profile.optJSONArray("hotspots")
        if (hotspots != null) for (i in 0 until hotspots.length()) {
            val h = hotspots.optJSONObject(i) ?: continue
            val file = h.optString("file")
            val reason = h.optString("reason")
            if (file.isNotBlank()) suggestions.put(JSONObject().put("file", file).put("reason", reason).put("priority", i + 1))
        }
        if (suggestions.length() == 0) suggestions.put(JSONObject().put("priority", 1).put("reason", "No static hotspot signal; capture runtime telemetry before optimizing."))
        return JSONObject().put("suggestions", suggestions).put("safe_to_auto_apply", false).put("generated_at_ms", System.currentTimeMillis())
    }

    fun write(profile: JSONObject): String = workspace.write("gameforge/PERFORMANCE_AUTOTUNE.json", analyze(profile).toString(2))
}
