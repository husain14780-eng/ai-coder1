package com.husain.aicoder.ml

import org.json.JSONObject

/** Keeps continuous-learning data useful: success, novelty, evidence and bounded size. */
class ExperienceQualityFilter {
    fun accept(goal: String, action: String, result: String, success: Boolean, reward: Double): Boolean {
        if (goal.isBlank() || action.isBlank()) return false
        if (result.length < 12) return false
        if (result.length > 50000) return false
        if (!success && reward <= -0.95) return true // hard failures are valuable diagnostics
        return success || reward > 0.15
    }
}
