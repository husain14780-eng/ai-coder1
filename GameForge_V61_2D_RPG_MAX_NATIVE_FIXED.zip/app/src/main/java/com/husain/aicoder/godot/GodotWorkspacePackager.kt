package com.husain.aicoder.godot

import com.husain.aicoder.agent.CodingWorkspace
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Packages the generated project into a runtime resource pack ZIP for the embedded Godot instance. */
class GodotWorkspacePackager(private val workspace: CodingWorkspace) {
    fun packageProject(outputDir: File, mainScene: String = "main.tscn"): File {
        require(File(workspace.root, "project.godot").isFile) { "Generated Godot project is missing project.godot" }
        val normalizedScene = mainScene.trim().removePrefix("res://").replace('\\', '/')
        require(normalizedScene.isNotBlank() && normalizedScene != "." && !normalizedScene.split('/').contains("..")) { "Invalid main scene path: $mainScene" }
        require(File(workspace.root, normalizedScene).isFile) { "Generated Godot main scene is missing: $normalizedScene" }
        outputDir.mkdirs()
        val out = File(outputDir, "gameforge_runtime_${System.currentTimeMillis()}.zip")
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            workspace.listAllFiles(20000).filter(::include).forEach { relative ->
                val source = File(workspace.root, relative)
                zip.putNextEntry(ZipEntry(relative.replace('\\', '/')))
                source.inputStream().use { it.copyTo(zip, 1024 * 1024) }
                zip.closeEntry()
            }
        }
        require(out.isFile && out.length() > 0) { "Runtime pack was not created" }
        File(outputDir, "LATEST_SCENE.txt").writeText(mainScene)
        return out
    }

    private fun include(path: String): Boolean {
        val normalized = path.replace('\\', '/')
        if (normalized.startsWith("checkpoints/") || normalized.startsWith("gameforge/runtime/")) return false
        if (normalized.contains("/.godot/") || normalized.startsWith(".godot/")) return false
        if (normalized.startsWith(".git/")) return false
        return true
    }
}
