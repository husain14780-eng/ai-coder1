package com.husain.aicoder.agent

/** Additional command safety: keep the agent inside the workspace and deny destructive/system escapes. */
object ToolPolicy {
    private val forbidden = listOf(
        "rm -rf /", "rm -rf *", "mkfs", "dd if=", "/system/", "/vendor/", "/proc/", "/sys/",
        "su ", "reboot", "shutdown", "pm install", "pm uninstall", "am start", "curl ", "wget ",
        "find -exec", "find --exec", "find -delete", "git reset", "git checkout", "git clean", "git restore",
        "git push", "git remote add", "git clone", "git init", "gradle init", "gradle wrapper",
        "settings.gradle", "build.gradle", "./gradlew"
    )
    fun validateCommand(command: String): Result<Unit> {
        val normalized = command.lowercase().trim()
        val hit = forbidden.firstOrNull { normalized.contains(it) }
        if (hit != null) return Result.failure(IllegalArgumentException("Command blocked by FINAL MAX safety policy: $hit"))
        val operators = listOf(";", "&&", "||", "`", "$((", "$(", ">", "<", "|&")
        val operator = operators.firstOrNull { normalized.contains(it) }
        if (operator != null) return Result.failure(IllegalArgumentException("Shell operator blocked by workspace safety policy: $operator"))
        if (Regex("(^|\\s)(/[^\\s]+|\\.\\./)").containsMatchIn(normalized)) {
            return Result.failure(IllegalArgumentException("Absolute/outside-workspace paths are blocked"))
        }
        return Result.success(Unit)
    }
}
