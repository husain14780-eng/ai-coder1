package com.husain.aicoder.mission

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persistent mission journal. Every significant state change is durable so a mission can resume. */
class MissionStore(context: Context) {
    private val root = File(context.filesDir, "missions").apply { mkdirs() }

    @Synchronized
    fun create(goal: String, maxSteps: Int): MissionState {
        val id = "m_" + System.currentTimeMillis()
        val state = MissionState(id, goal, "planning", 0, maxSteps, 0, 0, false, "")
        save(state)
        return state
    }

    @Synchronized
    fun load(id: String): MissionState? {
        val f = File(root, "$id.json")
        if (!f.isFile) return null
        return runCatching { MissionState.fromJson(JSONObject(f.readText())) }.getOrNull()
    }

    @Synchronized
    fun save(state: MissionState) {
        val target = File(root, "${state.id}.json")
        val tmp = File(root, "${state.id}.json.tmp")
        tmp.writeText(state.toJson().toString(2))
        if (!tmp.renameTo(target)) {
            target.writeText(tmp.readText())
            tmp.delete()
        }
    }

    fun latestIncomplete(): MissionState? = list().firstOrNull { !it.completed && it.phase != "complete" }

    fun list(): List<MissionState> = root.listFiles()?.mapNotNull { f ->
        if (!f.name.endsWith(".json")) null else runCatching { MissionState.fromJson(JSONObject(f.readText())) }.getOrNull()
    }?.sortedByDescending { it.updatedAtMs } ?: emptyList()
}

data class MissionState(
    val id: String,
    val goal: String,
    val phase: String,
    val step: Int,
    val maxSteps: Int,
    val failures: Int,
    val toolCalls: Int,
    val completed: Boolean,
    val summary: String,
    val updatedAtMs: Long = System.currentTimeMillis(),
    val tasks: List<MissionTask> = emptyList(),
    val evidence: List<String> = emptyList()
) {
    fun toJson() = JSONObject()
        .put("id", id).put("goal", goal).put("phase", phase).put("step", step)
        .put("max_steps", maxSteps).put("failures", failures).put("tool_calls", toolCalls)
        .put("completed", completed).put("summary", summary).put("updated_at_ms", updatedAtMs)
        .put("tasks", JSONArray(tasks.map { it.toJson().toString() }))
        .put("evidence", JSONArray(evidence))

    companion object {
        fun fromJson(o: JSONObject): MissionState {
            val tasksArr = o.optJSONArray("tasks") ?: JSONArray()
            val tasks = buildList { for (i in 0 until tasksArr.length()) {
                val raw = tasksArr.opt(i)
                when (raw) {
                    is JSONObject -> add(MissionTask.fromJson(raw))
                    is String -> runCatching { add(MissionTask.fromJson(JSONObject(raw))) }
                }
            }}
            val evidenceArr = o.optJSONArray("evidence") ?: JSONArray()
            return MissionState(
                o.optString("id"), o.optString("goal"), o.optString("phase", "planning"),
                o.optInt("step"), o.optInt("max_steps", 30), o.optInt("failures"),
                o.optInt("tool_calls"), o.optBoolean("completed"), o.optString("summary"),
                o.optLong("updated_at_ms", System.currentTimeMillis()), tasks,
                buildList { for (i in 0 until evidenceArr.length()) add(evidenceArr.optString(i)) }
            )
        }
    }
}

data class MissionTask(
    val id: String,
    val title: String,
    val status: String = "pending",
    val verification: String = "",
    val attempts: Int = 0
) {
    fun toJson() = JSONObject().put("id", id).put("title", title).put("status", status)
        .put("verification", verification).put("attempts", attempts)

    companion object {
        fun fromJson(o: JSONObject) = MissionTask(
            o.optString("id"), o.optString("title"), o.optString("status", "pending"),
            o.optString("verification"), o.optInt("attempts")
        )
    }
}
