package com.husain.aicoder.core

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** Append-only-ish evidence ledger: every acceptance claim is tied to fresh artifacts. */
class EvidenceLedger(private val workspace: CodingWorkspace) {
    private val file = File(workspace.root, "gameforge/EVIDENCE_LEDGER.jsonl").apply { parentFile?.mkdirs() }

    @Synchronized fun add(kind: String, source: String, details: String, artifactPath: String? = null): JSONObject {
        val o = JSONObject()
            .put("timestamp_ms", System.currentTimeMillis())
            .put("kind", kind)
            .put("source", source)
            .put("details", details.take(12000))
        artifactPath?.let {
            val f = File(workspace.root, it)
            if (f.isFile) o.put("artifact", it).put("sha256", sha256(f))
        }
        file.appendText(o.toString() + "\n")
        return o
    }

    fun recent(limit: Int = 24): JSONArray {
        if (!file.isFile) return JSONArray()
        return JSONArray().apply { file.readLines().takeLast(limit.coerceIn(1, 200)).forEach { line -> runCatching { put(JSONObject(line)) } } }
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(1024 * 1024)
            while (true) { val n = input.read(buf); if (n <= 0) break; md.update(buf, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
