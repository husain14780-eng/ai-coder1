package com.husain.aicoder.vision

import org.json.JSONObject

/** Optional local multimodal interface. The core agent remains usable without a VLM. */
interface VlmAdapter {
    suspend fun describeImage(imagePath: String, prompt: String): JSONObject
    fun id(): String
}

class NoopVlmAdapter : VlmAdapter {
    override suspend fun describeImage(imagePath: String, prompt: String): JSONObject = JSONObject()
        .put("available", false).put("reason", "No local VLM adapter configured")
    override fun id(): String = "none"
}
