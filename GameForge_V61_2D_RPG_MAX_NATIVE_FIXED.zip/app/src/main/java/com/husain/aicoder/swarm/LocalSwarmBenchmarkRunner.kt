package com.husain.aicoder.swarm

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.arm.aichat.ReasoningMode
import kotlinx.coroutines.flow.collect
import org.json.JSONArray
import org.json.JSONObject

/** Short, repeatable local benchmark used to rank installed serious specialists without any cloud service. */
class LocalSwarmBenchmarkRunner(
    private val swarm: LocalModelSwarmManager,
    private val engine: SwarmInferenceEngine,
    private val learning: SwarmLearningManager
) {
    data class Result(val modelId: String, val tasks: Int, val passed: Int, val averageMs: Long, val quality: Double)

    suspend fun run(onStatus: (String) -> Unit = {}): JSONObject {
        val results = mutableListOf<Result>()
        for (installed in swarm.installed()) {
            if (installed.profile.supportsVision || !swarm.canAutoLoad(installed.profile, allowHeavy = false)) continue
            engine.setManualProfile(installed.profile.id)
            val prompts = promptsFor(installed.profile)
            var pass = 0
            var totalQuality = 0.0
            var totalMs = 0L
            for ((i, prompt) in prompts.withIndex()) {
                onStatus("Benchmarking ${installed.profile.displayName} • ${i + 1}/${prompts.size}")
                val started = System.currentTimeMillis()
                var text = ""
                runCatching {
                    engine.sendUserPrompt(prompt, GenerationConfig(
                        mode = if (installed.profile.roles.contains(LocalModelProfile.Role.REASONING)) ReasoningMode.THINKING else ReasoningMode.FAST,
                        maxTokens = 900,
                        temperature = 0.45f,
                        topP = 0.90f,
                        topK = 20,
                        repeatPenalty = 1.05f
                    )).collect { text += it }
                }.onSuccess {
                    if (text.isNotBlank()) pass++
                }
                val ms = System.currentTimeMillis() - started
                totalMs += ms
                val quality = quality(text)
                totalQuality += quality
                learning.record("benchmark", installed.profile.id, text.isNotBlank(), quality, ms)
            }
            results += Result(installed.profile.id, prompts.size, pass, if (prompts.isEmpty()) 0 else totalMs / prompts.size, if (prompts.isEmpty()) 0.0 else totalQuality / prompts.size)
        }
        engine.clearManualProfile()
        val out = JSONObject().put("timestamp_ms", System.currentTimeMillis())
        out.put("results", JSONArray().apply { results.forEach { put(JSONObject().put("model", it.modelId).put("tasks", it.tasks).put("passed", it.passed).put("pass_rate", if (it.tasks == 0) 0.0 else it.passed.toDouble()/it.tasks).put("average_ms", it.averageMs).put("quality", it.quality)) } })
        return out
    }

    private fun promptsFor(p: LocalModelProfile): List<String> = when {
        p.roles.contains(LocalModelProfile.Role.CODING) -> listOf(
            "Fix this GDScript bug: var hp = 10; func hit(): hp -= damage where damage may be undefined. Return corrected code and explain the guard.",
            "Design a small Godot inventory data structure with add/remove/stack behavior. Return concise GDScript.",
            "Given a null reference crash in a player controller, list the root-cause checks in priority order."
        )
        p.roles.contains(LocalModelProfile.Role.REASONING) -> listOf(
            "Architect a save/load system for a Godot game with atomic writes, rollback and schema versions.",
            "A game feels repetitive after ten minutes. Diagnose three systemic causes and propose measurable fixes.",
            "Plan an autonomous build-test-repair loop for a small 3D game."
        )
        else -> listOf(
            "Give a concise implementation plan for a polished Godot game prototype.",
            "Review a game feature request and identify missing acceptance tests.",
            "List the evidence needed before declaring a game release-ready."
        )
    }

    private fun quality(text: String): Double {
        if (text.isBlank()) return 0.0
        var s = 0.3
        if (text.length > 250) s += 0.15
        if (text.contains("```")) s += 0.15
        if (text.contains("test", true) || text.contains("verify", true)) s += 0.15
        if (text.contains("error", true) || text.contains("edge", true)) s += 0.10
        return s.coerceIn(0.0, 1.0)
    }
}
