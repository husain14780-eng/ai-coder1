package com.husain.aicoder.ml

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import kotlin.math.max
import kotlin.random.Random

/** Persistent experience curator. It deliberately separates memory from weight updates. */
class ContinuousLearningManager(context: Context) {
    private val root = File(context.filesDir, "continuous_learning").apply { mkdirs() }
    private val raw = File(root, "experience.jsonl")
    private val curated = File(root, "curated_sft.jsonl")
    private val holdout = File(root, "holdout.jsonl")
    private val rejected = File(root, "rejected.jsonl")
    private val registry = File(root, "model_registry.jsonl")
    private val adapterState = File(root, "adapter_state.json")

    @Synchronized fun recordAgentTurn(goal: String, mode: String, output: String) {
        append(raw, JSONObject().put("type", "agent_turn").put("goal", goal).put("mode", mode)
            .put("output", output.take(16000)).put("time", System.currentTimeMillis()))
    }

    @Synchronized fun recordOutcome(goal: String, success: Boolean, result: String) {
        append(raw, JSONObject().put("type", "outcome").put("goal", goal).put("success", success)
            .put("result", result.take(16000)).put("time", System.currentTimeMillis()))
    }

    @Synchronized fun recordExperience(goal: String, observation: String, action: String, result: String, success: Boolean) {
        append(raw, JSONObject().put("type", "experience").put("goal", goal).put("observation", observation.take(12000))
            .put("action", action.take(4000)).put("result", result.take(8000)).put("success", success)
            .put("time", System.currentTimeMillis()))
    }

    @Synchronized fun curate(maxTrain: Int = 1500, maxHoldout: Int = 350) {
        val lines = raw.takeLastLines(10000)
        val candidates = buildCandidates(lines)
        val deduped = candidates.groupBy { sha256(it.normalizedKey()) }.values.map { group ->
            group.maxByOrNull { it.quality }!!
        }.sortedWith(compareByDescending<Candidate> { it.quality }.thenByDescending { it.time })

        val rng = Random(42)
        val shuffledByBucket = deduped.groupBy { it.bucket }.values.flatMap { it.shuffled(rng) }
        val holdoutPool = shuffledByBucket.take(maxHoldout).toMutableList()
        val trainPool = shuffledByBucket.drop(holdoutPool.size).toMutableList()

        // Keep recent data below 25% of the retained training set.
        val recentCutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L
        val recentTrain = trainPool.filter { it.time >= recentCutoff }
        val oldTrain = trainPool.filter { it.time < recentCutoff }
        val recentCap = max(1, (maxTrain * 0.25).toInt())
        val train = (oldTrain.take((maxTrain - recentCap).coerceAtLeast(0)) + recentTrain.shuffled(rng).take(recentCap))
            .distinctBy { sha256(it.normalizedKey()) }
            .take(maxTrain)

        holdout.writeText(holdoutPool.joinToString("\n") { it.json.toString() } + if (holdoutPool.isNotEmpty()) "\n" else "")
        curated.writeText(train.joinToString("\n") { toSft(it).toString() } + if (train.isNotEmpty()) "\n" else "")

        val rejectedRows = deduped.drop(maxTrain + maxHoldout).take(1000)
        rejected.writeText(rejectedRows.joinToString("\n") { it.json.toString() } + if (rejectedRows.isNotEmpty()) "\n" else "")
    }

    fun markAdapterLoaded(path: String, scale: Float) {
        adapterState.writeText(JSONObject().put("loaded", true).put("path", path).put("scale", scale).put("time", System.currentTimeMillis()).toString(2))
    }

    fun markAdapterCleared() {
        adapterState.writeText(JSONObject().put("loaded", false).put("time", System.currentTimeMillis()).toString(2))
    }

    fun registerEvaluation(file: File, score: Double, summary: String) {
        append(registry, JSONObject().put("type", "evaluation").put("file", file.absolutePath)
            .put("score", score).put("summary", summary).put("time", System.currentTimeMillis()))
    }

    @Synchronized fun exportLoraManifest(baseModel: String, outputDir: File): File {
        outputDir.mkdirs()
        curate()
        val manifest = File(outputDir, "qwen3_4b_lora_manifest.json")
        val eval = File(outputDir, "candidate_gate_policy.json")
        manifest.writeText(
            JSONObject()
                .put("base_model", baseModel)
                .put("dataset", curated.absolutePath)
                .put("holdout", holdout.absolutePath)
                .put("strategy", "LoRA_SFT_plus_replay_plus_holdout")
                .put("target_modules", JSONArray().put("q_proj").put("k_proj").put("v_proj").put("o_proj").put("gate_proj").put("up_proj").put("down_proj"))
                .put("epochs", 2)
                .put("learning_rate", 5e-6)
                .put("cutoff_len", 4096)
                .put("lora_rank", 16)
                .put("lora_alpha", 32)
                .put("lora_dropout", 0.05)
                .put("holdout_fraction", 0.15)
                .put("recent_data_cap", 0.25)
                .put("require_unseen_eval", true)
                .put("created_at_ms", System.currentTimeMillis())
                .toString(2)
        )
        eval.writeText(
            JSONObject()
                .put("minimum_absolute_score", 0.55)
                .put("minimum_delta_vs_previous", 0.01)
                .put("max_allowed_regression", 0.03)
                .put("must_pass_holdout", true)
                .put("must_pass_unseen", true)
                .put("base_model_immutable", true)
                .toString(2)
        )
        return manifest
    }

    @Synchronized fun registerAdapter(adapter: File, score: Double, notes: String) {
        append(registry, JSONObject().put("type", "adapter").put("adapter", adapter.absolutePath)
            .put("score", score).put("notes", notes).put("time", System.currentTimeMillis()))
    }

    fun root(): File = root
    fun curatedFile(): File = curated
    fun holdoutFile(): File = holdout
    fun rejectedFile(): File = rejected

    private data class Candidate(val json: JSONObject, val bucket: String, val quality: Double, val time: Long) {
        fun normalizedKey(): String = listOf(
            json.optString("goal"), json.optString("action"), json.optString("result"), json.optString("output")
        ).joinToString("|").trim().lowercase()
    }

    private fun buildCandidates(lines: List<String>): List<Candidate> {
        val turns = mutableMapOf<String, JSONObject>()
        val outcomes = mutableMapOf<String, JSONObject>()
        val result = mutableListOf<Candidate>()
        for (line in lines) {
            val o = runCatching { JSONObject(line) }.getOrNull() ?: continue
            val type = o.optString("type")
            val goal = o.optString("goal")
            when (type) {
                "agent_turn" -> turns[goal] = o
                "outcome" -> outcomes[goal] = o
                "experience", "coding_lesson" -> {
                    val quality = quality(o)
                    result += Candidate(o, bucket(o), quality, o.optLong("time", o.optLong("timestamp_ms", 0L)))
                }
            }
        }

        outcomes.forEach { (goal, outcome) ->
            val turn = turns[goal]
            val merged = JSONObject(outcome.toString())
            if (turn != null) {
                merged.put("output", turn.optString("output"))
                merged.put("mode", turn.optString("mode"))
            }
            result += Candidate(merged, bucket(merged), quality(merged), outcome.optLong("time", 0L))
        }
        return result
    }

    private fun quality(o: JSONObject): Double {
        var q = 0.35
        if (o.optBoolean("success", false)) q += 0.35
        val text = (o.optString("result") + " " + o.optString("output") + " " + o.optString("fix")).lowercase()
        if (text.contains("test") && (text.contains("pass") || text.contains("verified") || text.contains("evidence"))) q += 0.2
        if (o.optString("action").isNotBlank()) q += 0.05
        if (o.optString("fix").isNotBlank()) q += 0.05
        if (text.contains("guess") || text.contains("probably") || text.contains("maybe")) q -= 0.15
        return q.coerceIn(0.0, 1.0)
    }

    private fun bucket(o: JSONObject): String {
        val text = (o.optString("goal") + " " + o.optString("failure") + " " + o.optString("mode")).lowercase()
        return when {
            text.contains("debug") || text.contains("error") || text.contains("exception") -> "debugging"
            text.contains("architecture") || text.contains("refactor") -> "architecture"
            text.contains("test") -> "testing"
            text.contains("performance") || text.contains("perf") -> "performance"
            text.contains("gameplay") -> "gameplay"
            else -> "general"
        }
    }

    private fun toSft(c: Candidate): JSONObject {
        val o = c.json
        val goal = o.optString("goal")
        val context = listOf(o.optString("observation"), o.optString("result"), o.optString("failure"))
            .filter { it.isNotBlank() }.joinToString("\n")
        val action = listOf(o.optString("action"), o.optString("fix"), o.optString("output"))
            .firstOrNull { it.isNotBlank() } ?: o.optString("result")
        return JSONObject()
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", "You are a coding agent. Inspect, edit, test, verify. Never invent evidence."))
                .put(JSONObject().put("role", "user").put("content", "Goal: $goal\nContext: $context"))
                .put(JSONObject().put("role", "assistant").put("content", action)))
            .put("quality", c.quality)
            .put("bucket", c.bucket)
            .put("source", o.optString("type"))
    }

    private fun append(file: File, obj: JSONObject) = file.appendText(obj.toString() + "\n")
    private fun sha256(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
        .joinToString("") { "%02x".format(it) }
}

private fun File.takeLastLines(limit: Int): List<String> = if (!exists()) emptyList() else useLines { it.toList().takeLast(limit) }
