package com.husain.aicoder.mission

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** Durable GameForge session state for crash/restart recovery. */
class GameBuildStore(context: Context) {
    private val dir = File(context.filesDir, "gameforge/builds").apply { mkdirs() }

    @Synchronized
    fun save(id: String, state: JSONObject) {
        val safe = id.replace(Regex("[^A-Za-z0-9_.-]"), "_")
        val out = File(dir, "$safe.json")
        val tmp = File(dir, ".$safe.json.part")
        FileOutputStream(tmp).use { outStream ->
            outStream.write(state.toString(2).toByteArray(Charsets.UTF_8))
            outStream.fd.sync()
        }
        runCatching {
            java.nio.file.Files.move(tmp.toPath(), out.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE)
        }.recoverCatching {
            java.nio.file.Files.move(tmp.toPath(), out.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        }.getOrElse { throw IllegalStateException("Unable to finalize build state", it) }
    }

    fun latest(): JSONObject? = dir.listFiles()?.filter { it.extension == "json" }
        ?.maxByOrNull { it.lastModified() }
        ?.let { runCatching { JSONObject(it.readText()) }.getOrNull() }

    fun list(): List<File> = dir.listFiles()?.filter { it.extension == "json" }?.sortedByDescending { it.lastModified() } ?: emptyList()
}
