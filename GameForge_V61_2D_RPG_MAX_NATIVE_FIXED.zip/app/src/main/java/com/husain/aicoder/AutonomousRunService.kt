package com.husain.aicoder

import android.app.Notification
import android.app.NotificationChannel
import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.husain.aicoder.ml.MLTrainingCoordinator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Keeps the lightweight experience curation heartbeat alive in a foreground process. */
class AutonomousRunService : Service() {
    private val scope = CoroutineScope(Job() + Dispatchers.Default)
    private lateinit var learner: MLTrainingCoordinator

    override fun onCreate() {
        super.onCreate()
        learner = MLTrainingCoordinator(this)

        val channel = NotificationChannel(
            "ai_run",
            "AI autonomous runs",
            android.app.NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)

        val notification = Notification.Builder(this, "ai_run")
            .setContentTitle("AI Coder is running")
            .setContentText("Local Qwen + experience-learning heartbeat")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()

        startForeground(1001, notification)
        scope.launch {
            while (isActive) {
                runCatching { learner.periodicTraining() }
                delay(10 * 60 * 1000L)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        scope.coroutineContext[Job]?.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
