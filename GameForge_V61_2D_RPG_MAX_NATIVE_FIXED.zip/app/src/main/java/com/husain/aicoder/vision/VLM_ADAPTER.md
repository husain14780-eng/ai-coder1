# Local VLM adapter boundary

Qwen3-4B text inference remains text-only. GameForge therefore keeps perception behind `VisionBackend`.

Current default:
- `PixelVisionBackend`: luminance, edge density, motion and telemetry.

Optional stronger backend:
- implement `VisionBackend` for a local multimodal GGUF/VLM model;
- expose it through `VisionRouter.multimodalBackend`;
- convert its output to stable JSON fields rather than leaking long vision text into every coding prompt.

The rest of GameForge does not need to change when a local VLM is added.
