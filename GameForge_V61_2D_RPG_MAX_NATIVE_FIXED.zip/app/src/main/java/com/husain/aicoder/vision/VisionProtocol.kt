package com.husain.aicoder.vision

import android.graphics.Bitmap
import org.json.JSONObject

interface VisionProvider {
    suspend fun describe(bitmap: Bitmap, prompt: String = "Describe only actionable UI/gameplay facts."): JSONObject
}

/** Placeholder provider that exposes non-semantic pixel facts to the text-only coding model. */
class StructuredVisionProvider : VisionProvider {
    private val perception = ScreenPerception()
    override suspend fun describe(bitmap: Bitmap, prompt: String): JSONObject = perception.analyze(bitmap)
}
