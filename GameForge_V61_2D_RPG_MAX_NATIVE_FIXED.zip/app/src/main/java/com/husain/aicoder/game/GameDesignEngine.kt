package com.husain.aicoder.game

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.arm.aichat.ReasoningMode
import kotlinx.coroutines.flow.collect
import org.json.JSONObject

/** Turns a vague game idea into a concrete, testable GameSpec. */
class GameDesignEngine(private val engine: InferenceEngine) {
    private val router = com.husain.aicoder.router.ModelRouter()
    suspend fun design(goal: String): GameSpec {
        val prompt = """
            TASK_ROLE: DESIGN
            You are GameForge V6, an expert game designer and technical director.
            Convert the user's game idea into a build-ready JSON specification.
            This is the design/reasoning phase; do not implement code.
            Do not write implementation code yet. Make the design coherent, testable and achievable in Godot.
            For RPG/MMORPG/2D requests, default to a 2D camera such as top_down_2d or side_2d,
            explicitly plan generated sprites, animation sets, procedural maps, VFX and bot-testable combat.
            Visual assets must be AI-authored from the current game design/seed. The design may specify visual recipes for sprites/animations and ASCII layouts or landmarks for maps; do not assume a fixed asset pack.
            Return JSON only with keys:
            title, genre, camera, core_loop, mechanics, player, enemies, progression, scenes, ui,
            audio, save_system, performance_targets, polish_passes, constraints.

            USER GAME IDEA:
            $goal
        """.trimIndent()
        val out = StringBuilder()
        val route = router.route(kind = "design", risk = 0.90, evidence = false, complexity = 9)
        engine.sendUserPrompt(
            prompt,
            GenerationConfig(route.mode, route.maxTokens, route.temperature, 0.92f, 30, 0f, 1.05f)
        ).collect { out.append(it) }
        val text = out.toString()
        val jsonText = extractJson(text)
        return runCatching { GameSpec.fromJson(JSONObject(jsonText)) }
            .getOrElse { GameSpec.fallback(goal) }
    }

    private fun extractJson(text: String): String {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        require(start >= 0 && end > start) { "Game design did not return JSON" }
        return text.substring(start, end + 1)
    }
}
