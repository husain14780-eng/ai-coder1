package com.husain.aicoder.game

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Checks whether the implemented workspace still reflects the durable GameSpec and generated planning artifacts. */
class GameDesignConsistencyChecker(private val workspace: CodingWorkspace) {
    fun check(spec: GameSpec): JSONObject {
        val required = listOf(
            "GAME_SPEC.json", "GAME_DESIGN.md", "ASSET_MANIFEST.json", "GAMEFORGE_CONTRACT.md",
            "gameforge/LEVEL_DESIGN_PLAN.json", "gameforge/STYLE_BOOK.json", "gameforge/GAMEPLAY_SCENARIOS.json",
            "project.godot", "main.tscn"
        )
        val missing = JSONArray(required.filter { !File(workspace.root, it).isFile })
        val contradictions = JSONArray()
        val specFile = File(workspace.root, "GAME_SPEC.json")
        if (specFile.isFile) {
            val onDisk = runCatching { GameSpec.fromJson(JSONObject(specFile.readText())) }.getOrNull()
            if (onDisk != null && onDisk.genre != spec.genre) contradictions.put("genre_mismatch")
            if (onDisk != null && onDisk.camera != spec.camera) contradictions.put("camera_mismatch")
            if (onDisk != null && onDisk.title != spec.title) contradictions.put("title_mismatch")
        }
        val sourceFiles = workspace.list().count { it.endsWith(".gd") || it.endsWith(".tscn") }
        val requiredScore = 1.0 - missing.length().toDouble() / required.size.coerceAtLeast(1)
        val contradictionPenalty = contradictions.length() * 0.12
        val score = (requiredScore - contradictionPenalty).coerceIn(0.0, 1.0)
        return JSONObject()
            .put("score", score)
            .put("missing", missing)
            .put("contradictions", contradictions)
            .put("godot_source_files", sourceFiles)
            .put("passed", missing.length() == 0 && contradictions.length() == 0)
            .put("generated_at_ms", System.currentTimeMillis())
    }
}
