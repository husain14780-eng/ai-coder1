package com.husain.aicoder.swarm

import android.app.ActivityManager
import android.content.Context
import com.husain.aicoder.model.ModelManager
import java.io.File

/** Device-aware local model selection and installed-model discovery. */
class LocalModelSwarmManager(private val context: Context, private val modelManager: ModelManager) {
    data class DeviceSnapshot(
        val totalRamMb: Long,
        val availableRamMb: Long,
        val lowMemory: Boolean,
        val cpuCores: Int,
        val freeStorageGb: Double
    )

    data class Installed(val profile: LocalModelProfile, val file: File)

    fun deviceSnapshot(): DeviceSnapshot {
        val info = ActivityManager.MemoryInfo()
        context.getSystemService(ActivityManager::class.java).getMemoryInfo(info)
        val stat = android.os.StatFs(modelManager.modelsDirectory().absolutePath)
        return DeviceSnapshot(
            totalRamMb = info.totalMem / (1024L * 1024L),
            availableRamMb = info.availMem / (1024L * 1024L),
            lowMemory = info.lowMemory,
            cpuCores = Runtime.getRuntime().availableProcessors(),
            freeStorageGb = stat.availableBytes.toDouble() / 1_000_000_000.0
        )
    }

    fun installed(): List<Installed> {
        val dir = modelManager.modelsDirectory()
        return LocalModelCatalog.profiles.mapNotNull { p ->
            dir.listFiles()?.firstOrNull { f -> f.isFile && p.filenamePatterns.any { it.matches(f.name) } }?.let { Installed(p, it) }
        }
    }

    fun installedProfile(id: String): Installed? = installed().firstOrNull { it.profile.id == id }

    fun canAutoLoad(profile: LocalModelProfile, allowHeavy: Boolean = false): Boolean {
        val snap = deviceSnapshot()
        if (profile.experimentalHeavy && !allowHeavy) return false
        val required = profile.estimatedRamGb * 1024.0 + 700.0
        return snap.availableRamMb >= required && !snap.lowMemory
    }

    fun bestInstalled(role: LocalModelProfile.Role, scores: Map<String, Double> = emptyMap(), allowHeavy: Boolean = false): Installed? {
        val candidates = installed().filter { role in it.profile.roles && canAutoLoad(it.profile, allowHeavy) }
        return candidates.maxWithOrNull(compareBy<Installed> { scores[it.profile.id] ?: 0.0 }
            .thenBy { it.profile.estimatedRamGb * -1.0 })
    }

    fun bestFallbackFor(roles: Set<LocalModelProfile.Role>, allowHeavy: Boolean): Installed? {
        val preferredOrder = buildList {
            roles.forEach { add(it) }
            add(LocalModelProfile.Role.CODING)
            add(LocalModelProfile.Role.REASONING)
            add(LocalModelProfile.Role.GENERAL)
            add(LocalModelProfile.Role.GAME_DESIGN)
        }.distinct()
        for (preferred in preferredOrder) {
            val item = bestInstalled(preferred, emptyMap(), allowHeavy)
            if (item != null) return item
        }
        return installed().firstOrNull { canAutoLoad(it.profile, allowHeavy) }
    }

    fun contextFor(profile: LocalModelProfile, availableRamMb: Long): Int {
        val preferred = profile.contextTokens
        return when {
            availableRamMb >= 5600 -> minOf(preferred, 8192)
            availableRamMb >= 4300 -> minOf(preferred, 6144)
            availableRamMb >= 3000 -> minOf(preferred, 4096)
            else -> minOf(preferred, 3072)
        }.coerceAtLeast(2048)
    }

    fun statusText(): String {
        val snap = deviceSnapshot()
        val installed = installed()
        val names = if (installed.isEmpty()) "none" else installed.joinToString(", ") { it.profile.displayName }
        return "RAM ${snap.availableRamMb}MB free / ${snap.totalRamMb}MB • cores=${snap.cpuCores} • storage=${"%.1f".format(snap.freeStorageGb)}GB • installed: $names"
    }
}
