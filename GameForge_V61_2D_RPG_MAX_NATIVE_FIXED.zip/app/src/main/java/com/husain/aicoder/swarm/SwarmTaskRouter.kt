package com.husain.aicoder.swarm

/** Semantic task router. Explicit TASK_ROLE tags override keyword ambiguity. */
class SwarmTaskRouter(private val swarm: LocalModelSwarmManager, private val learning: SwarmLearningManager) {
    data class Decision(val task: String, val profile: LocalModelProfile, val reason: String)

    fun classify(prompt: String): String {
        val p = prompt.lowercase()
        val explicit = Regex("task_role\\s*[:=]\\s*(vision|coding|reasoning|design|general)").find(p)?.groupValues?.getOrNull(1)
        if (explicit != null) return explicit
        return when {
            listOf("screenshot", "image", "visual", "ui layout", "pixel", "camera frame").any { it in p } -> "vision"
            listOf("architecture", "root cause", "tradeoff", "quality gate", "system design", "debugging strategy").any { it in p } -> "reasoning"
            listOf("game design", "level design", "mechanic", "core loop", "progression", "player experience").any { it in p } &&
                !listOf("compile", "compiler", "stack trace", "exception", "bug", "fix", "refactor", "gdscript", "c#", "code", "script", "function", "class").any { it in p } -> "design"
            listOf("compile", "compiler", "stack trace", "exception", "bug", "fix", "refactor", "gdscript", "c#", "code", "script", "function", "class").any { it in p } -> "coding"
            else -> "general"
        }
    }

    fun decide(prompt: String): Decision {
        val task = classify(prompt)
        val role = when (task) {
            "coding" -> LocalModelProfile.Role.CODING
            "reasoning" -> LocalModelProfile.Role.REASONING
            "vision" -> LocalModelProfile.Role.VISION
            "design" -> LocalModelProfile.Role.GAME_DESIGN
            else -> LocalModelProfile.Role.GENERAL
        }
        val scores = swarm.installed().associate { it.profile.id to learning.score(it.profile.id, task) }
        val installed = if (task == "vision") {
            swarm.bestInstalled(LocalModelProfile.Role.GENERAL, scores, allowHeavy = false)
        } else {
            swarm.bestInstalled(role, scores, allowHeavy = task == "coding")
                ?: swarm.bestInstalled(LocalModelProfile.Role.REASONING, scores, allowHeavy = false).takeIf { task == "coding" }
                ?: swarm.bestInstalled(LocalModelProfile.Role.CODING, scores, allowHeavy = false).takeIf { task == "reasoning" }
                ?: swarm.bestInstalled(LocalModelProfile.Role.GENERAL, scores, allowHeavy = false)
        } ?: error("No installed local model can safely serve task=$task")
        val reason = "task=$task → role=$role → ${installed.profile.displayName}; learnedScore=${"%.3f".format(scores[installed.profile.id] ?: 0.0)}"
        return Decision(task, installed.profile, reason)
    }
}
