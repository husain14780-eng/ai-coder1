package com.husain.aicoder.quality

import com.husain.aicoder.game.GameSpec
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** Turns the design contract and test evidence into explicit pacing/balance targets. */
class GameplayBalanceEngine {
    fun assess(spec: GameSpec, playtest: JSONObject, scenarios: JSONObject): JSONObject {
        val scenarioCount = scenarios.optInt("scenario_count", 0)
        val iterations = playtest.optInt("iterations", 0)
        val passRate = playtest.optDouble("pass_rate", 0.0)
        val errors = playtest.optInt("error_signal_count", 0)
        val targetLayers = maxOf(4, spec.progression.size + spec.coreLoop.size / 2)
        val pacing = JSONArray().apply {
            put(JSONObject().put("stage", "onboarding").put("target_difficulty", 0.25))
            put(JSONObject().put("stage", "core").put("target_difficulty", 0.50))
            put(JSONObject().put("stage", "escalation").put("target_difficulty", 0.72))
            put(JSONObject().put("stage", "mastery").put("target_difficulty", 0.88))
        }
        val risk = (errors * 0.12 + abs(0.90 - passRate) * 0.75 + if (scenarioCount < targetLayers) 0.15 else 0.0).coerceIn(0.0, 1.0)
        return JSONObject()
            .put("genre", spec.genre)
            .put("target_progression_layers", targetLayers)
            .put("scenario_count", scenarioCount)
            .put("playtest_iterations", iterations)
            .put("pass_rate", passRate)
            .put("error_signals", errors)
            .put("balance_risk", risk)
            .put("pacing_contract", pacing)
            .put("recommendations", JSONArray().apply {
                if (scenarioCount < targetLayers) put("expand scenario coverage before tuning difficulty")
                if (passRate < 0.85) put("simplify the first successful path and add clearer feedback")
                if (errors > 0) put("remove failure loops before increasing challenge")
                if (risk > 0.45) put("run a dedicated balance pass after gameplay defects are fixed")
            })
    }
}
