package com.husain.aicoder.quality

import org.json.JSONArray
import org.json.JSONObject

/** Final benchmark overlay: adds genre fidelity, balance risk, artifact provenance and release hygiene. */
class GameQualityBenchmarkV4 {
    data class Result(val passed: Boolean, val score: Double, val report: JSONObject)

    fun evaluate(
        v3: JSONObject,
        genreBlueprint: JSONObject,
        balance: JSONObject,
        provenanceOk: Boolean,
        assetManifestOk: Boolean,
        saveContractOk: Boolean
    ): Result {
        val dims = JSONArray(v3.optJSONArray("dimensions")?.toString() ?: "[]")
        val blockers = mutableListOf<String>()
        val base = (v3.optDouble("score", 0.0) / 100.0).coerceIn(0.0, 1.0)
        val systems = genreBlueprint.optJSONArray("required_systems")?.length() ?: 0
        val balanceRisk = balance.optDouble("balance_risk", 1.0).coerceIn(0.0, 1.0)
        val genreFidelity = if (systems >= 5) 0.9 else 0.7
        val balanceHealth = 1.0 - balanceRisk
        val assetHealth = if (assetManifestOk) 1.0 else 0.0
        val saveHealth = if (saveContractOk) 1.0 else 0.0
        val provenance = if (provenanceOk) 1.0 else 0.0
        val finalScore = (base * 0.72 + genreFidelity * 0.07 + balanceHealth * 0.08 + assetHealth * 0.04 + saveHealth * 0.04 + provenance * 0.05).coerceIn(0.0, 1.0)

        if (balanceRisk > 0.60) blockers += "balance_risk_above_0.60"
        if (!assetManifestOk) blockers += "asset_manifest_missing_or_invalid"
        if (!saveContractOk) blockers += "save_system_contract_missing"
        if (!provenanceOk) blockers += "release_provenance_missing"
        if (v3.optBoolean("passed", false).not()) blockers += "v3_quality_gate_failed"

        val report = JSONObject()
            .put("benchmark_version", "4.0-final-max")
            .put("score", finalScore * 100.0)
            .put("passed", blockers.isEmpty() && finalScore >= 0.88)
            .put("base_v3_score", base * 100.0)
            .put("genre_fidelity", genreFidelity)
            .put("balance_health", balanceHealth)
            .put("asset_health", assetHealth)
            .put("save_contract_health", saveHealth)
            .put("provenance_health", provenance)
            .put("dimensions", dims)
            .put("blockers", JSONArray(blockers))
            .put("genre_blueprint", genreBlueprint)
            .put("balance", balance)
            .put("generated_at_ms", System.currentTimeMillis())
        return Result(report.optBoolean("passed", false), finalScore * 100.0, report)
    }
}
