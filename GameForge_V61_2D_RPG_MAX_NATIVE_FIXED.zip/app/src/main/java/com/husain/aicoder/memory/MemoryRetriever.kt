package com.husain.aicoder.memory

import android.content.Context
import org.json.JSONObject
import java.io.File
import kotlin.math.max

/** Lightweight on-device lexical retrieval; no server or embedding API required. */
class MemoryRetriever(context: Context) {
    private val root = File(context.filesDir, "continuous_learning")
    private val files = listOf("experience.jsonl", "curated_sft.jsonl", "holdout.jsonl")

    fun retrieve(query: String, topK: Int = 6): List<String> {
        val q = tokens(query)
        if (q.isEmpty()) return emptyList()
        val scored = mutableListOf<Pair<Double, String>>()
        for (name in files) {
            val f = File(root, name)
            if (!f.isFile) continue
            val lines = runCatching { f.useLines { it.toList().takeLast(4000) } }.getOrDefault(emptyList())
            for (line in lines) {
                val text = runCatching { JSONObject(line).toString() }.getOrDefault(line)
                val t = tokens(text)
                if (t.isEmpty()) continue
                val overlap = q.intersect(t).size.toDouble()
                val coverage = overlap / q.size
                val score = coverage * 0.7 + (overlap / max(1, t.size)) * 0.3
                if (score > 0.05) scored += score to text.take(5000)
            }
        }
        return scored.sortedByDescending { it.first }.take(topK).map { it.second }
    }

    private fun tokens(s: String): Set<String> = s.lowercase()
        .split(Regex("[^a-z0-9_+#.-]+"))
        .filter { it.length >= 3 }
        .toSet()
}
