package com.husain.aicoder.game

import org.json.JSONArray
import org.json.JSONObject

/** Deterministic genre blueprints keep generated games structurally faithful to their requested genre. */
class GenreBlueprintLibrary {
    fun blueprint(spec: GameSpec): JSONObject {
        val systems = when (spec.genre.lowercase()) {
            "action_shooter", "fps" -> listOf("aim", "weapons", "enemy_feedback", "cover", "encounters", "combat_loop")
            "rpg", "mmorpg", "rpg_2d" -> listOf("stats", "inventory", "dialogue", "quests", "rewards", "equipment", "save_progression", "combat_state", "bot_testability")
            "roguelike" -> listOf("run_generation", "resource_pressure", "death_loop", "meta_progression", "build_variation", "room_rules")
            "racing" -> listOf("vehicle_controller", "checkpointing", "laps", "opponents", "timing", "restart")
            "puzzle" -> listOf("rules", "state_reset", "hint_system", "progression", "solution_validation", "fail_soft")
            "strategy" -> listOf("resource_economy", "decision_space", "opponents", "map_state", "victory_conditions", "turn_or_tick_loop")
            "survival_horror" -> listOf("exploration", "threat", "resource_scarcity", "sound_feedback", "escape_loop", "save_recovery")
            "platformer" -> listOf("movement", "jump_consistency", "hazards", "checkpoints", "camera_follow", "restart")
            else -> listOf("movement", "interaction", "challenge", "reward", "progression", "recovery")
        }
        val required = JSONArray(systems)
        val acceptance = JSONArray(listOf(
            "core loop is reproducible from a fresh boot",
            "primary mechanic has visible feedback",
            "failure has recovery path",
            "progression is testable without manual intervention",
            "genre-defining system is covered by at least one automated scenario"
        ))
        return JSONObject()
            .put("genre", spec.genre)
            .put("required_systems", required)
            .put("acceptance_contract", acceptance)
            .put("camera_contract", spec.camera)
            .put("source", "GenreBlueprintLibrary")
    }
}
