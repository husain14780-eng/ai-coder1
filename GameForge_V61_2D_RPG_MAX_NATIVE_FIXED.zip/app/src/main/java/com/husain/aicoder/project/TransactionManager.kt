package com.husain.aicoder.project

import com.husain.aicoder.agent.CodingWorkspace

/** Checkpoint-backed transaction guard for risky multi-file repairs. */
class TransactionManager(private val workspace: CodingWorkspace) {
    suspend fun <T> run(label: String, body: suspend () -> T, accept: (T) -> Boolean): T {
        val checkpoint = workspace.checkpoint("tx_$label")
        return try {
            val result = body()
            if (!accept(result)) {
                workspace.restoreCheckpoint(checkpoint.name)
            }
            result
        } catch (t: Throwable) {
            workspace.restoreCheckpoint(checkpoint.name)
            throw t
        }
    }
}
