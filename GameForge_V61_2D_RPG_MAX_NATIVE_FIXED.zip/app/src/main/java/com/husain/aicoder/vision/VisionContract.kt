package com.husain.aicoder.vision

import org.json.JSONObject

/** Stable perception contract so vision models can change without rewriting the planner. */
data class VisionContract(
    val timestampMs: Long,
    val screenshotPath: String?,
    val objects: List<JSONObject>,
    val text: List<String>,
    val stateHints: List<String>,
    val confidence: Double
) {
    fun toJson(): JSONObject = JSONObject()
        .put("timestamp_ms", timestampMs)
        .put("screenshot_path", screenshotPath ?: "")
        .put("objects", org.json.JSONArray(objects))
        .put("text", org.json.JSONArray(text))
        .put("state_hints", org.json.JSONArray(stateHints))
        .put("confidence", confidence)
}
