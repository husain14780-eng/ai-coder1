package com.husain.aicoder.ml

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

/** Runs inexpensive on-device ML and periodically emits a safe Qwen LoRA training package. */
class MLTrainingCoordinator(context: Context) {
    private val learner = ExperienceLearningSystem(context)
    private val continuous = ContinuousLearningManager(context)
    private val modelsDir = File(context.filesDir, "learned_models").apply { mkdirs() }
    private val trainerLock = Any()
    private var cycle = 0

    fun experience(): ExperienceLearningSystem = learner

    suspend fun periodicTraining() = withContext(Dispatchers.Default) {
        synchronized(trainerLock) {
            cycle++
            val labeled = learner.labeledSamples()
            val unlabeled = learner.unlabeledFeatures()
            if (labeled.size >= 8) {
                LogisticRegression().apply { fit(labeled) }
                LinearRegression().apply { fit(labeled) }
                DecisionStumpClassifier().apply { fit(labeled) }

                val pseudo = SemiSupervisedLabeler().pseudoLabel(labeled, unlabeled)
                File(modelsDir, "pseudo_labels.jsonl").appendText(
                    pseudo.joinToString("\n") { JSONObject()
                        .put("input", it.input)
                        .put("label", it.label)
                        .put("confidence", it.confidence)
                        .put("cycle", cycle)
                        .toString() } + if (pseudo.isNotEmpty()) "\n" else ""
                )

                if (unlabeled.size >= 3) {
                    val k = minOf(3, unlabeled.size).coerceAtLeast(2)
                    val clusters = KMeans(k).fit(unlabeled)
                    val reduced = PCA(minOf(3, unlabeled.first().size)).transform(unlabeled)
                    JSONObject()
                        .put("clusters", clusters.toList())
                        .put("pca_points", reduced.map { it.toList() })
                        .put("cycle", cycle)
                        .toString(2)
                        .also { File(modelsDir, "state_features.json").writeText(it) }
                }
            }

            val masked = learner.selfSupervisedTokens().takeLast(100)
                .map { SelfSupervisedMasker().makeMasked(it) }
            if (masked.isNotEmpty()) {
                File(modelsDir, "self_supervised.jsonl").appendText(
                    masked.joinToString("\n") { JSONObject()
                        .put("masked", JSONArrayCompat.stringArray(it.first))
                        .put("targets", JSONArrayCompat.stringArray(it.second))
                        .put("cycle", cycle)
                        .toString() } + "\n"
                )
            }

            File(modelsDir, "q_table.json").writeText(JSONObject(learner.qTable().mapValues { JSONObject(it.value) }).toString(2))
            continuous.curate()
            val packageDir = File(modelsDir, "qwen_lora_dataset")
            continuous.exportLoraManifest("Qwen3-4B", packageDir)
            File(modelsDir, "coding_eval_manifest.json").writeText(
                CodingEvalSuite().manifest().toString(2)
            )
            File(modelsDir, "training_cycle.json").writeText(
                JSONObject()
                    .put("cycle", cycle)
                    .put("time_ms", System.currentTimeMillis())
                    .put("experiences", learner.steps())
                    .put("labeled", labeled.size)
                    .put("unlabeled", unlabeled.size)
                    .put("holdout", true)
                    .put("base_model_immutable", true)
                    .put("phone_side_weight_training", false)
                    .put("lora_data_ready", true)
                    .toString(2)
            )
        }
    }

    fun learnedModelsDirectory(): File = modelsDir
}

private object JSONArrayCompat {
    fun stringArray(values: List<String>): String = values.joinToString(",", prefix = "[", postfix = "]") {
        JSONObject.quote(it)
    }
}
