package com.husain.aicoder.game

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** Generates explicit level-design and procedural-map constraints. */
class LevelDesignEngine {
    fun plan(spec: GameSpec): JSONObject {
        val is2D = spec.camera.contains("2d", true) || spec.genre.contains("rpg", true) || spec.genre.contains("mmorpg", true)
        val hazards = if (is2D) {
            JSONArray().put("spawn safety zone").put("solid wall collision").put("recoverable combat space").put("goal visibility")
        } else {
            JSONArray().put("spawn safety zone").put("readable checkpoint spacing").put("recovery path")
        }
        val pacing = JSONArray().put("teach").put("escalate").put("variation").put("breather").put("payoff")
        return JSONObject()
            .put("genre", spec.genre)
            .put("camera", spec.camera)
            .put("generation", if (is2D) "procedural_2d_map_request_driven" else "deterministic_3d_bootstrap")
            .put("pacing", pacing)
            .put("hazards", hazards)
            .put("target_layout_count", (spec.scenes.size * 2).coerceIn(4, 20))
            .put("map_contract", if (is2D) JSONObject()
                .put("tile_size", 48)
                .put("minimum_dimensions", JSONArray(listOf(24, 16)))
                .put("solid_walls", true)
                .put("spawn_connected_to_goal", true)
                .put("editable_seed", true)
            else JSONObject())
            .put("difficulty_contract", JSONObject()
                .put("never_require_untelegraphed_failure", true)
                .put("keep_early_onboarding_short", true)
                .put("ensure_recovery_after_mistake", true))
    }

    fun validateTelemetry(positions: List<Float>): JSONObject {
        if (positions.size < 3) return JSONObject().put("ok", true).put("sample_count", positions.size)
        var violentJumps = 0
        for (i in 1 until positions.size) if (abs(positions[i] - positions[i - 1]) > 20f) violentJumps++
        return JSONObject().put("ok", violentJumps == 0).put("violent_position_jumps", violentJumps).put("sample_count", positions.size)
    }
}
