package com.husain.aicoder.ml

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt
import kotlin.random.Random

/** Lightweight, dependency-free ML primitives used by AI Coder on Android. */

data class Sample(val x: DoubleArray, val y: Double)

data class LabeledText(val input: String, val label: String)

data class PseudoLabel(val input: String, val label: String, val confidence: Double)

data class RLTransition(
    val state: String,
    val action: String,
    val reward: Double,
    val nextState: String,
    val done: Boolean
)

class LogisticRegression(private val learningRate: Double = 0.05, private val epochs: Int = 200) {
    private var weights = DoubleArray(0)
    private var bias = 0.0

    fun fit(samples: List<Sample>) {
        require(samples.isNotEmpty())
        weights = DoubleArray(samples.first().x.size)
        repeat(epochs) {
            for (s in samples) {
                val p = sigmoid(dot(weights, s.x) + bias)
                val e = p - s.y
                for (i in weights.indices) weights[i] -= learningRate * e * s.x[i]
                bias -= learningRate * e
            }
        }
    }

    fun predictProbability(x: DoubleArray): Double = sigmoid(dot(weights, x) + bias)
    fun predict(x: DoubleArray): Int = if (predictProbability(x) >= 0.5) 1 else 0
}

class LinearRegression(private val learningRate: Double = 0.01, private val epochs: Int = 300) {
    private var weights = DoubleArray(0)
    private var bias = 0.0

    fun fit(samples: List<Sample>) {
        require(samples.isNotEmpty())
        weights = DoubleArray(samples.first().x.size)
        repeat(epochs) {
            for (s in samples) {
                val err = dot(weights, s.x) + bias - s.y
                for (i in weights.indices) weights[i] -= learningRate * err * s.x[i]
                bias -= learningRate * err
            }
        }
    }

    fun predict(x: DoubleArray): Double = dot(weights, x) + bias
}

class DecisionStumpClassifier {
    private var feature = 0
    private var threshold = 0.0
    private var leftLabel = 0
    private var rightLabel = 1

    fun fit(samples: List<Sample>) {
        require(samples.isNotEmpty())
        var bestError = Double.POSITIVE_INFINITY
        val dimensions = samples.first().x.size
        for (f in 0 until dimensions) {
            val values = samples.map { it.x[f] }.distinct().sorted()
            for (t in values) {
                val left = samples.filter { it.x[f] <= t }
                val right = samples.filter { it.x[f] > t }
                if (left.isEmpty() || right.isEmpty()) continue
                val ll = majority(left)
                val rl = majority(right)
                val error = left.count { it.y.toInt() != ll } + right.count { it.y.toInt() != rl }
                if (error < bestError) {
                    bestError = error.toDouble(); feature = f; threshold = t; leftLabel = ll; rightLabel = rl
                }
            }
        }
    }

    fun predict(x: DoubleArray): Int = if (x[feature] <= threshold) leftLabel else rightLabel
    private fun majority(s: List<Sample>) = if (s.count { it.y >= 0.5 } * 2 >= s.size) 1 else 0
}

class KMeans(private val k: Int, private val iterations: Int = 20) {
    var centroids: List<DoubleArray> = emptyList(); private set

    private fun nearest(point: DoubleArray, centers: List<DoubleArray>): Int = centers.indices.minByOrNull { c ->
        var d = 0.0
        for (i in point.indices) { val z = point[i] - centers[c][i]; d += z * z }
        d
    } ?: 0

    fun fit(points: List<DoubleArray>): IntArray {
        require(points.isNotEmpty() && k > 0 && k <= points.size)
        val random = Random(42)
        centroids = points.shuffled(random).take(k).map { it.copyOf() }
        var assignments = IntArray(points.size)
        repeat(iterations) {
            assignments = IntArray(points.size) { nearest(points[it], centroids) }
            val sums = Array(k) { DoubleArray(points.first().size) }
            val counts = IntArray(k)
            points.forEachIndexed { i, p ->
                val c = assignments[i]; counts[c]++
                for (j in p.indices) sums[c][j] += p[j]
            }
            centroids = centroids.indices.map { c ->
                if (counts[c] == 0) points[random.nextInt(points.size)].copyOf()
                else DoubleArray(sums[c].size) { j -> sums[c][j] / counts[c] }
            }
        }
        return assignments
    }
}

class PCA(private val components: Int) {
    fun transform(points: List<DoubleArray>): List<DoubleArray> {
        require(points.isNotEmpty())
        val dims = points.first().size
        val means = DoubleArray(dims) { d -> points.map { it[d] }.average() }
        val variances = DoubleArray(dims) { d -> points.map { (it[d] - means[d]) * (it[d] - means[d]) }.average() }
        val order = variances.indices.sortedByDescending { variances[it] }.take(components)
        return points.map { p -> DoubleArray(order.size) { i -> p[order[i]] - means[order[i]] } }
    }
}

class SemiSupervisedLabeler(private val minConfidence: Double = 0.85) {
    private val classifier = LogisticRegression()

    fun pseudoLabel(labeled: List<Sample>, unlabeled: List<DoubleArray>): List<PseudoLabel> {
        if (labeled.isEmpty() || unlabeled.isEmpty()) return emptyList()
        classifier.fit(labeled)
        return unlabeled.mapIndexedNotNull { i, x ->
            val p = classifier.predictProbability(x)
            val confidence = max(p, 1.0 - p)
            if (confidence >= minConfidence) PseudoLabel("sample_$i", if (p >= .5) "1" else "0", confidence) else null
        }
    }
}

class SelfSupervisedMasker(private val maskProbability: Double = 0.15) {
    fun makeMasked(tokens: List<String>, seed: Int = 42): Pair<List<String>, List<String>> {
        val r = Random(seed); val masked = tokens.toMutableList(); val targets = mutableListOf<String>()
        for (i in tokens.indices) if (r.nextDouble() < maskProbability) { targets += tokens[i]; masked[i] = "<MASK>" }
        return masked to targets
    }
}

/** Tabular Q-learning for action selection; Qwen remains the language/reasoning model. */
class QLearning(
    private val alpha: Double = 0.15,
    private val gamma: Double = 0.95,
    private val epsilon: Double = 0.12
) {
    private val q = mutableMapOf<String, MutableMap<String, Double>>()

    fun chooseAction(state: String, actions: List<String>): String {
        require(actions.isNotEmpty())
        val values = q.getOrPut(state) { actions.associateWith { 0.0 }.toMutableMap() }
        if (Random.nextDouble() < epsilon) return actions.random()
        return actions.maxByOrNull { values[it] ?: 0.0 } ?: actions.first()
    }

    fun update(t: RLTransition) {
        val current = q.getOrPut(t.state) { mutableMapOf() }
        val next = q[t.nextState].orEmpty().values.maxOrNull() ?: 0.0
        val old = current[t.action] ?: 0.0
        val target = t.reward + if (t.done) 0.0 else gamma * next
        current[t.action] = old + alpha * (target - old)
    }

    fun export(): Map<String, Map<String, Double>> = q.mapValues { it.value.toMap() }

    @Synchronized
    fun importTable(table: Map<String, Map<String, Double>>) {
        q.clear()
        table.forEach { (state, actions) -> q[state] = actions.toMutableMap() }
    }
}

internal fun dot(a: DoubleArray, b: DoubleArray): Double {
    var s = 0.0
    for (i in a.indices) s += a[i] * b[i]
    return s
}

internal fun sigmoid(x: Double): Double = 1.0 / (1.0 + exp(-x.coerceIn(-40.0, 40.0)))
