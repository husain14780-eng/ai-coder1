package com.husain.aicoder.quality

import org.json.JSONArray
import org.json.JSONObject

/**
 * Evidence-based gameplay signal judge. It walks both boot observations and
 * per-action observations so nested failures are not silently ignored.
 */
class GameplayQualityJudge {
    fun evaluate(playtest: JSONObject): JSONObject {
        var finished = 0
        var errors = 0
        var deadOrReset = 0
        var observations = 0

        fun consume(obs: JSONObject?) {
            if (obs == null) return
            observations++
            if (obs.optBoolean("finished", false) || obs.optBoolean("goal_reached", false)) finished++
            if ((obs.optJSONArray("errors")?.length() ?: 0) > 0) errors++
            if (obs.optBoolean("dead", false) || obs.optBoolean("reset", false)) deadOrReset++
        }

        val results = playtest.optJSONArray("results")
        if (results != null) {
            for (i in 0 until results.length()) {
                val row = results.optJSONObject(i) ?: continue
                consume(row.optJSONObject("observation"))
                val actions = row.optJSONArray("actions")
                if (actions != null) {
                    for (j in 0 until actions.length()) {
                        val action = actions.optJSONObject(j) ?: continue
                        consume(action.optJSONObject("observation"))
                    }
                }
            }
        }

        return JSONObject()
            .put("observation_count", observations)
            .put("finish_signal_count", finished)
            .put("error_signal_count", errors)
            .put("death_or_reset_count", deadOrReset)
            .put("signals_available", observations > 0)
            .put("recommendations", JSONArray(listOfNotNull(
                if (errors > 0) "Resolve gameplay errors before polish." else null,
                if (observations > 0 && finished == 0) "Add a deterministic success/goal signal to the smoke-test path." else null,
                if (deadOrReset > observations / 2 && observations > 0) "Inspect difficulty/recovery balance; repeated failure may indicate a level or control issue." else null
            )))
    }
}
