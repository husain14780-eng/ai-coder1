package com.husain.aicoder.swarm

/** A non-lightweight model profile intended for the 8 GB Android device envelope. */
data class LocalModelProfile(
    val id: String,
    val displayName: String,
    val family: String,
    val roles: Set<Role>,
    val filenamePatterns: List<Regex>,
    val preferredQuant: String,
    val estimatedModelGb: Double,
    val estimatedRamGb: Double,
    val contextTokens: Int,
    val maxOutputTokens: Int,
    val supportsVision: Boolean = false,
    val experimentalHeavy: Boolean = false,
    val sourceUrl: String,
    val notes: String = ""
) {
    enum class Role { GENERAL, REASONING, CODING, VISION, CRITIC, GAME_DESIGN }
}
