# ML types

Supervised: curated successful coding/game episodes.

Unsupervised: clustering of telemetry, failures and project patterns.

Semi-supervised: confidence-gated pseudo-labeling of unlabeled episodes.

Self-supervised: future-state/prediction and masked reconstruction datasets.

Reinforcement learning: state/action/reward/next-state transitions from controlled playtests.

Continual learning: persistent replay store, curation, skill extraction and periodic adapter candidates.
