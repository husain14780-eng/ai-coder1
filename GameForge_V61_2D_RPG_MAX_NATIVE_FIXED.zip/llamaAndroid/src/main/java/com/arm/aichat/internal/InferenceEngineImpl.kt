package com.arm.aichat.internal

import android.content.Context
import android.util.Log
import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.arm.aichat.ReasoningMode
import com.arm.aichat.UnsupportedArchitectureException
import dalvik.annotation.optimization.FastNative
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

internal class InferenceEngineImpl private constructor(
    private val nativeLibDir: String
) : InferenceEngine {
    companion object {
        private const val TAG = "AI-Coder-Qwen"
        @Volatile private var instance: InferenceEngine? = null
        fun getInstance(context: Context): InferenceEngine = instance ?: synchronized(this) {
            instance ?: InferenceEngineImpl(context.applicationInfo.nativeLibraryDir).also { instance = it }
        }
    }

    @FastNative private external fun nativeInit(nativeLibDir: String): Int
    @FastNative private external fun nativeLoadModel(path: String, contextSize: Int, threads: Int, batchSize: Int): Int
    @FastNative private external fun nativeSetSystemPrompt(prompt: String): Int
    @FastNative private external fun nativeLoadAdapter(path: String, scale: Float): Int
    @FastNative private external fun nativeClearAdapter(): Int
    @FastNative private external fun nativeStartGeneration(
        prompt: String, thinking: Boolean, maxTokens: Int, temperature: Float,
        topP: Float, topK: Int, minP: Float, repeatPenalty: Float, seed: Int,
        grammar: String?, grammarRoot: String
    ): Int
    @FastNative private external fun nativeNextToken(): String?
    @FastNative private external fun nativeAbort()
    @FastNative private external fun nativeModelInfo(): String
    @FastNative private external fun nativeUnload()
    @FastNative private external fun nativeShutdown()

    private val stateMutable = MutableStateFlow<InferenceEngine.State>(InferenceEngine.State.Uninitialized)
    override val state: StateFlow<InferenceEngine.State> = stateMutable.asStateFlow()
    private val dispatcher = Dispatchers.IO
    @Volatile private var initialized = false
    private val destroyed = AtomicBoolean(false)
    @Volatile private var generationActive = false
    private val generationMutex = Mutex()

    init {
        CoroutineScope(dispatcher).launch {
            try {
                stateMutable.value = InferenceEngine.State.Initializing
                System.loadLibrary("ai-chat")
                check(!destroyed.get()) { "Inference engine destroyed during initialization" }
                check(nativeInit(nativeLibDir) == 0) { "Native llama initialization failed" }
                if (destroyed.get()) {
                    runCatching { nativeShutdown() }
                    return@launch
                }
                initialized = true
                stateMutable.value = InferenceEngine.State.Initialized
            } catch (t: Throwable) {
                val ex = t as? Exception ?: RuntimeException(t)
                stateMutable.value = InferenceEngine.State.Error(ex)
                Log.e(TAG, "Native init failed", t)
            }
        }
    }

    private suspend fun awaitInit() {
        check(!destroyed.get()) { "Inference engine destroyed" }
        while (!initialized) {
            check(!destroyed.get()) { "Inference engine destroyed" }
            when (val s = stateMutable.value) {
                is InferenceEngine.State.Error -> throw s.exception
                else -> kotlinx.coroutines.delay(20)
            }
        }
    }

    override suspend fun loadModel(pathToModel: String, contextSize: Int, threads: Int, batchSize: Int) {
        awaitInit()
        generationMutex.withLock {
        withContext(dispatcher) {
            val file = File(pathToModel)
            require(file.isFile && file.canRead()) { "Model unavailable: $pathToModel" }
            stateMutable.value = InferenceEngine.State.LoadingModel
            val hw = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)
            val chosenThreads = if (threads <= 0) max(2, hw - 1).coerceAtMost(8) else threads
            val ctx = contextSize.coerceIn(2048, 16384)
            val batch = batchSize.coerceIn(128, 1024)
            val rc = nativeLoadModel(pathToModel, ctx, chosenThreads, batch)
            if (rc != 0) {
                val ex = UnsupportedArchitectureException("llama.cpp load failed (rc=$rc)")
                stateMutable.value = InferenceEngine.State.Error(ex)
                throw ex
            }
            stateMutable.value = InferenceEngine.State.ModelReady
        }
        }
    }

    override suspend fun setSystemPrompt(systemPrompt: String) = withContext(dispatcher) {
        check(initialized && !destroyed.get())
        require(systemPrompt.isNotBlank())
        check(nativeSetSystemPrompt(systemPrompt) == 0) { "System prompt failed" }
    }

    override suspend fun loadLoraAdapter(path: String, scale: Float) = generationMutex.withLock { withContext(dispatcher) {
        val file = File(path)
        require(file.isFile && file.canRead()) { "LoRA adapter unavailable: $path" }
        stateMutable.value = InferenceEngine.State.LoadingAdapter
        check(nativeLoadAdapter(path, scale.coerceIn(-4f, 4f)) == 0) { "LoRA load failed" }
        stateMutable.value = InferenceEngine.State.ModelReady
    } }

    override suspend fun clearLoraAdapter() = generationMutex.withLock {
        withContext(dispatcher) {
            check(nativeClearAdapter() == 0) { "LoRA clear failed" }
        }
    }

    override fun sendUserPrompt(message: String, config: GenerationConfig): Flow<String> = flow {
        require(message.isNotBlank())
        generationMutex.withLock {
            withContext(dispatcher) {
                check(stateMutable.value is InferenceEngine.State.ModelReady) { "Model is not ready" }
                val rc = nativeStartGeneration(
                    message,
                    config.mode == ReasoningMode.THINKING,
                    config.maxTokens.coerceIn(16, 16384),
                    config.temperature.coerceIn(0.0f, 2.0f),
                    config.topP.coerceIn(0.01f, 1.0f),
                    config.topK.coerceIn(1, 200),
                    config.minP.coerceIn(0.0f, 1.0f),
                    config.repeatPenalty.coerceIn(0.8f, 1.5f),
                    config.seed,
                    config.grammar,
                    config.grammarRoot
                )
                if (rc != 0) throw IOException("Generation start failed (rc=$rc)")
                stateMutable.value = InferenceEngine.State.Generating
                generationActive = true
            }
            try {
                while (generationActive) {
                    val token = withContext(dispatcher) { nativeNextToken() } ?: break
                    if (token.isNotEmpty()) emit(token)
                }
            } catch (e: CancellationException) {
                abort()
                throw e
            } finally {
                withContext(dispatcher) {
                    generationActive = false
                    if (stateMutable.value !is InferenceEngine.State.Error) {
                        stateMutable.value = InferenceEngine.State.ModelReady
                    }
                }
            }
        }
    }.flowOn(dispatcher)

    override fun abort() {
        generationActive = false
        try { nativeAbort() } catch (_: Throwable) { }
    }

    override fun modelInfo(): String = runCatching { nativeModelInfo() }.getOrDefault("{}")

    override fun cleanUp() {
        abort()
        kotlinx.coroutines.runBlocking(dispatcher) {
            generationMutex.withLock {
                if (stateMutable.value is InferenceEngine.State.ModelReady || stateMutable.value is InferenceEngine.State.Generating) {
                    stateMutable.value = InferenceEngine.State.UnloadingModel
                    nativeUnload()
                    stateMutable.value = if (destroyed.get()) InferenceEngine.State.Uninitialized else InferenceEngine.State.Initialized
                }
            }
        }
    }

    override fun destroy() {
        if (!destroyed.compareAndSet(false, true)) return
        abort()
        kotlinx.coroutines.runBlocking(dispatcher) {
            generationMutex.withLock {
                runCatching { nativeUnload() }
                runCatching { nativeShutdown() }
                initialized = false
                stateMutable.value = InferenceEngine.State.Uninitialized
            }
        }
        instance = null
    }
}
