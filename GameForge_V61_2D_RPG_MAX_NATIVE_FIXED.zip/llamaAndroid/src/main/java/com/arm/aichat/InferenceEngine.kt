package com.arm.aichat

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

enum class ReasoningMode { FAST, THINKING }

data class GenerationConfig(
    val mode: ReasoningMode = ReasoningMode.FAST,
    val maxTokens: Int = 768,
    val temperature: Float = if (mode == ReasoningMode.THINKING) 0.6f else 0.7f,
    val topP: Float = if (mode == ReasoningMode.THINKING) 0.95f else 0.8f,
    val topK: Int = 20,
    val minP: Float = 0.0f,
    val repeatPenalty: Float = 1.05f,
    val seed: Int = -1,
    val grammar: String? = null,
    val grammarRoot: String = "root"
)

interface InferenceEngine {
    val state: StateFlow<State>
    suspend fun loadModel(pathToModel: String, contextSize: Int = 8192, threads: Int = 0, batchSize: Int = 512)
    suspend fun setSystemPrompt(systemPrompt: String)
    suspend fun loadLoraAdapter(path: String, scale: Float = 1.0f)
    suspend fun clearLoraAdapter()
    fun sendUserPrompt(message: String, config: GenerationConfig = GenerationConfig()): Flow<String>
    fun abort()
    fun modelInfo(): String
    fun cleanUp()
    fun destroy()

    sealed class State {
        data object Uninitialized : State()
        data object Initializing : State()
        data object Initialized : State()
        data object LoadingModel : State()
        data object ModelReady : State()
        data object LoadingAdapter : State()
        data object Generating : State()
        data object UnloadingModel : State()
        data class Error(val exception: Exception) : State()
    }

    companion object { const val DEFAULT_PREDICT_LENGTH = 768 }
}

class UnsupportedArchitectureException(message: String = "Native model load failed") : Exception(message)
