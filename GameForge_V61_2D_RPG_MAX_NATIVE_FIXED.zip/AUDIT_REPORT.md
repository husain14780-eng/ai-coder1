# GameForge V6 Reliability Audit

This release is a **source audit and bug-fix release**. It does not claim that an Android APK was physically built in this environment. The original v5 source release did not contain an APK, release keystore, or bundled Godot editor binary.

## Confirmed fixes in v5.1

- Fixed the LoRA clear JNI export mismatch (`nativeClearAdapter`).
- Prevented native generation from decoding past the loaded context window.
- Serialized model load/adapter/cleanup/destroy against generation.
- Connected Godot observations to the actual production `ToolExecutor` (the original main path had a stale/null observation bug).
- Required fresh observations after game actions, restart, and generated-game loading.
- Made Godot playtest pass/fail depend on action evidence and reported runtime errors, not boot alone.
- Fixed the visual regression test from accepting any `visual` key to requiring `visual.available=true`.
- Changed runtime Godot packaging from the 500-file agent listing to a complete capped listing (20,000 files).
- Validated `project.godot` and the requested main scene before packaging.
- Preserved existing user-authored GameForge contracts on reruns instead of overwriting them.
- Made model/adapter imports validate temporary files before atomic replacement and record SHA-256/provenance.
- Added GGUF version validation (v2-v4).
- Added robust model filename matching for generic `Qwen3-4B-Q4_K_M.gguf`.
- Preserved a LoRA across model switching only when the adapter belongs to the active base model; incompatible switches no longer silently reuse it.
- Fixed JPEG data URI MIME handling in the optional localhost VLM adapter.
- Hardened command-tool policy against `find -exec`, arbitrary Git mutations, Gradle init/settings injection, shell-style operators, and outside-workspace paths.
- Added property/environment based release signing configuration without shipping any private key.
- Made release benchmark artifact checks validate JSON/content rather than only checking that files exist.
- Added atomic workspace writes for core code/contract edits.

## V6 fixes verified in the final pass

- Fixed a real Kotlin syntax defect in `EpisodeStore.kt`: the class was missing its final closing brace. A Kotlin compiler syntax pass then reported no `expecting`/`unexpected tokens`/`unclosed` diagnostics across the source set; remaining local compiler diagnostics were dependency/classpath related because the Android/Gradle environment is not installed here.
- Coding implementation roles are forced to `ReasoningMode.THINKING` at the agent layer, while the native engine still receives the explicit thinking flag.
- Qwen3-4B-Thinking is the only catalog entry assigned to the dedicated `GAME_DESIGN` role; Qwen3-4B-Instruct remains general/director/critic.
- A new V6 build creates a checkpoint and resets a prior generated workspace before scaffolding, preventing stale project files from being reused accidentally.
- Final acceptance is now `regression_gate && package_ok`, so packaging failures cannot be hidden by an otherwise passing test suite.
- The GitHub workflow uses current documented action majors and validates the exact V6 ZIP with `unzip -tq` before extraction.

## Godot status

Godot is **embedded as the Android library dependency** `org.godotengine:godot:4.7.2.stable`; the generated Godot project is under `app/src/main/assets`, and `MainActivity` hosts `GodotFragment` and registers `AICoderGodotBridge`. The source ZIP does **not** contain the Godot editor executable. Gradle resolves the Godot Android AAR when building the APK.

At runtime, GameForge packages the generated workspace as a resource-pack ZIP and loads it into the embedded Godot process. This supports generated scenes/scripts/assets, but it is not identical to launching a separately exported Godot application: project-level settings and autoload behavior remain constrained by the host Godot process. GameForge therefore uses a bootstrap/contract approach and should avoid depending on project.godot-only settings that cannot be changed safely at runtime.

## Certificates / signing

No production signing certificate or private keystore is shipped. That is intentional. A release build can use `RELEASE_STORE_FILE`, `RELEASE_STORE_PASSWORD`, `RELEASE_KEY_ALIAS`, and `RELEASE_KEY_PASSWORD` via Gradle properties or environment variables. An actual APK certificate can only be verified after an APK is built; this source release cannot truthfully claim an APK signature.

## Web search decision

Web search is **not a core dependency** of GameForge. The base local models already contain strong coding/tool-use knowledge, but current Godot APIs can change after model training. The preferred future enhancement is an **optional offline Godot documentation/index pack**; an opt-in web knowledge bridge can be added later without making the core agent cloud-dependent.
