## V6.1 — 2D RPG/MMORPG Max Factory

- AI-directed procedural sprite generation with request-driven prompts, archetypes, palettes, seeds and animation profiles.
- Native PNG frame generation plus editable SVG sources and animation manifests.
- 8-direction player animation support, enemy/NPC animation sets, VFX sequences, icons and generated tilesets.
- Procedural multi-map generation with previews, JSON data, collision and AStarGrid2D navigation.
- Auto-bot swarm testing preserved and upgraded to use map-aware goal seeking/pathfinding.
- Final acceptance now requires 2D asset validation as well as static verification, runtime regression and packaging.
- Added deterministic binary asset writes and release-time factory validation.

# Changelog

## 6.1 — 2D RPG/MMORPG Max Factory

- Replaced the 3D-only procedural asset path for 2D projects with an AI-directed 2D asset compiler.
- Added request-driven sprite generation with editable visual recipes, motion recipes, seeded palettes and direction/frame control.
- Added generated PNG runtime frames, animation sheets/manifests, per-animation controllers, VFX sequences, icons and tilesets.
- Added AI-authored ASCII map layouts plus seeded procedural maps, previews, collision and AStarGrid2D navigation.
- Preserved and strengthened automatic bot swarm testing; the generated bots use the same map pathfinder and can be explicitly triggered through `bot_test`.
- Added final asset validation, deterministic binary writes, custom animation alias resolution, one-shot animation detection and fallback animation handling.


## 6.0 — GameForge Full Game Factory

- Added the V6 full-game autonomous generation pipeline.
- Added GameSpec compilation before implementation.
- Added deterministic genre blueprint and level-design contracts.
- Added a robust playable Godot vertical-slice bootstrap with movement, jump, checkpoints, hazards, coins, goal, pause UI, touch controls and persistence.
- Added static generated-project verification before runtime acceptance.
- Added genre-contract coverage checks and richer final evidence.
- Added repair passes that combine static failures, playtest evidence, performance hotspots and change-impact analysis.
- Added final regression and package gating before release artifacts are declared accepted.
- Added explicit `TASK_ROLE` model routing so reasoning/design prompts cannot be mistaken for coding prompts.
- Qwen2.5-Coder-7B Q4_K_M is now the primary implementation specialist; DeepSeek-Coder is not required.
- Fixed model-roster file-name mismatch, observation polling early-stop logic, adaptive playtest loop termination, and several non-atomic persistence paths.
- Fixed a missing closing brace in `EpisodeStore` discovered by a compiler syntax pass.
- Coding roles now force deliberate agent-level THINKING mode around Qwen2.5-Coder rather than silently falling back to routine FAST generation.
- Qwen3-4B-Thinking is now the explicit game-design/reasoning specialist; Qwen3-4B-Instruct is reserved for general/director/critic work.
- Fresh V6 builds checkpoint and reset the prior generated workspace so an old game cannot accidentally survive into a new build.
- Final acceptance now requires both the regression gate and successful runtime packaging; a packaging failure cannot be reported as a successful release.
- Added a V6 GitHub workflow that extracts the exact source ZIP before building.
