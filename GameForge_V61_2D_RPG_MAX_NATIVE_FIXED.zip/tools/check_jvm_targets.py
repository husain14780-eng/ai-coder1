#!/usr/bin/env python3
"""Regression check: every Android module using Kotlin must target JVM 17."""
from pathlib import Path
import re, sys

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
errors=[]
modules=[]
for gradle in sorted(root.rglob("build.gradle.kts")):
    text=gradle.read_text(encoding="utf-8")
    if ('id("com.android.application")' not in text and 'id("com.android.library")' not in text) or ('apply false' in text and 'plugins {' in text):
        continue
    if 'id("org.jetbrains.kotlin.android")' not in text:
        continue
    modules.append(str(gradle.relative_to(root)))
    if 'sourceCompatibility = JavaVersion.VERSION_17' not in text:
        errors.append(f"{gradle}: missing Java sourceCompatibility VERSION_17")
    if 'targetCompatibility = JavaVersion.VERSION_17' not in text:
        errors.append(f"{gradle}: missing Java targetCompatibility VERSION_17")
    if 'jvmToolchain(17)' not in text:
        errors.append(f"{gradle}: missing Kotlin jvmToolchain(17)")
    if 'jvmTarget.set(JvmTarget.JVM_17)' not in text:
        errors.append(f"{gradle}: missing explicit Kotlin JvmTarget.JVM_17")
    if re.search(r'JavaVersion\.VERSION_1_8|jvmTarget\s*=\s*["\']1\.8["\']', text):
        errors.append(f"{gradle}: conflicting JVM 1.8 target remains")

if not modules:
    errors.append("no Kotlin Android modules found")
print("JVM target checks:", "PASS" if not errors else "FAIL")
print("Kotlin Android modules:", ", ".join(modules))
for e in errors: print("ERROR:", e)
sys.exit(1 if errors else 0)
