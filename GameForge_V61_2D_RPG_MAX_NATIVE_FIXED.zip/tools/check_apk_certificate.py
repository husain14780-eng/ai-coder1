from pathlib import Path
import hashlib
import subprocess
import sys


def main() -> int:
    if len(sys.argv) < 2:
        print("usage: python3 tools/check_apk_certificate.py <apk> [expected_sha256_fingerprint]")
        return 2
    apk = Path(sys.argv[1]).resolve()
    if not apk.is_file():
        print(f"APK not found: {apk}")
        return 2
    tools = ["apksigner", "$ANDROID_HOME/build-tools/36.0.0/apksigner"]
    tool = None
    for candidate in tools:
        if candidate.startswith("$"):
            candidate = candidate.replace("$ANDROID_HOME", str(Path.home()/"Android/Sdk"))
        try:
            subprocess.run([candidate, "--version"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            tool = candidate
            break
        except Exception:
            pass
    if tool is None:
        print("CERTIFICATE CHECK: SKIPPED — apksigner is not installed in this environment")
        return 3
    proc = subprocess.run([tool, "verify", "--verbose", "--print-certs", str(apk)], text=True, capture_output=True)
    print(proc.stdout)
    if proc.returncode != 0:
        print(proc.stderr)
        return proc.returncode
    if len(sys.argv) >= 3:
        expected = sys.argv[2].lower().replace(":", "").strip()
        wanted = f"Signer #1 certificate SHA-256 digest: {expected}"
        normalized = proc.stdout.lower().replace(":", "")
        if expected not in normalized:
            print("CERTIFICATE CHECK: FAIL — certificate SHA-256 fingerprint does not match expected")
            return 1
    print("CERTIFICATE CHECK: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
