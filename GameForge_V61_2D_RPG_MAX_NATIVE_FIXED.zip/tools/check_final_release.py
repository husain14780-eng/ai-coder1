#!/usr/bin/env python3
from check_local_swarm_release import *

# v5 compatibility entry point: use check_local_swarm_release.py as the canonical source checker.
