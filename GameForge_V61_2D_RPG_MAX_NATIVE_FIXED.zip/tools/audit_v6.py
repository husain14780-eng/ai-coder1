#!/usr/bin/env python3
"""GameForge V6.1 deterministic source/release audit.

Checks source/release contracts that can be verified without an Android SDK/device.
It intentionally does not claim a real Godot runtime, Android build, GPU render, or GGUF
inference pass when those facilities are unavailable to the local audit.
"""
from __future__ import annotations
from pathlib import Path
import hashlib
import json
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
warnings: list[str] = []
TEXT_EXTS = {".kt", ".java", ".cpp", ".h", ".gd", ".kts", ".py", ".xml", ".json", ".md", ".txt", ".properties"}
SOURCE_EXTS = {".kt", ".java", ".cpp", ".h", ".gd", ".kts", ".py"}
EXCLUDED = {".git", ".gradle", "build", "__pycache__"}
VERSION = "6.1-2D-RPG-MAX"
VERSION_CODE = 61


def fail(msg: str) -> None:
    errors.append(msg)


def warn(msg: str) -> None:
    warnings.append(msg)


def read(rel: str) -> str:
    path = ROOT / rel
    if not path.is_file():
        fail(f"MISSING: {rel}")
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


# 1. File/text hygiene.
source_lines = 0
for path in ROOT.rglob("*"):
    if not path.is_file() or path.suffix.lower() not in TEXT_EXTS or any(part in EXCLUDED for part in path.parts) or path.name.startswith("audit_v"):
        continue
    try:
        data = path.read_bytes()
    except Exception as exc:
        fail(f"UNREADABLE {path}: {exc}")
        continue
    if b"\x00" in data:
        fail(f"NUL BYTE: {path}")
    text = data.decode("utf-8", errors="replace")
    for i, line in enumerate(text.splitlines(), 1):
        source_lines += 1
        if "\ufffd" in line:
            warn(f"REPLACEMENT CHAR in {path}:{i}")
        if path.suffix.lower() in SOURCE_EXTS:
            for marker in ("TODO", "FIXME", "NotImplementedException", "throw NotImplemented"):
                if marker in line:
                    fail(f"{marker} in {path}:{i}")

# 2. Structured syntax.
for path in ROOT.rglob("*.json"):
    if any(part in EXCLUDED for part in path.parts):
        continue
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"BAD JSON {path}: {exc}")
for rel in [
    "app/src/main/AndroidManifest.xml",
    "app/src/main/res/layout/activity_main.xml",
    "app/src/main/res/values/styles.xml",
    "app/src/main/res/xml/accessibility_service_config.xml",
    "app/src/main/res/xml/network_security_config.xml",
]:
    path = ROOT / rel
    if path.is_file():
        try:
            ET.parse(path)
        except Exception as exc:
            fail(f"BAD XML {rel}: {exc}")

# 3. Version/release metadata.
build = read("app/build.gradle.kts")
version = read("VERSION.txt").strip()
manifest = json.loads(read("RELEASE_MANIFEST.json"))
if f"versionCode = {VERSION_CODE}" not in build or f'versionName = "{VERSION}"' not in build:
    fail("Android app version is not V6.1")
if version != VERSION:
    fail("VERSION.txt mismatch")
if manifest.get("versionCode") != VERSION_CODE or manifest.get("version") != VERSION:
    fail("RELEASE_MANIFEST V6.1 version mismatch")
if manifest.get("local_only_runtime") is not True:
    fail("Release is not marked local-only")
if len(manifest.get("learning_modes", [])) != 5:
    fail("Expected five learning modes")

# 4. Android/Godot build contract.
if "org.godotengine:godot:4.7.2.stable" not in build:
    fail("Godot Maven dependency missing")
if "compileSdk = 36" not in build or "minSdk = 33" not in build or "targetSdk = 36" not in build:
    fail("Android SDK target contract changed unexpectedly")
settings = read("settings.gradle.kts")
if 'include(":app")' not in settings or 'include(":llamaAndroid")' not in settings:
    fail("Expected Android modules are not included")
main_activity = read("app/src/main/java/com/husain/aicoder/MainActivity.kt")
for needle in ["v6BuildButton", "buildGameV6", "GameForge V6"]:
    if needle not in main_activity:
        fail(f"UI integration missing: {needle}")
agent = read("app/src/main/java/com/husain/aicoder/agent/AgentController.kt")
if "suspend fun buildGameV6" not in agent or "maxCodingSteps = 110" not in agent:
    fail("AgentController V6 entry point missing")

# 5. Full-game factory contracts.
engine = read("app/src/main/java/com/husain/aicoder/game/GameForgeEngine.kt")
for needle in [
    "GameSpecCompiler", "GameGenerationVerifier", "scaffolder.scaffold", "adaptivePlaytest.run",
    "verifier.verify", "impact.analyze", "package_game", "FINAL_GAME_REPORT.json",
    "validate_2d_assets", "assetValidationOk", "TASK_ROLE: CODING", "TASK_ROLE: REASONING",
]:
    if needle not in engine:
        fail(f"GameForge pipeline contract missing: {needle}")
scaffolder = read("app/src/main/java/com/husain/aicoder/game/GameProjectScaffolder.kt")
for needle in [
    "GAME_SPEC.json", "gameforge/GENRE_BLUEPRINT.json", "gameforge/LEVEL_PLAN.json",
    "scripts/game_root.gd", "get_gameforge_observation", "apply_action", "reset_test", "pause", "checkpoint",
]:
    if needle not in scaffolder:
        fail(f"Scaffold contract missing: {needle}")
verifier = read("app/src/main/java/com/husain/aicoder/game/GameGenerationVerifier.kt")
for needle in ["GAMEFORGE_CONTRACT.md", "GENRE_BLUEPRINT.json", "LEVEL_PLAN.json", "apply_action", "get_gameforge_observation"]:
    if needle not in verifier:
        fail(f"Verifier contract missing: {needle}")
gate = read("app/src/main/java/com/husain/aicoder/quality/GameQualityGate.kt")
for needle in ["staticVerificationOk", "genreContractOk", "playtest.has(\"results\")"]:
    if needle not in gate:
        fail(f"Quality gate contract missing: {needle}")

# 6. V6.1 2D AI-driven asset pipeline.
factory_path = ROOT / "app/src/main/java/com/husain/aicoder/game/GameForge2DAssetFactory.kt"
if not factory_path.is_file():
    fail("GameForge2DAssetFactory.kt missing")
else:
    factory = factory_path.read_text(encoding="utf-8")
    for needle in [
        "class GameForge2DAssetFactory", "generateAll(spec: GameSpec)", "generateAsset(request: JSONObject)",
        "generateMap(request: JSONObject)", "encodePng", "writeBytes", "SpriteFrames.new()", "AStarGrid2D",
        "art_prompt", "seed", "directions", "frame_count", "generation_mode",
    ]:
        if needle not in factory:
            fail(f"2D factory contract missing: {needle}")
    if re.search(r"^\s*class_name GameForgeGenerated(Character|Vfx|WorldMap)2D", factory, re.M):
        fail("Generated 2D scripts declare duplicate global class_name identifiers")
    if '"ai_directed_seeded_raster"' not in factory:
        fail("2D factory does not explicitly mark request-driven generation mode")
    if "res://generated/%s/%s/d%d_f%d.png" not in factory:
        fail("Generated character controller is not wired to runtime PNG frames")
asset_planner = read("app/src/main/java/com/husain/aicoder/game/AssetPlanner.kt")
for needle in ["generation_mode", "ai_directed_seeded_procedural", "directions", "frame_count", "world_map", "dungeon_map"]:
    if needle not in asset_planner:
        fail(f"AssetPlanner 2D manifest contract missing: {needle}")
style = read("app/src/main/java/com/husain/aicoder/game/AssetStyleSystem.kt")
if "runtime_png_plus_editable_svg_source" not in style or "AI_directed_request_then_factory_render" not in style or "generation_policy" not in style:
    fail("Asset style policy is missing runtime/source/AI-generation guarantees")
tool = read("app/src/main/java/com/husain/aicoder/agent/ToolExecutor.kt")
for needle in ["generate_2d_asset", "generate_2d_map", "validate_2d_assets"]:
    if needle not in tool:
        fail(f"Agent 2D tool missing: {needle}")

# 7. Auto-bot testing and 2D navigation.
root_script = read("app/src/main/java/com/husain/aicoder/game/GameProjectScaffolder.kt")
for needle in ["_tick_bots", "_run_bot_test_burst", "get_path_direction", '"bot_testing"', '"swarm_goal_seek"']:
    if needle not in root_script:
        fail(f"Auto-bot 2D navigation contract missing: {needle}")
adaptive = read("app/src/main/java/com/husain/aicoder/quality/AdaptivePlaytestEngine.kt")
for needle in ["attack/skill/dodge/interact/bot_test", "fun fallbackAction(dimension: String", '"bot_test"']:
    if needle not in adaptive:
        fail(f"Adaptive 2D bot action contract missing: {needle}")
playtest = read("app/src/main/java/com/husain/aicoder/quality/PlaytestEngine.kt")
if '"bot_test"' not in playtest or '"attack"' not in playtest:
    fail("Deterministic playtest does not exercise 2D combat/bot actions")
grammar = read("app/src/main/assets/grammars/action.gbnf")
for token in ['\\"attack\\"', '\\"skill\\"', '\\"dodge\\"', '\\"interact\\"', '\\"bot_test\\"']:
    if token not in grammar:
        fail(f"Action grammar missing 2D action {token}")

# 8. Atomic binary asset writes retained.
workspace = read("app/src/main/java/com/husain/aicoder/agent/CodingWorkspace.kt")
for needle in ["fun writeBytes", "ATOMIC_MOVE", "FileOutputStream", ".part"]:
    if needle not in workspace:
        fail(f"Atomic binary-write contract missing: {needle}")

# 9. Explicit model routing / Qwen coding thinking contract retained.
catalog = read("app/src/main/java/com/husain/aicoder/swarm/LocalModelCatalog.kt")
for needle in ["Qwen3-4B-Instruct-2507", "Qwen3-4B-Thinking-2507", "Qwen2.5-Coder-7B-Instruct", "Qwen2.5-VL-3B-Instruct", "Q4_K_M"]:
    if needle not in catalog:
        fail(f"Model catalog missing: {needle}")
router = read("app/src/main/java/com/husain/aicoder/swarm/SwarmTaskRouter.kt")
for needle in ["TASK_ROLE", '"coding"', '"reasoning"', '"design"']:
    if needle not in router:
        fail(f"Explicit swarm routing missing: {needle}")
if "deepseek" in catalog.lower():
    fail("DeepSeek remains in the primary V6.1 model catalog")
coder_engine = read("app/src/main/java/com/husain/aicoder/mission/AutonomousCodingEngine.kt")
for needle in ["isCodingRole(role)", "mode = com.arm.aichat.ReasoningMode.THINKING", "effectiveDecision.mode.name"]:
    if needle not in coder_engine:
        fail(f"Coding THINKING-mode contract missing: {needle}")

# 10. Observation freshness/security retained.
obs_tool = read("app/src/main/java/com/husain/aicoder/agent/ToolExecutor.kt")
for needle in ["AtomicLong", "observationVersion", "observationHealthy"]:
    if needle not in obs_tool:
        fail(f"Tool observation contract missing: {needle}")
policy = read("app/src/main/java/com/husain/aicoder/agent/ToolPolicy.kt")
for forbidden in ["git push", "git reset", "git clean", "find -delete", "gradle init"]:
    if forbidden not in policy:
        fail(f"Tool policy does not explicitly block {forbidden}")

# 11. Release/index consistency.
idx = ROOT / "FILES.txt"
if not idx.is_file():
    fail("FILES.txt missing")
else:
    lines = [x for x in idx.read_text(encoding="utf-8").splitlines() if x]
    if manifest.get("file_count") != len(lines):
        fail(f"RELEASE_MANIFEST file_count={manifest.get('file_count')} but FILES.txt has {len(lines)}")
    actual = hashlib.sha256(idx.read_bytes()).hexdigest()
    if manifest.get("files_index_sha256") != actual:
        fail("RELEASE_MANIFEST files_index_sha256 mismatch")
    missing = [x for x in lines if not (ROOT / x).is_file()]
    if missing:
        fail(f"FILES.txt references missing files: {missing[:5]}")

# 12. Signing hygiene.
build = read("app/build.gradle.kts")
for path in ROOT.rglob("*"):
    if not path.is_file() or any(part in EXCLUDED for part in path.parts):
        continue
    if path.name.lower().endswith((".jks", ".keystore", ".p12", ".pfx", ".pem", ".der")) or path.name.lower() in {"debug.keystore", "upload-keystore.jks"}:
        fail(f"SIGNING SECRET MATERIAL SHIPPED: {path}")
for needle in ["RELEASE_STORE_FILE", "RELEASE_KEY_ALIAS"]:
    if needle not in build:
        fail(f"User-supplied release signing configuration missing: {needle}")

# 13. Workflow checks.
workflow = read(".github/workflows/build-apk.yml")
for needle in [
    "GameForge V6.1", "GameForge_v61_2D_RPG_MAX.zip", "unzip -q", "settings.gradle.kts",
    "Gradle 8.13", "android-36", "ndk;29.0.13113456", "tools/audit_v6.py",
    ":app:assembleDebug", "upload-artifact",
]:
    if needle not in workflow:
        fail(f"GitHub workflow missing V6.1 contract: {needle}")

# 14. Source release must not bundle a pre-rendered art pack.
if (ROOT / "generated").exists():
    fail("Source release contains a generated/ art pack; V6.1 should synthesize assets per game request")

if not any(ROOT.rglob("gradlew")):
    warn("No Gradle wrapper shipped; GitHub workflow provisions Gradle 8.13 explicitly.")
if not any(ROOT.rglob("*.apk")):
    warn("No APK is bundled; actual Android build/device execution still requires CI/device evidence.")

print(f"GameForge V6.1 audit: scanned_text_lines={source_lines}")
print(f"errors={len(errors)} warnings={len(warnings)}")
for err in errors:
    print("ERROR:", err)
for warning in warnings:
    print("WARN:", warning)
if errors:
    sys.exit(1)
print("AUDIT PASS")
