#!/usr/bin/env python3
import json, pathlib, zipfile, sys
root=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else pathlib.Path('.')
errors=[]
for p in root.rglob('*'):
    if p.is_file() and p.stat().st_size==0 and p.suffix in {'.kt','.cpp','.h','.xml','.json'}: errors.append(f'empty: {p}')
for p in root.rglob('*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'invalid json {p}: {e}')
for required in ['README.md','ARCHITECTURE.md','MODEL.md','TRAINING.md','VISION_AND_INPUT.md','REMOTE_DEVICE_PROTOCOL.md','VERSION.txt']:
    if not (root/required).exists(): errors.append(f'missing {required}')
print('release-check:', 'PASS' if not errors else 'FAIL')
for e in errors: print(e)
sys.exit(1 if errors else 0)
