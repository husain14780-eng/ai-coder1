#!/usr/bin/env python3
"""Deterministic source/release audit for GameForge 5.2.
Scans every text source line, validates structured files, and checks cross-file contracts.
It cannot replace an Android SDK/device build, APK install, or real GGUF execution.
"""
from __future__ import annotations
from pathlib import Path
import json
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
warnings: list[str] = []

TEXT_EXTS = {'.kt','.java','.cpp','.h','.gd','.kts','.py','.xml','.json','.md','.txt','.properties'}
SOURCE_EXTS = {'.kt','.java','.cpp','.h','.gd','.kts','.py'}

def fail(msg: str) -> None:
    errors.append(msg)

def warn(msg: str) -> None:
    warnings.append(msg)

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.is_file():
        fail(f'MISSING: {rel}')
        return ''
    return p.read_text(errors='replace')

# 1. Every source/text line scan: forbidden markers, NUL bytes, control chars.
source_lines = 0
for p in ROOT.rglob('*'):
    if not p.is_file() or p.suffix.lower() not in TEXT_EXTS:
        continue
    if p.name == 'audit_v5_1.py' or any(part in {'.git','.gradle','build','__pycache__'} for part in p.parts):
        continue
    try:
        data = p.read_bytes()
    except Exception as exc:
        fail(f'UNREADABLE {p}: {exc}')
        continue
    if b'\x00' in data:
        fail(f'NUL BYTE: {p}')
    for i, line in enumerate(data.decode('utf-8', errors='replace').splitlines(), 1):
        source_lines += 1
        if '\ufffd' in line:
            warn(f'REPLACEMENT CHAR in {p}:{i}')
        for marker in ('TODO','FIXME','NotImplementedException','throw NotImplemented'):
            if marker in line and p.suffix.lower() in SOURCE_EXTS:
                fail(f'{marker} in {p}:{i}')

# 2. Structured files.
for p in ROOT.rglob('*.json'):
    if any(part in {'.git','.gradle','build','__pycache__'} for part in p.parts):
        continue
    try:
        json.loads(p.read_text())
    except Exception as exc:
        fail(f'BAD JSON {p}: {exc}')
for rel in ['app/src/main/AndroidManifest.xml','app/src/main/res/layout/activity_main.xml','app/src/main/res/values/styles.xml','app/src/main/res/xml/accessibility_service_config.xml','app/src/main/res/xml/network_security_config.xml']:
    p=ROOT/rel
    if p.is_file():
        try: ET.parse(p)
        except Exception as exc: fail(f'BAD XML {rel}: {exc}')

# 3. Version consistency.
build = read('app/build.gradle.kts')
version_txt = read('VERSION.txt').strip()
if 'versionCode = 52' not in build or 'versionName = "5.2-LOCAL-SWARM-QWEN25-CODER"' not in build:
    fail('Android version is not 5.1 audited')
if version_txt != '5.2-LOCAL-SWARM-QWEN25-CODER':
    fail('VERSION.txt mismatch')
manifest = json.loads(read('RELEASE_MANIFEST.json') or '{}')
if manifest.get('versionCode') != 52:
    fail('RELEASE_MANIFEST versionCode != 51')
if manifest.get('version') != '5.2-LOCAL-SWARM-QWEN25-CODER':
    fail('RELEASE_MANIFEST version mismatch')

# 4. Godot integration cross-file contract.
if 'org.godotengine:godot:4.7.2.stable' not in build:
    fail('Godot Maven dependency missing')
main = read('app/src/main/java/com/husain/aicoder/MainActivity.kt')
for needle in ['GodotHost','GodotFragment','getHostPlugins','AICoderGodotBridge']:
    if needle not in main: fail(f'Missing Godot host contract: {needle}')
pack = read('app/src/main/java/com/husain/aicoder/godot/GodotWorkspacePackager.kt')
for needle in ['listAllFiles(20000)','project.godot','Invalid main scene path']:
    if needle not in pack: fail(f'Packager contract missing: {needle}')
bridge = read('app/src/main/assets/scripts/ai_bridge.gd')
for needle in ['load_workspace_pack','change_scene_to_file','observation_version','screenshot_path']:
    if needle not in bridge: fail(f'Godot bridge feature missing: {needle}')
scaffold = read('app/src/main/java/com/husain/aicoder/game/GameProjectScaffolder.kt')
for needle in ['if (!java.io.File(workspace.root, "project.godot").isFile)', 'main.tscn', 'scripts/game_root.gd', 'observation_version']:
    if needle not in scaffold: fail(f'Scaffolder contract missing: {needle}')

# 5. Native/JNI contract: each Kotlin native method must have matching C++ export.
kt = read('llamaAndroid/src/main/java/com/arm/aichat/internal/InferenceEngineImpl.kt')
cpp = read('llamaAndroid/src/main/cpp/ai_chat_jni.cpp')
natives = re.findall(r'native(?:Init|LoadModel|SetSystemPrompt|LoadAdapter|ClearAdapter|StartGeneration|NextToken|Abort|ModelInfo|Unload|Shutdown)', kt)
for short in sorted(set(natives)):
    camel = short
    expected = 'Java_com_arm_aichat_internal_InferenceEngineImpl_' + camel
    if expected not in cpp:
        fail(f'JNI export missing: {expected}')
if 'nativeClearLoraAdapter' in cpp:
    fail('Stale JNI export nativeClearLoraAdapter remains')
if 'std::clamp' in cpp and '#include <algorithm>' not in cpp:
    fail('C++ uses std::clamp/min/max without <algorithm> include')
if 'ctx_size - promptPos - 1' not in cpp:
    fail('Native output context cap missing')

# 6. Concurrency contract.
if 'generationMutex.withLock' not in kt:
    fail('Native generation lifecycle mutex missing')
swarm = read('app/src/main/java/com/husain/aicoder/swarm/SwarmInferenceEngine.kt')
for needle in ['private val modelMutex = Mutex()', 'modelMutex.withLock']:
    if needle not in swarm: fail(f'Swarm serialization missing: {needle}')

# 7. Observation freshness contract.
tool = read('app/src/main/java/com/husain/aicoder/agent/ToolExecutor.kt')
agent = read('app/src/main/java/com/husain/aicoder/agent/AgentController.kt')
for needle in ['AtomicLong','observationVersion','observationHealthy','fresh post-action observation']:
    if needle not in tool: fail(f'Observation reliability missing: {needle}')
if 'toolExecutor.observe(observation)' not in agent:
    fail('Bridge observations are not forwarded into ToolExecutor')

# 8. Security boundary.
policy = read('app/src/main/java/com/husain/aicoder/agent/ToolPolicy.kt')
executor = read('app/src/main/java/com/husain/aicoder/agent/ToolExecutor.kt')
for forbidden in ['find -delete','git reset','git clean','git push','./gradlew','gradle init']:
    if forbidden not in policy: fail(f'Tool policy does not explicitly block {forbidden}')
if '"python"' in executor or '"python3"' in executor:
    fail('Arbitrary Python execution remains in model tool surface')

# 9. Model import integrity.
mm = read('app/src/main/java/com/husain/aicoder/model/ModelManager.kt')
for needle in ['.part','hasGgufHeader','sha256','renameTo']:
    if needle not in mm: fail(f'Model import integrity missing: {needle}')

# 10. Android capture lifecycle.
screen = read('app/src/main/java/com/husain/aicoder/vision/ScreenCaptureService.kt')
for needle in ['registerCallback','unregisterCallback','FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION']:
    if needle not in screen: fail(f'MediaProjection lifecycle contract missing: {needle}')

# 11. Certificate/signing hygiene.
for p in ROOT.rglob('*'):
    if not p.is_file() or any(part in {'.git','.gradle','build','__pycache__'} for part in p.parts): continue
    low=p.name.lower()
    if low.endswith(('.jks','.keystore','.p12','.pfx','.pem','.der')) or low in {'debug.keystore','upload-keystore.jks'}:
        fail(f'SIGNING SECRET MATERIAL SHIPPED: {p}')
if 'RELEASE_STORE_FILE' not in build or 'RELEASE_KEY_ALIAS' not in build:
    fail('User-supplied release signing configuration missing')

# 12. Release manifest index consistency.
files_index = ROOT/'FILES.txt'
if files_index.is_file():
    index_lines=[x for x in files_index.read_text().splitlines() if x]
    if any(x.startswith(('.gradle/','build/')) for x in index_lines): fail('FILES.txt includes transient build artifacts')
    if manifest.get('file_count') != len(index_lines): fail('RELEASE_MANIFEST file_count does not match FILES.txt')
else:
    fail('FILES.txt missing')

# 13. Model roster sanity.
catalog = read('app/src/main/java/com/husain/aicoder/swarm/LocalModelCatalog.kt')
for name in ['Qwen3-4B-Instruct-2507','Qwen3-4B-Thinking-2507','Qwen2.5-Coder-7B-Instruct','Qwen2.5-VL-3B-Instruct']:
    if name not in catalog: fail(f'Model roster missing {name}')

# 14. Explicit reality checks (warnings, not false passes).
if not any(ROOT.rglob('gradlew')):
    warnings.append('No Gradle wrapper shipped; build requires Android Studio/Gradle environment.')
if not any(ROOT.rglob('*.apk')):
    warnings.append('No APK is bundled; certificate identity cannot be verified until a user-signed APK exists.')
if 'native multimodal backend pending' in read('RELEASE_MANIFEST.json'):
    warnings.append('Qwen2.5-VL profile is a reserved specialist; native multimodal backend is not wired into the llama text JNI bridge.')

print(f'GameForge 5.2 audit: scanned_text_lines={source_lines}')
print(f'errors={len(errors)} warnings={len(warnings)}')
for e in errors: print('ERROR:', e)
for w in warnings: print('WARN:', w)
if errors:
    sys.exit(1)
print('AUDIT PASS')
