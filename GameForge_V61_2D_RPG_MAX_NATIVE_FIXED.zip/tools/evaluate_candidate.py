#!/usr/bin/env python3
"""Small host-side promotion helper. It consumes JSONL benchmark reports."""
from __future__ import annotations
import json
import sys
from pathlib import Path


def score(path: Path) -> dict:
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    overall = sum(float(r.get("score", 0.0)) for r in rows) / max(1, len(rows))
    evidence = sum(bool(r.get("claimed_test_pass") is False or r.get("output", "").lower().find("evidence") >= 0) for r in rows) / max(1, len(rows))
    unseen = [r for r in rows if r.get("category") == "novel"]
    unseen_score = sum(float(r.get("score", 0.0)) for r in unseen) / max(1, len(unseen))
    return {"overall": overall, "unseen": unseen_score, "test_evidence_rate": evidence, "cases": len(rows)}


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: evaluate_candidate.py benchmark.jsonl", file=sys.stderr)
        return 2
    result = score(Path(sys.argv[1]))
    result["promote"] = result["overall"] >= 0.55 and result["unseen"] >= 0.55 and result["test_evidence_rate"] >= 0.5
    print(json.dumps(result, indent=2))
    return 0 if result["promote"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
