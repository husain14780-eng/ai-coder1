#!/usr/bin/env python3
"""Static regression checks for the pinned llama.cpp JNI bridge."""
from pathlib import Path
import re, sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
cmake=root/'llamaAndroid/src/main/cpp/CMakeLists.txt'
jni=root/'llamaAndroid/src/main/cpp/ai_chat_jni.cpp'
errors=[]
if not cmake.is_file() or not jni.is_file():
    errors.append('native llama.cpp source files are missing')
else:
    c=cmake.read_text(encoding='utf-8')
    j=jni.read_text(encoding='utf-8')
    if 'set(LLAMA_COMMIT "b10976"' not in c:
        errors.append('unexpected/unpinned llama.cpp commit; JNI API check targets b10976')
    if 'llama_sampler_init_penalties(\n            llama_vocab_n_tokens(g.vocab), 128, repeatPenalty, 0.0f, 0.0f)' not in j:
        errors.append('llama_sampler_init_penalties must pass vocab size plus four penalty arguments for b10976')
    if 'const int64_t remaining64' not in j or 'static_cast<int64_t>(g.ctx_size)' not in j:
        errors.append('remaining-token calculation must avoid unsigned arithmetic')
    if re.search(r'std::max\(1,\s*g\.ctx_size\s*-', j):
        errors.append('unsafe mixed signed/unsigned std::max expression remains')
print('Native API checks:', 'PASS' if not errors else 'FAIL')
for e in errors: print('ERROR:', e)
sys.exit(1 if errors else 0)
