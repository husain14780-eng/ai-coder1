#!/usr/bin/env python3
"""Deterministically split JSONL experiences while reserving holdout and unseen buckets."""
import argparse, hashlib, json, pathlib


def key(obj):
    text = "|".join(str(obj.get(k, "")) for k in ("goal", "observation", "action", "result", "output"))
    return hashlib.sha256(text.strip().lower().encode()).hexdigest()


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("input"); ap.add_argument("outdir"); ap.add_argument("--holdout", type=float, default=.15); ap.add_argument("--unseen", type=float, default=.10)
    a = ap.parse_args(); out = pathlib.Path(a.outdir); out.mkdir(parents=True, exist_ok=True)
    rows=[]; seen=set()
    for line in pathlib.Path(a.input).read_text(encoding="utf-8").splitlines():
        try: o=json.loads(line)
        except Exception: continue
        k=key(o)
        if k in seen: continue
        seen.add(k); rows.append(o)
    rows.sort(key=lambda o:key(o))
    n=len(rows); h=int(n*a.holdout); u=int(n*a.unseen)
    holdout=rows[:h]; unseen=rows[h:h+u]; train=rows[h+u:]
    for name,data in (("train.jsonl",train),("holdout.jsonl",holdout),("unseen.jsonl",unseen)):
        (out/name).write_text("\n".join(json.dumps(x,ensure_ascii=False) for x in data)+("\n" if data else ""), encoding="utf-8")
    print(json.dumps({"total":n,"train":len(train),"holdout":len(holdout),"unseen":len(unseen)}))

if __name__ == "__main__": main()
