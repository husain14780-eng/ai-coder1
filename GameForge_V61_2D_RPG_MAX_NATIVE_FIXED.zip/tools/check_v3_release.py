#!/usr/bin/env python3
from __future__ import annotations
import json
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path('.')
errors: list[str] = []

required = [
    'README.md', 'ARCHITECTURE.md', 'MODEL.md', 'TRAINING.md', 'CHECKS.md', 'VERSION.txt',
    'benchmarks/MAX_BENCHMARK.json', 'curriculum/CURRICULUM.json',
    'app/src/main/java/com/husain/aicoder/game/GameForgeEngine.kt',
    'app/src/main/java/com/husain/aicoder/game/GameSpec.kt',
    'app/src/main/java/com/husain/aicoder/project/ArchitectureGraph.kt',
    'app/src/main/java/com/husain/aicoder/quality/GameQualityGate.kt',
    'app/src/main/java/com/husain/aicoder/ml/GameBenchmarkSuite.kt',
    'app/src/main/java/com/husain/aicoder/vision/VisionRouter.kt',
]
for rel in required:
    if not (root / rel).exists():
        errors.append(f'missing required: {rel}')

for p in root.rglob('*.json'):
    if '__pycache__' in p.parts:
        continue
    try:
        json.loads(p.read_text(encoding='utf-8'))
    except Exception as e:
        errors.append(f'invalid json {p}: {e}')

for p in root.rglob('*.py'):
    try:
        compile(p.read_text(encoding='utf-8'), str(p), 'exec')
    except Exception as e:
        errors.append(f'python syntax error {p}: {e}')

if any('AI Coder 2.0 MAX' in p.read_text(encoding='utf-8', errors='ignore') for p in root.rglob('*') if p.is_file() and p != pathlib.Path(__file__) and p.suffix in {'.md','.txt','.yaml','.json','.kt'}):
    errors.append('stale 2.0 identity remains in release text')

if any('__pycache__' in p.parts for p in root.rglob('*')):
    errors.append('pycache artifact present')

version = (root / 'VERSION.txt').read_text(encoding='utf-8') if (root / 'VERSION.txt').exists() else ''
if 'Version: 3.0 MAX' not in version:
    errors.append('VERSION.txt is not 3.0 MAX')

print('v3 release check:', 'PASS' if not errors else 'FAIL')
for e in errors:
    print(e)
sys.exit(1 if errors else 0)
