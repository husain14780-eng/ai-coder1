# Release signing and certificate audit

No keystore, private key, PEM file, or certificate secret is included in the source archive. This is intentional. A production APK must be signed with the owner's release/upload key.

`app/build.gradle.kts` accepts these user-supplied Gradle properties or environment variables:

- `RELEASE_STORE_FILE`
- `RELEASE_STORE_PASSWORD`
- `RELEASE_KEY_ALIAS`
- `RELEASE_KEY_PASSWORD`

After producing an APK, run `python3 tools/check_apk_certificate.py app/build/outputs/apk/release/app-release.apk` on a machine that has Android `apksigner`. Pass the expected SHA-256 certificate fingerprint as the second argument to enforce identity checking.
