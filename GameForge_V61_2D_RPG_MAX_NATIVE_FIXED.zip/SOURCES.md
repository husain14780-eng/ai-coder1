# External technical sources used by the release design

- Qwen3 official local llama.cpp instructions: https://github.com/QwenLM/Qwen3/blob/main/docs/source/run_locally/llama.cpp.md
- Qwen3 quantization guidance: https://github.com/QwenLM/Qwen3/blob/main/docs/source/quantization/llama.cpp.md
- llama.cpp build/Android/KleidiAI documentation: https://github.com/ggml-org/llama.cpp/blob/master/docs/build.md
- llama.cpp release history: https://github.com/ggml-org/llama.cpp/releases
- Official Qwen3-4B GGUF repository: https://huggingface.co/Qwen/Qwen3-4B-GGUF
