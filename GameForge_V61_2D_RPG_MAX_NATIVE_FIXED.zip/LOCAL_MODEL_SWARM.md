# GameForge V6 — Local Model Swarm MAX

GameForge V6 routes each major task to the strongest installed specialist that passes the live device guard.

| Role | Model | Quantization | Use |
|---|---|---|---|
| Coding | Qwen2.5-Coder-7B-Instruct | Q4_K_M | implementation, refactors, bug fixes |
| Deep reasoning/design | Qwen3-4B-Thinking-2507 | Q6_K | game design, architecture, diagnosis, planning, critique |
| General/director | Qwen3-4B-Instruct-2507 | Q6_K | general game direction, summaries, critic |
| Vision | Qwen2.5-VL-3B-Instruct | Q6_K | reserved native multimodal profile |

DeepSeek-Coder is not required.

## Explicit routing

GameForge prompts carry `TASK_ROLE` markers:

- `TASK_ROLE: DESIGN` → Qwen3-Thinking game-design route
- `TASK_ROLE: REASONING` → Qwen3-Thinking route
- `TASK_ROLE: CODING` → Qwen2.5-Coder route
- `TASK_ROLE: VISION` → reserved vision route

Explicit role markers are evaluated before keyword heuristics, preventing phrases such as “implementation code” inside a design prompt from accidentally selecting the coding specialist.

## Learning

Verified outcomes feed five learning modes: supervised, unsupervised, semi-supervised, self-supervised and reinforcement learning. They improve experience/routing data; the base GGUF weights remain immutable.

## RAM and swapping

Only one text model is intended to be resident at a time. Model switching is serialized. Prompt/context budgets are reduced according to available RAM, and recoverable load failures try an installed fallback specialist rather than silently pretending a failed load succeeded.

The Qwen2.5-Coder Q4_K_M profile remains the primary coding target, but real Android memory availability still determines whether the native engine can successfully load it. Closing other memory-heavy apps may be necessary on an 8 GB device.
