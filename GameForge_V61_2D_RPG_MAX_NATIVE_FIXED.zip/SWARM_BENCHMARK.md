# Swarm Benchmark Plan

Before promoting a specialist to automatic routing, GameForge should evaluate:

- compile-error repair
- Godot/GDScript generation
- refactoring correctness
- dependency-impact analysis
- architecture planning
- root-cause diagnosis
- game-design consistency
- tool-call reliability
- output latency
- RAM required to load
- crash/OOM rate

Promotion is evidence-driven: pass rate + quality + latency + RAM stability. A single benchmark win does not override regression failures.
