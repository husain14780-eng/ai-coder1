# MAX trainer

The trainer directory contains configurations for Qwen3-4B LoRA candidates. v2 deliberately separates data generation from weight updates.

Phone side:
- records experiences,
- curates datasets,
- reserves holdout/unseen examples,
- exports the training manifest,
- evaluates candidates,
- loads approved GGUF adapters.

Training-machine side:
- run the LLaMA-Factory/compatible LoRA job,
- convert the resulting adapter to the native format expected by the chosen llama.cpp revision,
- copy the adapter back to the phone,
- benchmark before promoting it.

Do not train on the holdout or unseen split.
