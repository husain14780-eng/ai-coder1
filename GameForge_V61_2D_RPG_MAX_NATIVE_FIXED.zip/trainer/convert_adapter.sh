#!/usr/bin/env bash
set -euo pipefail

# Set LLAMA_CPP_DIR to a llama.cpp checkout containing convert_lora_to_gguf.py.
: "${LLAMA_CPP_DIR:?Set LLAMA_CPP_DIR=/path/to/llama.cpp}"
: "${ADAPTER_DIR:?Set ADAPTER_DIR=/path/to/peft_adapter}"
: "${OUTPUT_GGUF:=ai_coder_qwen3_4b_lora.gguf}"

python "$LLAMA_CPP_DIR/convert_lora_to_gguf.py" "$ADAPTER_DIR" --outfile "$OUTPUT_GGUF"
echo "Created $OUTPUT_GGUF"
