#!/usr/bin/env bash
set -euo pipefail

# Expected directory contents:
#   curated_sft.jsonl
#   holdout.jsonl
#   dataset_info.json
# Then install a compatible LLaMA-Factory environment and run this script.

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

: "${LLAMA_FACTORY:=llamafactory-cli}"
"$LLAMA_FACTORY" train qwen3_4b_lora.yaml

echo "Training finished. Evaluate outputs/ before converting the adapter."
