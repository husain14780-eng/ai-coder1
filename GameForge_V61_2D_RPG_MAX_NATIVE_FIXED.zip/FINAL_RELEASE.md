# GameForge V6.1 final release contract

A generated game is considered **accepted** only after fresh evidence supports:

- valid GameSpec and compiled design contract
- genre blueprint coverage
- static project verification
- successful fresh Godot boots/actions, including the generated 2D bot swarm path
- no gameplay error signals in fresh observations
- performance profile captured
- 2D asset factory validation: runtime PNGs, animation wiring, generated maps and bot navigation contract
- repair/regression pass completed after the final change
- package creation succeeded
- final report written to `gameforge/FINAL_GAME_REPORT.json`

The system preserves non-accepted builds with explicit failure evidence. It does not silently label an unverified game as finished.
