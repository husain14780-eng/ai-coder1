# GameForge v5 MAX Features

- Model-agnostic local inference interface.
- Local specialist catalog with serious models only.
- Per-task routing: coding, reasoning, game design, general/critic and vision classification.
- Automatic model unloading/loading between tasks.
- Live RAM and storage checks.
- Qwen2.5-Coder-7B Q4_K_M coding specialist with deliberate THINKING mode.
- Local specialist benchmark runner.
- Persistent routing experience and Q-learning state.
- Supervised, unsupervised, semi-supervised, self-supervised and reinforcement-learning hooks for routing/experience.
- Existing GameForge mission planning, coding, tool execution, Godot integration, autonomous playtesting, visual/pixel QA, performance profiling and release verification remain intact.
- Native prompt formatting changed from a Qwen-only path to the model's exported GGUF chat template, allowing non-Qwen text models to participate.
