# Model integration — GameForge V6

## Local model policy

GameForge is local-first and does not require a cloud model endpoint. The app does not silently download arbitrary model weights. Trusted local GGUF files are imported through Android storage, checked for a GGUF header, hashed and finalized atomically.

### Curated roster

- **Qwen2.5-Coder-7B-Instruct Q4_K_M** — primary coding specialist.
- **Qwen3-4B-Thinking-2507 Q6_K** — game design, architecture, difficult reasoning, root-cause analysis and planning.
- **Qwen3-4B-Instruct-2507 Q6_K** — general/director/critic tasks.
- **Qwen2.5-VL-3B-Instruct Q6_K** — reserved vision specialist; the current native text JNI path does not claim multimodal tensor support.

DeepSeek-Coder is not required by the V6 release.

## Coding “thinking” mode

Qwen2.5-Coder is used as the implementation model with an **agent-level deliberate planning mode**. The separate Qwen3-Thinking model is used for explicit reasoning/design phases through `TASK_ROLE: REASONING`. This distinction prevents the runtime from misrepresenting Qwen2.5-Coder as a native Qwen3 thinking model.

## Long-horizon generation

The V6 game factory compiles a `GameSpec`, creates a genre blueprint and level plan, creates a deterministic playable bootstrap, then lets the autonomous coding engine expand and repair the project using fresh evidence.

## Training/learning

The runtime stores experience and routing outcomes. The immutable base model is not rewritten after every bug. Curated data may later be used for separately evaluated SFT/LoRA adapter candidates.

## Native runtime

The JNI layer remains llama.cpp-based and model-agnostic at the text prompting level. Native generation/load/switch lifecycle operations are serialized. The Android build resolves the pinned Godot and llama.cpp dependencies; large model files are not bundled into the source release.
