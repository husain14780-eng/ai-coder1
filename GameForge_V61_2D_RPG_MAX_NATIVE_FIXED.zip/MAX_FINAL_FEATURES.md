# GameForge V6.1 Full Game Factory feature map

## Brain / model
- Native Qwen3-4B GGUF inference through JNI + llama.cpp.
- Qwen stored chat-template detection with ChatML fallback.
- Thinking/non-thinking routing.
- Grammar-constrained action generation.
- Streaming generation.
- Native LoRA adapter loading/clearing with current multi-adapter API.
- Model routing and persistent context/memory retrieval.

## Game intelligence
- GameSpec as the source of truth.
- Genre blueprint library with required systems and acceptance contracts.
- Game design compiler.
- Architecture/dependency graph.
- Project/symbol index.
- Change-impact analysis.
- Level-design contract.
- Asset-style contract.
- Gameplay scenario generator.
- Gameplay balance/pacing engine.
- Design consistency checker.

## Engineering agent
- Planner / coder / debugger / critic / QA / performance / reviewer roles.
- Safe filesystem and command tools.
- Prompt composer with bounded context.
- Mission graph and resumable missions.
- Transactional edits.
- Last-good checkpoints.
- Stagnation detection and rollback/replan.
- Persistent evidence ledger.
- Failure fingerprint memory and repair retrieval.

## Autonomous game building
- Godot project scaffolding.
- Procedural asset helpers.
- Game systems generation.
- Deterministic smoke tests.
- Qwen-driven adaptive playtesting.
- Gameplay quality judging.
- Runtime telemetry.
- Performance profiling and autotuning.
- Screenshot/pixel visual QA.
- Optional semantic local VLM adapter.
- Regression matrix.
- Defect prioritization.

## Final quality / release
- Quality benchmark v3.
- Final benchmark v4 with genre/balance/asset/save/provenance layers.
- Ultimate release benchmark.
- Artifact provenance and evidence traceability.
- Reproducible release ZIP with per-file SHA-256 manifest.
- Explicit ship/not-ship status.

## Self-improvement
- Persistent experiences.
- Supervised, unsupervised, semi-supervised, self-supervised and RL infrastructure.
- Curated train/holdout/unseen sets.
- Skill extraction and reusable skill memory.
- Candidate LoRA evaluation and promotion.
- Regression protection.
- Failure-aware curriculum.
- Immutable base model.

## Native/runtime protections
- Trusted local GGUF import with GGUF header validation, atomic finalization and recorded SHA-256 provenance.
- Resumable HTTP Range download.
- Free-space preflight.
- GGUF validation.
- Official-model SHA-256 verification.
- Android arm64-v8a/x86_64 native path.
- Current `GGML_CPU_KLEIDIAI` configuration.
- Shell-operator blocking.
- Outside-workspace path blocking.
- Context/prompt compaction.
- Bounded autonomous budgets.
