# Remote/device protocol — GameForge V6

The device tools are still bounded Android accessibility actions:

- tap
- swipe
- back
- home
- type

The primary 4.0 workflow is local game development. Device automation exists as an auxiliary integration surface for opening tools, checking UI and collecting external evidence when explicitly authorized.
