# AI Coder V6 — GameForge Full Game Factory

GameForge V6.1 is a local-first autonomous game-development agent for Android. It turns a natural-language game goal into a Godot project, implements it with specialist local models, runs fresh runtime tests, repairs failures, and produces a final evidence report.

## Local model strategy

- **Qwen3-4B-Thinking-2507** — architecture, difficult reasoning, diagnosis and planning.
- **Qwen2.5-Coder-7B-Instruct Q4_K_M** — primary implementation model.
- **Qwen3-4B-Instruct-2507** — general/director/critic work when installed.
- **Qwen2.5-VL-3B-Instruct** — reserved vision specialist; the current JNI backend does not pretend a text-only path is multimodal.
- DeepSeek-Coder is **not required** for the V6 workflow.

Qwen2.5-Coder uses an **agent-level deliberate planning/thinking mode** in GameForge; this is not a claim that the Qwen2.5-Coder base model has Qwen3's native thinking head.

## Full-game pipeline

```text
User goal
  -> GameSpec design
  -> contract compilation
  -> genre blueprint + level plan
  -> deterministic playable bootstrap
  -> long-horizon coding agent
  -> static generated-project verification
  -> fresh Godot playtest
  -> performance / gameplay / visual checks
  -> root-cause repair
  -> regression
  -> package + final report
```

The bootstrap is intentionally more than an empty template: it includes movement, jumping, checkpoints, hazards, coins, a goal, pause UI, touch controls, save/load, a deterministic restart path, and the GameForge automation bridge. The coding agent is expected to expand it into the actual game requested by the user.

## Godot architecture

Godot is embedded through the Android dependency `org.godotengine:godot:4.7.2.stable`. Generated projects are packaged into resource packs and loaded into the embedded runtime. The source ZIP does not contain a standalone Godot editor executable.

## Build

GitHub Actions extracts `GameForge_v61_2D_RPG_MAX.zip`, locates the Gradle root, installs the pinned Android/JDK/Gradle toolchain, runs `tools/check_release.py` and `tools/audit_v6.py`, builds `app-debug.apk`, verifies the APK archive, and publishes the APK plus SHA-256.

The source release intentionally does not bundle multi-gigabyte model weights, Android SDK/NDK files or private signing keys.

## V6.1 2D RPG/MMORPG generation

GameForge V6.1 is 2D-first for RPG/MMORPG projects. The coding model can request new characters, sprite frames, multi-direction animation sets, VFX, icons, tilesets, and procedural maps using prompts, style, palette, seed, frame count, and direction count. The factory synthesizes the runtime PNG assets and editable SVG sources per build; it does not require a fixed shipped art pack. Generated maps include runtime AStarGrid2D navigation, and the scaffolded bot swarm uses that navigation during automated tests.
