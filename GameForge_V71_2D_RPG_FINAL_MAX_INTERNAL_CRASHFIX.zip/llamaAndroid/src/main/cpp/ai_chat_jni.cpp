#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

#include "llama.h"

#define LOG_TAG "AI-Coder-Qwen"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

namespace {
struct Engine {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    llama_sampler * sampler = nullptr;
    llama_adapter_lora * adapter = nullptr;
    const llama_vocab * vocab = nullptr;
    std::string system_prompt;
    std::vector<llama_token> tokens;
    int32_t generated = 0;
    int32_t max_tokens = 0;
    int32_t threads = 4;
    int32_t batch_size = 512;
    uint32_t ctx_size = 8192;
    std::atomic<bool> abort{false};
    std::mutex mu;
    bool initialized = false;
};

Engine g;

static std::string jstr(JNIEnv * env, jstring s) {
    if (!s) return {};
    const char * p = env->GetStringUTFChars(s, nullptr);
    std::string out = p ? p : "";
    if (p) env->ReleaseStringUTFChars(s, p);
    return out;
}

static bool tokenize(const std::string & text, std::vector<llama_token> & out) {
    if (!g.model || !g.vocab) return false;
    int32_t need = llama_tokenize(g.vocab, text.data(), (int32_t) text.size(), nullptr, 0, true, true);
    if (need >= 0) need = -need;
    if (need <= 0) return false;
    out.resize((size_t)(-need));
    int32_t got = llama_tokenize(g.vocab, text.data(), (int32_t) text.size(), out.data(), (int32_t)out.size(), true, true);
    if (got < 0) return false;
    out.resize((size_t)got);
    return true;
}

static std::string genericPrompt(const std::string & system, const std::string & user, bool thinking) {
    const size_t max_system_chars = 8000;
    const size_t max_user_chars = 16000;
    const std::string compact_system = system.size() > max_system_chars ? system.substr(0, max_system_chars) : system;
    std::string compact_user = user;
    if (compact_user.size() > max_user_chars) {
        const size_t head = 9000;
        const size_t tail = max_user_chars - head;
        compact_user = compact_user.substr(0, head) + "\n...[prompt compacted by native runtime]...\n" + compact_user.substr(compact_user.size() - tail);
    }
    std::string thinking_user = compact_user;
    if (thinking) {
        thinking_user =
            "Work in deliberate reasoning mode. Think through the task privately, verify assumptions, "
            "and check edge cases before answering. Do not reveal chain-of-thought or hidden reasoning. "
            "Return only the requested final answer/tool call.\n\n" + compact_user;
    }
    const llama_chat_message messages[] = {
        {"system", compact_system.c_str()},
        {"user", thinking_user.c_str()},
    };
    const char * tmpl = g.model ? llama_model_chat_template(g.model, nullptr) : nullptr;
    const int32_t needed = llama_chat_apply_template(tmpl, messages, 2, true, nullptr, 0);
    if (needed > 0) {
        std::string formatted((size_t)needed + 1, '\0');
        const int32_t written = llama_chat_apply_template(tmpl, messages, 2, true, formatted.data(), (int32_t)formatted.size());
        if (written >= 0) {
            formatted.resize((size_t)written);
            return formatted;
        }
    }

    // Generic fallback for chat-tuned GGUFs when no template is exported.
    std::string fallback;
    fallback.reserve(compact_system.size() + compact_user.size() + 128);
    fallback += "<|im_start|>system\n";
    fallback += compact_system;
    fallback += "<|im_end|>\n<|im_start|>user\n";
    fallback += compact_user;
    fallback += "<|im_end|>\n<|im_start|>assistant\n";
    return fallback;
}
static void freeSampler() {
    if (g.sampler) { llama_sampler_free(g.sampler); g.sampler = nullptr; }
}

static void freeAdapter() {
    if (g.adapter) {
        llama_adapter_lora_free(g.adapter);
        g.adapter = nullptr;
    }
}

static void clearContext() {
    if (g.ctx) llama_memory_clear(llama_get_memory(g.ctx), true);
}

static bool addTokensToBatch(llama_batch & batch, const std::vector<llama_token> & toks, int start, int count, int pos_base) {
    batch.n_tokens = count;
    for (int i = 0; i < count; ++i) {
        const int idx = i;
        batch.token[idx] = toks[(size_t)start + (size_t)i];
        batch.pos[idx] = pos_base + i;
        batch.n_seq_id[idx] = 1;
        batch.seq_id[idx][0] = 0;
        batch.logits[idx] = (i == count - 1) ? 1 : 0;
    }
    return true;
}

static int decodePrompt(const std::vector<llama_token> & toks) {
    llama_batch batch = llama_batch_init(g.batch_size, 0, 1);
    if (!batch.token) return -10;
    int pos = 0;
    for (int start = 0; start < (int)toks.size(); start += g.batch_size) {
        int count = std::min(g.batch_size, (int)toks.size() - start);
        addTokensToBatch(batch, toks, start, count, pos);
        int rc = llama_decode(g.ctx, batch);
        if (rc != 0) { llama_batch_free(batch); return -20 + rc; }
        pos += count;
    }
    llama_batch_free(batch);
    return pos;
}

static bool sampleAndFeed(llama_token & token, int pos) {
    token = llama_sampler_sample(g.sampler, g.ctx, -1);
    llama_sampler_accept(g.sampler, token);
    if (llama_vocab_is_eog(g.vocab, token)) return false;

    llama_batch batch = llama_batch_init(1, 0, 1);
    if (!batch.token) return false;
    batch.n_tokens = 1;
    batch.token[0] = token;
    batch.pos[0] = pos;
    batch.n_seq_id[0] = 1;
    batch.seq_id[0][0] = 0;
    batch.logits[0] = 1;
    int rc = llama_decode(g.ctx, batch);
    llama_batch_free(batch);
    return rc == 0;
}

static std::string tokenPiece(llama_token token) {
    char buf[8192];
    int n = llama_token_to_piece(g.vocab, token, buf, (int)sizeof(buf), 0, true);
    if (n <= 0) return {};
    return std::string(buf, (size_t)n);
}

static bool setupSampler(float temperature, float topP, int topK, float minP, float repeatPenalty, int seed) {
    freeSampler();
    auto params = llama_sampler_chain_default_params();
    g.sampler = llama_sampler_chain_init(params);
    if (!g.sampler) return false;
    auto add = [&](llama_sampler * sampler) -> bool {
        if (!sampler) {
            freeSampler();
            return false;
        }
        llama_sampler_chain_add(g.sampler, sampler);
        return true;
    };
    if (repeatPenalty > 1.0001f && !add(llama_sampler_init_penalties(
            llama_vocab_n_tokens(g.vocab), 128, repeatPenalty, 0.0f, 0.0f))) return false;
    if (topK > 0 && !add(llama_sampler_init_top_k(topK))) return false;
    if (topP < 0.999f && !add(llama_sampler_init_top_p(topP, 1))) return false;
    if (minP > 0.0f && !add(llama_sampler_init_min_p(minP, 1))) return false;
    if (temperature > 0.0f && !add(llama_sampler_init_temp(temperature))) return false;
    return true;
}
}

extern "C" JNIEXPORT jint JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeInit(JNIEnv * env, jobject, jstring) {
    std::lock_guard<std::mutex> lock(g.mu);
    if (g.initialized) return 0;
    llama_backend_init();
    g.initialized = true;
    return 0;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeLoadModel(
    JNIEnv * env, jobject, jstring path, jint contextSize, jint threads, jint batchSize) {
    std::lock_guard<std::mutex> lock(g.mu);
    if (!g.initialized) return -1;
    if (g.ctx) { llama_free(g.ctx); g.ctx = nullptr; }
    freeAdapter();
    if (g.model) { llama_model_free(g.model); g.model = nullptr; }
    freeSampler();
    g.vocab = nullptr;
    std::vector<llama_token>().swap(g.tokens);

    const std::string p = jstr(env, path);
    auto mp = llama_model_default_params();
    mp.load_mode = LLAMA_LOAD_MODE_MMAP;
    mp.n_gpu_layers = 0; // portable Android CPU path
    g.model = llama_model_load_from_file(p.c_str(), mp);
    if (!g.model) return -2;

    const int safeContext = std::clamp((int)contextSize, 2048, 8192);
    const int safeBatch = std::clamp((int)batchSize, 128, 256);
    const int safeThreads = std::clamp((int)threads, 2, 6);
    auto cp = llama_context_default_params();
    cp.n_ctx = (uint32_t)safeContext;
    cp.n_batch = (uint32_t)safeBatch;
    cp.n_ubatch = (uint32_t)std::min(safeBatch, 256);
    cp.n_seq_max = 1;
    cp.n_threads = safeThreads;
    cp.n_threads_batch = safeThreads;
    g.ctx = llama_init_from_model(g.model, cp);
    if (!g.ctx) {
        llama_model_free(g.model); g.model = nullptr;
        return -3;
    }
    g.vocab = llama_model_get_vocab(g.model);
    g.threads = safeThreads;
    g.batch_size = safeBatch;
    g.ctx_size = llama_n_ctx(g.ctx);
    return 0;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeSetSystemPrompt(JNIEnv * env, jobject, jstring prompt) {
    std::lock_guard<std::mutex> lock(g.mu);
    const std::string value = jstr(env, prompt);
    constexpr size_t maxSystemPromptChars = 8000;
    g.system_prompt = value.size() > maxSystemPromptChars ? value.substr(0, maxSystemPromptChars) : value;
    return g.system_prompt.empty() ? -1 : 0;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeLoadAdapter(JNIEnv * env, jobject, jstring path, jfloat scale) {
    std::lock_guard<std::mutex> lock(g.mu);
    if (!g.model || !g.ctx) return -1;
    const std::string p = jstr(env, path);
    auto * adapter = llama_adapter_lora_init(g.model, p.c_str());
    if (!adapter) return -2;
    float scales[1] = {scale};
    llama_adapter_lora * adapters[1] = {adapter};
    int rc = llama_set_adapters_lora(g.ctx, adapters, 1, scales);
    if (rc != 0) { llama_adapter_lora_free(adapter); return -3; }
    freeAdapter();
    g.adapter = adapter;
    return 0;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeClearAdapter(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g.mu);
    if (!g.ctx) return -1;
    int rc = llama_set_adapters_lora(g.ctx, nullptr, 0, nullptr);
    if (rc != 0) return -2;
    freeAdapter();
    return 0;
}

static bool addSamplerForGeneration(llama_sampler * chain, llama_sampler * sampler) {
    if (!sampler || !chain) {
        if (sampler) llama_sampler_free(sampler);
        return false;
    }
    llama_sampler_chain_add(chain, sampler);
    return true;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeStartGeneration(
    JNIEnv * env, jobject, jstring prompt, jboolean thinking, jint maxTokens, jfloat temperature,
    jfloat topP, jint topK, jfloat minP, jfloat repeatPenalty, jint seed, jstring grammar, jstring grammarRoot) {
    std::lock_guard<std::mutex> lock(g.mu);
    if (!g.model || !g.ctx || !g.vocab) return -1;
    clearContext();
    g.abort.store(false);
    g.generated = 0;
    g.max_tokens = maxTokens;

    const std::string user = jstr(env, prompt);
    size_t userLimit = 16000;
    std::string full;
    bool promptFits = false;
    for (int attempt = 0; attempt < 6; ++attempt) {
        std::string boundedUser = user;
        if (boundedUser.size() > userLimit) {
            const size_t head = (userLimit * 3) / 5;
            const size_t tail = userLimit - head - 64;
            boundedUser = boundedUser.substr(0, head) + "\n...[prompt compacted for context safety]...\n" + boundedUser.substr(boundedUser.size() - std::max<size_t>(256, tail));
        }
        full = genericPrompt(g.system_prompt, boundedUser, thinking);
        if (tokenize(full, g.tokens) && !g.tokens.empty() && g.tokens.size() < g.ctx_size - 8) {
            promptFits = true;
            break;
        }
        userLimit = std::max<size_t>(2000, (userLimit * 3) / 4);
    }
    if (!promptFits) {
        freeSampler();
        std::vector<llama_token>().swap(g.tokens);
        return -3;
    }

    if (!setupSampler(temperature, topP, topK, minP, repeatPenalty, seed)) {
        std::vector<llama_token>().swap(g.tokens);
        return -4;
    }

    const std::string grammarStr = jstr(env, grammar);
    const std::string grammarRootStr = jstr(env, grammarRoot);
    if (!grammarStr.empty()) {
        auto grammarSampler = llama_sampler_init_grammar(
            g.vocab,
            grammarStr.c_str(),
            grammarRootStr.empty() ? "root" : grammarRootStr.c_str());
        if (!grammarSampler) {
            freeSampler();
            std::vector<llama_token>().swap(g.tokens);
            return -5;
        }
        llama_sampler_chain_add(g.sampler, grammarSampler);
    }
    if (temperature <= 0.0f) {
        if (!addSamplerForGeneration(g.sampler, llama_sampler_init_greedy())) {
            freeSampler();
            std::vector<llama_token>().swap(g.tokens);
            return -7;
        }
    } else {
        if (!addSamplerForGeneration(g.sampler,
                llama_sampler_init_dist(seed < 0 ? LLAMA_DEFAULT_SEED : (uint32_t)seed))) {
            freeSampler();
            std::vector<llama_token>().swap(g.tokens);
            return -7;
        }
    }

    int promptPos = decodePrompt(g.tokens);
    if (promptPos < 1) {
        freeSampler();
        std::vector<llama_token>().swap(g.tokens);
        return -6;
    }
    const int64_t remaining64 = std::max<int64_t>(
        1,
        static_cast<int64_t>(g.ctx_size) - static_cast<int64_t>(promptPos) - 1
    );
    const int remaining = static_cast<int>(remaining64);
    g.max_tokens = std::clamp(g.max_tokens, 1, remaining);
    return 0;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeNextToken(JNIEnv * env, jobject) {
    std::lock_guard<std::mutex> lock(g.mu);
    if (!g.ctx || !g.sampler || g.abort.load() || g.generated >= g.max_tokens) return nullptr;
    llama_token token = llama_sampler_sample(g.sampler, g.ctx, -1);
    llama_sampler_accept(g.sampler, token);
    if (llama_vocab_is_eog(g.vocab, token)) return nullptr;

    std::string piece = tokenPiece(token);
    int pos = (int)g.tokens.size() + g.generated;
    llama_batch batch = llama_batch_init(1, 0, 1);
    if (!batch.token) return nullptr;
    batch.n_tokens = 1;
    batch.token[0] = token;
    batch.pos[0] = pos;
    batch.n_seq_id[0] = 1;
    batch.seq_id[0][0] = 0;
    batch.logits[0] = 1;
    int rc = llama_decode(g.ctx, batch);
    llama_batch_free(batch);
    if (rc != 0) { g.abort.store(true); return nullptr; }
    g.generated++;
    return env->NewStringUTF(piece.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeAbort(JNIEnv *, jobject) { g.abort.store(true); }

extern "C" JNIEXPORT jstring JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeModelInfo(JNIEnv * env, jobject) {
    std::lock_guard<std::mutex> lock(g.mu);
    if (!g.model || !g.ctx) return env->NewStringUTF("{}");
    char desc[256] = {0};
    llama_model_desc(g.model, desc, sizeof(desc));
    std::ostringstream out;
    out << "{\"description\":\"" << desc << "\","
        << "\"params\":" << llama_model_n_params(g.model) << ","
        << "\"model_bytes\":" << llama_model_size(g.model) << ","
        << "\"context\":" << llama_n_ctx(g.ctx) << ","
        << "\"vocab\":" << llama_vocab_n_tokens(g.vocab) << ","
        << "\"llama_version\":\"" << llama_version() << "\","
        << "\"upstream_commit\":\"" << AI_CODER_LLAMA_COMMIT << "\"}"
        ;
    return env->NewStringUTF(out.str().c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeUnload(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g.mu);
    g.abort.store(true);
    freeSampler();
    if (g.ctx) { llama_free(g.ctx); g.ctx = nullptr; }
    freeAdapter();
    if (g.model) { llama_model_free(g.model); g.model = nullptr; }
    g.vocab = nullptr;
    std::vector<llama_token>().swap(g.tokens);
}

extern "C" JNIEXPORT void JNICALL
Java_com_arm_aichat_internal_InferenceEngineImpl_nativeShutdown(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g.mu);
    g.abort.store(true);
    freeSampler();
    if (g.ctx) { llama_free(g.ctx); g.ctx = nullptr; }
    freeAdapter();
    if (g.model) { llama_model_free(g.model); g.model = nullptr; }
    g.vocab = nullptr;
    std::vector<llama_token>().swap(g.tokens);
    if (g.initialized) { llama_backend_free(); g.initialized = false; }
}
