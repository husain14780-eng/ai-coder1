# V7 Internal Vision and Input

GameForge uses a self-contained observation loop. The embedded Godot viewport produces one short-lived image per observation. The Android process decodes it, runs `LocalGameVisionEngine`, fuses the result with structured game telemetry, and deletes the image immediately.

## Local vision

`LocalGameVisionEngine` performs deterministic multi-scale luminance/color/edge/contrast analysis, region detection, HUD activity detection, compact visual embeddings and frame-to-frame motion comparison. The current native llama.cpp JNI interface is text-oriented, so visual evidence is converted to structured features before it reaches the coding/reasoning models; the app does not pretend that a text-only model is a pixel-native VLM.

## Input

`AICoderGodotBridge` sends game actions directly into the generated Godot world. There is no Android AccessibilityService, no MediaProjection service, no camera permission, and no phone-wide gesture automation in V7.

## Research

The mature research agent performs multi-query HTTP search/open inside the AI Coder process, caches recent results, scores source provenance, validates every redirect, and never opens Chrome or another external browser.

## QA/repair loop

The final autonomous loop combines persistent bot memory, deterministic 96-case internal QA, asset-quality gating, procedural world planning, version checkpoints, model routing, performance optimization and rollback-safe repair/retest.
