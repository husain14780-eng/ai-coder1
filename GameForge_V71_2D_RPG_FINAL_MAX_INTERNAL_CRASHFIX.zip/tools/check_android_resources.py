#!/usr/bin/env python3
"""Static Android resource sanity checks for GameForge V7."""
from pathlib import Path
import re, sys
root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
styles = root / "app/src/main/res/values/styles.xml"
gradle = root / "app/build.gradle.kts"
manifest = root / "app/src/main/AndroidManifest.xml"
for p in (styles, gradle, manifest):
    if not p.is_file():
        raise SystemExit(f"missing required file: {p}")
text = styles.read_text(encoding="utf-8")
if "Theme.Material.NoActionBar" in text:
    raise SystemExit("obsolete Theme.Material.NoActionBar reference remains")
if not re.search(r'parent="Theme\.AppCompat\.NoActionBar"', text):
    raise SystemExit("AppTheme must inherit Theme.AppCompat.NoActionBar")
g = gradle.read_text(encoding="utf-8")
if "aaptOptions" in g:
    raise SystemExit("deprecated aaptOptions block remains")
if 'androidx.appcompat:appcompat:' not in g:
    raise SystemExit("AppCompat dependency missing")
m = manifest.read_text(encoding="utf-8")
if '@style/AppTheme' not in m:
    raise SystemExit("AppTheme is not referenced by the manifest")
print("Android resource sanity checks: PASS")
