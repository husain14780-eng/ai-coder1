#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
errors=[]
def read(p):
    f=root/p
    if not f.is_file(): errors.append(f"missing {p}"); return ""
    return f.read_text(encoding="utf-8",errors="replace")
proc=read(Path("app/src/main/java/com/husain/aicoder/vision/GameScreenshotProcessor.kt"))
for needle in ["decoded_and_deleted","ascii_luminance_grid","context.applicationInfo.dataDir","LocalGameVisionEngine"]:
    if needle not in proc: errors.append(f"GameScreenshotProcessor missing {needle}")
tool=read(Path("app/src/main/java/com/husain/aicoder/agent/ToolExecutor.kt"))
for needle in ['"web_search"','"web_open"','"research"','"run_massive_qa"','"plan_mmorpg_world"','"route_model"','GameScreenshotProcessor','fun observe(json: String): String']:
    if needle not in tool: errors.append(f"ToolExecutor missing {needle}")
manifest=read(Path("app/src/main/AndroidManifest.xml"))
for forbidden in ['BIND_ACCESSIBILITY_SERVICE','FOREGROUND_SERVICE_MEDIA_PROJECTION','AccessibilityService','ScreenCaptureService','mediaProjection']:
    if forbidden in manifest: errors.append(f"Forbidden device feature remains in manifest: {forbidden}")
activity=read(Path("app/src/main/java/com/husain/aicoder/MainActivity.kt"))
for forbidden in ['MediaProjectionManager','ScreenCaptureService','AccessibilityService']:
    if forbidden in activity: errors.append(f"Forbidden device feature remains in MainActivity: {forbidden}")
if errors:
    print("IN-APP INTERNAL CHECK: FAIL")
    for e in errors: print(" -",e)
    raise SystemExit(1)
print("IN-APP INTERNAL CHECK: PASS")
print(" - Embedded Godot viewport vision is ephemeral and local")
print(" - Accessibility and MediaProjection are removed")
print(" - Web research stays inside the app process")
print(" - QA/world/assets/model-routing tools are integrated")
