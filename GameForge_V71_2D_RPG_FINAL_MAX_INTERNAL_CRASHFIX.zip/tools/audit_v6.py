#!/usr/bin/env python3
"""Compatibility entry point for the current GameForge V7 audit."""
from pathlib import Path
import runpy

runpy.run_path(str(Path(__file__).with_name("audit_v7.py")), run_name="__main__")
