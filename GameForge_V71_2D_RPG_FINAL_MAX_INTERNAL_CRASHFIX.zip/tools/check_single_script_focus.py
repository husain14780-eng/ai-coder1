#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java'
errors: list[str] = []
warnings: list[str] = []


def must(path: Path, needle: str, label: str) -> None:
    text = path.read_text(encoding='utf-8')
    if needle not in text:
        errors.append(f'{label}: missing required invariant: {needle}')

# Core source invariants.
ws = SRC / 'com/husain/aicoder/agent/CodingWorkspace.kt'
tx = SRC / 'com/husain/aicoder/agent/ToolExecutor.kt'
ca = SRC / 'com/husain/aicoder/agent/CodingAgent.kt'
ac = SRC / 'com/husain/aicoder/mission/AutonomousCodingEngine.kt'
ve = SRC / 'com/husain/aicoder/mission/VerificationEngine.kt'
ms = SRC / 'com/husain/aicoder/mission/MissionStore.kt'
co = SRC / 'com/husain/aicoder/core/HeavyTaskCoordinator.kt'

must(ws, 'fun beginAgentScriptFocus(path: String)', 'workspace')
must(ws, 'normalized.endsWith(".gd", ignoreCase = true)', 'workspace')
must(ws, 'require(normalized == focused)', 'workspace')
must(ws, 'One script at a time.', 'workspace')
must(ws, 'Cannot checkpoint the workspace while a .gd script is focused', 'workspace checkpoint guard')
must(ws, 'Cannot restore a workspace checkpoint while a .gd script is focused', 'workspace restore guard')
must(ws, 'Cannot reset the workspace while a .gd script is focused', 'workspace reset guard')
must(tx, '"claim_script" ->', 'tool executor')
must(tx, 'workspace.agentReplaceText', 'tool executor')
must(tx, 'workspace.agentAppend', 'tool executor')
must(tx, 'Edit blocked: focused script is $focused; no other project file may be mutated during the script coding cycle.', 'tool executor all-file mutation guard')
must(tx, 'Cannot restore a workspace checkpoint while a .gd script is focused', 'tool executor')
must(tx, 'git mutation is blocked while a .gd script is focused', 'tool executor')
must(ca, 'SINGLE-SCRIPT CODING RULE', 'coding agent')
must(ca, 'claim_script', 'coding agent')
must(ac, 'HeavyTaskCoordinator.run("coding-mission")', 'autonomous coding')
must(ac, 'targetPath', 'autonomous coding')
must(ac, 'baselineSha256', 'autonomous coding')
must(ac, 'Stay on this script until its runtime verification passes.', 'autonomous coding')
must(ac, 'call.first in setOf("run_godot_test", "run_generated_game", "run_playtest")', 'autonomous coding')
must(ac, 'fun isGdScriptCodingRole(role: String): Boolean', 'autonomous coding role split')
must(ac, 'focusClaimed || isGdScriptCodingRole(role)', 'autonomous coding focus gate')
must(ac, 'evaluateFinal(', 'autonomous coding')
must(ve, 'passes", 0) == result.optInt("iterations", 0)', 'verification')
must(ve, 'r.optInt("passes", 0) == r.optInt("iterations", 0)', 'verification final')
ap = SRC / 'com/husain/aicoder/quality/AdaptivePlaytestEngine.kt'
must(ap, 'if (runOk) passedRuns++', 'adaptive playtest')
must(ms, 'val targetPath: String = ""', 'mission store')
must(ms, 'val baselineSha256: String = ""', 'mission store')
must(co, 'private val mutex = Mutex()', 'heavy gate')
vlm = SRC / 'com/husain/aicoder/vision/LocalVlmHttpAdapter.kt'
must(vlm, 'MAX_IMAGE_BYTES', 'local VLM memory bound')
must(vlm, 'MAX_RESPONSE_CHARS', 'local VLM response bound')
must(vlm, 'LOCAL_HOSTS', 'local-only VLM endpoint guard')

# Ensure only these sources directly invoke the old generic verifier API.
for p in SRC.rglob('*.kt'):
    text = p.read_text(encoding='utf-8')
    if re.search(r'\.evaluate\([^)]*\)', text) and 'VerificationEngine.kt' not in str(p) and 'AutonomousCodingEngine.kt' not in str(p):
        # This is deliberately conservative; report as warning rather than assuming a bug.
        if 'VerificationEngine' in text:
            warnings.append(f'possible verifier call outside autonomous engine: {p.relative_to(ROOT)}')

# Detect direct model-writer bypasses for focused .gd files inside ToolExecutor.
tex = tx.read_text(encoding='utf-8')
if 'workspace.write(path' in tex and 'isScript' not in tex:
    errors.append('tool executor: write_file appears to lack the .gd/non-.gd distinction')
if 'versions.restore' in tex and 'currentAgentScriptFocus' not in tex:
    errors.append('tool executor: version restore is not focus-gated')

# Check focus lifecycle: every begin in autonomous source has a finally that ends it.
if ac.read_text(encoding='utf-8').count('workspace.beginAgentScriptFocus') < 1:
    errors.append('autonomous coding: no focus acquisition found')
if ac.read_text(encoding='utf-8').count('workspace.endAgentScriptFocus()') < 1:
    errors.append('autonomous coding: no focus release found')

print(f'SINGLE_SCRIPT_FOCUS_CHECK: errors={len(errors)} warnings={len(warnings)}')
for x in errors:
    print('ERROR:', x)
for x in warnings:
    print('WARN:', x)
if errors:
    sys.exit(1)
print('PASS: one-script focus invariants are present and restore/shell bypass paths are guarded.')
