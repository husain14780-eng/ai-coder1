#!/usr/bin/env python3
"""Static regression checks for Kotlin compiler compatibility in GameForge."""
from pathlib import Path
import re
import sys

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')
errors = []

path = root / 'app/src/main/java/com/husain/aicoder/game/GameProjectScaffolder.kt'
if not path.is_file():
    errors.append(f'missing {path}')
else:
    text = path.read_text(encoding='utf-8')
    if 'appendLineCompat' in text:
        errors.append('GameProjectScaffolder.kt must not use appendLineCompat; use StringBuilder.append(...).append(\'\\n\')')
    if re.search(r'private\s+fun\s+StringBuilder\.appendLineCompat', text):
        errors.append('legacy appendLineCompat extension is still present')
    # These generated markdown builders must remain StringBuilder-backed buildString blocks.
    if 'private fun designMarkdown(s: GameSpec): String = buildString {' not in text:
        errors.append('designMarkdown must use buildString/StringBuilder')
    if 'private fun smokeTests(spec: GameSpec) = buildString {' not in text:
        errors.append('smokeTests must use buildString/StringBuilder')
    # Guard against the exact CI failure: direct append calls should be used at the section sites.
    for line_no, line in enumerate(text.splitlines(), 1):
        if 65 <= line_no <= 80 and 'appendLineCompat' in line:
            errors.append(f'legacy appendLineCompat call at line {line_no}')

print('kotlin-compat-check:', 'PASS' if not errors else 'FAIL')
for error in errors:
    print(error)
sys.exit(1 if errors else 0)
