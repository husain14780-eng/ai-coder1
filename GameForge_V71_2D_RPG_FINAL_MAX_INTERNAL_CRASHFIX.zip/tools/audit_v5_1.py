#!/usr/bin/env python3
print("audit_v5_1: retained only as a compatibility entry point; device-capture checks were removed in V7.")
