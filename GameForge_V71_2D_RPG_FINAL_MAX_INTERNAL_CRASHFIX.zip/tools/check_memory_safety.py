#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else '.')
JAVA = ROOT / 'app' / 'src' / 'main' / 'java'
errors = []

# Required single-flight components.
gate = JAVA / 'com/husain/aicoder/core/HeavyTaskCoordinator.kt'
if not gate.is_file():
    errors.append('HeavyTaskCoordinator.kt missing')
else:
    text = gate.read_text(encoding='utf-8')
    for needle in ('Mutex()', 'withLock', 'CoroutineContext', 'activeTask'):
        if needle not in text:
            errors.append(f'HeavyTaskCoordinator missing {needle}')

for rel in [
    'com/husain/aicoder/agent/ToolExecutor.kt',
    'com/husain/aicoder/swarm/SwarmInferenceEngine.kt',
    'com/husain/aicoder/ml/MLTrainingCoordinator.kt',
]:
    p = JAVA / rel
    if not p.is_file():
        errors.append(f'missing single-flight integration: {rel}')
    elif 'HeavyTaskCoordinator' not in p.read_text(encoding='utf-8'):
        errors.append(f'no HeavyTaskCoordinator integration: {rel}')

# Bounded tail readers must be used for append-only JSONL/log recovery paths.
for needle in ('readLines().takeLast', 'useLines { it.toList()', 'useLines { lines ->\n                    lines.toList()'):
    hits = []
    for p in JAVA.rglob('*.kt'):
        t = p.read_text(encoding='utf-8', errors='replace')
        if needle in t:
            hits.append(str(p.relative_to(ROOT)))
    if hits:
        errors.append(f'unbounded log-read pattern {needle!r}: {hits}')

# Q-learning and bot-memory state must be bounded.
mltypes = (JAVA / 'com/husain/aicoder/ml/MLTypes.kt').read_text(encoding='utf-8')
if 'maxStates: Int = 4096' not in mltypes:
    errors.append('QLearning maxStates bound missing')
bot = (JAVA / 'com/husain/aicoder/memory/BotMemoryStore.kt').read_text(encoding='utf-8')
if 'maxStatsEntries' not in bot or 'trimStats' not in bot:
    errors.append('BotMemoryStore statistics bound missing')

# Observation processing must stay outside the Godot callback and inside a gated tool phase.
tool = (JAVA / 'com/husain/aicoder/agent/ToolExecutor.kt').read_text(encoding='utf-8')
if 'val enriched = runCatching { gameVision.processObservation(parsed) }' in tool:
    errors.append('ToolExecutor.observe still performs pixel processing directly')
if 'private fun processLatestObservation()' not in tool or 'gameVision.processObservation(raw)' not in tool:
    errors.append('ToolExecutor on-demand observation processing contract missing')
agent = (JAVA / 'com/husain/aicoder/agent/AgentController.kt').read_text(encoding='utf-8')
if 'toolExecutor.execute("get_last_observation", JSONObject())' not in agent:
    errors.append('AgentController does not process observations through the gated tool path')

# Long streamed model output must not use quadratic String concatenation.
swarm = (JAVA / 'com/husain/aicoder/swarm/SwarmInferenceEngine.kt').read_text(encoding='utf-8')
if 'val full = StringBuilder()' not in swarm or 'full += token' in swarm:
    errors.append('SwarmInferenceEngine output aggregation is not memory-safe')

# Heavy model context and batch controls.
swarm = (JAVA / 'com/husain/aicoder/swarm/SwarmInferenceEngine.kt').read_text(encoding='utf-8')
for needle in ('safeBatch', 'safeThreads', 'contextFor', 'model:generate'):
    if needle not in swarm:
        errors.append(f'SwarmInferenceEngine missing {needle}')

# Physical RAM admission must not count RAM Plus as ordinary RAM.
manager = (JAVA / 'com/husain/aicoder/swarm/LocalModelSwarmManager.kt').read_text(encoding='utf-8')
if 'RAM Plus/swap is deliberately ignored' not in manager:
    errors.append('RAM Plus admission rule missing')

# Persisted Q-table recovery must cap stale files too.
exp = (JAVA / 'com/husain/aicoder/ml/ExperienceLearningSystem.kt').read_text(encoding='utf-8')
swarm_learning = (JAVA / 'com/husain/aicoder/swarm/SwarmLearningManager.kt').read_text(encoding='utf-8')
for name, text in [('ExperienceLearningSystem', exp), ('SwarmLearningManager', swarm_learning)]:
    if 'ArrayDeque<String>(4096)' not in text or 'qLearning.importTable(table)' not in text and name == 'ExperienceLearningSystem':
        errors.append(f'{name} bounded Q-table restore contract missing')

# Device-wide capture APIs remain forbidden.
manifest = (ROOT / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
for bad in ('BIND_ACCESSIBILITY_SERVICE', 'FOREGROUND_SERVICE_MEDIA_PROJECTION'):
    if bad in manifest:
        errors.append(f'forbidden manifest permission: {bad}')
for p in (ROOT / 'app/src/main').rglob('*'):
    if p.is_file() and ('AccessibilityService' in p.name or 'ScreenCaptureService' in p.name):
        errors.append(f'forbidden device automation source remains: {p}')

# Final Q-table storage must be JSONL + bounded tail recovery; legacy import is size-capped.
if 'learning_q_table.jsonl' not in exp:
    errors.append('ExperienceLearningSystem does not use bounded JSONL Q-table persistence')
if 'BoundedFileReader.tailLines(qTableFile, 4096' not in exp:
    errors.append('ExperienceLearningSystem Q-table recovery is not tail-bounded to 4096 lines')
if 'legacyQTableFile.length() <= 1_500_000L' not in exp:
    errors.append('legacy Q-table migration is not size capped')

# Direct workspace checkpoint/reset mutations must reject a focused script.
ws = (JAVA / 'com/husain/aicoder/agent/CodingWorkspace.kt').read_text(encoding='utf-8')
for needle in ('Cannot reset the workspace while a .gd script is focused', 'Cannot checkpoint the workspace while a .gd script is focused', 'Cannot restore a workspace checkpoint while a .gd script is focused'):
    if needle not in ws:
        errors.append(f'CodingWorkspace focus guard missing: {needle}')


# Focused-script mutation must not be bypassed through generic non-script mutators.
for needle in (
    'val focused = workspace.currentAgentScriptFocus()',
    'no other project file may be mutated during the script coding cycle',
):
    if needle not in tool:
        errors.append(f'focused-script mutation guard missing: {needle}')

# Q-learning state operations are synchronized because bot/test callbacks may overlap.
for needle in ('@Synchronized\n    fun chooseAction', '@Synchronized\n    fun update', '@Synchronized\n    fun stateActions'):
    if needle not in mltypes:
        errors.append(f'QLearning synchronization missing: {needle}')

bot = (JAVA / 'com/husain/aicoder/memory/BotMemoryStore.kt').read_text(encoding='utf-8')
for needle in ('MAX_PERSISTED_BYTES', 'MAX_ACTION_PAYLOAD_CHARS', 'file.length() > MAX_PERSISTED_BYTES'):
    if needle not in bot:
        errors.append(f'BotMemoryStore startup/payload cap missing: {needle}')

native = (ROOT / 'llamaAndroid/src/main/cpp/ai_chat_jni.cpp').read_text(encoding='utf-8')
for needle in ('if (!setupSampler(', 'std::vector<llama_token>().swap(g.tokens);', 'if (!addSamplerForGeneration'):
    if needle not in native:
        errors.append(f'native generation cleanup guard missing: {needle}')

infer = (ROOT / 'llamaAndroid/src/main/java/com/arm/aichat/internal/InferenceEngineImpl.kt').read_text(encoding='utf-8')
if 'stateMutable.value = InferenceEngine.State.UnloadingModel' not in infer or 'runCatching { nativeUnload() }' not in infer:
    errors.append('InferenceEngineImpl cleanup is not unconditional after abort')

if errors:
    print('MEMORY_SAFETY: FAIL')
    for e in errors:
        print(' -', e)
    sys.exit(1)
print('MEMORY_SAFETY: PASS')
