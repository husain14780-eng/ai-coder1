# ML architecture — GameForge V7

The five learning families from earlier releases remain available:

- supervised
- unsupervised
- semi-supervised
- self-supervised
- reinforcement learning

4.0 adds a final game-engineering curriculum, provenance and protected promotion layer around them:

idea -> implementation -> playtest -> failure -> repair -> verification -> skill -> dataset -> candidate adapter -> evaluation

The candidate gate remains evidence-based and protects against regressions.
