# GameForge V7 — Full Game Factory

## What changed

GameForge is no longer architected around one permanent language model. The existing agents now consume a model-agnostic inference interface backed by a local specialist router.

### Specialist roster

- **Qwen3-4B-Instruct-2507 Q6_K** — general/director/critic work.
- **Qwen3-4B-Thinking-2507 Q6_K** — game design, architecture, difficult reasoning, root-cause analysis and quality critique.
- **Qwen2.5-Coder-7B-Instruct Q4_K_M** — primary coding specialist with deliberate THINKING mode.
- **Qwen2.5-VL-3B-Instruct Q6_K** — vision profile. The V7 text-only JNI backend does not pretend it can accept image tensors, so this profile remains reserved until the native multimodal projector backend is connected.

### Learning

The router accumulates verified task outcomes and uses all five requested learning modes: supervised, unsupervised, semi-supervised, self-supervised and reinforcement learning. The base model files are not mutated after each task; model-weight improvement remains a separately gated training/adapter process.

### Local-only promise

No cloud model endpoint is required by the runtime. Internet access is only relevant when the user chooses to obtain/update model files or build dependencies.


## Final hardening

- A source compiler pass found and fixed a missing closing brace in `EpisodeStore.kt`.
- Fresh builds checkpoint/reset stale generated workspaces.
- Coding specialists use deliberate agent-level THINKING mode.
- The final quality gate includes runtime-packaging success.
- The GitHub workflow validates and extracts the exact V7 source ZIP before Gradle configuration/build.


## V7.1 in-app-only vision/research patch

- GameForge bot/playtest screenshots now come from the embedded Godot viewport, not the phone-wide screen.
- Each viewport screenshot is ephemeral: decode/analyze, enrich the observation, then delete it.
- Device MediaProjection/accessibility have been removed; GameForge is internal-only.
- Added in-app `web_search` and `web_open` tools; they never launch an external browser.


## V7 Internal MAX Upgrade
- Removed Android AccessibilityService and MediaProjection from the application manifest and source.
- Added true in-process local game vision from the embedded Godot viewport.
- Added autonomous repair/retest with rollback-safe version checkpoints.
- Added persistent bot episodic memory with reward/action ranking.
- Added a real 96-case internal QA matrix with deterministic fuzz replay.
- Added procedural MMORPG/world planning and validation.
- Added generated-asset integrity, animation-reference, dimension, FPS and style-consistency gating.
- Added closed-loop performance optimization with QA and rollback.
- Added adaptive local model routing for coding, reasoning, QA, world, performance, vision and research tasks.
- Added mature in-app research with cached provenance-aware multi-query retrieval.


## Final V7.1 single-script + runtime hardening
- Qwen2.5-Coder coding/debug cycles now lock to one `.gd` script until its fresh runtime verification passes.
- Generic file mutation tools cannot modify another project file while that script focus is active.
- QLearning is synchronized and capped at 4,096 states; persisted recovery remains tail-bounded.
- Bot memory has bounded startup/payload protection.
- Native sampler/token cleanup now runs on generation-start failures; model cleanup is unconditional after abort.
- Final release/version metadata avoids giant in-memory file manifests.
