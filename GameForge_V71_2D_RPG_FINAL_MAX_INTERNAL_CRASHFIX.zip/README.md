# AI Coder V7 — GameForge Full Game Factory

GameForge V7 is a local-first autonomous game-development agent for Android. It turns a natural-language game goal into a Godot project, implements it with specialist local models, runs fresh runtime tests, repairs failures, and produces a final evidence report.

## Local model strategy

- **Qwen3-4B-Thinking-2507** — architecture, difficult reasoning, diagnosis and planning.
- **Qwen2.5-Coder-7B-Instruct Q4_K_M** — primary implementation model.
- **Qwen3-4B-Instruct-2507** — general/director/critic work when installed.
- **Qwen2.5-VL-3B-Instruct** — reserved vision specialist; the current JNI backend does not pretend a text-only path is multimodal.
- DeepSeek-Coder is **not required** for the V7 workflow.

Qwen2.5-Coder uses an **agent-level deliberate planning/thinking mode** in GameForge; this is not a claim that the Qwen2.5-Coder base model has Qwen3's native thinking head.

## Full-game pipeline

```text
User goal
  -> GameSpec design
  -> contract compilation
  -> genre blueprint + level plan
  -> deterministic playable bootstrap
  -> long-horizon coding agent
  -> static generated-project verification
  -> fresh Godot playtest
  -> performance / gameplay / visual checks
  -> root-cause repair
  -> regression
  -> package + final report
```

The bootstrap is intentionally more than an empty template: it includes movement, jumping, checkpoints, hazards, coins, a goal, pause UI, touch controls, save/load, a deterministic restart path, and the GameForge automation bridge. The coding agent is expected to expand it into the actual game requested by the user.

## Godot architecture

Godot is embedded through the Android dependency `org.godotengine:godot:4.7.2.stable`. Generated projects are packaged into resource packs and loaded into the embedded runtime. The source ZIP does not contain a standalone Godot editor executable.

## Build

GitHub Actions extracts `GameForge_V71_2D_RPG_FINAL_MAX_INTERNAL.zip`, locates the Gradle root, installs the pinned Android/JDK/Gradle toolchain, runs `tools/check_release.py` and `tools/audit_v7.py`, builds `app-debug.apk`, verifies the APK archive, and publishes the APK plus SHA-256.

The source release intentionally does not bundle multi-gigabyte model weights, Android SDK/NDK files or private signing keys.

## V7.1 2D RPG/MMORPG generation

GameForge V7 is 2D-first for RPG/MMORPG projects. The coding model can request new characters, sprite frames, multi-direction animation sets, VFX, icons, tilesets, and procedural maps using prompts, style, palette, seed, frame count, and direction count. The factory synthesizes the runtime PNG assets and editable SVG sources per build; it does not require a fixed shipped art pack. Generated maps include runtime AStarGrid2D navigation, and the scaffolded bot swarm uses that navigation during automated tests.


## In-app-only GameForge vision and research

GameForge uses the embedded Godot viewport as its normal visual source. After a bot action/observation, Godot emits one ephemeral JPEG of the game viewport; AI Coder decodes it, derives compact visual cues, and deletes the image immediately after processing. The normal GameForge path does not use Android MediaProjection or device-wide screen capture.

Web research is also in-app: the `web_search` and `web_open` tools perform HTTP(S) requests directly from AI Coder and return compact evidence without launching an external browser.

Android accessibility and MediaProjection are removed. GameForge uses only its embedded Godot runtime, local vision, in-app HTTP research, and local model swarm. INTERNET is retained only for the in-app HTTP research agent; it does not launch a browser or control the device. Research evidence is saved under each game workspace at gameforge/research/LAST_RESEARCH.json.
