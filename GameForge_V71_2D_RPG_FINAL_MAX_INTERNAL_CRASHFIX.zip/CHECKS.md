# GameForge V7 release checks

## Source/reliability checks

- [x] V7 version metadata is consistent.
- [x] Qwen2.5-Coder-7B Q4_K_M is the primary coding profile.
- [x] DeepSeek is not required by the V7 model catalog.
- [x] Explicit `TASK_ROLE` routing is present for design/reasoning/coding.
- [x] Native generation lifecycle remains serialized.
- [x] Model switching is serialized and has recoverable fallbacks.
- [x] Workspace writes and build-state persistence use atomic finalization.
- [x] Fresh Godot observations use versioned polling rather than stale cached state.
- [x] Adaptive playtesting exits loops with real `break` semantics.
- [x] Generated projects have a deterministic automation contract.
- [x] Static generated-project verification runs before quality acceptance.
- [x] Final regression and the final runtime-packaging step must both succeed before a build is marked accepted.
- [x] Fresh-build mode checkpoints and resets an existing generated workspace to prevent stale-game carryover.
- [x] Kotlin source syntax pass found and fixed a missing closing brace in EpisodeStore.
- [x] GitHub Actions extracts the exact V7 ZIP before building.
- [x] No private signing material is shipped.

## Environment checks

- [ ] Android Gradle/NDK build completed on GitHub.
- [ ] APK installed and executed on a Galaxy M33.
- [ ] Real Qwen GGUF inference completed on target hardware.
- [ ] Native multimodal Qwen2.5-VL execution completed through an image-capable backend.
- [ ] On-device gradient training completed.

Those checks require a real Android build/device/runtime and are never faked by the source audit.


## V7.1 2D-specific checks

- compile-probe `GameForge2DAssetFactory.kt` with a clean workspace stub
- generate baseline assets plus a custom 8-direction character with a non-standard attack animation and visual recipe
- generate an explicitly AI-authored ASCII map and validate its preview/metadata
- verify PNG signatures/decoding and SVG XML well-formedness
- verify animation-frame changes, one-shot animation semantics, and runtime `SpriteFrames` wiring
- verify generated map scripts expose `get_path_direction` / `get_random_walkable_position` for bot navigation
- verify deterministic playtest action coverage includes `attack`, `skill`, and `bot_test`

## V7.1 single-script/runtime hardening checks

- [x] Coding/debugging tasks claim exactly one `.gd` target before direct script edits.
- [x] The active script remains locked through repair/retest until runtime verification passes.
- [x] Mission checkpoints persist target path, baseline/current SHA-256 and last test evidence.
- [x] Checkpoint/version restore and mutable Git commands are blocked during script focus.
- [x] Non-script project files remain editable so the focus rule does not remove scene/config/asset functionality.
- [x] Deterministic and adaptive playtests count only fully successful runs, with no partial-pass inflation.
- [x] Playtest completion requires all requested iterations to pass.
- [x] Coroutine cancellation propagates through tool/gameplay boundaries.
- [x] Optional local VLM image/response memory is bounded and endpoints are localhost-only.
- [x] `tools/check_single_script_focus.py` passes.

