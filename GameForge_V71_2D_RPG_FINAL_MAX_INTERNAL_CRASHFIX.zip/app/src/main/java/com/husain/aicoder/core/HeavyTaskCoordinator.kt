package com.husain.aicoder.core

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.AbstractCoroutineContextElement
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.withContext

/**
 * Global single-flight gate for memory-heavy GameForge work.
 *
 * The gate is intentionally re-entrant for child calls in the same coroutine context, so a
 * composite operation (for example Massive QA -> ToolExecutor -> nested tools) does not deadlock.
 * RAM Plus is never considered additional physical RAM by this coordinator.
 */
object HeavyTaskCoordinator {
    private val mutex = Mutex()
    @Volatile private var activeName: String? = null

    private class Lease(val name: String) : AbstractCoroutineContextElement(Key) {
        companion object Key : CoroutineContext.Key<Lease>
    }

    suspend fun <T> run(name: String, block: suspend () -> T): T {
        if (coroutineContext[Lease] != null) return block()
        return mutex.withLock {
            activeName = name
            try {
                withContext(Lease(name)) { block() }
            } finally {
                activeName = null
            }
        }
    }

    fun activeTask(): String? = activeName
}
