package com.husain.aicoder.router

import com.husain.aicoder.swarm.LocalModelProfile
import com.husain.aicoder.swarm.LocalModelSwarmManager
import com.husain.aicoder.swarm.SwarmLearningManager
import org.json.JSONObject

/** Unified model routing policy with risk, evidence, memory and device-budget awareness. */
class AdaptiveModelRouter(
    private val swarm: LocalModelSwarmManager,
    private val learning: SwarmLearningManager
) {
    fun route(task: String, prompt: String, risk: Double, evidence: Boolean): JSONObject {
        val normalized = classify(task, prompt)
        val profiles = swarm.installed()
        val scores = profiles.associate { it.profile.id to learning.score(it.profile.id, normalized) }
        val preferredRole = when (normalized) {
            "coding" -> LocalModelProfile.Role.CODING
            "reasoning", "debugging", "qa", "research", "performance" -> LocalModelProfile.Role.REASONING
            "design", "world", "asset" -> LocalModelProfile.Role.GAME_DESIGN
            "vision" -> LocalModelProfile.Role.VISION
            else -> LocalModelProfile.Role.GENERAL
        }
        val heavy = risk >= 0.60 || !evidence || normalized in setOf("reasoning", "debugging", "world", "performance", "qa", "research")
        val candidate = swarm.bestInstalled(preferredRole, scores, allowHeavy = heavy)
            ?: swarm.bestFallbackFor(setOf(preferredRole), allowHeavy = heavy)
        val decision = when (normalized) {
            "reasoning", "debugging", "world", "performance", "qa", "research" -> "THINKING"
            else -> "FAST"
        }
        val selectedId = if (normalized == "vision") "GameVision-Local-7.0" else candidate?.profile?.id ?: "none"
        val selectedDisplay = if (normalized == "vision") "Local embedded-Godot vision pipeline" else candidate?.profile?.displayName ?: "none"
        return JSONObject()
            .put("task", normalized)
            .put("reasoning_mode", decision)
            .put("risk", risk.coerceIn(0.0, 1.0))
            .put("evidence_present", evidence)
            .put("device", swarm.deviceSnapshot().let { s ->
                JSONObject().put("available_ram_mb", s.availableRamMb).put("low_memory", s.lowMemory).put("cpu_cores", s.cpuCores)
            })
            .put("selected_model", selectedId)
            .put("selected_model_display", selectedDisplay)
            .put("learned_score", if (candidate == null) 0.0 else (scores[candidate.profile.id] ?: 0.0))
            .put("fallback", candidate == null)
            .put("reason", "task=$normalized risk=${"%.2f".format(risk)} evidence=$evidence heavy=$heavy")
    }

    private fun classify(task: String, prompt: String): String {
        val p = "$task $prompt".lowercase()
        return when {
            listOf("vision", "screenshot", "pixel", "frame", "image").any { it in p } -> "vision"
            listOf("root cause", "debug", "crash", "compiler", "exception").any { it in p } -> "debugging"
            listOf("qa", "regression", "test matrix", "quality", "fuzz").any { it in p } -> "qa"
            listOf("world", "mmorpg", "quest graph", "faction", "zone", "procedural world").any { it in p } -> "world"
            listOf("research", "documentation", "official docs", "web search", "source").any { it in p } -> "research"
            listOf("performance", "fps", "memory", "optimizer", "profile").any { it in p } -> "performance"
            listOf("asset", "sprite", "tileset", "animation manifest", "style consistency").any { it in p } -> "asset"
            listOf("game design", "mechanic", "progression", "level design").any { it in p } -> "design"
            listOf("code", "gdscript", "kotlin", "implementation", "refactor").any { it in p } -> "coding"
            else -> "general"
        }
    }
}
