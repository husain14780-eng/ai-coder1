package com.husain.aicoder.release

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Produces a reproducible ship pack with manifest + hashes, excluding transient checkpoints and caches. */
class FinalReleasePackager(private val workspace: CodingWorkspace) {
    fun packageRelease(goal: String, accepted: Boolean): File {
        val releaseDir = File(workspace.root.parentFile, "final_releases").apply { mkdirs() }
        val stamp = System.currentTimeMillis()
        val manifestFile = File(workspace.root, "gameforge/FINAL_RELEASE_MANIFEST.json")
        manifestFile.parentFile?.mkdirs()
        val fileCount = workspace.root.walkTopDown()
            .count { it.isFile && !excluded(it) && it != manifestFile }
        manifestFile.bufferedWriter(Charsets.UTF_8).use { writer ->
            writer.append("{\n")
            writer.append("  \"release_version\": \"7.1-2D-RPG-FINAL-MAX-INTERNAL\",\n")
            writer.append("  \"goal\": ").append(JSONObject.quote(goal)).append(",\n")
            writer.append("  \"accepted\": ").append(accepted.toString()).append(",\n")
            writer.append("  \"generated_at_ms\": ").append(stamp.toString()).append(",\n")
            writer.append("  \"file_count_excluding_manifest\": ").append(fileCount.toString()).append(",\n")
            writer.append("  \"manifest_is_self_excluded_from_hash_index\": true,\n")
            writer.append("  \"files\": [\n")
            var first = true
            workspace.root.walkTopDown().filter { it.isFile && !excluded(it) && it != manifestFile }.forEach { f ->
                val rel = f.relativeTo(workspace.root).path.replace(File.separatorChar, '/')
                if (!first) writer.append(",\n") else first = false
                writer.append("    ")
                writer.append(JSONObject().put("path", rel).put("bytes", f.length()).put("sha256", sha256(f)).toString())
            }
            writer.append("\n  ]\n}")
        }

        val zip = File(releaseDir, "GameForge_FINAL_MAX_$stamp.zip")
        ZipOutputStream(zip.outputStream().buffered()).use { out ->
            workspace.root.walkTopDown().filter { it.isFile && !excluded(it) }.forEach { f ->
                val rel = f.relativeTo(workspace.root).path.replace(File.separatorChar, '/')
                out.putNextEntry(ZipEntry(rel))
                f.inputStream().use { it.copyTo(out, 1024 * 1024) }
                out.closeEntry()
            }
        }
        return zip
    }

    private fun excluded(file: File): Boolean {
        val rel = file.relativeTo(workspace.root).path.replace(File.separatorChar, '/')
        return rel.startsWith(".git/") || rel.startsWith("gameforge/runtime/cache/") ||
            rel.startsWith("checkpoints/") || rel.endsWith(".part") ||
            rel.contains("/tmp/") || rel.contains("/cache/")
    }

    private fun sha256(file: File): String = MessageDigest.getInstance("SHA-256").let { md ->
        file.inputStream().use { input ->
            val buf = ByteArray(1024 * 1024)
            while (true) { val n = input.read(buf); if (n <= 0) break; md.update(buf, 0, n) }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }
}
