package com.husain.aicoder.agent

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.FileInputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

class CodingWorkspace(context: Context) {
    val root: File = File(context.filesDir, "workspace").apply { mkdirs() }
    private val checkpointRoot = File(context.filesDir, "checkpoints").apply { mkdirs() }
    @Volatile private var agentScriptFocus: String? = null

    companion object {
        private const val MAX_EDITABLE_SCRIPT_BYTES = 2_000_000L
        private const val DEFAULT_READ_CHARS = 30_000
        private const val MAX_RANGE_CHARS = 16_000
    }

    private fun resolve(relative: String): File {
        val clean = relative.trimStart('/').replace('\\', '/')
        val f = File(root, clean).canonicalFile
        val rootPath = root.canonicalPath
        check(f.path == rootPath || f.path.startsWith(rootPath + File.separator)) { "Path escapes workspace" }
        return f
    }

    fun read(path: String): String {
        val f = resolve(path)
        require(f.isFile) { "File not found: $path" }
        return readHead(f, DEFAULT_READ_CHARS)
    }

    fun readRange(path: String, startChar: Int = 0, maxChars: Int = DEFAULT_READ_CHARS): String {
        val f = resolve(path)
        require(f.isFile) { "File not found: $path" }
        return readRange(f, startChar.coerceAtLeast(0), maxChars.coerceIn(1, MAX_RANGE_CHARS))
    }

    @Synchronized
    fun beginAgentScriptFocus(path: String): String {
        val f = resolve(path)
        val normalized = f.relativeTo(root).path.replace(File.separatorChar, '/')
        require(normalized.endsWith(".gd", ignoreCase = true)) {
            "Qwen script focus must be a .gd script: $normalized"
        }
        require(!normalized.startsWith("gameforge/runtime/")) {
            "Qwen cannot directly edit internal runtime scripts: $normalized"
        }
        val current = agentScriptFocus
        if (current != null && current != normalized) {
            throw IllegalStateException("A different script is already focused: $current")
        }
        agentScriptFocus = normalized
        return normalized
    }

    @Synchronized
    fun endAgentScriptFocus() {
        agentScriptFocus = null
    }

    fun currentAgentScriptFocus(): String? = agentScriptFocus

    fun agentWrite(path: String, content: String): String {
        enforceAgentScriptFocus(path)
        return write(path, content)
    }

    fun agentReplaceText(path: String, old: String, new: String, expectedCount: Int = 1): String {
        enforceAgentScriptFocus(path)
        val f = resolve(path)
        require(f.isFile) { "File not found: $path" }
        require(f.length() <= MAX_EDITABLE_SCRIPT_BYTES) {
            "Focused script is too large for safe whole-file replacement (${f.length()} bytes). Use smaller targeted replacements."
        }
        return replaceText(path, old, new, expectedCount)
    }

    fun agentAppend(path: String, content: String): String {
        enforceAgentScriptFocus(path)
        return append(path, content)
    }

    fun agentTargetExists(path: String): Boolean = resolve(path).isFile

    private fun enforceAgentScriptFocus(path: String) {
        val f = resolve(path)
        val normalized = f.relativeTo(root).path.replace(File.separatorChar, '/')
        val focused = agentScriptFocus ?: throw IllegalStateException(
            "No script is claimed. Call claim_script with exactly one .gd target before editing."
        )
        require(normalized == focused) {
            "Edit blocked: focused script is $focused; requested $normalized. One script at a time."
        }
        require(normalized.endsWith(".gd", ignoreCase = true)) { "Only the focused .gd script may be edited." }
    }

    fun writeBytes(path: String, content: ByteArray): String {
        val f = resolve(path)
        f.parentFile?.mkdirs()
        val temp = File(f.parentFile, ".${f.name}.part")
        FileOutputStream(temp).use { output ->
            output.write(content)
            output.fd.sync()
        }
        runCatching {
            Files.move(temp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        }.recoverCatching {
            Files.move(temp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }.getOrElse { throw IllegalStateException("Cannot finalize workspace binary file: $path", it) }
        return f.relativeTo(root).path.replace(File.separatorChar, '/')
    }

    fun write(path: String, content: String): String {
        val f = resolve(path)
        f.parentFile?.mkdirs()
        val temp = File(f.parentFile, ".${f.name}.part")
        FileOutputStream(temp).use { output ->
            output.write(content.toByteArray(Charsets.UTF_8))
            output.fd.sync()
        }
        runCatching {
            Files.move(temp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        }.recoverCatching {
            Files.move(temp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }.getOrElse { throw IllegalStateException("Cannot finalize workspace file: $path", it) }
        return f.relativeTo(root).path
    }

    @Synchronized
    fun resetWorkspace() {
        require(agentScriptFocus == null) {
            "Cannot reset the workspace while a .gd script is focused; finish or abort the current script first."
        }
        root.listFiles()?.forEach { it.deleteRecursively() }
        root.mkdirs()
    }

    fun listAllFiles(limit: Int = 20000): List<String> = root.walkTopDown()
        .onEnter { it.name != ".git" && it.name != ".godot" && it.name != "checkpoints" }
        .filter { it.isFile }
        .take(limit.coerceIn(1, 100000))
        .map { it.relativeTo(root).path.replace(File.separatorChar, '/') }
        .toList()

    fun replaceText(path: String, old: String, new: String, expectedCount: Int = 1): String {
        require(old.isNotEmpty()) { "old text must not be empty" }
        val f = resolve(path)
        require(f.isFile) { "File not found: $path" }
        require(f.length() <= MAX_EDITABLE_SCRIPT_BYTES) {
            "File is too large for safe whole-file replacement (${f.length()} bytes). Use smaller targeted replacements."
        }
        val original = f.readText()
        val actual = countOccurrences(original, old)
        require(actual == expectedCount) { "replace_text expected $expectedCount match(es), found $actual" }
        write(path, original.replace(old, new))
        return f.relativeTo(root).path.replace(File.separatorChar, '/')
    }

    @Synchronized
    fun append(path: String, content: String): String {
        val f = resolve(path)
        f.parentFile?.mkdirs()
        val temp = File(f.parentFile, ".${f.name}.append.part")
        FileOutputStream(temp).use { output ->
            if (f.isFile) {
                FileInputStream(f).use { input ->
                    input.copyTo(output, 1024 * 1024)
                }
            }
            output.write(content.toByteArray(Charsets.UTF_8))
            output.fd.sync()
        }
        runCatching {
            Files.move(temp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        }.recoverCatching {
            Files.move(temp.toPath(), f.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }.getOrElse { throw IllegalStateException("Cannot finalize appended workspace file: $path", it) }
        return f.relativeTo(root).path.replace(File.separatorChar, '/')
    }

    fun list(path: String = ""): List<String> = resolve(path)
        .walkTopDown().filter { it.isFile }.take(500)
        .map { it.relativeTo(root).path }.toList()

    fun search(query: String, path: String = ""): List<String> {
        val q = query.lowercase(); require(q.isNotBlank())
        return resolve(path).walkTopDown().filter { it.isFile }.take(1000).mapNotNull { f ->
            val text = runCatching { readHead(f, 64_000) }.getOrNull() ?: return@mapNotNull null
            if (text.lowercase().contains(q)) f.relativeTo(root).path.replace(File.separatorChar, '/') else null
        }.take(160).toList()
    }

    fun sha256(path: String): String {
        val f = resolve(path)
        require(f.isFile) { "File not found: $path" }
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(f).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                if (count > 0) digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    @Synchronized fun checkpoint(label: String): File {
        require(agentScriptFocus == null) {
            "Cannot checkpoint the workspace while a .gd script is focused; finish or abort the current script first."
        }
        val safe = label.replace(Regex("[^A-Za-z0-9_.-]+"), "_").take(80)
        val out = File(checkpointRoot, "${System.currentTimeMillis()}_$safe").apply { mkdirs() }
        copyTree(root, out)
        return out
    }

    fun listCheckpoints(): List<File> = checkpointRoot.listFiles()?.filter { it.isDirectory }
        ?.sortedByDescending { it.name } ?: emptyList()

    @Synchronized fun restoreCheckpoint(name: String): Boolean {
        require(agentScriptFocus == null) {
            "Cannot restore a workspace checkpoint while a .gd script is focused; finish or abort the current script first."
        }
        val source = checkpointRoot.listFiles()?.firstOrNull { it.name == name && it.isDirectory } ?: return false
        root.deleteRecursively(); root.mkdirs(); copyTree(source, root); return true
    }

    private fun copyTree(from: File, to: File) {
        if (from.isDirectory) {
            to.mkdirs()
            from.listFiles()?.forEach { child -> copyTree(child, File(to, child.name)) }
        } else if (from.isFile) {
            to.parentFile?.mkdirs(); from.copyTo(to, overwrite = true)
        }
    }

    private fun readHead(file: File, maxChars: Int): String {
        require(maxChars > 0)
        InputStreamReader(FileInputStream(file), Charsets.UTF_8).use { reader ->
            val buffer = CharArray(4096)
            val out = StringBuilder(minOf(maxChars, 65_536))
            while (out.length < maxChars) {
                val want = minOf(buffer.size, maxChars - out.length)
                val count = reader.read(buffer, 0, want)
                if (count <= 0) break
                out.append(buffer, 0, count)
            }
            return out.toString()
        }
    }

    private fun readRange(file: File, startChar: Int, maxChars: Int): String {
        require(startChar >= 0 && maxChars > 0)
        InputStreamReader(FileInputStream(file), Charsets.UTF_8).use { reader ->
            val buffer = CharArray(4096)
            var remaining = startChar
            while (remaining > 0) {
                val count = reader.read(buffer, 0, minOf(buffer.size, remaining))
                if (count <= 0) return ""
                remaining -= count
            }
            val out = StringBuilder(maxChars)
            while (out.length < maxChars) {
                val want = minOf(buffer.size, maxChars - out.length)
                val count = reader.read(buffer, 0, want)
                if (count <= 0) break
                out.append(buffer, 0, count)
            }
            return out.toString()
        }
    }

    private fun countOccurrences(haystack: String, needle: String): Int {
        var count = 0; var at = 0
        while (true) {
            val i = haystack.indexOf(needle, at)
            if (i < 0) return count
            count++; at = i + needle.length
        }
    }
}
