package com.husain.aicoder.web

import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Multi-query, cached, source-provenance-aware research layer for the autonomous agent. */
class MatureResearchAgent(private val web: InAppWebResearch = InAppWebResearch()) {
    private data class CacheEntry(val createdAt: Long, val value: JSONObject)
    private val cache = ConcurrentHashMap<String, CacheEntry>()
    private val ttlMs = 15 * 60 * 1000L

    suspend fun research(question: String, maxSources: Int = 8): JSONObject {
        val normalized = question.trim().replace(Regex("\\s+"), " ").take(320)
        require(normalized.isNotBlank()) { "research question must not be blank" }
        val cacheKey = digest(normalized.lowercase())
        val cached = cache[cacheKey]
        if (cached != null && System.currentTimeMillis() - cached.createdAt < ttlMs) {
            return JSONObject(cached.value.toString()).put("cache", "hit")
        }
        val queries = buildQueries(normalized)
        val candidates = linkedMapOf<String, JSONObject>()
        for (query in queries) {
            val result = runCatching { web.search(query, maxSources.coerceIn(1, 8)) }.getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "search failed") }
            val rows = result.optJSONArray("results") ?: JSONArray()
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                val url = row.optString("url").trim()
                if (url.isNotBlank()) candidates.putIfAbsent(url, JSONObject(row.toString()).put("query", query))
                if (candidates.size >= maxSources.coerceIn(3, 16) * 2) break
            }
            if (candidates.size >= maxSources.coerceIn(3, 16) * 2) break
        }

        val sources = JSONArray()
        val claims = JSONArray()
        var openFailures = 0
        candidates.values.sortedByDescending { sourceScore(it.optString("url"), normalized) }.take(maxSources.coerceIn(3, 16)).forEachIndexed { index, row ->
            val opened = runCatching { web.open(row.optString("url"), 16000) }.getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "open failed") }
            val content = opened.optString("content")
            if (!opened.optBoolean("ok", false)) openFailures++
            val source = JSONObject(row.toString())
                .put("rank", index + 1)
                .put("trust_score", sourceScore(row.optString("url"), normalized))
                .put("opened", opened.optBoolean("ok", false))
                .put("content_preview", content.take(2400))
            sources.put(source)
            if (content.isNotBlank()) {
                claims.put(JSONObject()
                    .put("source_url", row.optString("url"))
                    .put("claim", sentenceExtract(content, normalized).take(900))
                    .put("confidence", (0.40 + sourceScore(row.optString("url"), normalized) * 0.55).coerceIn(0.40, 0.95)))
            }
        }
        val result = JSONObject()
            .put("ok", sources.length() >= 1)
            .put("question", normalized)
            .put("query_plan", JSONArray(queries))
            .put("source_count", sources.length())
            .put("sources", sources)
            .put("claims", claims)
            .put("method", "multi_query_in_app_http_with_provenance")
            .put("network_mode", "app_process_only")
            .put("failed_opens", openFailures)
            .put("source_domains", JSONArray(sourcesToDomains(sources)))
            .put("generated_at_ms", System.currentTimeMillis())
        cache[cacheKey] = CacheEntry(System.currentTimeMillis(), JSONObject(result.toString()))
        return result
    }

    fun clearCache() { cache.clear() }

    fun status(): JSONObject = JSONObject()
        .put("ok", true)
        .put("cache_entries", cache.size)
        .put("cache_ttl_ms", ttlMs)
        .put("network_mode", "app_process_only")
        .put("external_browser", false)
        .put("redirect_limit", 4)
        .put("private_network_targets_blocked", true)

    private fun buildQueries(question: String): List<String> {
        val base = question.trim()
        val out = linkedSetOf(base)
        out += "$base official documentation"
        out += "$base implementation guide"
        out += "$base github"
        out += "$base pitfalls limitations"
        return out.take(5)
    }

    private fun sourceScore(url: String, query: String): Double {
        val lower = url.lowercase()
        var score = 0.30
        if (lower.contains("godotengine.org") || lower.contains("developer.android.com")) score += 0.45
        if (lower.contains("github.com")) score += 0.30
        if (lower.contains("huggingface.co")) score += 0.25
        if (lower.contains("wikipedia.org")) score += 0.12
        if (lower.contains("reddit.com")) score += 0.05
        val queryTerms = query.lowercase().split(Regex("[^a-z0-9]+")) .filter { it.length >= 4 }
        val overlap = queryTerms.count { lower.contains(it) }
        score += (overlap / queryTerms.size.coerceAtLeast(1).toDouble()) * 0.20
        return score.coerceIn(0.0, 1.0)
    }

    private fun sentenceExtract(content: String, query: String): String {
        val sentences = content.split(Regex("(?<=[.!?])\\s+"))
        val terms = query.lowercase().split(Regex("[^a-z0-9]+")) .filter { it.length >= 4 }.take(8)
        return sentences.maxByOrNull { sentence -> terms.count { sentence.lowercase().contains(it) } }?.trim().orEmpty().ifBlank { content.take(900) }
    }

    private fun sourcesToDomains(sources: JSONArray): List<String> {
        val out = linkedSetOf<String>()
        for (i in 0 until sources.length()) {
            val url = sources.optJSONObject(i)?.optString("url").orEmpty()
            runCatching { java.net.URI(url).host.orEmpty().lowercase() }.getOrNull()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        }
        return out.toList()
    }

    private fun digest(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
