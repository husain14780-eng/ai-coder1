package com.husain.aicoder.web

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URI
import java.net.URL
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * Minimal in-app web research layer. It performs HTTP requests directly from the AI Coder
 * process and returns compact, evidence-oriented text. No external browser app is launched.
 */
class InAppWebResearch {
    suspend fun search(query: String, maxResults: Int = 8): JSONObject = withContext(Dispatchers.IO) {
        require(query.trim().isNotBlank()) { "query must not be blank" }
        val normalized = query.trim().take(240)
        val endpoint = "https://html.duckduckgo.com/html/?q=" + java.net.URLEncoder.encode(normalized, "UTF-8")
        val html = httpGet(endpoint, 2_000_000)
        val results = JSONArray()
        val cards = Regex("(?is)<div[^>]+class=\\\"[^\\\"]*result[^\\\"]*results_links[^\\\"]*\\\"[^>]*>(.*?)</div>\\s*</div>")
            .findAll(html)
            .map { it.groupValues[1] }
            .toList()
        val fallbackTitles = Regex("(?is)<a[^>]+class=\\\"result__a\\\"[^>]*href=\\\"([^\\\"]+)\\\"[^>]*>(.*?)</a>")
            .findAll(html)
            .toList()
        val fallbackSnippets = Regex("(?is)<a[^>]+class=\\\"result__snippet[^\\\"]*\\\"[^>]*>(.*?)</a>")
            .findAll(html)
            .map { cleanHtml(it.groupValues[1]) }
            .toList()

        if (cards.isNotEmpty()) {
            cards.take(maxResults.coerceIn(1, 12)).forEach { card ->
                val m = Regex("(?is)<a[^>]+class=\\\"result__a\\\"[^>]*href=\\\"([^\\\"]+)\\\"[^>]*>(.*?)</a>").find(card)
                val href = m?.groupValues?.getOrNull(1)?.let(::decodeRedirect)
                val title = m?.groupValues?.getOrNull(2)?.let(::cleanHtml).orEmpty()
                val snippet = Regex("(?is)class=\\\"result__snippet[^>]*>(.*?)</a>").find(card)?.groupValues?.getOrNull(1)?.let(::cleanHtml).orEmpty()
                if (!href.isNullOrBlank() && title.isNotBlank()) {
                    results.put(JSONObject().put("title", title).put("url", href).put("snippet", snippet))
                }
            }
        }
        if (results.length() == 0) {
            fallbackTitles.take(maxResults.coerceIn(1, 12)).forEachIndexed { index, m ->
                val href = decodeRedirect(m.groupValues[1])
                val title = cleanHtml(m.groupValues[2])
                if (href.isNotBlank() && title.isNotBlank()) {
                    results.put(JSONObject().put("title", title).put("url", href).put("snippet", fallbackSnippets.getOrNull(index).orEmpty()))
                }
            }
        }

        JSONObject()
            .put("ok", results.length() > 0)
            .put("query", normalized)
            .put("engine", "duckduckgo_html_in_app")
            .put("results", results)
            .put("evidence", if (results.length() > 0) "fresh in-app web search results" else "search completed with no parsed results")
    }

    suspend fun open(url: String, maxChars: Int = 12000): JSONObject = withContext(Dispatchers.IO) {
        val safeUrl = validateUrl(url)
        val body = httpGet(safeUrl, 2_000_000)
        val text = cleanHtml(body).replace(Regex("\\s+"), " ").trim()
        JSONObject()
            .put("ok", text.isNotBlank())
            .put("url", safeUrl)
            .put("content", text.take(maxChars.coerceIn(1000, 30000)))
            .put("evidence", "fresh in-app web page fetch")
    }

    private fun httpGet(url: String, maxBytes: Int, maxRedirects: Int = 4): String {
        var current = validateUrl(url)
        var redirects = 0
        while (true) {
            validateUrl(current)
            val connection = (URL(current).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 12000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", "AI-Coder-GameForge/7.1 (in-app research)")
                setRequestProperty("Accept", "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5")
            }
            try {
                val code = connection.responseCode
                if (code in 300..399) {
                    val location = connection.getHeaderField("Location")
                        ?: throw IllegalStateException("HTTP redirect without Location")
                    require(redirects < maxRedirects) { "Too many redirects" }
                    val resolved: URI = URI(current).resolve(location)
                    current = validateUrl(resolved.toString())
                    redirects++
                    continue
                }
                if (code !in 200..299) throw IllegalStateException("HTTP $code")
                val input = connection.inputStream
                val reader = BufferedReader(InputStreamReader(input, StandardCharsets.UTF_8))
                val out = StringBuilder(minOf(maxBytes, 64 * 1024))
                val buf = CharArray(8192)
                while (true) {
                    val n = reader.read(buf)
                    if (n <= 0) break
                    val room = maxBytes - out.length
                    if (room <= 0) break
                    out.append(buf, 0, minOf(n, room))
                }
                return out.toString()
            } finally {
                connection.disconnect()
            }
        }
    }

    private fun validateUrl(raw: String): String {
        val uri = URI(raw.trim())
        require(uri.userInfo == null) { "URL credentials are not allowed" }
        require(uri.scheme.equals("https", true) || uri.scheme.equals("http", true)) { "Only HTTP(S) URLs are allowed" }
        require(uri.port == -1 || uri.port == 80 || uri.port == 443) { "Non-standard research ports are blocked" }
        val host = uri.host?.lowercase()?.trim('.') ?: throw IllegalArgumentException("URL host is missing")
        require(host != "localhost" && !host.endsWith(".local")) { "Local hosts are not allowed for web research" }
        val addresses = runCatching { InetAddress.getAllByName(host).toList() }.getOrElse { emptyList() }
        require(addresses.none { address ->
            address.isAnyLocalAddress || address.isLoopbackAddress || address.isLinkLocalAddress ||
                address.isSiteLocalAddress || address.isMulticastAddress
        }) { "Private/local network hosts are blocked" }
        return uri.toString()
    }

    private fun decodeRedirect(raw: String): String {
        val href = cleanHtml(raw)
        val u = runCatching { URI(href) }.getOrNull()
        val query = u?.rawQuery.orEmpty()
        val uddg = query.split('&').firstOrNull { it.startsWith("uddg=") }?.substringAfter('=')
        return if (uddg != null) runCatching { URLDecoder.decode(uddg, "UTF-8") }.getOrDefault(href) else href
    }

    private fun cleanHtml(raw: String): String {
        return decodeEntities(raw
            .replace(Regex("(?is)<script[^>]*>.*?</script>"), " ")
            .replace(Regex("(?is)<style[^>]*>.*?</style>"), " ")
            .replace(Regex("(?is)<[^>]+>"), " ")
        )
    }

    private fun decodeEntities(input: String): String {
        return input
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace(Regex("&#x([0-9a-fA-F]+);")) { m ->
                m.groupValues[1].toIntOrNull(16)?.toChar()?.toString() ?: m.value
            }
            .replace(Regex("&#([0-9]+);")) { m ->
                m.groupValues[1].toIntOrNull()?.toChar()?.toString() ?: m.value
            }
    }
}
