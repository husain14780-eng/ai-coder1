package com.husain.aicoder.quality

import com.husain.aicoder.agent.ToolExecutor
import org.json.JSONArray
import org.json.JSONObject
import java.util.Random

/**
 * Deterministic 96-case internal QA matrix. Every row is a real tool call: no synthetic
 * pass-through cases are inserted into the score.
 */
class MassiveQASuite(private val tools: ToolExecutor) {
    suspend fun run(iterations: Int = 12, seed: Long = 0x4F7E9A11L): JSONObject {
        val scenarioCount = 8
        val rng = Random(seed)
        val cases = JSONArray()
        var passed = 0
        var executed = 0
        var boots = 0
        var actionPasses = 0
        var actionTotal = 0
        val failureSignatures = linkedSetOf<String>()

        suspend fun check(id: String, result: JSONObject, category: String): Boolean {
            val ok = result.optBoolean("ok", false)
            cases.put(caseRow(id, category, ok, result))
            executed++
            if (ok) passed++ else failureSignatures += signature(result)
            return ok
        }

        val load = tools.execute("run_generated_game", JSONObject().put("main_scene", "main.tscn"))
        check("load", load, "lifecycle")

        repeat(scenarioCount) { scenario ->
            val boot = tools.execute("run_godot_test", JSONObject())
            if (check("boot_$scenario", boot, "boot")) boots++
            for (step in 0 until 5) {
                val action = actionFor(step, scenario, rng)
                val row = tools.execute("game_action", action.put("settle_ms", 70))
                val ok = check("s${scenario}_a$step", row, "action")
                actionTotal++
                if (ok) actionPasses++
            }
        }

        // 12 structural/system checks: these catch failures that runtime-only tests miss.
        val systemChecks = listOf(
            "run_godot_test" to JSONObject(),
            "validate_2d_assets" to JSONObject(),
            "inspect_project_graph" to JSONObject(),
            "profile_project" to JSONObject(),
            "analyze_visual_quality" to JSONObject(),
            "analyze_change_impact" to JSONObject().put("changed_paths", JSONArray(listOf("main.tscn", "GAME_SPEC.json"))),
            "read_game_spec" to JSONObject(),
            "list_checkpoints" to JSONObject(),
            "plan_mmorpg_world" to JSONObject(),
            "audit_asset_pipeline" to JSONObject(),
            "get_last_observation" to JSONObject(),
            "write_project_graph" to JSONObject()
        )
        for ((tool, args) in systemChecks) {
            val row = tools.execute(tool, args)
            check("system_$tool", row, "system")
        }

        // 12 contract probes complete the matrix to exactly 96 executed cases.
        val contractChecks = listOf(
            "search_workspace_for_project" to JSONObject().put("query", "project.godot"),
            "search_workspace_for_game_spec" to JSONObject().put("query", "GAME_SPEC"),
            "search_workspace_for_world" to JSONObject().put("query", "WORLD_PLAN"),
            "search_workspace_for_assets" to JSONObject().put("query", "ASSET_MANIFEST"),
            "hash_version_file" to JSONObject().put("path", "GAME_SPEC.json"),
            "read_world_plan" to JSONObject().put("path", "gameforge/WORLD_PLAN.json"),
            "read_asset_report" to JSONObject().put("path", "gameforge/ASSET_QUALITY_REPORT.json"),
            "route_model_contract" to JSONObject().put("task", "qa").put("prompt", "QA regression routing contract").put("risk", 0.75).put("evidence", true),
            "vision_contract" to JSONObject(),
            "research_contract" to JSONObject(),
            "get_last_observation_contract" to JSONObject(),
            "read_apex_plan_contract" to JSONObject().put("path", "gameforge/APEX_PLAN.json")
        )
        for ((id, args) in contractChecks) {
            val row = when (id) {
                "search_workspace_for_project", "search_workspace_for_game_spec", "search_workspace_for_world", "search_workspace_for_assets" -> {
                    val query = args.getString("query")
                    val matches = tools.execute("search_text", JSONObject().put("query", query))
                    JSONObject(matches.toString()).put("ok", matches.optBoolean("ok") && (matches.optJSONArray("matches")?.length() ?: 0) > 0)
                }
                "hash_version_file" -> tools.execute("hash_file", args)
                "route_model_contract" -> tools.execute("route_model", args)
                "vision_contract" -> tools.execute("get_local_vision_status", args)
                "research_contract" -> tools.execute("get_research_status", args)
                "get_last_observation_contract" -> tools.execute("get_last_observation", args)
                else -> tools.execute("read_file", args)
            }
            check("contract_$id", row, "contract")
        }

        // Exact matrix target: 1 load + 8*(1 boot+5 actions) + 12 system + 12 contract + 23 genuine fuzz replays = 96.
        while (executed < 96) {
            val n = executed
            val action = actionFor(n % ACTIONS.size, n / ACTIONS.size, rng)
            val row = tools.execute("game_action", action.put("settle_ms", 60))
            val ok = check("fuzz_replay_$n", row, "fuzz")
            actionTotal++
            if (ok) actionPasses++
        }

        val passRate = if (executed == 0) 0.0 else passed.toDouble() / executed
        val bootRate = boots.toDouble() / scenarioCount
        val critical = casesFailureCount(cases, setOf("lifecycle", "boot"))
        val result = JSONObject()
            .put("ok", executed == 96 && load.optBoolean("ok") && bootRate >= 0.875 && passRate >= 0.90 && critical == 0)
            .put("suite", "GameForge Massive QA 7.1 Internal")
            .put("seed", seed)
            .put("scenario_count", scenarioCount)
            .put("logical_case_count", executed)
            .put("real_executed_case_count", executed)
            .put("passed", passed)
            .put("failed", executed - passed)
            .put("pass_rate", passRate)
            .put("successful_boots", boots)
            .put("boot_rate", bootRate)
            .put("action_total", actionTotal)
            .put("action_passes", actionPasses)
            .put("action_pass_rate", if (actionTotal == 0) 0.0 else actionPasses.toDouble() / actionTotal)
            .put("critical_failure_count", critical)
            .put("failure_signatures", JSONArray(failureSignatures.take(40)))
            .put("load", load)
            .put("cases", cases)
            .put("fuzz", JSONObject().put("deterministic_rng", true).put("action_space", JSONArray(ACTIONS)))
            .put("coverage", JSONObject()
                .put("real_cases", executed)
                .put("categories", JSONArray(listOf("lifecycle", "boot", "action", "system", "contract", "fuzz")))
                .put("internal_contracts", JSONArray(listOf("vision", "research", "model_routing", "world_plan", "asset_pipeline")))
                .put("device_automation_used", false)
                .put("external_browser_used", false))
            .put("generated_at_ms", System.currentTimeMillis())
        return result
    }

    private fun actionFor(step: Int, scenario: Int, rng: Random): JSONObject {
        val action = JSONObject(ACTIONS[(step + scenario) % ACTIONS.size].toString())
        if (action.optString("type") == "move") {
            action.put("x", (rng.nextDouble() * 2.0 - 1.0).coerceIn(-1.0, 1.0))
            action.put("y", (rng.nextDouble() * 2.0 - 1.0).coerceIn(-1.0, 1.0))
        }
        return action
    }

    private fun caseRow(id: String, category: String, ok: Boolean, result: JSONObject): JSONObject = JSONObject()
        .put("id", id)
        .put("category", category)
        .put("ok", ok)
        .put("evidence", result.optString("evidence", result.optString("error", "")))
        .put("result", result)

    private fun signature(result: JSONObject): String = result.optString("error", result.optString("evidence", "unknown_failure"))
        .trim().lowercase().replace(Regex("\\d+"), "#").take(180)

    private fun casesFailureCount(cases: JSONArray, categories: Set<String>): Int {
        var count = 0
        for (i in 0 until cases.length()) {
            val row = cases.optJSONObject(i) ?: continue
            if (row.optString("category") in categories && !row.optBoolean("ok")) count++
        }
        return count
    }

    companion object {
        private val ACTIONS = listOf(
            JSONObject().put("type", "move").put("x", 0.8).put("y", 0.0).put("jump", false),
            JSONObject().put("type", "move").put("x", -0.8).put("y", 0.0).put("jump", false),
            JSONObject().put("type", "move").put("x", 0.0).put("y", 0.8).put("jump", false),
            JSONObject().put("type", "move").put("x", 0.0).put("y", -0.8).put("jump", false),
            JSONObject().put("type", "jump").put("x", 0.45).put("y", 0.0).put("jump", true),
            JSONObject().put("type", "attack"),
            JSONObject().put("type", "skill"),
            JSONObject().put("type", "dodge"),
            JSONObject().put("type", "interact"),
            JSONObject().put("type", "bot_test")
        )
    }
}
