package com.husain.aicoder.version

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** Durable version/checkpoint metadata layered on top of the safe workspace snapshots. */
class VersionCheckpointSystem(private val workspace: CodingWorkspace, private val maxVersions: Int = 30) {
    private val root = File(workspace.root.parentFile, "versions").apply { mkdirs() }
    private val indexFile = File(root, "index.json")

    @Synchronized
    fun create(label: String, reason: String, tags: List<String> = emptyList()): JSONObject {
        val safe = label.replace(Regex("[^A-Za-z0-9_.-]+"), "_").take(70).ifBlank { "checkpoint" }
        val snapshot = workspace.checkpoint("version_$safe")
        val manifest = manifest()
        val id = snapshot.name
        val record = JSONObject()
            .put("id", id)
            .put("label", safe)
            .put("reason", reason.take(1500))
            .put("snapshot", snapshot.name)
            .put("tags", JSONArray(tags.distinct().take(20)))
            .put("manifest_sha256", manifest.digest)
            .put("file_count", manifest.count)
            .put("created_at_ms", System.currentTimeMillis())
            .put("status", "pending")
        val versions = readIndex()
        versions.put(record)
        prune(versions)
        writeIndex(versions)
        return record
    }

    @Synchronized
    fun mark(id: String, status: String, score: Double? = null, note: String = "") {
        val versions = readIndex()
        for (i in 0 until versions.length()) {
            val row = versions.optJSONObject(i) ?: continue
            if (row.optString("id") == id) {
                row.put("status", status)
                row.put("updated_at_ms", System.currentTimeMillis())
                if (score != null) row.put("score", score)
                if (note.isNotBlank()) row.put("note", note.take(2000))
                break
            }
        }
        writeIndex(versions)
    }

    @Synchronized
    fun restore(id: String): JSONObject {
        val versions = readIndex()
        val row = (0 until versions.length()).asSequence().mapNotNull { versions.optJSONObject(it) }.firstOrNull { it.optString("id") == id }
            ?: return JSONObject().put("ok", false).put("error", "version not found").put("id", id)
        val restored = workspace.restoreCheckpoint(row.optString("snapshot"))
        if (restored) mark(id, "restored")
        return JSONObject().put("ok", restored).put("id", id).put("snapshot", row.optString("snapshot"))
    }

    @Synchronized
    fun list(): JSONArray = JSONArray(readIndex().toString())

    @Synchronized
    fun markStable(id: String, score: Double, note: String = "") {
        val versions = readIndex()
        for (i in 0 until versions.length()) {
            val row = versions.optJSONObject(i) ?: continue
            if (row.optString("status") == "stable") row.put("status", "superseded")
        }
        for (i in 0 until versions.length()) {
            val row = versions.optJSONObject(i) ?: continue
            if (row.optString("id") == id) {
                row.put("status", "stable").put("score", score).put("updated_at_ms", System.currentTimeMillis())
                if (note.isNotBlank()) row.put("note", note.take(2000))
                break
            }
        }
        writeIndex(versions)
    }

    @Synchronized
    fun latest(): JSONObject? {
        val versions = readIndex()
        return if (versions.length() == 0) null else versions.optJSONObject(versions.length() - 1)?.let { JSONObject(it.toString()) }
    }

    @Synchronized
    fun latestStable(): JSONObject? {
        val versions = readIndex()
        for (i in versions.length() - 1 downTo 0) {
            val row = versions.optJSONObject(i) ?: continue
            if (row.optString("status") in setOf("stable", "accepted")) return JSONObject(row.toString())
        }
        return null
    }

    fun summary(): JSONObject = JSONObject().put("versions", list()).put("latest_stable", latestStable() ?: JSONObject())

    private data class ManifestDigest(val digest: String, val count: Int)

    private fun manifest(): ManifestDigest {
        val md = MessageDigest.getInstance("SHA-256")
        var count = 0
        workspace.listAllFiles(30000).sorted().forEach { path ->
            val hash = workspace.sha256(path)
            md.update(path.toByteArray(Charsets.UTF_8))
            md.update(0.toByte())
            md.update(hash.toByteArray(Charsets.UTF_8))
            md.update('\n'.code.toByte())
            count++
        }
        return ManifestDigest(
            md.digest().joinToString("") { "%02x".format(it) },
            count
        )
    }

    private fun readIndex(): JSONArray = if (!indexFile.isFile) JSONArray() else runCatching { JSONArray(indexFile.readText()) }.getOrElse { JSONArray() }
    private fun writeIndex(index: JSONArray) { indexFile.writeText(index.toString(2)) }

    private fun prune(index: JSONArray) {
        while (index.length() > maxVersions) {
            index.remove(0)
        }
    }

    private fun digest(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
