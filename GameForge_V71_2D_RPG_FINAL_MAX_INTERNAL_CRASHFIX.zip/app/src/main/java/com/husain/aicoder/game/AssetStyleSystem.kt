package com.husain.aicoder.game

import org.json.JSONArray
import org.json.JSONObject

/** Shared visual language for AI-directed generated assets. */
class AssetStyleSystem {
    fun styleBook(spec: GameSpec): JSONObject {
        val is2D = spec.camera.contains("2d", true) || spec.genre.contains("rpg", true) || spec.genre.contains("mmorpg", true)
        val seed = spec.title.hashCode()
        return JSONObject()
            .put("style_id", "gameforge_v71_${spec.genre}_${spec.camera}")
            .put("render_mode", if (is2D) "2d" else "3d")
            .put("art_direction", if (is2D) JSONArray(listOf(
                "readable RPG silhouettes",
                "pixel-inspired crisp geometry",
                "high contrast character separation",
                "consistent outline weight",
                "animation readability at mobile scale",
                "AI-selected variations must remain within the style contract"
            )) else JSONArray())
            .put("palette_policy", "deterministic_palette_from_game_seed")
            .put("texture_policy", if (is2D) "runtime_png_plus_editable_svg_source" else "procedural_or_imported")
            .put("default_sprite_size", 64)
            .put("default_directions", if (is2D && spec.camera.contains("top_down", true)) 8 else 4)
            .put("default_animation_frames", 6)
            .put("default_animation_fps", 12)
            .put("generation_policy", JSONArray(listOf(
                "no_fixed_shipped_character_art",
                "AI_directed_request_then_factory_render",
                "seeded_reproducibility",
                "validate_before_gameplay",
                "bot_playtest_after_visual_generation"
            )))
            .put("game_seed_hint", seed)
            .put("generated_at_ms", System.currentTimeMillis())
    }
}
