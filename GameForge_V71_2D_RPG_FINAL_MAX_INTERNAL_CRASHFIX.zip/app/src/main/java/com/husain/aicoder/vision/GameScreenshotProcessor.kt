package com.husain.aicoder.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlin.math.ceil
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max

/**
 * Handles screenshots emitted by the embedded Godot runtime.
 *
 * A screenshot is intentionally ephemeral: decode -> analyze -> enrich the observation ->
 * delete the image. No persistent game screenshots are kept by the normal GameForge path.
 */
class GameScreenshotProcessor(private val context: Context) {
    private val vision = LocalGameVisionEngine()

    fun resetTemporalState() = vision.resetTemporalState()

    fun status(): JSONObject = JSONObject()
        .put("ok", true)
        .put("backend", LocalGameVisionEngine.MODEL_ID)
        .put("source", "embedded_godot_viewport")
        .put("device_capture", false)
        .put("external_browser", false)
        .put("raw_frame_persistence", false)
        .put("ephemeral_frame_policy", "decode_analyze_delete")

    @Synchronized
    fun processObservation(input: JSONObject): JSONObject {
        val output = JSONObject(input.toString())
        val rawPath = output.optString("screenshot_path").trim()
        if (rawPath.isBlank()) return output.put("screenshot_lifecycle", "no_image")

        val file = File(rawPath)
        output.put("screenshot_ephemeral", true)
        output.put("screenshot_size_bytes", if (file.isFile) file.length() else 0L)

        if (!isAllowedGodotObservation(file)) {
            output.put("screenshot_lifecycle", "screenshot_path_rejected")
                .put("vision_summary", JSONObject().put("available", false).put("reason", "screenshot_path_not_ephemeral_godot_observation"))
            output.remove("screenshot_path")
            return output
        }
        if (!file.isFile) {
            output.put("screenshot_lifecycle", "missing")
                .put("vision_summary", JSONObject().put("available", false).put("reason", "screenshot_missing"))
            output.remove("screenshot_path")
            return output
        }

        val bitmap = runCatching { decodeBounded(file) }.getOrNull()
        if (bitmap == null) {
            return cleanupRejected(output, file, "bitmap_decode_failed")
        }

        try {
            val metrics = vision.analyze(bitmap, output)
            val summary = buildVisualSummary(bitmap, metrics)
            output.put("vision_summary", summary)
            output.put("local_vision", metrics)
            output.put("screenshot_width", bitmap.width)
            output.put("screenshot_height", bitmap.height)
        } finally {
            bitmap.recycle()
            val deleted = runCatching { file.delete() }.getOrDefault(false)
            output.put("screenshot_deleted", deleted || !file.exists())
            output.remove("screenshot_path")
            output.put("screenshot_lifecycle", if (deleted || !file.exists()) "decoded_and_deleted" else "decoded_delete_failed")
        }
        return output
    }

    fun cleanupKnownObservationPath(input: JSONObject): JSONObject = processObservation(input)

    /** Safely drops a stale embedded-Godot ephemeral frame without invoking pixel decoding. */
    fun discardEphemeralFrame(path: String) {
        val file = File(path)
        if (isAllowedGodotObservation(file) && file.isFile) {
            runCatching { file.delete() }
        }
    }

    private fun decodeBounded(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        val maxWidth = 512
        val maxHeight = 288
        val widthScale = bounds.outWidth.toDouble() / maxWidth
        val heightScale = bounds.outHeight.toDouble() / maxHeight
        val scale = maxOf(1.0, widthScale, heightScale)
        val sample = 1 shl ceil(kotlin.math.log2(scale)).toInt().coerceAtLeast(0)

        val options = BitmapFactory.Options().apply {
            inSampleSize = sample.coerceAtLeast(1)
            inPreferredConfig = Bitmap.Config.RGB_565
            inDither = true
        }
        return BitmapFactory.decodeFile(file.absolutePath, options)
    }

    private fun cleanupRejected(output: JSONObject, file: File, reason: String): JSONObject {
        runCatching {
            if (isAllowedGodotObservation(file) && file.isFile) file.delete()
        }
        output.put("screenshot_lifecycle", reason)
            .put("vision_summary", JSONObject().put("available", false).put("reason", reason))
        output.remove("screenshot_path")
        return output
    }

    private fun isAllowedGodotObservation(file: File): Boolean {
        val appData = File(context.applicationInfo.dataDir).canonicalFile
        val candidate = runCatching { file.canonicalFile }.getOrNull() ?: return false
        if (!(candidate.path == appData.path || candidate.path.startsWith(appData.path + File.separator))) return false
        val parent = candidate.parentFile ?: return false
        return parent.name == "observations" && candidate.name.startsWith("ephemeral_") && candidate.extension.equals("jpg", true)
    }

    private fun buildVisualSummary(bitmap: Bitmap, metrics: JSONObject): JSONObject {
        val gridW = 24
        val gridH = max(10, (gridW * bitmap.height.toDouble() / bitmap.width.coerceAtLeast(1)).toInt())
        val grid = StringBuilder(gridW * (gridH + 1))
        val ramp = " .:-=+*#%@"
        for (gy in 0 until gridH) {
            for (gx in 0 until gridW) {
                val x = ((gx + 0.5) * bitmap.width / gridW).toInt().coerceIn(0, bitmap.width - 1)
                val y = ((gy + 0.5) * bitmap.height / gridH).toInt().coerceIn(0, bitmap.height - 1)
                val p = bitmap.getPixel(x, y)
                val lum = (0.2126 * android.graphics.Color.red(p) +
                    0.7152 * android.graphics.Color.green(p) +
                    0.0722 * android.graphics.Color.blue(p)) / 255.0
                val idx = (lum * (ramp.length - 1)).toInt().coerceIn(0, ramp.length - 1)
                grid.append(ramp[idx])
            }
            grid.append('\n')
        }
        return JSONObject()
            .put("available", true)
            .put("backend", metrics.optString("backend", "embedded_godot_ephemeral_pixels"))
            .put("scene", metrics.optJSONObject("scene") ?: JSONObject())
            .put("objects", metrics.optJSONArray("objects") ?: JSONArray())
            .put("hud", metrics.optJSONObject("hud") ?: JSONObject())
            .put("quality", metrics.optJSONObject("quality") ?: JSONObject())
            .put("confidence", metrics.optDouble("confidence", 0.0))
            .put("mean_luminance", metrics.optDouble("mean_luminance", -1.0))
            .put("edge_density", metrics.optDouble("edge_density", -1.0))
            .put("motion_similarity", metrics.optDouble("motion_similarity", -1.0))
            .put("motion_delta", metrics.optDouble("motion_delta", -1.0))
            .put("ascii_luminance_grid", grid.toString().trimEnd())
            .put("instruction", "This compact grid is a visual cue derived from the embedded Godot game viewport; use it with structured game state and test evidence.")
    }
}
