package com.husain.aicoder.game

import org.json.JSONArray
import org.json.JSONObject

/** AI-directed 2D-first asset contract. The agent can regenerate any row with a new request/seed. */
class AssetPlanner {
    fun manifest(spec: GameSpec): JSONObject {
        val rows = JSONArray()
        fun add(category: String, name: String, generator: String, priority: String, details: JSONObject = JSONObject()) {
            rows.put(JSONObject()
                .put("category", category)
                .put("name", name)
                .put("generator", generator)
                .put("priority", priority)
                .put("generation_mode", "ai_directed_seeded_procedural")
                .put("details", details))
        }

        val is2D = spec.camera.contains("2d", true) || spec.genre.contains("rpg", true) || spec.genre.contains("mmorpg", true)
        if (is2D) {
            add("character", "player", "generate_2d_asset", "P0", JSONObject()
                .put("asset_type", "character")
                .put("directions", 8)
                .put("frame_count", 6)
                .put("fps", 12)
                .put("animations", JSONArray(listOf("idle", "walk", "run", "attack", "cast", "hurt", "death"))))
            spec.enemies.take(8).forEachIndexed { i, e ->
                add("character", "enemy_${i + 1}", "generate_2d_asset", if (i == 0) "P0" else "P1", JSONObject()
                    .put("asset_type", "enemy")
                    .put("display_name", e)
                    .put("art_prompt", e)
                    .put("directions", 4)
                    .put("frame_count", 5)
                    .put("fps", 10)
                    .put("animations", JSONArray(listOf("idle", "walk", "attack", "hurt", "death"))))
            }
            listOf(
                "merchant" to "merchant shopkeeper NPC",
                "questgiver" to "quest giver NPC"
            ).forEach { (name, prompt) ->
                add("npc", name, "generate_2d_asset", "P1", JSONObject()
                    .put("asset_type", "npc")
                    .put("art_prompt", prompt)
                    .put("directions", 4)
                    .put("frame_count", 4)
                    .put("animations", JSONArray(listOf("idle", "walk", "interact"))))
            }
            listOf("world_map", "town_map", "dungeon_map").forEachIndexed { i, name ->
                add("map", name, "generate_2d_map", if (i == 0) "P0" else "P1", JSONObject()
                    .put("width", if (i == 0) 36 else 28)
                    .put("height", if (i == 0) 22 else 18)
                    .put("rooms", if (i == 0) 7 else 4 + i * 2)
                    .put("collision", true)
                    .put("astar_pathfinding", true)
                    .put("goal", true))
            }
            add("tileset", "generated_tiles", "generate_2d_asset", "P1", JSONObject()
                .put("asset_type", "tileset")
                .put("tile_size", 48)
                .put("atlas", true))
            listOf("hit", "slash", "heal", "level_up", "teleport", "fireball").forEach { name ->
                add("vfx", name, "generate_2d_asset", "P1", JSONObject()
                    .put("asset_type", "vfx")
                    .put("frame_count", 10)
                    .put("fps", 18))
            }
            listOf("sword", "armor", "potion", "skill_orb").forEach { name ->
                add("item", name, "generate_2d_asset", "P2", JSONObject().put("asset_type", "item"))
            }
        } else {
            add("player", "player_controller", "procedural_character", "P0")
            spec.enemies.take(8).forEachIndexed { i, e -> add("enemy", "enemy_${i + 1}", "procedural_enemy", if (i == 0) "P0" else "P1", JSONObject().put("display_name", e)) }
            spec.scenes.take(12).forEach { add("scene", it, "godot_scene", "P0") }
            spec.ui.take(12).forEach { add("ui", it, "ui_scene", "P1") }
            spec.audio.take(12).forEach { add("audio", it, "placeholder_or_import", "P2") }
            add("vfx", "hit_feedback", "procedural_particles", "P1")
            add("vfx", "level_feedback", "procedural_particles", "P2")
        }
        return JSONObject()
            .put("generated_by", "GameForge V7 2D RPG Full Game Factory")
            .put("visual_generation", "ai_directed_seeded_procedural")
            .put("is_2d_first", is2D)
            .put("assets", rows)
    }
}
