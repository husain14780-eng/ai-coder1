package com.husain.aicoder.swarm

import com.arm.aichat.GenerationConfig
import com.husain.aicoder.core.HeavyTaskCoordinator
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Model-switching inference wrapper with RAM admission, prompt budgeting and recovery. */
class SwarmInferenceEngine(
    private val base: InferenceEngine,
    private val swarm: LocalModelSwarmManager,
    private val router: SwarmTaskRouter,
    private val learning: SwarmLearningManager
) : InferenceEngine {
    @Volatile private var loadedId: String? = null
    @Volatile private var loadedPath: String? = null
    @Volatile private var manualProfileId: String? = null
    @Volatile private var adapterPath: String? = null
    @Volatile private var adapterScale: Float = 1.0f
    @Volatile private var adapterBasePath: String? = null
    @Volatile private var adapterLoadedForPath: String? = null
    private val modelMutex = Mutex()

    override val state get() = base.state

    override suspend fun loadModel(pathToModel: String, contextSize: Int, threads: Int, batchSize: Int) = HeavyTaskCoordinator.run("model:load") {
        modelMutex.withLock {
            val profile = LocalModelCatalog.matchFileName(java.io.File(pathToModel).name)
            val snapshot = swarm.deviceSnapshot()
            val safeContext = profile?.let { swarm.contextFor(it, snapshot.availableRamMb) } ?: contextSize.coerceIn(2048, 6144)
            if (snapshot.lowMemory) error("Android reports low physical memory; model load postponed")
            base.loadModel(pathToModel, safeContext, safeThreads(threads), safeBatch(batchSize, safeContext))
            loadedPath = pathToModel
            loadedId = profile?.id
            adapterLoadedForPath = null
            if (adapterPath != null && adapterBasePath == pathToModel) {
                base.loadLoraAdapter(adapterPath!!, adapterScale)
                adapterLoadedForPath = pathToModel
            }
        }
    }

    override suspend fun setSystemPrompt(systemPrompt: String) = base.setSystemPrompt(systemPrompt)

    override suspend fun loadLoraAdapter(path: String, scale: Float) = HeavyTaskCoordinator.run("model:adapter") { modelMutex.withLock {
        base.loadLoraAdapter(path, scale)
        adapterPath = path
        adapterScale = scale
        adapterBasePath = loadedPath
        adapterLoadedForPath = loadedPath
    } }

    override suspend fun clearLoraAdapter() = HeavyTaskCoordinator.run("model:adapter-clear") { modelMutex.withLock {
        base.clearLoraAdapter()
        adapterPath = null
        adapterScale = 1.0f
        adapterBasePath = null
        adapterLoadedForPath = null
    } }

    override fun sendUserPrompt(message: String, config: GenerationConfig): Flow<String> = flow {
        HeavyTaskCoordinator.run("model:generate") {
            modelMutex.withLock {
            require(message.isNotBlank())
            val decision = runCatching {
                manualProfileId?.let { id ->
                    LocalModelCatalog.byId(id)?.let { p -> swarm.installedProfile(p.id)?.let { SwarmTaskRouter.Decision("manual", p, "manual model") } }
                } ?: router.decide(message)
            }.getOrElse { throw IllegalStateException("Local model swarm has no usable installed specialist: ${it.message}", it) }

            var installed = swarm.installedProfile(decision.profile.id)
                ?: error("Model ${decision.profile.displayName} is not installed")
            val snap = swarm.deviceSnapshot()
            val alreadyLoaded = loadedId == decision.profile.id && loadedPath == installed.file.absolutePath
            if (!swarm.canAutoLoad(decision.profile, allowHeavy = true) && !alreadyLoaded) {
                installed = swarm.bestFallbackFor(decision.profile.roles, allowHeavy = false)
                    ?: error("Model ${decision.profile.displayName} rejected by RAM guard and no fallback is installed")
            }

            if (loadedId != installed.profile.id || loadedPath != installed.file.absolutePath) {
                base.cleanUp()
                loadedId = null
                loadedPath = null
                val context = swarm.contextFor(installed.profile, swarm.deviceSnapshot().availableRamMb)
                val loadResult = runCatching { base.loadModel(installed.file.absolutePath, context, safeThreads(0), safeBatch(256, context)) }
                if (loadResult.isFailure) {
                    val fallback = swarm.bestFallbackFor(installed.profile.roles, allowHeavy = false)
                    if (fallback == null || fallback.file.absolutePath == installed.file.absolutePath) {
                        throw loadResult.exceptionOrNull()!!
                    }
                    base.cleanUp()
                    val fallbackContext = swarm.contextFor(fallback.profile, swarm.deviceSnapshot().availableRamMb)
                    base.loadModel(fallback.file.absolutePath, fallbackContext, safeThreads(0), safeBatch(256, fallbackContext))
                    installed = fallback
                }
                loadedId = installed.profile.id
                loadedPath = installed.file.absolutePath
            }

            if (adapterPath != null && adapterLoadedForPath != loadedPath && adapterBasePath == loadedPath) {
                base.loadLoraAdapter(adapterPath!!, adapterScale)
                adapterLoadedForPath = loadedPath
            }

            val started = System.currentTimeMillis()
            val budgeted = PromptBudgeter.fit(message, installed.profile.contextTokens)
            val maxTokens = PromptBudgeter.outputBudget(budgeted, installed.profile.contextTokens, config.maxTokens, installed.profile.maxOutputTokens)
            val full = StringBuilder()
            try {
                base.sendUserPrompt(budgeted, config.copy(maxTokens = maxTokens)).collect { token ->
                    full.append(token)
                    emit(token)
                }
                learning.record(decision.task, loadedId ?: installed.profile.id, success = full.isNotBlank(), quality = qualityHeuristic(full.toString()), latencyMs = System.currentTimeMillis() - started)
            } catch (t: Throwable) {
                learning.record(decision.task, loadedId ?: installed.profile.id, success = false, quality = 0.0, latencyMs = System.currentTimeMillis() - started)
                throw t
                }
            }
        }
    }

    fun setManualProfile(id: String?) { manualProfileId = id }
    fun activeProfileId(): String? = loadedId
    fun clearManualProfile() { manualProfileId = null }

    override fun abort() = base.abort()
    override fun modelInfo(): String = base.modelInfo()
    override fun cleanUp() { base.cleanUp(); loadedId = null; loadedPath = null; adapterLoadedForPath = null }
    override fun destroy() = base.destroy()

    private fun safeThreads(requested: Int): Int {
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)
        return if (requested > 0) requested.coerceIn(2, 6) else (cores - 1).coerceIn(2, 6)
    }

    private fun safeBatch(requested: Int, contextSize: Int): Int {
        val requestedSafe = requested.coerceIn(128, 512)
        return when {
            contextSize >= 6144 -> minOf(requestedSafe, 256)
            contextSize >= 4096 -> minOf(requestedSafe, 256)
            else -> minOf(requestedSafe, 192)
        }
    }

    private fun qualityHeuristic(text: String): Double {
        if (text.isBlank()) return 0.0
        var s = 0.35
        if (text.length > 160) s += 0.15
        if (text.contains("<tool_call>") || text.contains("```")) s += 0.15
        if (text.contains("test", ignoreCase = true) || text.contains("verify", ignoreCase = true)) s += 0.15
        if (text.length > 700) s += 0.10
        return s.coerceIn(0.0, 1.0)
    }
}

private object PromptBudgeter {
    fun fit(prompt: String, contextTokens: Int): String {
        val charBudget = (contextTokens * 3.4).toInt().coerceAtLeast(6000)
        if (prompt.length <= charBudget) return prompt
        val head = (charBudget * 0.74).toInt()
        val tail = charBudget - head - 180
        return prompt.take(head) + "\n\n[CONTEXT COMPACTED BY GAMEFORGE V7]\n\n" + prompt.takeLast(tail.coerceAtLeast(500))
    }

    fun outputBudget(prompt: String, contextTokens: Int, requested: Int, profileMax: Int): Int {
        val approxPromptTokens = (prompt.length / 3.4).toInt()
        val remaining = (contextTokens - approxPromptTokens - 256).coerceAtLeast(256)
        return minOf(requested.coerceAtLeast(16), profileMax, remaining).coerceAtLeast(16)
    }
}
