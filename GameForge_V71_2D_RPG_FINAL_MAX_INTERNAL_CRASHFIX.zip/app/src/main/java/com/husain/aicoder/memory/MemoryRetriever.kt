package com.husain.aicoder.memory

import android.content.Context
import org.json.JSONObject
import com.husain.aicoder.core.BoundedFileReader
import java.io.File
import kotlin.math.max

/** Lightweight on-device lexical retrieval; no server or embedding API required. */
class MemoryRetriever(context: Context) {
    private val root = File(context.filesDir, "continuous_learning")
    private val files = listOf("experience.jsonl", "curated_sft.jsonl", "holdout.jsonl")

    fun retrieve(query: String, topK: Int = 6): List<String> {
        val q = tokens(query)
        val limit = topK.coerceIn(1, 24)
        if (q.isEmpty()) return emptyList()
        val best = java.util.PriorityQueue<Pair<Double, String>>(limit) { a, b -> a.first.compareTo(b.first) }
        for (name in files) {
            val f = File(root, name)
            if (!f.isFile) continue
            f.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val bounded = if (line.length > 12000) line.take(12000) else line
                    val text = runCatching { JSONObject(bounded).toString() }.getOrDefault(bounded)
                    val t = tokens(text)
                    if (t.isEmpty()) return@forEach
                    val overlap = q.intersect(t).size.toDouble()
                    val coverage = overlap / q.size
                    val score = coverage * 0.7 + (overlap / max(1, t.size)) * 0.3
                    if (score <= 0.05) return@forEach
                    val row = score to text.take(5000)
                    if (best.size < limit) best.add(row)
                    else if (score > best.peek().first) { best.poll(); best.add(row) }
                }
            }
        }
        return best.toList().sortedByDescending { it.first }.map { it.second }
    }

    private fun tokens(s: String): Set<String> = s.lowercase()
        .split(Regex("[^a-z0-9_+#.-]+"))
        .filter { it.length >= 3 }
        .toSet()
}
