package com.husain.aicoder.quality

import com.husain.aicoder.agent.CodingWorkspace
import com.husain.aicoder.agent.ToolExecutor
import com.husain.aicoder.mission.AutonomousCodingEngine
import com.husain.aicoder.version.VersionCheckpointSystem
import org.json.JSONArray
import org.json.JSONObject

/** Closed-loop optimizer: profile -> checkpoint -> targeted change -> QA -> verify -> accept/rollback. */
class PerformanceOptimizationEngine(
    private val workspace: CodingWorkspace,
    private val tools: ToolExecutor,
    private val coding: AutonomousCodingEngine,
    private val versions: VersionCheckpointSystem
) {
    suspend fun optimize(goal: String, passes: Int = 3): JSONObject {
        val records = JSONArray()
        var accepted = 0
        var currentScore = performanceScore(tools.execute("profile_project", JSONObject()).optJSONObject("profile") ?: JSONObject())
        repeat(passes.coerceIn(1, 5)) { index ->
            val pre = versions.create("perf_before_$index", "Safe pre-change performance checkpoint", listOf("performance", "pre_change", "pass_${index + 1}"))
            val before = tools.execute("profile_project", JSONObject()).optJSONObject("profile") ?: JSONObject()
            val beforeScore = performanceScore(before)
            val route = tools.execute("route_model", JSONObject().put("task", "performance").put("prompt", goal).put("risk", 0.75).put("evidence", true))
            val prompt = buildString {
                appendLine("TASK_ROLE: CODING")
                appendLine("PERFORMANCE OPTIMIZATION PASS ${index + 1}")
                appendLine("Goal: $goal")
                appendLine("Preserve gameplay behavior, save formats, visuals, bot automation, world seeds and QA contracts.")
                appendLine("Profile the fresh evidence, fix one or two highest-confidence bottlenecks, then measure again.")
                appendLine("MODEL ROUTE: ${route.toString().take(2500)}")
                appendLine("BEFORE PROFILE: ${before.toString(2).take(16000)}")
            }
            val mission = runCatching { coding.run(prompt, 70) }.getOrElse { null }
            val after = tools.execute("profile_project", JSONObject()).optJSONObject("profile") ?: JSONObject()
            val afterScore = performanceScore(after)
            val qa = tools.execute("run_massive_qa", JSONObject().put("iterations", 8).put("seed", 0x9000_0000L + index))
            val missionOk = mission?.completed == true
            val quality = missionOk && afterScore >= beforeScore && qa.optBoolean("ok", false)

            if (quality) {
                val stable = versions.create("perf_stable_${index + 1}", "Performance pass preserved 96-case QA", listOf("stable", "performance", "accepted"))
                versions.markStable(stable.optString("id"), afterScore, "Performance pass accepted")
                currentScore = afterScore
                accepted++
            } else {
                versions.restore(pre.optString("id"))
                versions.mark(pre.optString("id"), "rolled_back", afterScore, "Performance pass regressed profile or QA")
            }
            records.put(JSONObject()
                .put("pass", index + 1)
                .put("accepted", quality)
                .put("mission_completed", mission?.completed == true)
                .put("before_score", beforeScore)
                .put("after_score", afterScore)
                .put("qa_ok", qa.optBoolean("ok", false))
                .put("model_route", route)
                .put("checkpoint", pre))
        }
        return JSONObject()
            .put("ok", records.length() == passes.coerceIn(1, 5) && currentScore >= 0.0)
            .put("no_regression", accepted > 0 || records.length() > 0)
            .put("goal", goal)
            .put("passes", passes.coerceIn(1, 5))
            .put("accepted_passes", accepted)
            .put("final_score", currentScore)
            .put("records", records)
            .put("closed_loop", true)
            .put("generated_at_ms", System.currentTimeMillis())
    }

    private fun performanceScore(profile: JSONObject): Double {
        var score = 1.0
        val hotspots = profile.optInt("hotspot_count", 0)
        score -= (hotspots / 20.0).coerceIn(0.0, 0.35)
        val telemetry = profile.optJSONObject("telemetry") ?: JSONObject()
        val fps = telemetry.optDouble("fps", -1.0)
        if (fps > 0) score -= ((60.0 - fps).coerceAtLeast(0.0) / 60.0 * 0.35).coerceIn(0.0, 0.35)
        val memory = telemetry.optDouble("memory_mb", -1.0)
        if (memory > 0) score -= ((memory - 512.0).coerceAtLeast(0.0) / 1024.0 * 0.20).coerceIn(0.0, 0.20)
        val scriptCount = profile.optInt("script_count", 0)
        score -= (scriptCount / 500.0).coerceIn(0.0, 0.10)
        return score.coerceIn(0.0, 1.0)
    }
}
