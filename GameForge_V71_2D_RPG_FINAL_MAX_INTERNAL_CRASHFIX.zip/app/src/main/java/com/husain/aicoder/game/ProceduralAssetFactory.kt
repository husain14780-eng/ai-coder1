package com.husain.aicoder.game

import com.husain.aicoder.agent.CodingWorkspace

/** Legacy 3D helper retained for non-2D builds. V7 RPG/MMORPG generation uses GameForge2DAssetFactory. */
class ProceduralAssetFactory(private val workspace: CodingWorkspace) {
    fun writeHelpers(): String = workspace.write("gameforge/procedural_asset_factory.gd", SCRIPT)

    companion object {
        private const val SCRIPT = """
extends Node
class_name GameForgeProceduralAssetFactory

static func box(parent: Node3D, size: Vector3, material: Material = null) -> MeshInstance3D:
    var mesh := MeshInstance3D.new()
    var primitive := BoxMesh.new()
    primitive.size = size
    mesh.mesh = primitive
    mesh.material_override = material
    parent.add_child(mesh)
    return mesh

static func sphere(parent: Node3D, radius: float, material: Material = null) -> MeshInstance3D:
    var mesh := MeshInstance3D.new()
    var primitive := SphereMesh.new()
    primitive.radius = radius
    primitive.height = radius * 2.0
    mesh.mesh = primitive
    mesh.material_override = material
    parent.add_child(mesh)
    return mesh

static func capsule(parent: Node3D, radius: float, height: float, material: Material = null) -> MeshInstance3D:
    var mesh := MeshInstance3D.new()
    var primitive := CapsuleMesh.new()
    primitive.radius = radius
    primitive.height = height
    mesh.mesh = primitive
    mesh.material_override = material
    parent.add_child(mesh)
    return mesh
"""
    }
}
