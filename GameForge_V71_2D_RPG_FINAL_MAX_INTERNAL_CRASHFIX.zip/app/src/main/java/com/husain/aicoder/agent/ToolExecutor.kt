package com.husain.aicoder.agent

import android.content.Context
import android.os.SystemClock
import com.husain.aicoder.godot.AICoderGodotBridge
import com.husain.aicoder.godot.GodotWorkspacePackager
import com.husain.aicoder.vision.GameScreenshotProcessor
import com.husain.aicoder.web.InAppWebResearch
import com.husain.aicoder.web.MatureResearchAgent
import com.husain.aicoder.router.AdaptiveModelRouter
import com.husain.aicoder.version.VersionCheckpointSystem
import com.husain.aicoder.project.ArchitectureGraph
import com.husain.aicoder.project.ChangeImpactAnalyzer
import com.husain.aicoder.project.ProjectIndexer
import com.husain.aicoder.agent.ToolPolicy
import com.husain.aicoder.core.HeavyTaskCoordinator
import com.husain.aicoder.quality.PerformanceProfiler
import com.husain.aicoder.quality.VisualQualityAnalyzer
import kotlinx.coroutines.delay
import kotlin.coroutines.cancellation.CancellationException
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/** Bounded tool boundary. Every tool returns explicit evidence and never silently claims success. */
class ToolExecutor(
    private val context: Context,
    private val workspace: CodingWorkspace,
    private val godot: AICoderGodotBridge?,
    private val missionContext: () -> String = { "" },
    private val adaptiveRouter: AdaptiveModelRouter? = null
) {
    @Volatile private var lastObservation: JSONObject? = null
    @Volatile private var lastProcessedObservation: JSONObject? = null
    @Volatile private var lastProcessedVersion = -1L
    @Volatile private var processingScreenshotPath: String? = null
    private val observationVersion = AtomicLong(0L)
    private val graph = ArchitectureGraph(workspace)
    private val profiler = PerformanceProfiler(workspace)
    private val visual = VisualQualityAnalyzer(workspace)
    private val impact = ChangeImpactAnalyzer(workspace, graph)
    private val packager = GodotWorkspacePackager(workspace)
    private val runtimeDir = File(workspace.root.parentFile, "gameforge/runtime")
    private val indexer = ProjectIndexer(workspace)
    private val assetFactory2D = com.husain.aicoder.game.GameForge2DAssetFactory(workspace)
    private val gameVision = GameScreenshotProcessor(context)
    private val webResearch = InAppWebResearch()
    private val matureResearch = MatureResearchAgent(webResearch)
    private val assetQuality = com.husain.aicoder.game.AssetQualityPipeline(workspace)
    private val worldPlanner = com.husain.aicoder.game.ProceduralMMORPGWorldPlanner()
    private val massiveQa = com.husain.aicoder.quality.MassiveQASuite(this)
    private val versions = VersionCheckpointSystem(workspace)

    @Synchronized
    fun observe(json: String): String {
        val parsed = runCatching { JSONObject(json) }.getOrNull() ?: return json
        val oldPath = lastObservation?.optString("screenshot_path")?.takeIf { it.isNotBlank() }
        val newPath = parsed.optString("screenshot_path").trim().takeIf { it.isNotBlank() }
        if (oldPath != null && oldPath != newPath && oldPath != processingScreenshotPath) {
            gameVision.discardEphemeralFrame(oldPath)
        }
        parsed.put("tool_observation_version", observationVersion.incrementAndGet())
        lastObservation = parsed
        lastProcessedObservation = null
        lastProcessedVersion = -1L
        return parsed.toString()
    }

    /**
     * Performs pixel/vision work only while the global heavy-task gate is held. This prevents
     * screenshot decoding and analysis from competing with Qwen inference or QA/training.
     */
    private fun processLatestObservation(): JSONObject? {
        val snapshot: Pair<Long, JSONObject>? = synchronized(this) {
            val raw = lastObservation ?: return@synchronized null
            val version = raw.optLong("tool_observation_version", observationVersion.get())
            if (version == lastProcessedVersion && lastProcessedObservation != null) {
                return@synchronized version to JSONObject(lastProcessedObservation.toString())
            }
            processingScreenshotPath = raw.optString("screenshot_path").trim().takeIf { it.isNotBlank() }
            version to JSONObject(raw.toString())
        }
        snapshot ?: return null

        val (version, raw) = snapshot
        val rawScreenshotPath = raw.optString("screenshot_path").trim()
        val processed = runCatching { gameVision.processObservation(raw) }.getOrElse {
            JSONObject(raw.toString()).put(
                "vision_error",
                it.message ?: it::class.java.simpleName
            )
        }
        // Never allow a residual screenshot path to survive a failed/stale vision pass.
        processed.optString("screenshot_path").trim().takeIf { it.isNotBlank() }?.let {
            gameVision.discardEphemeralFrame(it)
            processed.remove("screenshot_path")
        }
        if (version != observationVersion.get() && rawScreenshotPath.isNotBlank()) {
            gameVision.discardEphemeralFrame(rawScreenshotPath)
        }
        processed.put("tool_observation_version", version)
        synchronized(this) {
            if (version == observationVersion.get()) {
                lastObservation = processed
                lastProcessedObservation = processed
                lastProcessedVersion = version
                persistTelemetry(processed)
            }
            processingScreenshotPath = null
        }
        return processed
    }

    private fun observationHealthy(observation: JSONObject?): Boolean {
        if (observation == null) return false
        val errors = observation.optJSONArray("errors")
        if (errors != null && errors.length() > 0) return false
        if (observation.optBoolean("crashed", false)) return false
        if (observation.optBoolean("runtime_error", false)) return false
        return true
    }

    suspend fun execute(name: String, args: JSONObject): JSONObject = HeavyTaskCoordinator.run("tool:$name") {
        try {
            when (name) {
            "claim_script" -> {
                val path = workspace.beginAgentScriptFocus(args.getString("path"))
                val exists = workspace.agentTargetExists(path)
                val out = JSONObject().put("ok", true)
                    .put("path", path)
                    .put("exists", exists)
                    .put("evidence", "single-script coding focus claimed; only this .gd may be edited")
                out.put("baseline_sha256", if (exists) workspace.sha256(path) else "__MISSING__")
                out
            }
            "get_script_focus" -> JSONObject().put("ok", true)
                .put("path", workspace.currentAgentScriptFocus() ?: "")
                .put("evidence", "current Qwen single-script focus")
            "read_file" -> {
                val path = args.getString("path")
                JSONObject().put("ok", true)
                    .put("content", workspace.read(path))
                    .put("path", path)
                    .put("sha256", runCatching { workspace.sha256(path) }.getOrDefault(""))
                    .put("evidence", "fresh bounded file read (head up to 30000 chars)")
            }
            "read_file_range" -> {
                val path = args.getString("path")
                val start = args.optInt("start_char", 0).coerceAtLeast(0)
                val limit = args.optInt("max_chars", 16000).coerceIn(1, 16000)
                JSONObject().put("ok", true)
                    .put("path", path)
                    .put("start_char", start)
                    .put("content", workspace.readRange(path, start, limit))
                    .put("evidence", "fresh bounded file-range read")
            }
            "write_file" -> {
                val path = args.getString("path")
                val content = args.getString("content")
                val isScript = path.endsWith(".gd", ignoreCase = true)
                val focused = workspace.currentAgentScriptFocus()
                if (focused != null) {
                    require(isScript && path.replace('\\', '/').trimStart('/') == focused) {
                        "Edit blocked: focused script is $focused; no other project file may be mutated during the script coding cycle."
                    }
                }
                if (isScript) {
                    require(!workspace.agentTargetExists(path)) {
                        "Existing .gd scripts must not be overwritten wholesale. Use replace_text/append_file on the single focused script."
                    }
                    JSONObject().put("ok", true)
                        .put("path", workspace.agentWrite(path, content))
                        .put("evidence", "new focused .gd script created")
                } else {
                    JSONObject().put("ok", true)
                        .put("path", workspace.write(path, content))
                        .put("evidence", "non-script project file written with no active .gd focus")
                }
            }
            "replace_text" -> {
                val path = args.getString("path")
                val focused = workspace.currentAgentScriptFocus()
                if (focused != null) {
                    require(path.replace('\\', '/').trimStart('/') == focused) {
                        "Edit blocked: focused script is $focused; no other project file may be mutated during the script coding cycle."
                    }
                }
                val result = if (path.endsWith(".gd", ignoreCase = true)) {
                    workspace.agentReplaceText(path, args.getString("old"), args.getString("new"), args.optInt("expected_count", 1))
                } else {
                    workspace.replaceText(path, args.getString("old"), args.getString("new"), args.optInt("expected_count", 1))
                }
                JSONObject().put("ok", true).put("path", result)
                    .put("evidence", if (path.endsWith(".gd", true)) "targeted replacement completed on focused .gd script" else "targeted replacement completed on non-script project file")
            }
            "append_file" -> {
                val path = args.getString("path")
                val focused = workspace.currentAgentScriptFocus()
                if (focused != null) {
                    require(path.replace('\\', '/').trimStart('/') == focused) {
                        "Edit blocked: focused script is $focused; no other project file may be mutated during the script coding cycle."
                    }
                }
                val result = if (path.endsWith(".gd", ignoreCase = true)) {
                    workspace.agentAppend(path, args.getString("content"))
                } else {
                    workspace.append(path, args.getString("content"))
                }
                JSONObject().put("ok", true).put("path", result)
                    .put("evidence", if (path.endsWith(".gd", true)) "file append completed on focused .gd script" else "file append completed on non-script project file")
            }
            "list_files" -> JSONObject().put("ok", true).put("files", JSONArray(workspace.list(args.optString("path", "")))).put("evidence", "fresh workspace listing")
            "search_text" -> JSONObject().put("ok", true).put("matches", JSONArray(workspace.search(args.getString("query"), args.optString("path", "")))).put("evidence", "fresh text search")
            "hash_file" -> JSONObject().put("ok", true).put("sha256", workspace.sha256(args.getString("path"))).put("evidence", "fresh SHA-256")
            "checkpoint" -> {
                require(workspace.currentAgentScriptFocus() == null) {
                    "Cannot checkpoint while a .gd script is focused; finish or abort the current script first."
                }
                JSONObject().put("ok", true)
                    .put("checkpoint", workspace.checkpoint(args.optString("label", "mission")).name)
                    .put("evidence", "workspace checkpoint created with no active script focus")
            }
            "list_checkpoints" -> JSONObject().put("ok", true).put("checkpoints", JSONArray(workspace.listCheckpoints().map { it.name })).put("evidence", "fresh checkpoint list")
            "restore_checkpoint" -> {
                require(workspace.currentAgentScriptFocus() == null) {
                    "Cannot restore a workspace checkpoint while a .gd script is focused; finish or abort the current script first."
                }
                JSONObject().put("ok", workspace.restoreCheckpoint(args.getString("name")))
                    .put("evidence", "checkpoint restore attempted with no active script focus")
            }
            "create_version" -> {
                require(workspace.currentAgentScriptFocus() == null) {
                    "Cannot create a version while a .gd script is focused; finish or abort the current script first."
                }
                versions.create(args.optString("label", "manual"), args.optString("reason", "agent checkpoint"), jsonArrayStrings(args.optJSONArray("tags"))).let {
                val path = writeVersionIndex()
                JSONObject().put("ok", true).put("version", it).put("path", path).put("evidence", "durable version checkpoint and workspace index created")
                }
            }
            "list_versions" -> JSONObject().put("ok", true).put("versions", versions.list()).put("latest_stable", versions.latestStable() ?: JSONObject()).put("latest", versions.latest() ?: JSONObject()).put("evidence", "durable version index read")
            "mark_version" -> {
                require(workspace.currentAgentScriptFocus() == null) {
                    "Cannot mutate version metadata while a .gd script is focused; finish or abort the current script first."
                }
                versions.mark(args.getString("id"), args.getString("status"), args.optDouble("score", Double.NaN).takeIf { !it.isNaN() }, args.optString("note", ""))
                JSONObject().put("ok", true).put("path", writeVersionIndex()).put("evidence", "version status updated and persisted")
            }
            "restore_version" -> {
                require(workspace.currentAgentScriptFocus() == null) {
                    "Cannot restore a version while a .gd script is focused; finish or abort the current script first."
                }
                versions.restore(args.getString("id")).also { writeVersionIndex() }
            }
            "mark_version_stable" -> {
                require(workspace.currentAgentScriptFocus() == null) {
                    "Cannot mark a version stable while a .gd script is focused; finish or abort the current script first."
                }
                versions.markStable(args.getString("id"), args.optDouble("score", 0.0), args.optString("note", ""))
                JSONObject().put("ok", true).put("path", writeVersionIndex()).put("evidence", "latest stable version updated")
            }
            "get_last_observation" -> JSONObject().put("ok", lastObservation != null).put("observation", processLatestObservation() ?: JSONObject()).put("evidence", "latest embedded-Godot observation processed on-demand")
            "get_game_observation" -> gameObservation()
            "get_local_vision_status" -> JSONObject().put("ok", true).put("status", gameVision.status()).put("evidence", "local embedded-Godot vision contract")
            "get_research_status" -> JSONObject().put("ok", true).put("status", matureResearch.status()).put("evidence", "mature in-app research contract")
            "web_search" -> webResearch.search(args.getString("query"), args.optInt("max_results", 8))
            "web_open" -> webResearch.open(args.getString("url"), args.optInt("max_chars", 12000))
            "research" -> {
                val result = matureResearch.research(args.getString("question"), args.optInt("max_sources", 8))
                val path = workspace.write("gameforge/research/LAST_RESEARCH.json", result.toString(2))
                result.put("path", path)
            }
            "get_mission_context" -> JSONObject().put("ok", true)
                .put("context", missionContext())
                .put("script_focus", workspace.currentAgentScriptFocus() ?: "")
                .put("evidence", "mission context + current single-script focus")
            "inspect_project_graph" -> JSONObject().put("ok", true).put("graph", graph.scan()).put("evidence", "fresh architecture scan")
            "write_project_graph" -> JSONObject().put("ok", true).put("path", graph.writeReport()).put("evidence", "architecture graph persisted")
            "write_project_index" -> JSONObject().put("ok", true).put("path", indexer.write()).put("evidence", "fresh project symbol/file index persisted")
            "analyze_change_impact" -> JSONObject().put("ok", true).put("analysis", impact.analyze(jsonArrayStrings(args.optJSONArray("changed_paths")))).put("evidence", "fresh impact analysis")
            "profile_project" -> JSONObject().put("ok", true).put("profile", profiler.profile()).put("evidence", "fresh project performance heuristic profile")
            "write_profile_report" -> JSONObject().put("ok", true).put("path", profiler.writeReport()).put("evidence", "performance report persisted")
            "analyze_visual_quality" -> JSONObject().put("ok", true).put("visual", visual.analyze()).put("evidence", "fresh visual QA analysis")
            "write_visual_quality_report" -> JSONObject().put("ok", true).put("path", visual.writeReport()).put("evidence", "visual quality report persisted")
            "read_game_spec" -> readGameSpec()
            "generate_2d_asset" -> assetFactory2D.generateAsset(args)
            "generate_2d_map" -> assetFactory2D.generateMap(args)
            "validate_2d_assets" -> assetFactory2D.validate()
            "audit_asset_pipeline" -> assetAudit()
            "plan_mmorpg_world" -> planWorld(args)
            "run_massive_qa" -> {
                val report = massiveQa.run(args.optInt("iterations", 8), args.optLong("seed", 0x4F7E9A11L))
                val path = workspace.write("gameforge/MASSIVE_QA.json", report.toString(2))
                report.put("path", path)
            }
            "route_model" -> adaptiveRouter?.route(args.optString("task", "general"), args.optString("prompt", ""), args.optDouble("risk", 0.5), args.optBoolean("evidence", false)) ?: JSONObject().put("ok", false).put("error", "adaptive model router unavailable")
            "package_game" -> packageGame(args.optString("main_scene", "main.tscn"))
            "run_generated_game" -> runGeneratedGame(args.optString("main_scene", "main.tscn"))
            "run_godot_test" -> runGodotTest()
            "game_action" -> sendGameAction(args)
            "run_playtest" -> runPlaytest(args.optInt("iterations", 5))
            "wait" -> { delay(args.optLong("ms", 250).coerceIn(0, 5000)); JSONObject().put("ok", true).put("evidence", "wait completed") }
            "run_command" -> runSafeCommand(args.getString("command"), args.optLong("timeout_ms", 20000))
                else -> JSONObject().put("ok", false).put("error", "Unknown tool: $name")
            }
        } catch (t: CancellationException) {
            throw t
        } catch (t: Throwable) {
            JSONObject().put("ok", false).put("error", t.message ?: t::class.java.simpleName).put("evidence", "tool exception")
        }
    }

    private fun writeVersionIndex(): String = workspace.write("gameforge/VERSION_INDEX.json", versions.list().toString(2))

    private fun gameObservation(): JSONObject {
        val observation = processLatestObservation()
        return JSONObject()
            .put("ok", observation != null)
            .put("observation", observation ?: JSONObject())
            .put("evidence", if (observation != null) "latest embedded-Godot game observation processed on-demand" else "no embedded game observation available")
    }


    private fun assetAudit(): JSONObject {
        val path = assetQuality.write()
        val report = runCatching { JSONObject(File(workspace.root, path).readText()) }.getOrElse { assetQuality.audit() }
        return JSONObject().put("ok", report.optBoolean("ok")).put("report", report).put("path", path).put("evidence", "deep generated-art QA and consistency audit persisted in workspace")
    }

    private fun planWorld(args: JSONObject): JSONObject {
        val spec = readGameSpec().optJSONObject("spec")?.let { com.husain.aicoder.game.GameSpec.fromJson(it) }
            ?: com.husain.aicoder.game.GameSpec.fallback(args.optString("goal", "2D MMORPG world"))
        val plan = worldPlanner.plan(spec, args.optLong("seed", 0L).takeIf { it != 0L } ?: 1469598103934665603L)
        val validation = worldPlanner.validate(plan)
        val planWithValidation = JSONObject(plan.toString()).put("validation", validation)
        val path = workspace.write("gameforge/WORLD_PLAN.json", planWithValidation.toString(2))
        return JSONObject().put("ok", validation.optBoolean("ok", false)).put("path", path).put("plan", planWithValidation).put("evidence", "deterministic procedural MMORPG/world plan generated and validated in-app")
    }

    private fun readGameSpec(): JSONObject {
        val file = File(workspace.root, "GAME_SPEC.json")
        return JSONObject().put("ok", file.isFile)
            .put("spec", if (file.isFile) runCatching { JSONObject(file.readText()) }.getOrDefault(JSONObject()) else JSONObject())
            .put("evidence", if (file.isFile) "fresh GameSpec read" else "GameSpec missing")
    }

    private suspend fun sendGameAction(args: JSONObject): JSONObject {
        val bridge = godot ?: return JSONObject().put("ok", false).put("error", "Godot bridge unavailable").put("evidence", "no bridge")
        val before = observationVersion.get()
        bridge.sendAction(args.toString())
        delay(args.optLong("settle_ms", 180).coerceIn(40, 1000))
        bridge.requestObservation()
        var waited = 0
        while (observationVersion.get() <= before && waited < 30) {
            delay(50)
            waited++
        }
        val obs = if (observationVersion.get() > before) processLatestObservation() else null
        obs?.let { persistTelemetry(it) }
        return JSONObject()
            .put("ok", observationHealthy(obs))
            .put("action", args)
            .put("observation", obs ?: JSONObject())
            .put("observation_fresh", obs != null)
            .put("evidence", if (obs != null) "fresh post-action observation received" else "no fresh observation received after action")
    }

    private suspend fun packageGame(mainScene: String): JSONObject {
        val pack = packager.packageProject(runtimeDir, mainScene)
        return JSONObject().put("ok", true).put("pack", pack.absolutePath).put("main_scene", mainScene).put("evidence", "workspace packaged for embedded Godot")
    }

    private suspend fun runGeneratedGame(mainScene: String): JSONObject {
        gameVision.resetTemporalState()
        val bridge = godot ?: return JSONObject().put("ok", false).put("error", "Godot bridge unavailable").put("evidence", "no bridge")
        val pack = runCatching { packager.packageProject(runtimeDir, mainScene) }.getOrElse {
            return JSONObject().put("ok", false).put("error", it.message ?: "packaging failed").put("evidence", "workspace packager rejected the generated project")
        }
        val before = observationVersion.get()
        lastObservation = null
        bridge.loadWorkspacePack(pack.absolutePath, mainScene)
        var waited = 0
        while (observationVersion.get() <= before && waited < 40) {
            delay(100)
            waited++
        }
        val obs = if (observationVersion.get() > before) processLatestObservation() else null
        obs?.let { persistTelemetry(it) }
        return JSONObject()
            .put("ok", observationHealthy(obs))
            .put("pack", pack.absolutePath)
            .put("main_scene", mainScene)
            .put("observation", obs ?: JSONObject())
            .put("observation_fresh", obs != null)
            .put("evidence", if (obs != null) "generated workspace pack loaded and observed" else "workspace pack load gave no fresh observation")
    }

    private suspend fun runGodotTest(): JSONObject {
        gameVision.resetTemporalState()
        val bridge = godot ?: return JSONObject().put("ok", false).put("error", "Godot bridge unavailable").put("evidence", "no bridge")
        val before = observationVersion.get()
        lastObservation = null
        bridge.restartTest()
        bridge.requestObservation()
        var waited = 0
        while (observationVersion.get() <= before && waited < 30) {
            delay(50)
            waited++
        }
        val obs = if (observationVersion.get() > before) processLatestObservation() else null
        obs?.let { persistTelemetry(it) }
        return JSONObject()
            .put("ok", observationHealthy(obs))
            .put("observation", obs ?: JSONObject())
            .put("observation_fresh", obs != null)
            .put("evidence", if (obs != null) "fresh Godot observation received" else "no fresh observation received")
    }

    private suspend fun runPlaytest(iterations: Int): JSONObject {
        val n = iterations.coerceIn(1, 20)
        val loaded = runGeneratedGame("main.tscn")
        val results = JSONArray()
        var passes = 0
        val actions = listOf(
            JSONObject().put("type", "move").put("x", 0.65).put("y", 0.10).put("jump", false),
            JSONObject().put("type", "attack"),
            JSONObject().put("type", "skill"),
            JSONObject().put("type", "move").put("x", -0.65).put("y", -0.10).put("jump", false),
            JSONObject().put("type", "interact"),
            JSONObject().put("type", "bot_test")
        )
        repeat(n) { i ->
            val boot = runGodotTest()
            val actionRows = JSONArray()
            var actionsOk = boot.optBoolean("ok")
            if (actionsOk) {
                for (action in actions) {
                    val row = sendGameAction(action)
                    actionRows.put(row)
                    if (!row.optBoolean("ok")) actionsOk = false
                }
            }
            val result = JSONObject()
                .put("iteration", i + 1)
                .put("boot", boot)
                .put("actions", actionRows)
                .put("passed", actionsOk)
            if (actionsOk) passes++
            results.put(result)
        }
        return JSONObject()
            .put("ok", loaded.optBoolean("ok") && passes == n)
            .put("runtime_load", loaded)
            .put("iterations", n)
            .put("passes", passes)
            .put("pass_rate", passes.toDouble() / n)
            .put("results", results)
            .put("generated_at_ms", System.currentTimeMillis())
            .put("evidence", "fresh boot and post-action observations from generated Godot runtime")
    }

    private fun persistTelemetry(observation: JSONObject) {
        val telemetry = JSONObject(observation.toString())
            .put("captured_at_ms", System.currentTimeMillis())
        val file = File(workspace.root, "gameforge/telemetry/latest.json")
        file.parentFile?.mkdirs()
        runCatching { file.writeText(telemetry.toString(2)) }
    }

    private fun jsonArrayStrings(a: JSONArray?): List<String> = if (a == null) emptyList() else buildList {
        for (i in 0 until a.length()) add(a.optString(i))
    }

    private fun runSafeCommand(command: String, timeoutMs: Long): JSONObject {
        val tokens = splitArgs(command)
        val executable = tokens.firstOrNull()?.lowercase() ?: return JSONObject().put("ok", false).put("error", "empty command")
        ToolPolicy.validateCommand(command).getOrElse { return JSONObject().put("ok", false).put("error", it.message ?: "blocked command") }
        val allowed = setOf("ls", "pwd", "find", "grep", "cat", "wc", "git")
        if (executable !in allowed) return JSONObject().put("ok", false).put("error", "command not allow-listed: $executable")
        if (executable == "git" && workspace.currentAgentScriptFocus() != null) {
            val gitSubcommand = tokens.getOrNull(1)?.lowercase() ?: ""
            val readOnlyGit = setOf("status", "diff", "log", "show", "rev-parse", "ls-files")
            if (gitSubcommand !in readOnlyGit) {
                return JSONObject().put("ok", false)
                    .put("error", "git mutation is blocked while a .gd script is focused; finish the focused script first")
            }
        }
        val process = ProcessBuilder(tokens).directory(workspace.root).redirectErrorStream(true).start()
        val deadline = SystemClock.uptimeMillis() + timeoutMs.coerceIn(250, 60000)
        while (process.isAlive && SystemClock.uptimeMillis() < deadline) Thread.sleep(40)
        if (process.isAlive) { process.destroyForcibly(); return JSONObject().put("ok", false).put("error", "command timed out").put("evidence", "process exceeded timeout") }
        val output = process.inputStream.bufferedReader().use { reader ->
            val out = StringBuilder(16_000)
            val buffer = CharArray(4096)
            while (out.length < 16_000) {
                val want = minOf(buffer.size, 16_000 - out.length)
                val n = reader.read(buffer, 0, want)
                if (n <= 0) break
                out.append(buffer, 0, n)
            }
            out.toString()
        }
        return JSONObject().put("ok", process.exitValue() == 0).put("exit_code", process.exitValue())
            .put("output", output).put("evidence", "process exit code=${process.exitValue()}")
    }

    private fun splitArgs(input: String): List<String> {
        val out = mutableListOf<String>()
        val current = StringBuilder()
        var quote: Char? = null
        var escaped = false
        for (ch in input.trim()) {
            if (escaped) { current.append(ch); escaped = false; continue }
            if (ch == '\\') { escaped = true; continue }
            if (quote != null) {
                if (ch == quote) quote = null else current.append(ch)
                continue
            }
            when {
                ch == '\'' || ch == '"' -> quote = ch
                ch.isWhitespace() -> if (current.isNotEmpty()) { out += current.toString(); current.setLength(0) }
                else -> current.append(ch)
            }
        }
        if (escaped) current.append('\\')
        if (quote != null) throw IllegalArgumentException("Unclosed command quote")
        if (current.isNotEmpty()) out += current.toString()
        return out
    }
}
