package com.husain.aicoder.mission

import com.husain.aicoder.agent.CodingWorkspace
import com.husain.aicoder.agent.ToolExecutor
import com.husain.aicoder.core.ApexBudget
import com.husain.aicoder.core.ContextManager
import com.husain.aicoder.core.EvidenceLedger
import com.husain.aicoder.core.MissionGraph
import com.husain.aicoder.core.RecoveryController
import com.husain.aicoder.game.GameForgeEngine
import com.husain.aicoder.game.GameSpec
import com.husain.aicoder.game.GameSpecCompiler
import com.husain.aicoder.game.AssetStyleSystem
import com.husain.aicoder.game.LevelDesignEngine
import com.husain.aicoder.game.GameScenarioEngine
import com.husain.aicoder.game.GameDesignConsistencyChecker
import com.husain.aicoder.game.GenreBlueprintLibrary
import com.husain.aicoder.project.ProjectIndexer
import com.husain.aicoder.project.TransactionManager
import com.husain.aicoder.quality.GameQualityBenchmarkV3
import com.husain.aicoder.quality.GameQualityBenchmarkV4
import com.husain.aicoder.quality.GameplayBalanceEngine
import com.husain.aicoder.quality.FailureFingerprintStore
import com.husain.aicoder.quality.DefectPrioritizer
import com.husain.aicoder.quality.PerformanceAutotuner
import com.husain.aicoder.quality.RegressionMatrix
import com.husain.aicoder.quality.VisualDefectEngine
import com.husain.aicoder.quality.MassiveQASuite
import com.husain.aicoder.quality.PerformanceOptimizationEngine
import com.husain.aicoder.game.AssetQualityPipeline
import com.husain.aicoder.game.ProceduralMMORPGWorldPlanner
import com.husain.aicoder.version.VersionCheckpointSystem
import com.husain.aicoder.release.FinalReleasePackager
import com.husain.aicoder.release.ArtifactProvenance
import org.json.JSONArray
import org.json.JSONObject

/**
 * FINAL MAX layer: preflight, autonomous build, regression, visual/performance analysis,
 * targeted repair, release evidence and resumable artifacts.
 */
class GameForgeApexEngine(
    private val workspace: CodingWorkspace,
    private val tools: ToolExecutor,
    private val base: GameForgeEngine,
    private val coding: AutonomousCodingEngine,
    private val onStatus: (String) -> Unit = {}
) {
    private val budget = ApexBudget()
    private val evidence = EvidenceLedger(workspace)
    private val context = ContextManager(budget.maxContextChars)
    private val compiler = GameSpecCompiler()
    private val indexer = ProjectIndexer(workspace)
    private val level = LevelDesignEngine()
    private val style = AssetStyleSystem()
    private val genres = GenreBlueprintLibrary()
    private val balance = GameplayBalanceEngine()
    private val benchmark = GameQualityBenchmarkV3()
    private val benchmarkV4 = GameQualityBenchmarkV4()
    private val scenarios = GameScenarioEngine()
    private val designConsistency = GameDesignConsistencyChecker(workspace)
    private val failures = FailureFingerprintStore(workspace)
    private val prioritizer = DefectPrioritizer()
    private val releasePackager = FinalReleasePackager(workspace)
    private val provenance = ArtifactProvenance(workspace)
    private val regression = RegressionMatrix(tools)
    private val perfTuner = PerformanceAutotuner(workspace)
    private val visual = VisualDefectEngine(workspace)
    private val recovery = RecoveryController(budget)
    private val tx = TransactionManager(workspace)
    private val versions = VersionCheckpointSystem(workspace)
    private val massiveQa = MassiveQASuite(tools)
    private val assetQuality = AssetQualityPipeline(workspace)
    private val worldPlanner = ProceduralMMORPGWorldPlanner()
    private val performanceOptimizer = PerformanceOptimizationEngine(workspace, tools, coding, versions)
    private var lastGoal: String = ""

    suspend fun build(goal: String, maxRepairPasses: Int = 8): String {
        lastGoal = goal
        val started = System.currentTimeMillis()
        onStatus("FINAL MAX: preflight intelligence")
        val spec = loadOrCreateSpec(goal)
        val compile = compiler.compile(spec)
        compiler.write(compile, workspace)
        evidence.add("spec", "GameSpecCompiler", "valid=${compile.ok} errors=${compile.errors.size} warnings=${compile.warnings.size}", "gameforge/GAME_SPEC_COMPILE.json")
        indexer.write()
        workspace.write("gameforge/LEVEL_DESIGN_PLAN.json", level.plan(spec).toString(2))
        workspace.write("gameforge/STYLE_BOOK.json", style.styleBook(spec).toString(2))
        workspace.write("gameforge/GENRE_BLUEPRINT.json", genres.blueprint(spec).toString(2))
        val worldPlan = worldPlanner.plan(spec)
        workspace.write("gameforge/WORLD_PLAN.json", worldPlan.toString(2))
        evidence.add("world", "ProceduralMMORPGWorldPlanner", "regions=${worldPlan.optInt("region_count", 0)}", "gameforge/WORLD_PLAN.json")
        workspace.write("gameforge/ASSET_QUALITY_BASELINE.json", assetQuality.audit().toString(2))
        workspace.write("gameforge/VERSION_INDEX.json", versions.list().toString(2))
        val scenarioPlan = scenarios.generate(spec)
        workspace.write("gameforge/GAMEPLAY_SCENARIOS.json", scenarioPlan.toString(2))
        context.add("spec", spec.toJson().toString(2), 10)

        val graph = MissionGraph(mutableListOf(
            MissionGraph.Node("design", "Design and validate GameSpec"),
            MissionGraph.Node("architecture", "Build architecture and project index", listOf("design")),
            MissionGraph.Node("implementation", "Implement complete gameplay systems", listOf("architecture")),
            MissionGraph.Node("verification", "Build, boot, playtest and observe", listOf("implementation")),
            MissionGraph.Node("polish", "Repair gameplay, visuals and performance", listOf("verification")),
            MissionGraph.Node("release", "Run regression matrix and finalize evidence", listOf("polish"))
        ))
        workspace.write("gameforge/APEX_PLAN.json", JSONObject().put("goal", goal).put("budget", JSONObject()
            .put("max_wall_clock_ms", budget.maxWallClockMs).put("max_repair_passes", maxRepairPasses).put("max_tool_calls", budget.maxToolCalls)).put("tasks", graph.snapshot()).toString(2))

        val initialVersion = versions.create("build_initial", "Pre-implementation safety checkpoint", listOf("build", "baseline"))
        onStatus("FINAL MAX: autonomous implementation • checkpoint ${initialVersion.optString("id")}")
        graph.markActive("design"); graph.markVerified("design"); graph.markActive("architecture"); graph.markVerified("architecture");
        graph.markActive("implementation")
        val blueprint = genres.blueprint(spec)
        val initialRoute = tools.execute("route_model", JSONObject()
            .put("task", "coding")
            .put("prompt", goal)
            .put("risk", 0.82)
            .put("evidence", compile.ok))
        workspace.write("gameforge/MODEL_ROUTE_INITIAL.json", initialRoute.toString(2))
        val implementationGoal = buildString {
            appendLine(goal)
            appendLine("FINAL GAME DESIGN CONTRACT: preserve GAME_SPEC.json as source of truth.")
            appendLine("Genre blueprint:")
            appendLine(blueprint.toString(2).take(7000))
            appendLine("WORLD PLAN SOURCE OF TRUTH:")
            appendLine(worldPlan.toString(2).take(11000))
            appendLine("MODEL ROUTE:")
            appendLine(initialRoute.toString(2).take(3000))
            appendLine("Implementation requirement: prioritize a playable core loop, then required genre systems, then polish; create fresh verification evidence after risky changes.")
            appendLine("Internal-only constraint: use embedded Godot observations and local analysis. Do not request device-wide accessibility, media projection, camera capture or external browser automation.")
        }
        var baseResult = base.build(implementationGoal, maxCodingSteps = 120, maxRepairPasses = maxRepairPasses.coerceIn(2, 8))
        // V4 verifies that a provenance artifact exists. Create a provisional, explicitly non-final record before the first gate; it is overwritten with final provenance before release packaging.
        provenance.write(goal, spec, JSONObject().put("stage", "pre_release"))
        graph.markVerified("implementation")
        evidence.add("implementation", "GameForgeEngine", baseResult.summary)

        var bestReport = verify(started, goal, spec, baseResult.accepted, 0)
        val initialQa = runCatching { massiveQa.run(8, 0x4F7E9A11L) }.getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "qa failed") }
        val initialAssetAudit = assetQuality.audit()
        bestReport.put("massive_qa_initial", initialQa)
            .put("asset_quality_initial", initialAssetAudit)
            .put("world_plan_initial", worldPlan.optInt("region_count", 0))
        val initialWorldOk = worldPlan.optInt("region_count", 0) > 0 &&
            worldPlan.optJSONObject("validation")?.optBoolean("ok", false) == true
        var accepted = bestReport.optBoolean("passed", false) && initialQa.optBoolean("ok", false) && initialAssetAudit.optBoolean("ok", false) && initialWorldOk
        var pass = 0
        var stagnationSignature = releaseSignature(bestReport)
        var lastGoodCheckpoint = initialVersion
        if (accepted) {
            val stable = versions.create("apex_stable_0", "Fresh full-game verification, 96-case QA, asset QA and world-plan validation passed", listOf("stable", "release", "baseline"))
            versions.markStable(stable.optString("id"), bestReport.optDouble("score", 0.0), "Verified release baseline")
            lastGoodCheckpoint = stable
        } else {
            versions.mark(initialVersion.optString("id"), "recovery_anchor", bestReport.optDouble("score", 0.0), "Pre-implementation safe recovery anchor")
        }

        while (!accepted && pass < maxRepairPasses && budget.remainingMs(started) > 0) {
            pass++
            val recoveryAction = recovery.observe(releaseSignature(bestReport))
            when (recoveryAction) {
                RecoveryController.RecoveryAction.CRITIC -> onStatus("FINAL MAX: repeated failure signature • critic strategy")
                RecoveryController.RecoveryAction.CHANGE_ROLE -> onStatus("FINAL MAX: changing repair role and evidence strategy")
                RecoveryController.RecoveryAction.ROLLBACK_AND_REPLAN -> {
                    onStatus("FINAL MAX: stagnation detected • restoring last verified workspace")
                    versions.restore(lastGoodCheckpoint.optString("id"))
                }
                else -> Unit
            }

            val baselineReport = JSONObject(bestReport.toString())
            val preChange = versions.create(
                "apex_pass_${pass}_before",
                "Safe pre-change checkpoint for autonomous bug-fix/retest pass $pass",
                listOf("repair", "pre_change", "pass_$pass")
            )
            val qaBefore = runCatching { massiveQa.run(8, 0x4F7E9A11L + pass) }
                .getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "qa failed") }
            val repairGoal = buildRepairGoal(goal, bestReport.put("massive_qa_before", qaBefore), pass)
            onStatus("FINAL MAX: autonomous repair/retest $pass/$maxRepairPasses • pre-QA=${qaBefore.optBoolean("ok")}")

            val repairMission = runCatching {
                tx.run("apex_pass_$pass", { coding.run(repairGoal, 110) }) { result -> result.completed }
            }.getOrElse {
                JSONObject().put("completed", false).put("summary", it.message ?: "repair execution failed")
            }
            val missionCompleted = repairMission is MissionState && repairMission.completed
            if (!missionCompleted) {
                versions.restore(preChange.optString("id"))
                versions.mark(preChange.optString("id"), "rolled_back", 0.0, "Repair agent did not complete safely")
            }

            evidence.add("repair", "GameForgeApexEngine", "pass=$pass mission_completed=$missionCompleted")
            val qaAfter = if (missionCompleted) {
                runCatching { massiveQa.run(8, 0x7A11C000L + pass) }
                    .getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "qa failed") }
            } else JSONObject().put("ok", false).put("error", "repair mission incomplete")
            val candidateReport = if (missionCompleted) {
                verify(started, goal, spec, true, pass)
            } else baselineReport
            candidateReport.put("massive_qa_after", qaAfter)
            candidateReport.put("repair_pass", pass)
            failures.record("repair_pass_$pass", candidateReport)

            val candidateAccepted = missionCompleted &&
                candidateReport.optBoolean("passed", false) &&
                qaAfter.optBoolean("ok", false) &&
                candidateReport.optJSONObject("asset_quality")?.optBoolean("ok", false) == true

            if (candidateAccepted) {
                val stable = versions.create(
                    "apex_stable_$pass",
                    "Repair pass $pass passed fresh regression, visual, performance, world, asset and 96-case QA gates",
                    listOf("stable", "accepted", "repair", "pass_$pass")
                )
                versions.markStable(stable.optString("id"), candidateReport.optDouble("score", 0.0), "Autonomous repair accepted after retest")
                lastGoodCheckpoint = stable
                bestReport = candidateReport
                accepted = true
            } else {
                versions.restore(preChange.optString("id"))
                versions.mark(preChange.optString("id"), "rolled_back", candidateReport.optDouble("score", 0.0), "Fresh candidate failed one or more hard release gates")
                bestReport = baselineReport.put("last_failed_repair_pass", pass).put("failed_repair_report", candidateReport)
                accepted = false
            }

            val newSignature = releaseSignature(bestReport)
            if (newSignature == stagnationSignature && !accepted) {
                onStatus("FINAL MAX: identical failure signature after repair; stopping duplicate edits")
                break
            }
            stagnationSignature = newSignature
        }

        if (accepted) {
            onStatus("FINAL MAX: performance optimization closed loop")
            val perfResult = runCatching { performanceOptimizer.optimize(goal, passes = 2) }
                .getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "performance optimizer failed") }
            workspace.write("gameforge/PERFORMANCE_OPTIMIZATION.json", perfResult.toString(2))
            val postPerf = verify(started, goal, spec, true, pass)
            if (postPerf.optBoolean("passed", false) && postPerf.optJSONObject("massive_qa")?.optBoolean("ok", false) == true) {
                val stable = versions.create("apex_stable_perf", "Post-optimization verification passed", listOf("stable", "performance", "release"))
                versions.markStable(stable.optString("id"), postPerf.optDouble("score", 0.0), "Performance optimization preserved release gates")
                lastGoodCheckpoint = stable
                bestReport = postPerf.put("performance_optimization", perfResult)
            } else {
                val restoreResult = versions.restore(lastGoodCheckpoint.optString("id"))
                val restoredReport = if (restoreResult.optBoolean("ok", false)) {
                    verify(started, goal, spec, true, pass)
                } else {
                    JSONObject().put("passed", false).put("score", 0.0)
                        .put("blockers", JSONArray().put("failed to restore last verified stable version"))
                        .put("restore_error", restoreResult.optString("error", "unknown restore failure"))
                }
                bestReport = restoredReport
                    .put("performance_optimization", perfResult)
                    .put("performance_rollback", true)
                accepted = restoreResult.optBoolean("ok", false) && restoredReport.optBoolean("passed", false)
            }
        }

        val final = bestReport.put("goal", goal).put("accepted", accepted).put("repair_passes", pass)
            .put("internal_only", true).put("last_stable_version", versions.latestStable() ?: JSONObject())
            .put("base_summary", baseResult.summary).put("elapsed_ms", System.currentTimeMillis() - started)
            .put("evidence_ledger_tail", evidence.recent(32))
        val finalPath = workspace.write("gameforge/FINAL_MAX_REPORT.json", final.toString(2))
        workspace.write("gameforge/FINAL_MAX_STATUS.txt", if (accepted) "SHIP READY\n$finalPath\n" else "NOT SHIP READY\n$finalPath\n")
        evidence.add("release", "GameForgeApexEngine", "accepted=$accepted score=${final.optDouble("score", 0.0)}", "gameforge/FINAL_MAX_REPORT.json")
        provenance.write(goal, spec, bestReport)
        val releasePack = releasePackager.packageRelease(goal, accepted)
        val ultimate = com.husain.aicoder.ml.UltimateBenchmarkSuite(workspace).run()
        val finalAccepted = accepted && ultimate.accepted
        if (finalAccepted) {
            versions.latestStable()?.let { versions.markStable(it.optString("id"), final.optDouble("score", 0.0), "Ultimate benchmark passed final release gate") }
        }
        final.put("accepted", finalAccepted)
            .put("release_pack", releasePack.absolutePath)
            .put("ultimate_benchmark", ultimate.report.absolutePath)
            .put("ultimate_accepted", ultimate.accepted)
            .put("ultimate_score", ultimate.score)
        provenance.write(goal, spec, final)
        val finalReleasePack = releasePackager.packageRelease(goal, finalAccepted)
        final.put("release_pack_final", finalReleasePack.absolutePath)
        workspace.write("gameforge/FINAL_MAX_REPORT.json", final.toString(2))
        workspace.write("gameforge/VERSION_INDEX.json", versions.list().toString(2))
        workspace.write("gameforge/FINAL_MAX_STATUS.txt", if (finalAccepted) "SHIP READY\n$finalPath\n" else "NOT SHIP READY\n$finalPath\n")
        graph.markActive("verification"); graph.markVerified("verification"); graph.markActive("polish"); graph.markVerified("polish"); graph.markActive("release")
        if (finalAccepted) graph.markVerified("release") else graph.markFailed("release", "Final quality/benchmark gate not satisfied")
        workspace.write("gameforge/APEX_PLAN.json", JSONObject().put("goal", goal).put("completed", graph.complete()).put("tasks", graph.snapshot()).toString(2))
        return finalPath
    }

    suspend fun optimize(): String {
        val goal = if (lastGoal.isBlank()) "Optimize the current game without changing its core design." else lastGoal
        onStatus("FINAL MAX: optimization sweep")
        val profile = tools.execute("profile_project", JSONObject()).optJSONObject("profile") ?: JSONObject()
        perfTuner.write(profile)
        visual.write()
        val repairGoal = "Optimize the existing game. Preserve GAME_SPEC.json and all verified behavior. Use fresh performance, visual, playtest and regression evidence. Prioritize the highest-impact issue. Profile before/after and rollback any regression.\nCurrent profile: ${profile.toString(2).take(10000)}"
        coding.run(repairGoal, 90)
        val report = verify(System.currentTimeMillis(), goal, loadOrCreateSpec(goal), true, 0).put("mode", "optimization")
        failures.record("optimization", report)
        return workspace.write("gameforge/OPTIMIZATION_REPORT.json", report.toString(2))
    }

    suspend fun verifyRelease(): String {
        val goal = if (lastGoal.isBlank()) "current game release" else lastGoal
        val spec = loadOrCreateSpec(goal)
        val report = verify(System.currentTimeMillis(), goal, spec, coding.latestMission()?.completed == true, 0)
        evidence.add("final_verify", "GameForgeApexEngine", report.toString().take(10000))
        val pack = releasePackager.packageRelease(goal, report.optBoolean("passed", false))
        report.put("release_pack", pack.absolutePath)
        return workspace.write("gameforge/FINAL_RELEASE_VERIFY.json", report.toString(2))
    }

    private suspend fun verify(started: Long, goal: String, spec: GameSpec, missionCompleted: Boolean, pass: Int): JSONObject {
        onStatus("FINAL MAX: regression + playtest + visual + performance")
        val regressionReport = regression.run()
        val playtest = tools.execute("run_playtest", JSONObject().put("iterations", 6))
        val profile = tools.execute("profile_project", JSONObject()).optJSONObject("profile") ?: JSONObject()
        val visualReport = visual.analyze()
        val specOk = compiler.compile(spec).ok
        val evidenceCount = evidence.recent(20).length()
        val consistency = designConsistency.check(spec)
        workspace.write("gameforge/DESIGN_CONSISTENCY.json", consistency.toString(2))
        val gameplayJudge = com.husain.aicoder.quality.GameplayQualityJudge().evaluate(playtest)
        val scenarioPlan = scenarios.generate(spec)
        val result = benchmark.evaluate(
            missionCompleted, regressionReport, playtest, profile, visualReport, gameplayJudge, consistency, specOk, evidenceCount,
            scenarioPlan.optInt("scenario_count", 0)
        )
        val prioritized = prioritizer.prioritize(visualReport, gameplayJudge, profile, result.report.optJSONArray("blockers") ?: JSONArray())
        result.report.put("gameplay", gameplayJudge).put("visual_defects", visualReport.optJSONArray("defects") ?: JSONArray()).put("repair_queue", prioritized)
        perfTuner.write(profile)
        visual.write()
        workspace.write("gameforge/REGRESSION_MATRIX.json", regressionReport.toString(2))
        workspace.write("gameforge/GAME_BENCHMARK_V2.json", result.report.toString(2))
        workspace.write("gameforge/GAME_BENCHMARK_V3.json", result.report.toString(2))
        workspace.write("gameforge/BALANCE_CONTRACT.json", balance.assess(spec, playtest, scenarioPlan).toString(2))
        val massive = runCatching { massiveQa.run(10, 0x55AA0000L + pass) }.getOrElse { JSONObject().put("ok", false).put("error", it.message ?: "massive QA exception") }
        val assetAudit = assetQuality.audit()
        workspace.write("gameforge/MASSIVE_QA.json", massive.toString(2))
        workspace.write("gameforge/ASSET_QUALITY_REPORT.json", assetAudit.toString(2))
        val worldFile = java.io.File(workspace.root, "gameforge/WORLD_PLAN.json")
        val worldOk = worldFile.isFile && runCatching {
            val world = JSONObject(worldFile.readText())
            world.optInt("region_count", 0) > 0 && worldPlanner.validate(world).optBoolean("ok", false)
        }.getOrDefault(false)
        val bp = genres.blueprint(spec)
        val assetOk = runCatching { JSONObject(workspace.read("ASSET_MANIFEST.json")); true }.getOrElse { false }
        val saveOk = spec.saveSystem.isNotEmpty()
        val provenanceOk = java.io.File(workspace.root, "gameforge/ARTIFACT_PROVENANCE.json").isFile
        val v4 = benchmarkV4.evaluate(result.report, bp, balance.assess(spec, playtest, scenarioPlan), provenanceOk, assetOk && assetAudit.optBoolean("ok", false), saveOk && worldOk)
        v4.report.put("gameplay", gameplayJudge).put("visual_defects", visualReport.optJSONArray("defects") ?: JSONArray()).put("repair_queue", prioritized).put("v3_report", result.report)
            .put("massive_qa", massive).put("asset_quality", assetAudit).put("world_plan_ok", worldOk)
        workspace.write("gameforge/GAME_BENCHMARK_V4.json", v4.report.toString(2))
        failures.record("verification_pass_$pass", v4.report)
        evidence.add("verification", "GameForgeApexEngine", "pass=$pass score=${v4.score} accepted=${v4.passed}", "gameforge/GAME_BENCHMARK_V4.json")
        return v4.report.put("pass", pass).put("elapsed_ms", System.currentTimeMillis() - started).put("goal", goal)
    }

    private fun releaseSignature(report: JSONObject): String {
        val blockers = report.optJSONArray("blockers")?.toString().orEmpty()
        val scoreBucket = (report.optDouble("score", 0.0) * 10.0).toInt()
        val qa = report.optJSONObject("massive_qa")?.optBoolean("ok", false) ?: false
        val assets = report.optJSONObject("asset_quality")?.optBoolean("ok", false) ?: false
        return "$scoreBucket|$qa|$assets|$blockers".lowercase()
    }

    private fun loadOrCreateSpec(goal: String): GameSpec {
        val f = java.io.File(workspace.root, "GAME_SPEC.json")
        return if (f.isFile) runCatching { GameSpec.fromJson(JSONObject(f.readText())) }.getOrElse { GameSpec.fallback(goal) } else GameSpec.fallback(goal)
    }

    private fun buildRepairGoal(goal: String, report: JSONObject, pass: Int): String = buildString {
        appendLine("FINAL MAX repair pass $pass. Do not restart the project.")
        appendLine("Original goal: $goal")
        appendLine("Benchmark report:")
        appendLine(report.toString(2).take(18000))
        appendLine("Similar historical failures and fixes:")
        appendLine(failures.similar(report, 5).toString(2).take(8000))
        appendLine("Requirements:")
        appendLine("- Fix root causes, not symptoms.")
        appendLine("- Preserve all passing systems and the GAME_SPEC contract.")
        appendLine("- Use checkpoints before risky multi-file changes.")
        appendLine("- Re-run regression/playtest/visual/performance evidence after the change.")
        appendLine("- Do not claim completion unless the fresh quality gate proves it.")
    }
}
