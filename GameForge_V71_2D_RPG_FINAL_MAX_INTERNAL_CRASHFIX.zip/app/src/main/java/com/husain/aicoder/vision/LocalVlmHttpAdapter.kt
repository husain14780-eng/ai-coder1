package com.husain.aicoder.vision

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

/** Optional localhost-only OpenAI-compatible vision adapter. No cloud endpoint is required. */
class LocalVlmHttpAdapter(private val endpoint: String = "http://localhost:8080/v1/chat/completions") : VlmAdapter {
    override fun id(): String = "local-http"

    override suspend fun describeImage(imagePath: String, prompt: String): JSONObject = withContext(Dispatchers.IO) {
        val file = File(imagePath)
        if (!file.isFile) return@withContext JSONObject().put("available", false).put("reason", "image missing")
        if (file.length() > MAX_IMAGE_BYTES) {
            return@withContext JSONObject().put("available", false)
                .put("reason", "image exceeds local VLM memory limit")
        }
        val endpointUrl = runCatching { URL(endpoint) }.getOrNull()
            ?: return@withContext JSONObject().put("available", false).put("reason", "invalid local VLM endpoint")
        val host = endpointUrl.host.lowercase()
        if (host !in LOCAL_HOSTS) {
            return@withContext JSONObject().put("available", false)
                .put("reason", "local VLM adapter accepts localhost endpoints only")
        }
        val b64 = Base64.getEncoder().encodeToString(file.readBytes())
        val mime = when (file.extension.lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"
            "webp" -> "image/webp"
            else -> "image/png"
        }
        val body = JSONObject()
            .put("model", "local-vlm")
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", JSONArray()
                .put(JSONObject().put("type", "text").put("text", prompt))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:$mime;base64,$b64"))))))
            .put("max_tokens", 700)
        val conn = (endpointUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 5000; readTimeout = 20000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        return@withContext try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val text = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                .bufferedReader().use { reader ->
                    val out = StringBuilder(MAX_RESPONSE_CHARS)
                    val buffer = CharArray(4096)
                    while (out.length < MAX_RESPONSE_CHARS) {
                        val want = minOf(buffer.size, MAX_RESPONSE_CHARS - out.length)
                        val n = reader.read(buffer, 0, want)
                        if (n <= 0) break
                        out.append(buffer, 0, n)
                    }
                    out.toString()
                }
            JSONObject().put("available", conn.responseCode in 200..299).put("response", runCatching { JSONObject(text) }.getOrElse { JSONObject().put("raw", text) })
        } finally { conn.disconnect() }
    }

    companion object {
        private const val MAX_IMAGE_BYTES = 2L * 1024L * 1024L
        private const val MAX_RESPONSE_CHARS = 24_000
        private val LOCAL_HOSTS = setOf("localhost", "127.0.0.1", "::1")
    }
}
