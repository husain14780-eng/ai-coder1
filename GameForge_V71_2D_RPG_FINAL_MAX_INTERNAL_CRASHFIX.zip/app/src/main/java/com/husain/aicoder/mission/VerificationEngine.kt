package com.husain.aicoder.mission

import org.json.JSONObject

class VerificationEngine {
    data class Verdict(val accepted: Boolean, val reason: String, val evidence: List<String>)

    private val runtimeTools = setOf(
        "run_godot_test",
        "run_generated_game",
        "run_playtest"
    )

    fun evaluate(toolName: String, result: JSONObject, priorFailures: Int): Verdict {
        val ok = result.optBoolean("ok")
        val evidenceText = result.optString("evidence")
        val evidence = listOfNotNull(evidenceText.takeIf { it.isNotBlank() })
        val observation = result.optJSONObject("observation")
        val observationHealthy = observation != null &&
            !observation.optBoolean("crashed", false) &&
            !observation.optBoolean("runtime_error", false) &&
            (observation.optJSONArray("errors")?.length() ?: 0) == 0

        val freshRuntimePass = ok && toolName in runtimeTools && (
            (toolName == "run_playtest" &&
                result.optInt("iterations", 0) > 0 &&
                result.optInt("passes", 0) == result.optInt("iterations", 0) &&
                result.optDouble("pass_rate", 0.0) >= 1.0) ||
            (toolName != "run_playtest" && (observationHealthy || evidenceText.contains("observation", true)))
        )

        val accepted = freshRuntimePass && evidence.isNotEmpty()
        val reason = when {
            accepted -> "fresh runtime/test evidence supports completion"
            !ok -> "verification tool reported failure"
            toolName !in runtimeTools -> "tool is not a completion-grade runtime verifier"
            priorFailures >= 3 -> "verification incomplete after repeated failures"
            evidence.isEmpty() -> "no fresh evidence"
            else -> "runtime verification incomplete"
        }
        return Verdict(accepted, reason, evidence)
    }

    fun evaluateFinal(results: List<Pair<String, JSONObject>>): Verdict {
        val evidence = results.flatMap { (_, r) ->
            listOfNotNull(r.optString("evidence").takeIf { it.isNotBlank() })
        }
        val runtimePass = results.any { (name, r) ->
            r.optBoolean("ok") && name in runtimeTools &&
                if (name == "run_playtest") {
                    r.optInt("iterations", 0) > 0 &&
                        r.optInt("passes", 0) == r.optInt("iterations", 0) &&
                        r.optDouble("pass_rate", 0.0) >= 1.0
                } else {
                    r.has("observation")
                }
        }
        val godotPass = results.any { (name, r) -> name == "run_godot_test" && r.optBoolean("ok") && r.has("observation") }
        val playtestPass = results.any { (name, r) ->
            name == "run_playtest" && r.optBoolean("ok") &&
                r.optInt("iterations", 0) > 0 &&
                r.optInt("passes", 0) == r.optInt("iterations", 0) &&
                r.optDouble("pass_rate", 0.0) >= 1.0
        }
        val accepted = runtimePass && godotPass && playtestPass && evidence.isNotEmpty() &&
            results.none { (_, r) -> r.optBoolean("crashed") || r.optBoolean("runtime_error") }
        return Verdict(
            accepted = accepted,
            reason = if (accepted) "final runtime evidence is fresh and healthy" else "final runtime verification did not provide sufficient healthy evidence",
            evidence = evidence.takeLast(12)
        )
    }
}
