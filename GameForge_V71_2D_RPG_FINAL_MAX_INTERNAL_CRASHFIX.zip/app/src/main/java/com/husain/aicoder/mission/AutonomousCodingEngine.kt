package com.husain.aicoder.mission

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.husain.aicoder.agent.CodingWorkspace
import com.husain.aicoder.agent.ToolExecutor
import com.husain.aicoder.core.AgentRoles
import com.husain.aicoder.core.DynamicReasoningPolicy
import com.husain.aicoder.core.HeavyTaskCoordinator
import com.husain.aicoder.memory.ContextLedger
import com.husain.aicoder.memory.MemoryRetriever
import com.husain.aicoder.ml.ContinuousLearningManager
import com.husain.aicoder.skills.SkillLibrary
import kotlinx.coroutines.flow.collect
import org.json.JSONObject

/** GameForge V7 long-horizon implementation agent with explicit one-script focus and evidence gates. */
class AutonomousCodingEngine(
    private val engine: InferenceEngine,
    private val workspace: CodingWorkspace,
    private val learning: ContinuousLearningManager,
    private val missions: MissionStore,
    private val memory: MemoryRetriever,
    private val skills: SkillLibrary,
    private val onStatus: (String) -> Unit = {}
) {
    private val policy = DynamicReasoningPolicy()
    private val verifier = VerificationEngine()
    private val reflection = ReflectionEngine(engine)
    private val ledger = ContextLedger(18000)
    private var executor: ToolExecutor? = null

    fun attachTools(toolExecutor: ToolExecutor) {
        executor = toolExecutor
    }

    suspend fun run(goal: String, maxSteps: Int = 60, resume: MissionState? = null): MissionState =
        HeavyTaskCoordinator.run("coding-mission") {
            runInternal(goal, maxSteps, resume)
        }

    private suspend fun runInternal(goal: String, maxSteps: Int, resume: MissionState?): MissionState {
        val tool = executor ?: error("Tools not attached")
        var state = resume ?: missions.create(goal, maxSteps)
        state = state.copy(phase = "planning")
        missions.save(state)
        ledger.add("goal", goal)

        tool.execute("checkpoint", JSONObject().put("label", "before_${state.id}"))

        val tasks = if (state.tasks.isNotEmpty()) {
            state.tasks
        } else {
            plan(goal).mapIndexed { i, title ->
                MissionTask(
                    id = "t_${i + 1}",
                    title = title,
                    verification = "fresh runtime/test evidence for: $title"
                )
            }
        }
        state = state.copy(tasks = tasks)
        missions.save(state)
        onStatus("MAX plan: ${tasks.size} tasks")

        var current = state
        val startIndex = tasks.indexOfFirst { it.status != "verified" }
            .let { if (it < 0) tasks.size else it }

        for (taskIndex in startIndex until tasks.size) {
            val title = current.tasks[taskIndex].title
            val savedTask = current.tasks[taskIndex]
            val requiresFocusFromTitle = titleNeedsScriptFocus(title)

            current = current.copy(
                phase = "implementation",
                step = current.step + 1,
                tasks = current.tasks.mapIndexed { i, t ->
                    if (i == taskIndex) t.copy(
                        status = "active",
                        attempts = t.attempts + 1,
                        lastError = "",
                        lastTestEvidence = ""
                    ) else t
                }
            )
            missions.save(current)
            ledger.add("task", "${taskIndex + 1}/${tasks.size}: $title")

            var taskDone = false
            var localAttempts = 0
            var baselineHash = savedTask.baselineSha256
            var focusClaimed = savedTask.targetPath.isNotBlank()

            if (focusClaimed) {
                workspace.beginAgentScriptFocus(savedTask.targetPath)
                if (baselineHash.isBlank()) {
                    baselineHash = runCatching { workspace.sha256(savedTask.targetPath) }.getOrDefault("")
                    current = current.copy(
                        tasks = current.tasks.mapIndexed { i, t ->
                            if (i == taskIndex) t.copy(baselineSha256 = baselineHash) else t
                        }
                    )
                    missions.save(current)
                }
            }

            try {
                while (!taskDone && current.step < maxSteps) {
                    localAttempts++
                    val retrieved = memory.retrieve("$goal $title", 4)
                    val skillText = skills.retrieve("$goal $title", 3).joinToString("\n") { it.toString() }
                    val decision = policy.choose(
                        current.phase,
                        current.failures,
                        current.toolCalls,
                        verifiedTests = countVerified(),
                        hasFreshEvidence = hasEvidence()
                    )
                    val taskLower = title.lowercase()
                    val role = when {
                        current.failures >= 2 -> AgentRoles.DEBUGGER
                        listOf("design", "loop", "mechanic", "progression").any { taskLower.contains(it) } -> AgentRoles.GAME_DESIGNER
                        listOf("architecture", "system", "dependency", "refactor").any { taskLower.contains(it) } -> AgentRoles.ARCHITECT
                        listOf("level", "scene", "layout", "map").any { taskLower.contains(it) } -> AgentRoles.LEVEL_DESIGNER
                        listOf("visual", "material", "lighting", "vfx", "asset").any { taskLower.contains(it) } -> AgentRoles.TECHNICAL_ARTIST
                        listOf("ui", "menu", "hud", "settings").any { taskLower.contains(it) } -> AgentRoles.UI_ENGINEER
                        listOf("performance", "fps", "optimization", "memory").any { taskLower.contains(it) } -> AgentRoles.PERFORMANCE
                        listOf("playtest", "qa", "quality", "edge case").any { taskLower.contains(it) } -> AgentRoles.QA
                        localAttempts > 2 -> AgentRoles.CRITIC
                        else -> AgentRoles.CODER
                    }
                    val requiresScriptFocus = requiresFocusFromTitle || focusClaimed || isGdScriptCodingRole(role)
                    val prompt = buildPrompt(
                        goal = goal,
                        task = title,
                        state = current,
                        role = role,
                        memories = retrieved,
                        skills = skillText,
                        focusPath = workspace.currentAgentScriptFocus(),
                        requiresScriptFocus = requiresScriptFocus,
                        baselineHash = baselineHash
                    )
                    val effectiveDecision = if (isCodingRole(role)) {
                        decision.copy(
                            mode = com.arm.aichat.ReasoningMode.THINKING,
                            maxTokens = maxOf(decision.maxTokens, 1800),
                            temperature = 0.58f,
                            reason = "GameForge coding must use deliberate agent-level thinking"
                        )
                    } else {
                        decision
                    }

                    val output = generate(prompt, effectiveDecision)
                    learning.recordAgentTurn(goal, effectiveDecision.mode.name, output)
                    ledger.add("assistant", output.take(7000))
                    onStatus(
                        "MAX $role ${effectiveDecision.mode.name} step=${current.step} " +
                            "tools=${current.toolCalls} failures=${current.failures}: ${output.take(170)}"
                    )

                    val call = parseToolCall(output)
                    if (call != null) {
                        val result = tool.execute(call.first, call.second)
                        val ok = result.optBoolean("ok")
                        val evidence = result.optString("evidence")

                        if (call.first == "claim_script" && ok) {
                            val claimed = result.optString("path").trim()
                            workspace.beginAgentScriptFocus(claimed)
                            focusClaimed = true
                            baselineHash = result.optString("baseline_sha256").ifBlank {
                                result.optString("sha256").ifBlank {
                                    runCatching { workspace.sha256(claimed) }.getOrDefault("__MISSING__")
                                }
                            }
                            current = current.copy(
                                tasks = current.tasks.mapIndexed { i, t ->
                                    if (i == taskIndex) t.copy(
                                        targetPath = claimed,
                                        baselineSha256 = baselineHash,
                                        currentSha256 = baselineHash
                                    ) else t
                                }
                            )
                        }

                        val focusPath = workspace.currentAgentScriptFocus()
                        val currentHash = if (focusPath != null && workspace.agentTargetExists(focusPath)) {
                            runCatching { workspace.sha256(focusPath) }.getOrDefault("")
                        } else {
                            ""
                        }
                        val scriptChanged = focusClaimed &&
                            baselineHash.isNotBlank() &&
                            currentHash.isNotBlank() &&
                            currentHash != baselineHash

                        current = current.copy(
                            step = current.step + 1,
                            toolCalls = current.toolCalls + 1,
                            failures = if (ok) {
                                (current.failures - 1).coerceAtLeast(0)
                            } else {
                                current.failures + 1
                            },
                            evidence = (
                                current.evidence +
                                    (evidence.takeIf { it.isNotBlank() }?.let { listOf(it) } ?: emptyList())
                                ).takeLast(30),
                            tasks = current.tasks.mapIndexed { i, t ->
                                if (i == taskIndex) t.copy(
                                    currentSha256 = currentHash,
                                    lastError = if (!ok) result.optString("error").take(1200) else t.lastError,
                                    lastTestEvidence = if (
                                        call.first in setOf("run_godot_test", "run_generated_game", "run_playtest")
                                    ) {
                                        evidence.take(1200)
                                    } else {
                                        t.lastTestEvidence
                                    }
                                ) else {
                                    t
                                }
                            }
                        )
                        missions.save(current)
                        ledger.add("tool:${call.first}", result.toString().take(9000))
                        learning.recordExperience(
                            goal,
                            "$title\n${ledger.compact()}",
                            call.first,
                            result.toString(),
                            ok
                        )

                        if (call.first in setOf("run_godot_test", "run_generated_game", "run_playtest")) {
                            val verdict = verifier.evaluate(call.first, result, current.failures)
                            val editRequirementSatisfied = (!focusClaimed && !requiresFocusFromTitle) || scriptChanged
                            if (verdict.accepted && editRequirementSatisfied) {
                                taskDone = true
                                val task = current.tasks[taskIndex]
                                current = current.copy(
                                    tasks = current.tasks.mapIndexed { i, t ->
                                        if (i == taskIndex) t.copy(
                                            status = "verified",
                                            currentSha256 = currentHash,
                                            lastTestEvidence = verdict.evidence.joinToString(" | ").take(1800)
                                        ) else t
                                    },
                                    evidence = (current.evidence + verdict.evidence).takeLast(30)
                                )
                                missions.save(current)
                                onStatus(
                                    "Verified ${if (task.targetPath.isNotBlank()) "script" else "task"} " +
                                        "${taskIndex + 1}/${tasks.size}: ${task.targetPath.ifBlank { "no direct script edit" }}"
                                )
                            }
                        }

                        if (!ok) {
                            val ref = reflection.summarize(goal, ledger.compact())
                            learning.recordExperience(goal, ledger.compact(), "reflection", ref, false)
                            ledger.add("reflection", ref)
                            current = current.copy(phase = "debugging")
                            missions.save(current)
                        } else {
                            current = current.copy(phase = "implementation")
                        }
                    } else if (output.contains("DONE", true)) {
                        current = current.copy(
                            failures = current.failures + 1,
                            phase = "verification"
                        )
                        missions.save(current)
                    } else {
                        current = current.copy(
                            failures = current.failures + 1,
                            phase = "debugging",
                            step = current.step + 1
                        )
                        missions.save(current)
                    }

                    if (current.failures >= 5) {
                        onStatus("Too many failures; asking critic before continuing")
                        val critic = generate(
                            buildPrompt(
                                goal = goal,
                                task = title,
                                state = current,
                                role = AgentRoles.CRITIC,
                                memories = memory.retrieve(goal, 6),
                                skills = skills.retrieve(goal, 4).joinToString("\n"),
                                focusPath = workspace.currentAgentScriptFocus(),
                                requiresScriptFocus = workspace.currentAgentScriptFocus() != null,
                                baselineHash = baselineHash
                            ),
                            DynamicReasoningPolicy().choose(
                                "critique",
                                current.failures,
                                current.toolCalls,
                                countVerified(),
                                hasEvidence()
                            )
                        )
                        ledger.add("critic", critic)
                        learning.recordAgentTurn(goal, "CRITIC", critic)
                        current = current.copy(failures = 0, phase = "debugging")
                        missions.save(current)
                    }
                }
            } finally {
                workspace.endAgentScriptFocus()
            }

            if (!taskDone) {
                current = current.copy(
                    completed = false,
                    summary = "Stopped before verifying focused task: $title"
                )
                missions.save(current)
                return current
            }
        }

        val finalTest = tool.execute("run_godot_test", JSONObject())
        val finalPlaytest = tool.execute(
            "run_playtest",
            JSONObject().put("iterations", 2)
        )
        val finalVerdict = verifier.evaluateFinal(
            listOf(
                "run_godot_test" to finalTest,
                "run_playtest" to finalPlaytest
            )
        )

        current = current.copy(
            evidence = (current.evidence + finalVerdict.evidence).takeLast(30),
            phase = if (finalVerdict.accepted) "final_review" else "verification"
        )
        missions.save(current)

        if (!finalVerdict.accepted) {
            val finalSummary = "Final runtime verification failed: ${finalVerdict.reason}. " +
                finalTest.optString("error", finalTest.optString("evidence")).take(1000)
            current = current.copy(completed = false, summary = finalSummary)
            missions.save(current)
            return current
        }

        val finalCritique = generate(
            buildPrompt(
                goal = goal,
                task = "final system review",
                state = current,
                role = AgentRoles.CRITIC,
                memories = memory.retrieve(goal, 8),
                skills = skills.retrieve(goal, 5).joinToString("\n"),
                focusPath = null,
                requiresScriptFocus = false,
                baselineHash = ""
            ),
            DynamicReasoningPolicy().choose(
                "critique",
                current.failures,
                current.toolCalls,
                countVerified(),
                hasEvidence()
            )
        )
        ledger.add("final_critic", finalCritique)
        val finalReflection = reflection.summarize(goal, ledger.compact())

        learning.recordExperience(goal, ledger.compact(), "verified_mission", finalReflection, true)
        skills.upsert(
            name = "verified_${goal.take(48).replace(Regex("[^A-Za-z0-9_-]+"), "_")}",
            trigger = goal,
            procedure = current.tasks.map { it.title },
            evidence = (current.evidence + finalVerdict.evidence).takeLast(8).joinToString(" | "),
            failureModes = listOfNotNull(
                finalCritique.takeIf { it.contains("risk", true) }?.take(500)
            )
        )

        current = current.copy(
            phase = "complete",
            completed = true,
            summary = finalReflection.take(5000)
        )
        missions.save(current)
        learning.recordOutcome(goal, true, finalReflection)
        return current
    }

    private suspend fun plan(goal: String): List<String> {
        val prompt = """
            TASK_ROLE: REASONING
            ${AgentRoles.instruction(AgentRoles.ARCHITECT)}
            Goal: $goal
            Return 5-14 numbered implementation tasks. Each line must begin with TASK:. Include a concise verification rule and optionally one role tag such as [GAMEPLAY], [LEVEL], [UI], [ART], [PERF], [QA], [ARCH]. Prioritize a functioning core loop before polish.
        """.trimIndent()
        val out = generate(prompt, DynamicReasoningPolicy().choose("planning", 0, 0, 0, false))
        val parsed = out.lines().mapNotNull { line ->
            val t = line.substringAfter("TASK:", "").trim()
            t.takeIf { it.isNotBlank() }
        }.take(10)
        return if (parsed.isEmpty()) {
            listOf(
                "Inspect the existing project",
                "Implement the requested change",
                "Run tests and verify the result"
            )
        } else {
            parsed
        }
    }

    private suspend fun generate(
        prompt: String,
        decision: DynamicReasoningPolicy.Decision
    ): String {
        val out = StringBuilder()
        engine.sendUserPrompt(
            prompt,
            GenerationConfig(
                decision.mode,
                decision.maxTokens,
                decision.temperature,
                if (decision.mode.name == "THINKING") 0.95f else 0.8f,
                20,
                0f,
                1.05f
            )
        ).collect { out.append(it) }
        return out.toString().replace(Regex("</?think>"), "").trim()
    }

    private fun titleNeedsScriptFocus(title: String): Boolean =
        title.lowercase().contains(
            Regex("""\b(implement|fix|edit|code|script|refactor|feature|mechanic|system)\b""")
        )

    private fun isCodingRole(role: String): Boolean = role in setOf(
        AgentRoles.CODER,
        AgentRoles.GAMEPLAY,
        AgentRoles.UI_ENGINEER,
        AgentRoles.LEVEL_DESIGNER,
        AgentRoles.TECHNICAL_ARTIST,
        AgentRoles.PERFORMANCE,
        AgentRoles.DEBUGGER
    )

    /** Only roles that normally mutate GDScript require a claimed single-script focus before verification. */
    private fun isGdScriptCodingRole(role: String): Boolean = role in setOf(
        AgentRoles.CODER,
        AgentRoles.GAMEPLAY,
        AgentRoles.UI_ENGINEER,
        AgentRoles.PERFORMANCE,
        AgentRoles.DEBUGGER
    )

    private fun buildPrompt(
        goal: String,
        task: String,
        state: MissionState,
        role: String,
        memories: List<String>,
        skills: String,
        focusPath: String?,
        requiresScriptFocus: Boolean,
        baselineHash: String
    ): String = buildString {
        val routingRole = when (role) {
            AgentRoles.ARCHITECT,
            AgentRoles.CRITIC,
            AgentRoles.DEBUGGER,
            AgentRoles.GAME_DESIGNER -> "REASONING"
            else -> "CODING"
        }
        append("TASK_ROLE: $routingRole\n")
        append("You are GameForge V7 2D RPG Max Factory. Role: $role\n")
        append(AgentRoles.instruction(role)).append('\n')
        append("Mission goal: ").append(goal).append('\n')
        append("Current task: ").append(task).append('\n')
        append("Mission state: phase=${state.phase}, step=${state.step}/${state.maxSteps}, failures=${state.failures}, toolCalls=${state.toolCalls}\n")
        append("Verified evidence: ").append(state.evidence.takeLast(8).joinToString(" | ")).append('\n')
        append("SINGLE-SCRIPT FOCUS: ").append(focusPath ?: "NONE").append('\n')
        append("SCRIPT EDIT REQUIRED: ").append(requiresScriptFocus).append('\n')
        append("BASELINE SCRIPT SHA256: ").append(baselineHash.ifBlank { "not claimed yet" }).append('\n')
        if (requiresScriptFocus && focusPath == null) {
            append(
                "MANDATORY NEXT STEP: inspect the project, then claim exactly ONE .gd script with " +
                    "claim_script. You may read other files, but you may not edit any file until the script is claimed.\n"
            )
        } else if (requiresScriptFocus && focusPath != null) {
            append(
                "EDIT RULE: You may edit ONLY $focusPath. Do not write, replace, append, rename, or " +
                    "generate another .gd directly. Read other files only for dependency context. " +
                    "Stay on this script until its runtime verification passes.\n"
            )
        }
        append("Useful memories:\n").append(memories.joinToString("\n---\n")).append('\n')
        append("Useful skills:\n").append(skills.take(9000)).append('\n')
        append("Working ledger:\n").append(ledger.compact()).append('\n')
        append(
            "Available tools: claim_script, get_script_focus, read_file, read_file_range, write_file, " +
                "replace_text, append_file, list_files, search_text, hash_file, checkpoint, list_checkpoints, " +
                "restore_checkpoint, create_version, list_versions, mark_version, restore_version, " +
                "mark_version_stable, get_last_observation, get_game_observation, get_local_vision_status, " +
                "get_research_status, web_search, web_open, research, route_model, get_mission_context, " +
                "inspect_project_graph, write_project_graph, write_project_index, analyze_change_impact, " +
                "profile_project, write_profile_report, analyze_visual_quality, write_visual_quality_report, " +
                "read_game_spec, generate_2d_asset, generate_2d_map, validate_2d_assets, audit_asset_pipeline, " +
                "plan_mmorpg_world, run_massive_qa, package_game, run_generated_game, run_godot_test, " +
                "run_playtest, run_command, game_action, wait.\n"
        )
        append(
            "Choose exactly one next action. For 2D assets/maps, prefer generation tools over hard-coded " +
                "fixed assets. Use one <tool_call>{\"name\":...,\"arguments\":{...}}</tool_call> block, " +
                "or explain why no tool is needed. Never claim success without fresh evidence. A coding task " +
                "is not complete merely because a file changed; the focused script must be tested after the final edit.\n"
        )
    }

    private fun parseToolCall(text: String): Pair<String, JSONObject>? {
        val s = text.indexOf("<tool_call>")
        val e = text.indexOf("</tool_call>", s + 11)
        if (s < 0 || e <= s) return null
        val obj = runCatching { JSONObject(text.substring(s + 11, e).trim()) }.getOrNull() ?: return null
        val name = obj.optString("name").trim()
        if (name.isBlank()) return null
        return name to (obj.optJSONObject("arguments") ?: JSONObject())
    }

    private fun countVerified(): Int =
        ledger.snapshot().lineSequence().count { it.contains("verified", true) }

    private fun hasEvidence(): Boolean =
        ledger.snapshot().contains("evidence", true)

    fun latestMission(): MissionState? =
        missions.latestIncomplete() ?: missions.list().firstOrNull()

    suspend fun resumeLatest(maxSteps: Int = 60): MissionState? =
        missions.latestIncomplete()?.let { run(it.goal, maxSteps, it) }
}
