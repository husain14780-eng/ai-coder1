package com.husain.aicoder.agent

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.arm.aichat.ReasoningMode
import com.husain.aicoder.core.HeavyTaskCoordinator
import com.husain.aicoder.godot.AICoderGodotBridge
import com.husain.aicoder.ml.ContinuousLearningManager
import kotlinx.coroutines.flow.collect
import org.json.JSONObject

/**
 * Long-horizon coding agent. The base model stays immutable; experience is persisted separately.
 */
class CodingAgent(
    private val engine: InferenceEngine,
    private val workspace: CodingWorkspace,
    private val learning: ContinuousLearningManager,
    private val context: android.content.Context? = null
) {
    private var tools: ToolExecutor? = null

    fun attachTools(bridge: AICoderGodotBridge?) {
        val appContext = context ?: throw IllegalStateException("CodingAgent requires Android context for in-app tools")
        tools = ToolExecutor(appContext, workspace, bridge)
    }

    fun observe(json: String): String = tools?.observe(json) ?: json

    suspend fun configure() {
        engine.setSystemPrompt(
            """
            You are GameForge V7 2D RPG Max Factory, a rigorous local game-engineering agent running on the selected local specialist (Qwen2.5-Coder-7B for coding, Qwen3-4B-Thinking for deep reasoning).
            TASK_ROLE: CODING
            Goal: produce a complete working game, not plausible text.

            Rules:
            1. Inspect relevant files before editing.
            2. Prefer small, reversible edits. Never overwrite unrelated work.
            3. Use tools to inspect, edit and test. Do not invent tool results.
            4. After an edit, run the narrowest useful test; after a successful narrow test, run a broader test when practical.
            5. Treat compiler/runtime/test failures as evidence. Diagnose from the actual error before changing code.
            6. For tool use emit exactly one call in this format and nothing else in that turn:
               <tool_call>{"name":"read_file","arguments":{"path":"..."}}</tool_call>
            7. Available tools: claim_script, get_script_focus, read_file, read_file_range, write_file, replace_text, append_file, list_files, search_text,
               hash_file, checkpoint, list_checkpoints, restore_checkpoint, get_last_observation, get_game_observation, get_local_vision_status, get_research_status, web_search, web_open, research, read_game_spec, generate_2d_asset, generate_2d_map, validate_2d_assets, audit_asset_pipeline, plan_mmorpg_world, run_massive_qa, inspect_project_graph, analyze_change_impact, profile_project, analyze_visual_quality, create_version, list_versions, mark_version, restore_version, mark_version_stable, run_godot_test, run_generated_game, run_playtest, game_action, wait.
            8. SINGLE-SCRIPT CODING RULE: for every coding/debugging task, inspect dependencies first, then call claim_script for exactly ONE .gd target. After claiming it, you may read other files for context but may edit ONLY the focused .gd with write_file/replace_text/append_file. Stay on that same script through every repair/retest cycle until fresh runtime evidence passes; do not switch to another script because the first edit is difficult.
            9. For 2D RPG/MMORPG work, generate or regenerate assets from the current game instead of inventing paths to fixed art. Use generate_2d_asset and generate_2d_map, then validate with validate_2d_assets and bot playtests. For custom art, author a `visual_recipe` with normalized rect/ellipse/circle/line layers plus a motion recipe; for maps, you may author an ASCII `layout` (`#` wall, `.` floor, `~` water, `S` spawn, `G` goal) so the AI defines the actual geometry rather than selecting a fixed map.
            10. When the mission is genuinely complete, emit: DONE: <concise verified summary>.
            11. Never say a test passed unless the tool returned evidence of success.
            12. Never expose hidden chain-of-thought. Summarize decisions and evidence instead.
            """.trimIndent()
        )
    }

    suspend fun run(goal: String, maxSteps: Int = 30, onStatus: (String) -> Unit = {}) =
        HeavyTaskCoordinator.run("coding-agent") coding@ {
        val executor = tools ?: error("Tools not attached")
        var transcript = "Goal: $goal\n"
        var failures = 0
        var toolCalls = 0
        var successfulTests = 0

        try {
        for (step in 1..maxSteps) {
            // Coding is deliberately run in THINKING mode. For Qwen2.5-Coder this is
            // an agent-level deliberate-planning mode, not a claim that the base model
            // has Qwen3-style native thinking tokens.
            val thinking = true
            val mode = if (thinking) ReasoningMode.THINKING else ReasoningMode.FAST
            val maxTokens = if (thinking) 1800 else 900
            val prompt = buildPrompt(transcript, step, maxSteps, failures, toolCalls, successfulTests)
            val output = generate(prompt, mode, maxTokens)
            learning.recordAgentTurn(goal, mode.name, output)
            onStatus("step=$step/$maxSteps mode=${mode.name} tools=$toolCalls failures=$failures ${output.take(180)}")

            val call = parseToolCall(output)
            if (call == null) {
                if (output.contains("DONE", ignoreCase = true) && successfulTests > 0 && workspace.currentAgentScriptFocus() != null) {
                    learning.recordOutcome(goal, true, output)
                    return@coding
                }
                failures++
                transcript += "\nAssistant: ${output.take(4000)}\n"
                continue
            }

            toolCalls++
            val result = executor.execute(call.first, call.second)
            val ok = result.optBoolean("ok", false)
            if (!ok) failures++ else if (failures > 0) failures--
            if (ok && call.first == "run_godot_test") successfulTests++

            transcript += "\nTool ${call.first} args=${call.second}\nResult=${result.toString().take(14000)}\n"
            if (toolCalls >= 2 && successfulTests == 0 && step >= 4) {
                transcript += "\nVerifier reminder: no successful test evidence yet. Do not declare DONE.\n"
            }
        }

        learning.recordOutcome(goal, false, "max steps reached; toolCalls=$toolCalls successfulTests=$successfulTests")
        } finally {
            workspace.endAgentScriptFocus()
        }
        }

    private fun buildPrompt(
        transcript: String,
        step: Int,
        maxSteps: Int,
        failures: Int,
        toolCalls: Int,
        successfulTests: Int
    ): String = buildString {
        append(transcript)
        append("\nStep ").append(step).append('/').append(maxSteps)
        append(" | failures=").append(failures)
        append(" | tool_calls=").append(toolCalls)
        append(" | verified_tests=").append(successfulTests)
        append("\nChoose exactly one next action. Inspect before editing. ")
        append("If a tool is required, emit exactly one <tool_call> JSON block. ")
        append("Otherwise emit DONE only when the available evidence supports completion.")
    }

    private suspend fun generate(prompt: String, mode: ReasoningMode, maxTokens: Int): String {
        val out = StringBuilder()
        engine.sendUserPrompt(
            prompt,
            GenerationConfig(
                mode = mode,
                maxTokens = maxTokens,
                temperature = if (mode == ReasoningMode.THINKING) 0.6f else 0.7f,
                topP = if (mode == ReasoningMode.THINKING) 0.95f else 0.8f,
                topK = 20,
                minP = 0f,
                repeatPenalty = 1.05f
            )
        ).collect { out.append(it) }
        return stripReasoning(out.toString())
    }

    private fun stripReasoning(text: String): String {
        val closed = text.lastIndexOf("</think>")
        return if (closed >= 0) text.substring(closed + "</think>".length).trim() else text.trim()
    }

    private fun parseToolCall(text: String): Pair<String, JSONObject>? {
        val s = text.indexOf("<tool_call>")
        val e = text.indexOf("</tool_call>", s + 11)
        if (s < 0 || e <= s) return null
        val body = text.substring(s + 11, e).trim()
        val obj = runCatching { JSONObject(body) }.getOrNull() ?: return null
        val name = obj.optString("name").trim()
        if (name.isBlank()) return null
        val args = obj.optJSONObject("arguments") ?: JSONObject()
        return name to args
    }
}
