package com.husain.aicoder.game

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Deep generated-art validation, reference integrity, and cross-asset consistency gate. */
class AssetQualityPipeline(private val workspace: CodingWorkspace) {
    fun audit(): JSONObject {
        val files = workspace.listAllFiles(20000)
        val generated = files.filter { it.startsWith("generated/") }
        val pngs = generated.filter { it.endsWith(".png", true) }
        val svgs = generated.filter { it.endsWith(".svg", true) }
        val manifests = generated.filter {
            it.endsWith("animation_manifest.json", true) ||
                (it.endsWith(".json", true) && it.contains("manifest", ignoreCase = true))
        }
        val corrupt = JSONArray()
        val empty = JSONArray()
        val dimensions = linkedSetOf<String>()
        val fps = linkedSetOf<Int>()
        val styleHashes = linkedSetOf<String>()
        val referencedFrames = linkedSetOf<String>()
        var maxPixels = 0L
        var hugeImages = 0

        for (path in pngs) {
            val file = File(workspace.root, path)
            if (!file.isFile || file.length() == 0L) {
                empty.put(path)
                continue
            }
            val bytes = runCatching { file.inputStream().use { it.readNBytes(33) } }.getOrDefault(ByteArray(0))
            val validHeader = bytes.size >= 24 && bytes.sliceArray(0 until 8).contentEquals(
                byteArrayOf(137.toByte(), 80, 78, 71, 13, 10, 26, 10)
            )
            if (!validHeader) {
                corrupt.put(path)
                continue
            }
            val width = readInt(bytes, 16)
            val height = readInt(bytes, 20)
            val pixels = width.toLong().coerceAtLeast(0L) * height.toLong().coerceAtLeast(0L)
            maxPixels = maxOf(maxPixels, pixels)
            if (width <= 0 || height <= 0 || width > 8192 || height > 8192 || pixels > 64_000_000L) {
                corrupt.put(path)
            } else {
                dimensions += "${width}x${height}"
                if (pixels > 16_000_000L) hugeImages++
            }
        }

        var missingFrames = 0
        var manifestErrors = 0
        var manifestCount = 0
        var invalidFps = 0
        var duplicateFrames = 0
        val referencedSet = linkedSetOf<String>()
        for (path in manifests) {
            val file = File(workspace.root, path)
            if (!file.isFile) continue
            val obj = runCatching { JSONObject(file.readText()) }.getOrNull()
            if (obj == null) {
                manifestErrors++
                continue
            }
            manifestCount++
            val manifestFps = obj.optInt("fps", -1)
            if (manifestFps <= 0 || manifestFps > 120) invalidFps++ else fps += manifestFps
            obj.optJSONArray("palette")?.let { palette -> styleHashes += palette.toString().hashCode().toString() }
            val animations = obj.optJSONArray("animations")
            if (animations != null) {
                for (i in 0 until animations.length()) {
                    val animation = animations.optJSONObject(i) ?: continue
                    val framePaths = animation.optJSONArray("frame_paths") ?: continue
                    for (j in 0 until framePaths.length()) {
                        val rawFrame = framePaths.optString(j).trim()
                        if (rawFrame.isBlank()) continue
                        val frame = normalizeAssetPath(rawFrame)
                        if (frame.isBlank()) continue
                        if (!referencedSet.add(frame)) duplicateFrames++
                        referencedFrames += frame
                        val frameFile = safeWorkspaceFile(frame)
                        if (frameFile == null || !frameFile.isFile) missingFrames++
                    }
                }
            }
        }

        val orphanPngs = pngs.filter { it !in referencedFrames }
        val styleConsistency = styleHashes.size <= 1 || generated.size < 10
        val score = qualityScore(
            pngs.size,
            corrupt.length(),
            empty.length(),
            missingFrames,
            manifestErrors,
            invalidFps,
            styleConsistency,
            orphanPngs.size,
            hugeImages
        )
        val ok = corrupt.length() == 0 && empty.length() == 0 && missingFrames == 0 &&
            manifestErrors == 0 && invalidFps == 0 && styleConsistency && orphanPngs.isEmpty()

        return JSONObject()
            .put("ok", ok)
            .put("score", score)
            .put("generated_file_count", generated.size)
            .put("png_count", pngs.size)
            .put("svg_count", svgs.size)
            .put("manifest_count", manifestCount)
            .put("corrupt_pngs", corrupt)
            .put("empty_assets", empty)
            .put("missing_animation_frames", missingFrames)
            .put("manifest_errors", manifestErrors)
            .put("invalid_fps_manifests", invalidFps)
            .put("duplicate_frame_references", duplicateFrames)
            .put("unique_dimensions", dimensions.size)
            .put("max_image_pixels", maxPixels)
            .put("huge_image_count", hugeImages)
            .put("fps_variants", JSONArray(fps.toList().sorted()))
            .put("style_variants", styleHashes.size)
            .put("orphan_png_count", orphanPngs.size)
            .put("orphan_pngs", JSONArray(orphanPngs.take(200)))
            .put("recommendations", recommendations(corrupt, missingFrames, manifestErrors, invalidFps, styleConsistency, orphanPngs.size, hugeImages))
            .put("generated_at_ms", System.currentTimeMillis())
    }

    fun write(): String = workspace.write("gameforge/ASSET_QUALITY_REPORT.json", audit().toString(2))

    private fun qualityScore(
        pngs: Int,
        corrupt: Int,
        empty: Int,
        missing: Int,
        manifestErrors: Int,
        invalidFps: Int,
        styleConsistent: Boolean,
        orphan: Int,
        huge: Int
    ): Double {
        if (pngs == 0) return 0.0
        var score = 1.0
        score -= corrupt.toDouble() / pngs * 0.35
        score -= empty.toDouble() / pngs * 0.20
        score -= minOf(0.20, missing * 0.01)
        score -= minOf(0.10, manifestErrors * 0.02)
        score -= minOf(0.08, invalidFps * 0.01)
        score -= minOf(0.10, orphan * 0.004)
        score -= minOf(0.08, huge * 0.02)
        if (!styleConsistent) score -= 0.10
        return score.coerceIn(0.0, 1.0)
    }

    private fun recommendations(
        corrupt: JSONArray,
        missing: Int,
        manifestErrors: Int,
        invalidFps: Int,
        style: Boolean,
        orphan: Int,
        huge: Int
    ): JSONArray = JSONArray().apply {
        if (corrupt.length() > 0) put("Regenerate or repair corrupt PNG files before release.")
        if (missing > 0) put("Rebuild animation manifests whose frame paths are missing.")
        if (manifestErrors > 0) put("Repair malformed animation/style manifest JSON.")
        if (invalidFps > 0) put("Normalize animation FPS to a sane 1..120 range.")
        if (!style) put("Normalize palette/style manifests so characters, tiles and effects share a coherent visual language.")
        if (orphan > 0) put("Remove or register orphaned generated PNGs so every generated asset has a declared use.")
        if (huge > 0) put("Downscale oversized textures to reduce runtime memory and load time.")
        if (length() == 0) put("Asset filesystem, animation references, image headers, dimensions and style consistency passed.")
    }

    private fun normalizeAssetPath(path: String): String = path.trim()
        .removePrefix("res://")
        .removePrefix("./")
        .replace('\\', '/')
        .trimStart('/')

    private fun safeWorkspaceFile(relative: String): File? {
        val root = workspace.root.canonicalFile
        val candidate = runCatching { File(root, relative).canonicalFile }.getOrNull() ?: return null
        return if (candidate.path == root.path || candidate.path.startsWith(root.path + File.separator)) candidate else null
    }

    private fun readInt(bytes: ByteArray, offset: Int): Int {
        if (offset + 3 >= bytes.size) return -1
        return ((bytes[offset].toInt() and 0xff) shl 24) or
            ((bytes[offset + 1].toInt() and 0xff) shl 16) or
            ((bytes[offset + 2].toInt() and 0xff) shl 8) or
            (bytes[offset + 3].toInt() and 0xff)
    }
}
