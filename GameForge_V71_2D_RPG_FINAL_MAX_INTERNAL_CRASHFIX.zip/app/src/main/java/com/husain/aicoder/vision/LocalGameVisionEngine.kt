package com.husain.aicoder.vision

import android.graphics.Bitmap
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Deterministic in-process computer-vision engine for embedded Godot frames.
 * It never requests device-wide capture, accessibility, camera access, or a cloud vision service.
 * The output is compact enough for a text-only coding model while retaining a 64-D visual state.
 */
class LocalGameVisionEngine(
    private val patchGrid: Int = 16,
    private val embeddingSize: Int = 64,
    private val maxSampleWidth: Int = 256,
    private val maxSampleHeight: Int = 144
) {
    companion object { const val MODEL_ID = "GameVision-Local-7.1" }

    @Volatile private var previousEmbedding: FloatArray? = null

    fun resetTemporalState() {
        previousEmbedding = null
    }

    fun analyze(bitmap: Bitmap, telemetry: JSONObject = JSONObject()): JSONObject {
        require(bitmap.width > 0 && bitmap.height > 0) { "bitmap must have positive dimensions" }
        val sampled = downsample(bitmap)
        val features = patchFeatures(sampled)
        val embedding = projectEmbedding(features.values)
        val motion = comparePrevious(embedding)
        val scene = classifyScene(features, telemetry)
        val objects = detectRegions(sampled)
        val hud = detectHud(sampled)
        val quality = imageQuality(sampled, features)
        return JSONObject()
            .put("available", true)
            .put("backend", MODEL_ID)
            .put("model_version", MODEL_ID)
            .put("source", "embedded_godot_viewport")
            .put("width", bitmap.width)
            .put("height", bitmap.height)
            .put("sample_width", sampled.width)
            .put("sample_height", sampled.height)
            .put("scene", scene)
            .put("scene_label", scene.optString("label", "unknown"))
            .put("objects", JSONArray(objects))
            .put("hud", hud)
            .put("quality", quality)
            .put("embedding", JSONArray().apply { embedding.forEach { put(it.toDouble()) } })
            .put("motion_similarity", motion.optDouble("cosine_similarity", 1.0))
            .put("motion_delta", motion.optDouble("delta", 0.0))
            .put("mean_luminance", features.meanLuma)
            .put("edge_density", features.edgeDensity)
            .put("saturation", features.meanSaturation)
            .put("contrast", features.contrast)
            .put("confidence", confidence(features, objects.size, quality))
    }

    private data class PixelGrid(val width: Int, val height: Int, val pixels: IntArray) {
        fun pixel(x: Int, y: Int): Int = pixels[y * width + x]
    }

    private data class FeatureBundle(
        val values: FloatArray,
        val meanLuma: Double,
        val edgeDensity: Double,
        val meanSaturation: Double,
        val contrast: Double,
        val brightFraction: Double,
        val darkFraction: Double,
        val topLuma: Double,
        val bottomLuma: Double
    )

    private fun downsample(bitmap: Bitmap): PixelGrid {
        val scale = min(
            1.0,
            min(maxSampleWidth.toDouble() / bitmap.width.toDouble(), maxSampleHeight.toDouble() / bitmap.height.toDouble())
        )
        val width = max(32, (bitmap.width * scale).toInt()).coerceAtMost(maxSampleWidth)
        val height = max(18, (bitmap.height * scale).toInt()).coerceAtMost(maxSampleHeight)
        val source = if (width == bitmap.width && height == bitmap.height) bitmap
        else Bitmap.createScaledBitmap(bitmap, width, height, true)
        val pixels = IntArray(width * height)
        source.getPixels(pixels, 0, width, 0, 0, width, height)
        if (source !== bitmap) source.recycle()
        return PixelGrid(width, height, pixels)
    }

    private fun patchFeatures(grid: PixelGrid): FeatureBundle {
        val cells = patchGrid.coerceIn(8, 24)
        val perPatch = 10
        val values = FloatArray(cells * cells * perPatch)
        var index = 0
        var globalLuma = 0.0
        var globalSat = 0.0
        var globalLumaSq = 0.0
        var edges = 0.0
        var bright = 0.0
        var dark = 0.0
        var samples = 0
        var topSum = 0.0
        var topN = 0
        var bottomSum = 0.0
        var bottomN = 0
        for (py in 0 until cells) for (px in 0 until cells) {
            val x0 = px * grid.width / cells
            val x1 = max(x0 + 1, (px + 1) * grid.width / cells).coerceAtMost(grid.width)
            val y0 = py * grid.height / cells
            val y1 = max(y0 + 1, (py + 1) * grid.height / cells).coerceAtMost(grid.height)
            var lumaSum = 0.0
            var satSum = 0.0
            var rSum = 0.0
            var gSum = 0.0
            var bSum = 0.0
            var lumaSq = 0.0
            var localEdges = 0
            var localCount = 0
            for (y in y0 until y1) {
                var prev = -1.0
                for (x in x0 until x1) {
                    val p = grid.pixel(x, y)
                    val r = Color.red(p) / 255.0
                    val g = Color.green(p) / 255.0
                    val b = Color.blue(p) / 255.0
                    val l = 0.2126 * r + 0.7152 * g + 0.0722 * b
                    val hi = max(r, max(g, b))
                    val lo = min(r, min(g, b))
                    val sat = if (hi <= 1e-6) 0.0 else (hi - lo) / hi
                    lumaSum += l; satSum += sat; rSum += r; gSum += g; bSum += b; lumaSq += l * l
                    globalLuma += l; globalSat += sat; globalLumaSq += l * l; samples++
                    if (l > 0.82) bright++
                    if (l < 0.18) dark++
                    if (prev >= 0 && abs(l - prev) > 0.20) { localEdges++; edges++ }
                    prev = l; localCount++
                    if (py < cells / 3) { topSum += l; topN++ }
                    if (py >= cells * 2 / 3) { bottomSum += l; bottomN++ }
                }
            }
            val inv = 1.0 / max(1, localCount)
            val mean = lumaSum * inv
            val sat = satSum * inv
            val variance = max(0.0, lumaSq * inv - mean * mean)
            values[index++] = mean.toFloat()
            values[index++] = sat.toFloat()
            values[index++] = (rSum * inv).toFloat()
            values[index++] = (gSum * inv).toFloat()
            values[index++] = (bSum * inv).toFloat()
            values[index++] = sqrt(variance).toFloat()
            values[index++] = (localEdges * inv).toFloat()
            values[index++] = boundaryContrast(grid, x0, x1, y0, y1).toFloat()
            values[index++] = (py.toDouble() / cells).toFloat()
            values[index++] = (px.toDouble() / cells).toFloat()
        }
        val count = max(1, samples)
        val mean = globalLuma / count
        return FeatureBundle(
            values,
            mean,
            edges / count,
            globalSat / count,
            sqrt(max(0.0, globalLumaSq / count - mean * mean)),
            bright / count,
            dark / count,
            if (topN == 0) mean else topSum / topN,
            if (bottomN == 0) mean else bottomSum / bottomN
        )
    }

    private fun boundaryContrast(g: PixelGrid, x0: Int, x1: Int, y0: Int, y1: Int): Double {
        val xs = intArrayOf(x0.coerceIn(0, g.width - 1), (x1 - 1).coerceIn(0, g.width - 1), ((x0 + x1) / 2).coerceIn(0, g.width - 1))
        val ys = intArrayOf(y0.coerceIn(0, g.height - 1), (y1 - 1).coerceIn(0, g.height - 1), ((y0 + y1) / 2).coerceIn(0, g.height - 1))
        var mean = 0.0; var count = 0
        for (x in xs) for (y in ys) { mean += luma(g.pixel(x, y)); count++ }
        mean /= max(1, count)
        var variance = 0.0
        for (x in xs) for (y in ys) { val v = luma(g.pixel(x, y)); variance += (v - mean) * (v - mean) }
        return sqrt(variance / max(1, count))
    }

    private fun luma(p: Int): Double = (0.2126 * Color.red(p) + 0.7152 * Color.green(p) + 0.0722 * Color.blue(p)) / 255.0

    private fun projectEmbedding(values: FloatArray): FloatArray {
        val out = FloatArray(embeddingSize)
        if (values.isEmpty()) return out
        for (i in out.indices) {
            var sum = 0.0
            val phase = (i + 1) * 0.071
            for (j in values.indices) {
                val weight = sin((j + 1) * phase) * 0.62 + cos((j + 3) * phase * 0.37) * 0.38
                sum += values[j] * weight
            }
            out[i] = (sum / sqrt(values.size.toDouble())).toFloat()
        }
        var norm = 0.0
        for (v in out) norm += v * v
        val d = sqrt(norm).coerceAtLeast(1e-6)
        for (i in out.indices) out[i] /= d.toFloat()
        return out
    }

    private fun comparePrevious(current: FloatArray): JSONObject {
        val previous = previousEmbedding
        previousEmbedding = current.copyOf()
        if (previous == null || previous.size != current.size) return JSONObject().put("cosine_similarity", 0.0).put("delta", 1.0)
        var dot = 0.0; var a = 0.0; var b = 0.0
        for (i in current.indices) { dot += current[i] * previous[i]; a += current[i] * current[i]; b += previous[i] * previous[i] }
        val cosine = dot / (sqrt(a) * sqrt(b)).coerceAtLeast(1e-6)
        return JSONObject().put("cosine_similarity", cosine.coerceIn(-1.0, 1.0)).put("delta", (1.0 - cosine).coerceIn(0.0, 2.0))
    }

    private fun classifyScene(f: FeatureBundle, telemetry: JSONObject): JSONObject {
        val scores = linkedMapOf(
            "combat" to (telemetry.optInt("enemy_count", 0) * 0.12 + f.edgeDensity * 1.4 + (1.0 - f.meanLuma) * 0.20),
            "exploration" to (0.8 - abs(f.topLuma - f.bottomLuma) + (1.0 - f.edgeDensity) * 0.7),
            "dialogue" to (if (telemetry.optBoolean("dialogue_open", false)) 1.2 else 0.0) + f.edgeDensity * 0.3,
            "menu" to (if (telemetry.optBoolean("menu_open", false)) 1.4 else 0.0) + f.meanLuma * 0.2,
            "unknown" to 0.15
        )
        val best = scores.maxByOrNull { it.value }?.key ?: "unknown"
        return JSONObject().apply {
            put("label", best)
            put("scores", JSONObject(scores as Map<*, *>))
        }
    }

    private fun detectRegions(g: PixelGrid): List<JSONObject> {
        val cellsX = 12; val cellsY = 8
        val out = mutableListOf<JSONObject>()
        for (gy in 0 until cellsY) for (gx in 0 until cellsX) {
            val x0 = gx * g.width / cellsX; val x1 = max(x0 + 1, (gx + 1) * g.width / cellsX).coerceAtMost(g.width)
            val y0 = gy * g.height / cellsY; val y1 = max(y0 + 1, (gy + 1) * g.height / cellsY).coerceAtMost(g.height)
            var sum = 0.0; var bright = 0; var n = 0
            for (y in y0 until y1) for (x in x0 until x1) { val l = luma(g.pixel(x, y)); sum += l; if (l > 0.88) bright++; n++ }
            val mean = sum / max(1, n); val brightFrac = bright.toDouble() / max(1, n)
            if (brightFrac > 0.28 || (mean > 0.65 && mean < 0.92)) {
                out += JSONObject().put("x", gx.toDouble() / cellsX).put("y", gy.toDouble() / cellsY)
                    .put("w", 1.0 / cellsX).put("h", 1.0 / cellsY).put("score", (0.45 * brightFrac + 0.55 * mean))
            }
        }
        return out.sortedByDescending { it.optDouble("score", 0.0) }.take(18)
    }

    private fun detectHud(g: PixelGrid): JSONObject {
        val top = regionStats(g, 0, 0, g.width, max(1, g.height / 6))
        val bottom = regionStats(g, 0, g.height - max(1, g.height / 6), g.width, g.height)
        return JSONObject()
            .put("top_activity", top)
            .put("bottom_activity", bottom)
            .put("hud_likely", top.optDouble("edge_density", 0.0) > 0.12 || bottom.optDouble("edge_density", 0.0) > 0.12)
    }

    private fun regionStats(g: PixelGrid, x0: Int, y0: Int, x1: Int, y1: Int): JSONObject {
        var lSum = 0.0; var edges = 0; var n = 0
        for (y in y0 until y1) {
            var prev = -1.0
            for (x in x0 until x1) { val l = luma(g.pixel(x, y)); lSum += l; if (prev >= 0 && abs(l - prev) > 0.18) edges++; prev = l; n++ }
        }
        return JSONObject().put("mean_luminance", lSum / max(1, n)).put("edge_density", edges.toDouble() / max(1, n))
    }

    private fun imageQuality(g: PixelGrid, f: FeatureBundle): JSONObject {
        val clipping = (f.brightFraction + f.darkFraction).coerceAtMost(1.0)
        val sharpness = (f.edgeDensity * 2.8).coerceIn(0.0, 1.0)
        val detail = (f.contrast * 2.6).coerceIn(0.0, 1.0)
        val score = (0.35 * sharpness + 0.40 * detail + 0.25 * (1.0 - clipping * 0.65)).coerceIn(0.0, 1.0)
        return JSONObject().put("score", score).put("sharpness", sharpness).put("detail", detail).put("clipping", clipping).put("sample_pixels", g.width * g.height)
    }

    private fun confidence(f: FeatureBundle, objectCount: Int, quality: JSONObject): Double {
        val objectSignal = min(1.0, objectCount / 8.0)
        val qualitySignal = quality.optDouble("score", 0.0)
        val contrastSignal = min(1.0, f.contrast * 3.0)
        return (0.45 * qualitySignal + 0.30 * objectSignal + 0.25 * contrastSignal).coerceIn(0.0, 1.0)
    }
}
