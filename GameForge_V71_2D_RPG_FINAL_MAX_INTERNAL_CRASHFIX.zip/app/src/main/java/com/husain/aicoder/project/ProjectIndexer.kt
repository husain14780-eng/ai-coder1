package com.husain.aicoder.project

import com.husain.aicoder.agent.CodingWorkspace
import com.husain.aicoder.core.BoundedFileReader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.regex.Pattern

/** Lightweight symbol/file index used to make large Godot projects searchable without full parsing. */
class ProjectIndexer(private val workspace: CodingWorkspace) {
    private val function = Pattern.compile("(?:func|function|def)\\s+([A-Za-z_][A-Za-z0-9_]*)")
    private val className = Pattern.compile("(?:class_name|class)\\s+([A-Za-z_][A-Za-z0-9_]*)")

    fun build(): JSONObject {
        val files = JSONArray()
        workspace.root.walkTopDown().filter { it.isFile }.take(1600).forEach { f ->
            val rel = f.relativeTo(workspace.root).path.replace(File.separatorChar, '/')
            if (rel.startsWith(".git") || rel.startsWith("gameforge/runtime")) return@forEach
            if (f.length() > 512_000L || extensionOf(rel) !in TEXT_EXTENSIONS) return@forEach
            val text = runCatching { BoundedFileReader.headText(f, 256_000) }.getOrNull() ?: return@forEach
            val symbols = JSONArray()
            fun collect(p: Pattern, kind: String) {
                val m = p.matcher(text)
                while (m.find() && symbols.length() < 80) symbols.put(JSONObject().put("kind", kind).put("name", m.group(1)))
            }
            collect(className, "class")
            collect(function, "function")
            files.put(JSONObject().put("path", rel).put("bytes", f.length()).put("symbols", symbols))
        }
        return JSONObject().put("file_count", files.length()).put("files", files).put("generated_at_ms", System.currentTimeMillis())
    }

    private fun extensionOf(path: String): String = path.substringAfterLast('.', "").lowercase()

    companion object {
        private val TEXT_EXTENSIONS = setOf(
            "gd", "tscn", "tres", "godot", "json", "cfg", "ini", "toml", "txt", "md",
            "kt", "java", "xml", "yaml", "yml"
        )
    }

    fun write(): String = workspace.write("gameforge/PROJECT_INDEX.json", build().toString(2))
}
