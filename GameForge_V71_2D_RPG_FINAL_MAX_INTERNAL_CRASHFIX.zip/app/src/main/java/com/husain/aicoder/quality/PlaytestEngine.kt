package com.husain.aicoder.quality

import com.husain.aicoder.agent.ToolExecutor
import org.json.JSONArray
import org.json.JSONObject

/** Repeats smoke-test cycles against the current generated workspace pack. */
class PlaytestEngine(private val tools: ToolExecutor) {
    suspend fun run(iterations: Int = 5, mainScene: String = "main.tscn"): JSONObject {
        val n = iterations.coerceIn(1, 20)
        val loaded = tools.execute("run_generated_game", JSONObject().put("main_scene", mainScene))
        val results = JSONArray()
        var passes = 0
        val actions = listOf(
            JSONObject().put("type", "move").put("x", 0.65).put("jump", false),
            JSONObject().put("type", "jump").put("x", 0.0).put("jump", true),
            JSONObject().put("type", "move").put("x", -0.65).put("jump", false),
            JSONObject().put("type", "interact"),
            JSONObject().put("type", "attack"),
            JSONObject().put("type", "skill"),
            JSONObject().put("type", "bot_test")
        )
        repeat(n) { i ->
            val boot = tools.execute("run_godot_test", JSONObject())
            val actionRows = JSONArray()
            var iterationOk = boot.optBoolean("ok")
            if (iterationOk) {
                actions.forEach { action ->
                    val row = tools.execute("game_action", action)
                    actionRows.put(row)
                    if (!row.optBoolean("ok")) iterationOk = false
                }
            }
            val result = boot.put("iteration", i + 1).put("actions", actionRows).put("passed", iterationOk)
            if (iterationOk) passes++
            results.put(result)
        }
        return JSONObject()
            .put("ok", loaded.optBoolean("ok") && passes == n)
            .put("runtime_load", loaded)
            .put("iterations", n)
            .put("passes", passes)
            .put("pass_rate", passes.toDouble() / n)
            .put("results", results)
            .put("generated_at_ms", System.currentTimeMillis())
    }
}
