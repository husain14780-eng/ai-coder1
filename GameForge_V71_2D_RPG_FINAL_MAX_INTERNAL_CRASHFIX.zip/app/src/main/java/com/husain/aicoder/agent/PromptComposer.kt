package com.husain.aicoder.agent

import com.husain.aicoder.core.ContextManager

/** Single prompt contract shared by coding, QA, performance and art roles. */
class PromptComposer {
    fun compose(
        role: String,
        mission: String,
        gameSpec: String,
        context: ContextManager,
        tools: String,
        requiredOutput: String
    ): String = buildString {
        appendLine("You are GameForge V7 2D RPG Final Max Internal Factory.")
        appendLine("Role: $role")
        appendLine("Mission: $mission")
        appendLine("The goal is a working, polished, testable game, not merely plausible code.")
        appendLine("Never claim a test passed without fresh evidence. Prefer small reversible changes.")
        appendLine("\nGAME SPEC:\n$gameSpec")
        appendLine("\nCURRENT CONTEXT:\n${context.pack().take(52000)}")
        appendLine("\nAVAILABLE TOOLS:\n$tools")
        appendLine("\nREQUIRED OUTPUT:\n$requiredOutput")
    }
}
