package com.husain.aicoder.core

import java.io.File
import java.util.ArrayDeque

/** Memory-bounded helpers for append-only JSONL/log files. */
object BoundedFileReader {
    fun tailLines(file: File, limit: Int, maxLineChars: Int = 32_000): List<String> {
        if (!file.isFile || limit <= 0) return emptyList()
        val ring = ArrayDeque<String>(limit.coerceAtMost(4096))
        file.bufferedReader().useLines { lines ->
            lines.forEach { raw ->
                val line = if (raw.length > maxLineChars) raw.take(maxLineChars) else raw
                if (ring.size == limit) ring.removeFirst()
                ring.addLast(line)
            }
        }
        return ring.toList()
    }

    fun headText(file: File, maxChars: Int): String {
        if (!file.isFile || maxChars <= 0) return ""
        file.bufferedReader().use { reader ->
            val buffer = CharArray(4096)
            val out = StringBuilder(maxChars.coerceAtMost(65_536))
            while (out.length < maxChars) {
                val n = reader.read(buffer, 0, minOf(buffer.size, maxChars - out.length))
                if (n <= 0) break
                out.append(buffer, 0, n)
            }
            return out.toString()
        }
    }

    fun countLines(file: File): Long {
        if (!file.isFile) return 0L
        var count = 0L
        file.bufferedReader().useLines { lines -> lines.forEach { count++ } }
        return count
    }
}
