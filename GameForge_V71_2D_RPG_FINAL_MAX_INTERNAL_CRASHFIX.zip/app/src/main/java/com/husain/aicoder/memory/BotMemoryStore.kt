package com.husain.aicoder.memory

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import kotlin.math.max

/** Persistent episodic/semantic memory for autonomous game bots. */
class BotMemoryStore(context: Context, private val maxEpisodes: Int = 1200) {
    private val maxStatsEntries = (maxEpisodes * 3).coerceIn(1024, 4096)
    private val file = File(context.filesDir, "gameforge/memory/bot_memory.json")
    private val lock = Any()

    companion object {
        private const val MAX_PERSISTED_BYTES = 8_000_000L
        private const val MAX_ACTION_PAYLOAD_CHARS = 2048
    }

    private var root: JSONObject = load()

    fun record(botId: String, observation: JSONObject, action: JSONObject, result: JSONObject) {
        synchronized(lock) {
            val episodes = root.optJSONArray("episodes") ?: JSONArray().also { root.put("episodes", it) }
            val stateKey = stateKey(observation)
            val actionType = action.optString("type", "unknown")
            val reward = reward(observation, result)
            val nextObservation = result.optJSONObject("observation") ?: JSONObject()
            val row = JSONObject()
                .put("bot_id", botId)
                .put("state_key", stateKey)
                .put("next_state_key", if (nextObservation.length() == 0) "" else stateKey(nextObservation))
                .put("action", actionType)
                .put("action_payload", action.toString().take(MAX_ACTION_PAYLOAD_CHARS))
                .put("reward", reward)
                .put("success", result.optBoolean("ok", false))
                .put("goal_reached", observation.optBoolean("goal_reached", false) || observation.optBoolean("finished", false))
                .put("dead", observation.optBoolean("dead", false))
                .put("timestamp_ms", System.currentTimeMillis())
            episodes.put(row)
            while (episodes.length() > maxEpisodes) {
                episodes.remove(0)
            }
            updateStats(botId, stateKey, actionType, reward)
            root.put("updated_at_ms", System.currentTimeMillis())
            persist()
        }
    }

    fun planContext(botId: String, observation: JSONObject, maxEpisodes: Int = 10): JSONObject {
        synchronized(lock) {
            val state = stateKey(observation)
            val stats = root.optJSONObject("stats")?.optJSONObject("$botId|$state")
            val episodes = root.optJSONArray("episodes") ?: JSONArray()
            val similar = mutableListOf<JSONObject>()
            for (i in episodes.length() - 1 downTo 0) {
                val row = episodes.optJSONObject(i) ?: continue
                if (row.optString("bot_id") != botId) continue
                if (row.optString("state_key") == state) similar += JSONObject(row.toString())
                if (similar.size >= maxEpisodes) break
            }
            val ranked = rankActions(stats, similar)
            val preferred = ranked.map { it.optString("action") }.filter { it.isNotBlank() }.take(6)
            return JSONObject()
                .put("bot_id", botId)
                .put("state_key", state)
                .put("preferred_actions", JSONArray(preferred))
                .put("action_scores", JSONArray(ranked))
                .put("similar_episodes", JSONArray(similar.take(maxEpisodes)))
                .put("exploration_action", explorationAction(ranked))
                .put("long_term", root.opt("long_term") ?: JSONObject())
        }
    }

    fun forgetBot(botId: String) {
        synchronized(lock) {
            val episodes = root.optJSONArray("episodes") ?: return
            val kept = JSONArray()
            for (i in 0 until episodes.length()) {
                val row = episodes.optJSONObject(i) ?: continue
                if (row.optString("bot_id") != botId) kept.put(row)
            }
            root.put("episodes", kept)
            root.optJSONObject("stats")?.keys()?.asSequence()?.toList()?.forEach { key ->
                if (key.startsWith("$botId|")) root.optJSONObject("stats")?.remove(key)
            }
            persist()
        }
    }

    fun summary(): JSONObject = synchronized(lock) {
        JSONObject()
            .put("episode_count", root.optJSONArray("episodes")?.length() ?: 0)
            .put("stats_entries", root.optJSONObject("stats")?.length() ?: 0)
            .put("file", file.absolutePath)
            .put("updated_at_ms", root.optLong("updated_at_ms", 0L))
    }

    private fun load(): JSONObject {
        if (!file.isFile) return JSONObject().put("episodes", JSONArray()).put("stats", JSONObject())
        if (file.length() > MAX_PERSISTED_BYTES) {
            // Protect startup from a corrupt or unexpectedly huge memory file. Runtime memory remains bounded.
            return JSONObject()
                .put("episodes", JSONArray())
                .put("stats", JSONObject())
                .put("recovery", "oversized_persisted_memory_ignored")
        }
        return runCatching { JSONObject(file.readText()) }
            .getOrElse { JSONObject().put("episodes", JSONArray()).put("stats", JSONObject()).put("recovery", "invalid_persisted_memory_ignored") }
    }

    private fun persist() {
        file.parentFile?.mkdirs()
        file.writeText(root.toString(2))
    }

    private fun updateStats(botId: String, stateKey: String, action: String, reward: Double) {
        val stats = root.optJSONObject("stats") ?: JSONObject().also { root.put("stats", it) }
        val key = "$botId|$stateKey"
        val state = stats.optJSONObject(key) ?: JSONObject().also { stats.put(key, it) }
        val actionStats = state.optJSONObject("actions") ?: JSONObject().also { state.put("actions", it) }
        val a = actionStats.optJSONObject(action) ?: JSONObject().put("count", 0).put("reward", 0.0).put("wins", 0).also { actionStats.put(action, it) }
        a.put("count", a.optInt("count") + 1)
        a.put("reward", a.optDouble("reward") + reward)
        if (reward > 0.5) a.put("wins", a.optInt("wins") + 1)
        trimStats(stats)
    }


    private fun trimStats(stats: JSONObject) {
        val excess = stats.length() - maxStatsEntries
        if (excess <= 0) return
        val keysToRemove = stats.keys().asSequence().take(excess).toList()
        keysToRemove.forEach { stats.remove(it) }
    }

    private fun rankActions(stats: JSONObject?, similar: List<JSONObject>): List<JSONObject> {
        val aggregate = linkedMapOf<String, MutableStats>()
        stats?.optJSONObject("actions")?.let { actions ->
            actions.keys().forEach { key ->
                val a = actions.optJSONObject(key) ?: return@forEach
                aggregate[key] = MutableStats(
                    visits = a.optInt("count", 0),
                    reward = a.optDouble("reward", 0.0),
                    wins = a.optInt("wins", 0)
                )
            }
        }
        similar.forEach { row ->
            val action = row.optString("action")
            if (action.isBlank()) return@forEach
            val a = aggregate.getOrPut(action) { MutableStats() }
            a.visits += 1
            a.reward += row.optDouble("reward", 0.0)
            if (row.optBoolean("goal_reached", false)) a.wins += 1
        }
        val totalVisits = aggregate.values.sumOf { it.visits }.coerceAtLeast(1)
        return aggregate.entries.map { (action, a) ->
            val mean = a.reward / max(1, a.visits)
            val winRate = a.wins.toDouble() / max(1, a.visits)
            val exploration = kotlin.math.sqrt(kotlin.math.ln(totalVisits + 1.0) / max(1, a.visits).toDouble())
            JSONObject()
                .put("action", action)
                .put("visits", a.visits)
                .put("mean_reward", mean)
                .put("win_rate", winRate)
                .put("exploration_bonus", exploration)
                .put("score", mean + 0.65 * winRate + 0.08 * exploration)
        }.sortedByDescending { it.optDouble("score", 0.0) }
    }

    private fun explorationAction(ranked: List<JSONObject>): String {
        if (ranked.isEmpty()) return "move"
        return ranked.minByOrNull { it.optInt("visits", 0) }?.optString("action", "move") ?: "move"
    }

    private data class MutableStats(var visits: Int = 0, var reward: Double = 0.0, var wins: Int = 0)

    private fun stateKey(observation: JSONObject): String {
        val normalized = JSONObject()
            .put("dimension", observation.optString("dimension", "2d"))
            .put("zone", observation.optString("zone", observation.optString("scene", "unknown")))
            .put("scene_label", observation.optString("scene_label", observation.optJSONObject("scene")?.optString("label", "unknown") ?: "unknown"))
            .put("goal", observation.optBoolean("goal_reached", false))
            .put("dead", observation.optBoolean("dead", false))
            .put("health_bucket", (observation.optDouble("health", 1.0) * 10.0).toInt().coerceIn(0, 10))
            .put("enemy_count", observation.optInt("enemy_count", 0).coerceIn(0, 20))
            .put("position_x", (observation.optDouble("x", 0.0) * 4.0).toInt())
            .put("position_y", (observation.optDouble("y", 0.0) * 4.0).toInt())
        return sha256(normalized.toString())
    }

    private fun reward(observation: JSONObject, result: JSONObject): Double {
        var r = if (result.optBoolean("ok", false)) 0.10 else -0.50
        val next = result.optJSONObject("observation") ?: JSONObject()
        if (observation.optBoolean("goal_reached", false) || observation.optBoolean("finished", false) || next.optBoolean("goal_reached", false) || next.optBoolean("finished", false)) r += 2.0
        if (observation.optBoolean("dead", false) || next.optBoolean("dead", false)) r -= 1.0
        if ((observation.optJSONArray("errors")?.length() ?: 0) > 0 || (next.optJSONArray("errors")?.length() ?: 0) > 0) r -= 0.75
        return r.coerceIn(-3.0, 3.0)
    }

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
