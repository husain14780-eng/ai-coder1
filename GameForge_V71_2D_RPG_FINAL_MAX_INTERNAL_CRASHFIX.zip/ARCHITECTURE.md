# GameForge V7 Full Game Factory Architecture

```text
User Goal
   ↓
Game Director / Qwen3-Thinking reasoning
   ↓
GameSpec compiler
   ↓
Genre Blueprint + Level Plan
   ↓
Deterministic 2D/3D playable bootstrap
   ↓
AI-directed 2D asset compiler (sprites / animations / VFX / tiles / maps)
   ↓
Qwen2.5-Coder-7B implementation agent
   ↓
Static generated-project verifier
   ↓
Embedded Godot runtime
   ↓
Fresh observations / playtests / telemetry
   ↓
Gameplay + visual + performance review
   ↓
Change-impact analysis + root-cause repair
   ↺
Regression
   ↓
Final quality gate
   ↓
Package + FINAL_GAME_REPORT.json
   ↓
Experience memory / learning
```

The bootstrap guarantees that GameForge starts from a deterministic, automation-friendly project rather than an empty shell. The coding agent must then replace/expand the bootstrap into the actual requested game while preserving the bridge contract.

## Runtime contract

The generated game exposes:

- `get_observation()`
- `get_gameforge_observation()`
- `apply_action(action: Dictionary)`
- `reset_test()`

The bridge adds observation freshness metadata and screenshot paths. The Android-side tool executor refuses to treat stale/missing runtime observations as successful evidence.

## Godot

Godot 4.7.2 is embedded as an Android dependency. Generated project files are packaged as resource packs and loaded by the embedded runtime. The ZIP does not ship a standalone Godot editor executable.

## V7.1 2D generation contract

For 2D RPG/MMORPG builds, the model is not restricted to a shipped art library. It authors an asset request containing prompt, style, palette, seed, directions, animation names, optional visual layers/motion, and optional ASCII map geometry. `GameForge2DAssetFactory` rasterizes each request into runtime PNG frames, editable SVG/source metadata, SpriteFrames wiring, VFX sequences, tilesets and map data.

## Automated bot testing

The generated runtime includes multiple bot actors. Bots use the generated map's `AStarGrid2D` pathfinder, pursue goals, perform combat actions, and expose bot-testing telemetry. The playtest action grammar includes `bot_test`, and both deterministic and model-driven playtesting can invoke the swarm scenario.


### In-app-only visual loop

GameForge's normal visual QA loop is embedded-Godot-only: the runtime renders the game, the bridge captures one ephemeral viewport image, Android-side vision processing consumes it, and the image is deleted immediately after the observation is enriched. Device-wide MediaProjection is removed; the GameForge visual loop is embedded-Godot-only.

### In-app web research

The agent has `web_search` and `web_open` tools implemented directly in the Android process. They do not open external browser apps.
