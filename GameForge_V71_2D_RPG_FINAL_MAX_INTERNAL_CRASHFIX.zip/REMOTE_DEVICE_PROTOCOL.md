# Internal Runtime Protocol

GameForge V7 is intentionally self-contained. Device-wide accessibility, MediaProjection, camera capture, and external UI automation are not part of the product.

The only gameplay observation source is the embedded Godot viewport. Godot emits an ephemeral observation image inside the app sandbox; `GameScreenshotProcessor` decodes it, `LocalGameVisionEngine` extracts local visual features, and the image is deleted immediately after processing.

Bot input is sent through `AICoderGodotBridge` directly to the in-process Godot world. Web research is performed by the app's own HTTP client and never launches a browser app.
