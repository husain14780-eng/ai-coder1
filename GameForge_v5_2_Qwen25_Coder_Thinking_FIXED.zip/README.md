# AI Coder 5.1 — GameForge Local Model Swarm MAX

This release turns GameForge into a model-agnostic local swarm. The agent can route different tasks to different locally installed serious models while preserving the existing GameForge planner/coder/tester/debugger/critic/verification stack.

The application remains local-only at inference time: no cloud model is required.

Key additions:

- local model registry/catalog
- live RAM-aware model loading/unloading
- per-task specialist routing
- Qwen2.5-Coder-7B Q4_K_M coding specialist with deliberate THINKING mode
- Qwen3-4B Instruct and Thinking-2507 specialists
- Qwen2.5-VL vision profile with an explicit native-multimodal boundary
- model routing learned from experience
- all five ML learning modes connected to swarm routing
- generic chat-template handling in the native bridge rather than Qwen-only prompt formatting
- no tiny helper-model spam

See `LOCAL_MODEL_SWARM.md` for deployment constraints and `SWARM_BENCHMARK.md` for promotion policy.
