# 5.2 LOCAL-SWARM MAX — Qwen2.5-Coder release contract

## Ship gate

A game is marked accepted only when fresh evidence supports the final benchmark and no hard blockers remain.

### Hard blockers
- implementation not verified
- regression below the release threshold
- playtest below the release threshold
- gameplay error signals
- high-severity visual defects
- invalid GameSpec
- design contract inconsistency
- insufficient fresh evidence

### Release artifacts
- `GAME_SPEC.json`
- `GAME_DESIGN.md`
- `ASSET_MANIFEST.json`
- `gameforge/GAMEPLAY_SCENARIOS.json`
- `gameforge/DESIGN_CONSISTENCY.json`
- `gameforge/PROJECT_INDEX.json`
- `gameforge/ARCHITECTURE_GRAPH.json`
- `gameforge/REGRESSION_MATRIX.json`
- `gameforge/GAME_BENCHMARK_V3.json`
- `gameforge/VISUAL_DEFECTS.json`
- `gameforge/PERFORMANCE_AUTOTUNE.json`
- `gameforge/FINAL_MAX_REPORT.json`
- `gameforge/FINAL_RELEASE_MANIFEST.json`

Accepted and non-accepted builds are both preserved with explicit evidence; the system does not silently call an unverified build “finished”.
