#!/usr/bin/env python3
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
checks = {
    'web index': root / 'app/src/main/assets/web/index.html',
    'web js': root / 'app/src/main/assets/web/app.js',
    'web css': root / 'app/src/main/assets/web/style.css',
    'web bridge': root / 'app/src/main/java/com/husain/aicoder/web/GameForgeWebBridge.kt',
    'browser': root / 'app/src/main/java/com/husain/aicoder/web/LocalWebBrowser.kt',
    'main activity': root / 'app/src/main/java/com/husain/aicoder/MainActivity.kt',
    'workspace': root / 'app/src/main/java/com/husain/aicoder/agent/CodingWorkspace.kt',
    'agent': root / 'app/src/main/java/com/husain/aicoder/agent/AgentController.kt',
    'godot bridge': root / 'app/src/main/java/com/husain/aicoder/godot/AICoderGodotBridge.kt',
}
missing = [k for k, v in checks.items() if not v.is_file()]
assert not missing, missing

main = checks['main activity'].read_text()
bridge = checks['web bridge'].read_text()
workspace = checks['workspace'].read_text()
html = checks['web index'].read_text()
js = checks['web js'].read_text()
browser = checks['browser'].read_text()
agent = checks['agent'].read_text()

assert 'addJavascriptInterface' in main and 'file:///android_asset/web/index.html' in main
assert 'allowFileAccess = false' in main
assert 'allowContentAccess = false' in main
assert 'allowUniversalAccessFromFileURLs = false' in main
assert 'MIXED_CONTENT_NEVER_ALLOW' in main
assert 'shouldOverrideUrlLoading' in main
assert 'isFinishing || isDestroyed' in main
assert '@Synchronized fun write' in workspace
assert '@Synchronized fun checkpoint' in workspace
assert '@Synchronized fun restoreCheckpoint' in workspace
assert 'MAX_TEXT_WRITE_BYTES' in workspace
assert 'Mutex()' in bridge and 'exclusiveJobs.withLock' in bridge and 'kotlinx.coroutines.sync.withLock' in bridge
assert 'AtomicLong' in bridge and '"id", id' in bridge
assert 'connect-src \'none\'' in html
assert 'localStorage' in js
assert 'listCheckpoints' in bridge and 'listCheckpoints()' in js
assert 'MAX_RESPONSE_BYTES' in browser and 'MAX_QUERY_CHARS' in browser
assert 'godotReady' in bridge and 'isGodotReady' in agent

# All JS-visible native calls must have a corresponding bridge method.
native_calls = set(re.findall(r'GameForgeNative\.([A-Za-z0-9_]+)', js))
bridge_methods = set(re.findall(r'@JavascriptInterface\s+fun\s+([A-Za-z0-9_]+)', bridge))
missing_methods = sorted(native_calls - bridge_methods)
assert not missing_methods, missing_methods

print('GameForge V6 audit: PASS')
for k, v in checks.items():
    print(f'PASS {k}: {v.relative_to(root)}')
