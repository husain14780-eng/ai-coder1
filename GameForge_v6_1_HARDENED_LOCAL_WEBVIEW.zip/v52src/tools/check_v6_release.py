from pathlib import Path
import json, sys, xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]

def fail(msg):
    print('FAIL', msg); sys.exit(1)

build=(ROOT/'app/src/main/java/com/husain/aicoder/agent/AgentController.kt').read_text()
gradle=(ROOT/'app/build.gradle.kts').read_text()
version=(ROOT/'VERSION.txt').read_text().strip()
manifest=json.loads((ROOT/'RELEASE_MANIFEST.json').read_text())

if 'versionCode = 61' not in gradle or 'versionName = "6.1-LOCAL-WEBVIEW-HARDENED"' not in gradle:
    fail('Android version is not V6.1 hardened')
if version != '6.1-LOCAL-WEBVIEW-HARDENED':
    fail('VERSION.txt is stale')
if manifest.get('versionCode') != 61 or manifest.get('version') != version:
    fail('RELEASE_MANIFEST.json version mismatch')
if manifest.get('local_only_runtime') is not True:
    fail('runtime must remain local-only')
if len(manifest.get('learning_modes', [])) != 5:
    fail('expected five learning modes')

ET.parse(ROOT/'app/src/main/AndroidManifest.xml')
ET.parse(ROOT/'app/src/main/res/layout/activity_main.xml')

web=(ROOT/'app/src/main/assets/web')
for name in ['index.html','app.js','style.css']:
    if not (web/name).is_file(): fail(f'missing web asset {name}')
main=(ROOT/'app/src/main/java/com/husain/aicoder/MainActivity.kt').read_text()
bridge=(ROOT/'app/src/main/java/com/husain/aicoder/web/GameForgeWebBridge.kt').read_text()
workspace=(ROOT/'app/src/main/java/com/husain/aicoder/agent/CodingWorkspace.kt').read_text()
agent=(ROOT/'app/src/main/java/com/husain/aicoder/agent/AgentController.kt').read_text()
html=(web/'index.html').read_text(); js=(web/'app.js').read_text()
for needle in ['file:///android_asset/web/index.html','addJavascriptInterface','allowFileAccess = false','allowContentAccess = false','allowUniversalAccessFromFileURLs = false','MIXED_CONTENT_NEVER_ALLOW','shouldOverrideUrlLoading']:
    if needle not in main: fail(f'MainActivity hardening missing: {needle}')
for needle in ['Mutex()', 'exclusiveJobs.withLock', 'AtomicLong', '"id", id', 'kotlinx.coroutines.sync.withLock']:
    if needle not in bridge: fail(f'Web bridge hardening missing: {needle}')
for needle in ['@Synchronized fun write', '@Synchronized fun append', '@Synchronized fun replaceText', '@Synchronized fun checkpoint', '@Synchronized fun restoreCheckpoint', 'MAX_TEXT_WRITE_BYTES']:
    if needle not in workspace: fail(f'workspace safety missing: {needle}')
for needle in ['workspacePath()', 'isGodotReady()', 'listWorkspaceCheckpoints()']:
    if needle not in agent: fail(f'agent/web state API missing: {needle}')
if "connect-src 'none'" not in html or 'localStorage' not in js:
    fail('local-only CSP or UI persistence is missing')

import re
calls=set(re.findall(r'GameForgeNative\.([A-Za-z0-9_]+)', js))
methods=set(re.findall(r'@JavascriptInterface\s+fun\s+([A-Za-z0-9_]+)', bridge))
missing=sorted(calls-methods)
if missing: fail(f'JS/native methods missing: {missing}')

catalog=(ROOT/'app/src/main/java/com/husain/aicoder/swarm/LocalModelCatalog.kt').read_text()
for needle in ['Qwen3-4B-Thinking-2507','Qwen2.5-Coder-7B-Instruct','Qwen2.5-VL-3B-Instruct','Q4_K_M']:
    if needle not in catalog: fail(f'model roster missing: {needle}')

agent_text=(ROOT/'app/src/main/java/com/husain/aicoder/agent/CodingAgent.kt').read_text()
if 'val thinking = true' not in agent_text: fail('thinking mode contract missing')

print('GameForge V6.1 release check: PASS')
