# GameForge 6.1 — Local WebView Hardened

- Local-first Android WebView control surface; no hosted UI is required.
- Preserves local GGUF inference, model swarm, LoRA, memory/learning, game generation, verification and embedded Godot runtime.
- Workspace writes/checkpoints are serialized and path-confined.
- Heavy AI/Godot jobs are serialized and emit job IDs plus queued/running/done/error states.
- Native web search/page fetch is explicit and bounded; the WebView itself cannot navigate to arbitrary pages.
- UI state (active tab and goal) is persisted in WebView DOM storage.
- The GitHub Actions workflow builds the checked-out V6 source directly; it no longer expects a legacy V5.3 ZIP.
