# GameForge 6.1 hardened build

Requirements:

- Android SDK API 36
- NDK 29.0.13113456
- CMake 3.31.6
- JDK 17
- Gradle 8.13 (the GitHub workflow installs it)

The source archive intentionally does not contain the Android SDK, a private signing key, or multi-gigabyte model weights. It also does not bundle the standalone Godot Editor executable. Godot is resolved as the pinned Android library dependency `org.godotengine:godot:4.7.2.stable`.

## GitHub Actions

Use `.github/workflows/build-apk.yml`. It builds the checked-out V6.1 project directly, runs the V6 release checks/audit, builds `app-debug.apk`, and uploads the APK as an artifact.

## Release signing

Supply the owner's keystore values through the properties/environment documented in `RELEASE_SIGNING.md`. Never commit the keystore or its passwords.

## Model import

Import a trusted GGUF through the app. Do not place multi-gigabyte model weights into the source ZIP.

## What the agent can execute

GameForge does not require a standalone Godot executable. It creates/edits a Godot project in its workspace, packages the project, loads that package into the embedded Godot runtime, requests observations/actions, and performs playtests. Exporting a standalone APK/desktop build of a generated game remains a separate build pipeline.
