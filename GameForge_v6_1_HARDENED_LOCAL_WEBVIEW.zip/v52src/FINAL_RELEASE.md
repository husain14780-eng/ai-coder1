# GameForge 6.1 — Hardened Local WebView release contract

This release is the V6 local-first WebView architecture hardened for real workflows.

## Runtime contract
- Android hosts the bundled GameForge HTML/CSS/JS UI in a WebView.
- Native AI/ML/Godot systems remain local and are not replaced by browser JavaScript.
- The bridge is attached only to the bundled local GameForge page.
- Heavy AI/Godot jobs are serialized.
- Workspace mutations are serialized and path-confined.
- WebView navigation is restricted to bundled assets; explicit web fetching is performed natively.

## Build contract
- `tools/check_v6_release.py` validates the V6.1 release identity and required capabilities.
- `tools/audit_v6.py` validates the WebView bridge and hardening invariants.
- `.github/workflows/build-apk.yml` builds the checked-out source directly.
- Final Android/NDK linking and device execution remain environment-dependent.

## Godot contract
Godot remains the embedded Android runtime dependency. GameForge creates/edits projects locally, loads generated project content into the embedded runtime, and runs playtests through `AICoderGodotBridge`.
