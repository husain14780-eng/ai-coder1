package com.husain.aicoder.project

import com.husain.aicoder.agent.CodingWorkspace
import org.json.JSONArray
import org.json.JSONObject

/** Lightweight dependency graph for impact analysis before edits. */
class ArchitectureGraph(private val workspace: CodingWorkspace) {
    fun scan(): JSONObject {
        val nodes = JSONArray()
        val edges = JSONArray()
        workspace.list().forEach { path ->
            if (path.contains("/.git/") || path.contains("build/")) return@forEach
            val id = path
            nodes.put(JSONObject().put("id", id).put("kind", kind(path)))
            val text = runCatching { workspace.read(path) }.getOrNull() ?: return@forEach
            references(path, text).forEach { ref ->
                val resolved = resolveReference(path, ref)
                if (resolved != null) edges.put(JSONObject().put("from", id).put("to", resolved).put("type", "reference"))
            }
        }
        return JSONObject()
            .put("node_count", nodes.length())
            .put("edge_count", edges.length())
            .put("nodes", nodes)
            .put("edges", edges)
            .put("generated_at_ms", System.currentTimeMillis())
    }

    fun writeReport(): String = workspace.write("gameforge/ARCHITECTURE_GRAPH.json", scan().toString(2))

    private fun references(path: String, text: String): List<String> {
        val out = linkedSetOf<String>()
        val importRegex = Regex("(?:import|preload|load)\\s*\\(?(?:\\\"|')([^\\\"']+)")
        importRegex.findAll(text).forEach { out += it.groupValues[1] }
        Regex("ExtResource\\(.*?path *= *\\\"([^\\\"]+)\\\"").findAll(text).forEach { out += it.groupValues[1] }
        Regex("res://[^\\\"'\\s)]+").findAll(text).forEach { out += it.value }
        return out
    }

    private fun resolveReference(from: String, ref: String): String? {
        if (ref.startsWith("res://")) return ref.removePrefix("res://")
        val base = from.substringBeforeLast('/', missingDelimiterValue = "")
        val candidate = if (base.isBlank()) ref else "$base/$ref"
        return workspace.list().firstOrNull { it == candidate || it.endsWith('/' + ref) }
    }

    private fun kind(path: String) = when {
        path.endsWith(".gd") -> "gdscript"
        path.endsWith(".tscn") -> "scene"
        path.endsWith(".tres") -> "resource"
        path.endsWith(".kt") -> "kotlin"
        path.endsWith(".java") -> "java"
        path.endsWith(".json") -> "data"
        else -> "file"
    }
}
