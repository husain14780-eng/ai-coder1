package com.husain.aicoder.web

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

/** Local browser/search tool. Network access is initiated only by an explicit GameForge action. */
class LocalWebBrowser {
    companion object {
        private const val MAX_QUERY_CHARS = 2000
        private const val MAX_RESPONSE_BYTES = 2 * 1024 * 1024
        private const val MAX_PAGE_CHARS = 60000
    }

    suspend fun search(query: String, limit: Int = 8): JSONObject = withContext(Dispatchers.IO) {
        val normalizedQuery = query.trim()
        require(normalizedQuery.isNotEmpty()) { "Search query is empty" }
        require(normalizedQuery.length <= MAX_QUERY_CHARS) { "Search query is too long" }
        val encoded = URLEncoder.encode(normalizedQuery, "UTF-8")
        val html = request("https://html.duckduckgo.com/html/?q=$encoded")
        val results = JSONArray()
        val pattern = Regex(
            "<a[^>]*class=[\\\"']?[^>]*result__a[^>]*[\\\"']?[^>]*href=[\\\"']([^\\\"']+)[\\\"'][^>]*>(.*?)</a>",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        for (m in pattern.findAll(html).take(limit.coerceIn(1, 20))) {
            val href = extractTargetUrl(m.groupValues[1]) ?: continue
            val title = clean(m.groupValues[2])
            if (title.isNotBlank()) results.put(JSONObject().put("title", title).put("url", href))
        }
        JSONObject().put("query", normalizedQuery).put("results", results)
    }

    suspend fun open(url: String): JSONObject = withContext(Dispatchers.IO) {
        val normalized = url.trim()
        require(normalized.length <= MAX_QUERY_CHARS) { "URL is too long" }
        val parsed = runCatching { URI(normalized) }.getOrElse { error("Invalid URL") }
        require(parsed.scheme.equals("https", true) || parsed.scheme.equals("http", true)) { "Only HTTP(S) URLs are supported" }
        val body = clean(request(parsed.toString())).take(MAX_PAGE_CHARS)
        JSONObject().put("url", parsed.toString()).put("text", body)
    }

    private fun extractTargetUrl(raw: String): String? {
        val decoded = decodeHtmlEntities(raw)
        return runCatching {
            val uri = URI(decoded)
            if (uri.path?.contains("/l/") == true) {
                val query = uri.rawQuery.orEmpty().split('&').mapNotNull {
                    val parts = it.split('=', limit = 2)
                    if (parts.size == 2 && parts[0] == "uddg") parts[1] else null
                }.firstOrNull()
                if (!query.isNullOrBlank()) URLDecoder.decode(query, "UTF-8") else decoded
            } else decoded
        }.getOrNull()
    }

    private fun request(url: String): String {
        val conn = (URI(url).toURL().openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 12000
            readTimeout = 20000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "GameForge/6.0 LocalWebBrowser")
            setRequestProperty("Accept", "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5")
        }
        return try {
            if (conn.responseCode !in 200..399) error("HTTP ${conn.responseCode}")
            val input = conn.inputStream
            val buffer = ByteArray(8192)
            val out = java.io.ByteArrayOutputStream()
            var total = 0
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                if (total > MAX_RESPONSE_BYTES) error("Web response exceeds ${MAX_RESPONSE_BYTES / (1024 * 1024)} MiB")
                out.write(buffer, 0, read)
            }
            val charset = conn.contentType?.substringAfter("charset=", "")?.trim()?.takeIf { it.isNotBlank() } ?: "UTF-8"
            out.toString(charset)
        } finally { conn.disconnect() }
    }

    private fun clean(html: String): String = decodeHtmlEntities(
        html
            .replace(Regex("(?is)<script.*?</script>"), " ")
            .replace(Regex("(?is)<style.*?</style>"), " ")
            .replace(Regex("(?is)<noscript.*?</noscript>"), " ")
            .replace(Regex("<[^>]+>"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    )

    private fun decodeHtmlEntities(text: String): String = text
        .replace("&nbsp;", " ", ignoreCase = true)
        .replace("&amp;", "&", ignoreCase = true)
        .replace("&quot;", "\"", ignoreCase = true)
        .replace("&#39;", "'", ignoreCase = true)
        .replace("&lt;", "<", ignoreCase = true)
        .replace("&gt;", ">", ignoreCase = true)
}
