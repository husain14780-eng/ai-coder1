package com.husain.aicoder.mission

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Durable GameForge session state for crash/restart recovery. */
class GameBuildStore(context: Context) {
    private val dir = File(context.filesDir, "gameforge/builds").apply { mkdirs() }

    fun save(id: String, state: JSONObject) {
        File(dir, "$id.json").writeText(state.toString(2))
    }

    fun latest(): JSONObject? = dir.listFiles()?.filter { it.extension == "json" }
        ?.maxByOrNull { it.lastModified() }
        ?.let { runCatching { JSONObject(it.readText()) }.getOrNull() }

    fun list(): List<File> = dir.listFiles()?.filter { it.extension == "json" }?.sortedByDescending { it.lastModified() } ?: emptyList()
}
