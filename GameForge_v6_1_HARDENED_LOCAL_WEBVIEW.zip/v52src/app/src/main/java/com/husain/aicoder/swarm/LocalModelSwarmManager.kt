package com.husain.aicoder.swarm

import android.app.ActivityManager
import android.content.Context
import com.husain.aicoder.model.ModelManager
import java.io.File

/** Device-aware local model selection and installed-model discovery. */
class LocalModelSwarmManager(private val context: Context, private val modelManager: ModelManager) {
    data class DeviceSnapshot(
        val totalRamMb: Long,
        val availableRamMb: Long,
        val lowMemory: Boolean,
        val cpuCores: Int,
        val freeStorageGb: Double
    )

    data class Installed(val profile: LocalModelProfile, val file: File)

    fun deviceSnapshot(): DeviceSnapshot {
        val info = ActivityManager.MemoryInfo()
        context.getSystemService(ActivityManager::class.java).getMemoryInfo(info)
        val stat = android.os.StatFs(modelManager.modelsDirectory().absolutePath)
        return DeviceSnapshot(
            totalRamMb = info.totalMem / (1024L * 1024L),
            availableRamMb = info.availMem / (1024L * 1024L),
            lowMemory = info.lowMemory,
            cpuCores = Runtime.getRuntime().availableProcessors(),
            freeStorageGb = stat.availableBytes.toDouble() / 1_000_000_000.0
        )
    }

    fun installed(): List<Installed> {
        val dir = modelManager.modelsDirectory()
        return LocalModelCatalog.profiles.mapNotNull { p ->
            dir.listFiles()?.firstOrNull { f -> f.isFile && p.filenamePatterns.any { it.matches(f.name) } }?.let { Installed(p, it) }
        }
    }

    fun installedProfile(id: String): Installed? = installed().firstOrNull { it.profile.id == id }

    fun canAutoLoad(profile: LocalModelProfile, allowHeavy: Boolean = false): Boolean {
        val snap = deviceSnapshot()
        if (profile.experimentalHeavy && !allowHeavy) return false
        // The Q4 coder is mmap-backed and should not be rejected solely because
        // Android reports less free RAM than its conservative peak estimate.
        // The native loader remains the final admission gate. Other profiles use
        // a conservative free-RAM guard to avoid unnecessary model switching/OOMs.
        if (profile.id == LocalModelCatalog.DEFAULT_CODER) return !snap.lowMemory && snap.availableRamMb >= 1400L
        val required = profile.estimatedRamGb * 1024.0 + 700.0
        return snap.availableRamMb >= required && !snap.lowMemory
    }

    fun bestInstalled(role: LocalModelProfile.Role, scores: Map<String, Double> = emptyMap(), allowHeavy: Boolean = false): Installed? {
        val candidates = installed().filter { role in it.profile.roles && canAutoLoad(it.profile, allowHeavy) }
        return candidates.maxWithOrNull(compareBy<Installed> { scores[it.profile.id] ?: 0.0 }
            .thenBy { it.profile.estimatedRamGb * -1.0 })
    }

    fun contextTokensFor(profile: LocalModelProfile): Int {
        val snap = deviceSnapshot()
        val free = snap.availableRamMb
        return when (profile.id) {
            LocalModelCatalog.DEFAULT_CODER -> when { free >= 6000 -> 8192; free >= 4500 -> 6144; free >= 3000 -> 4096; else -> 3072 }
            LocalModelCatalog.DEFAULT_REASONING -> when { free >= 5000 -> 6144; free >= 3500 -> 4096; else -> 3072 }
            else -> when { free >= 5000 -> profile.contextTokens; free >= 3200 -> minOf(profile.contextTokens, 4096); else -> minOf(profile.contextTokens, 3072) }
        }
    }

    fun statusText(): String {
        val snap = deviceSnapshot()
        val installed = installed()
        val names = if (installed.isEmpty()) "none" else installed.joinToString(", ") { it.profile.displayName }
        return "RAM ${snap.availableRamMb}MB free / ${snap.totalRamMb}MB • cores=${snap.cpuCores} • storage=${"%.1f".format(snap.freeStorageGb)}GB • installed: $names"
    }
}
