package com.husain.aicoder.quality

import org.json.JSONObject

/** Evidence-based release gate for game builds. */
class GameQualityGate {
    private val gameplay = GameplayQualityJudge()
    data class Verdict(val accepted: Boolean, val reasons: List<String>, val risk: Double)

    fun evaluate(playtest: JSONObject, profile: JSONObject, missionCompleted: Boolean): Verdict {
        val reasons = mutableListOf<String>()
        val passRate = playtest.optDouble("pass_rate", 0.0)
        if (passRate < 0.8) reasons += "Smoke/playtest pass rate is below 0.80"
        if (!missionCompleted) reasons += "Autonomous implementation mission lacks a verified completion state"
        val hotspots = profile.optInt("hotspot_count", 0)
        if (hotspots > 8) reasons += "Source hotspot count is high; run a performance-focused pass"
        if (!playtest.has("results")) reasons += "No fresh playtest evidence"
        val gameplayReport = gameplay.evaluate(playtest)
        val gameplayErrors = gameplayReport.optInt("error_signal_count", 0)
        if (gameplayErrors > 0) reasons += "Playtest reported $gameplayErrors gameplay error signal(s)"
        val risk = (1.0 - passRate).coerceIn(0.0, 1.0) * 0.50 + (hotspots / 10.0).coerceAtMost(1.0) * 0.20 + (gameplayErrors / 5.0).coerceAtMost(1.0) * 0.10 + if (missionCompleted) 0.0 else 0.2
        return Verdict(reasons.isEmpty(), reasons, risk.coerceIn(0.0, 1.0))
    }
}
