package com.husain.aicoder.game

import org.json.JSONArray
import org.json.JSONObject

/** Immutable high-level contract for a game build. */
data class GameSpec(
    val title: String,
    val genre: String,
    val camera: String,
    val coreLoop: List<String>,
    val mechanics: List<String>,
    val player: List<String>,
    val enemies: List<String>,
    val progression: List<String>,
    val scenes: List<String>,
    val ui: List<String>,
    val audio: List<String>,
    val saveSystem: List<String>,
    val performanceTargets: List<String>,
    val polishPasses: List<String>,
    val constraints: List<String>
) {
    fun toJson(): JSONObject = JSONObject()
        .put("title", title)
        .put("genre", genre)
        .put("camera", camera)
        .put("core_loop", JSONArray(coreLoop))
        .put("mechanics", JSONArray(mechanics))
        .put("player", JSONArray(player))
        .put("enemies", JSONArray(enemies))
        .put("progression", JSONArray(progression))
        .put("scenes", JSONArray(scenes))
        .put("ui", JSONArray(ui))
        .put("audio", JSONArray(audio))
        .put("save_system", JSONArray(saveSystem))
        .put("performance_targets", JSONArray(performanceTargets))
        .put("polish_passes", JSONArray(polishPasses))
        .put("constraints", JSONArray(constraints))

    companion object {
        fun fromJson(o: JSONObject): GameSpec = GameSpec(
            title = o.optString("title", "Untitled Game"),
            genre = o.optString("genre", "3D action"),
            camera = o.optString("camera", "third_person"),
            coreLoop = o.array("core_loop"),
            mechanics = o.array("mechanics"),
            player = o.array("player"),
            enemies = o.array("enemies"),
            progression = o.array("progression"),
            scenes = o.array("scenes"),
            ui = o.array("ui"),
            audio = o.array("audio"),
            saveSystem = o.array("save_system"),
            performanceTargets = o.array("performance_targets"),
            polishPasses = o.array("polish_passes"),
            constraints = o.array("constraints")
        )

        fun fallback(goal: String): GameSpec {
            val lower = goal.lowercase()
            val genre = when {
                "horror" in lower -> "survival_horror"
                "rpg" in lower -> "rpg"
                "racing" in lower -> "racing"
                "puzzle" in lower -> "puzzle"
                "strategy" in lower -> "strategy"
                "roguelike" in lower || "rogue" in lower -> "roguelike"
                "platform" in lower -> "platformer"
                "fps" in lower || "shooter" in lower -> "action_shooter"
                else -> "3d_action"
            }
            return GameSpec(
                title = "GameForge Prototype",
                genre = genre,
                camera = if (genre == "action_shooter") "first_person" else "third_person",
                coreLoop = listOf("explore", "interact", "overcome challenge", "earn progression", "repeat"),
                mechanics = listOf("movement", "camera", "interaction", "health", "restart", "pause"),
                player = listOf("controller", "movement", "camera", "health", "basic interaction"),
                enemies = listOf("one readable enemy archetype", "telegraphed attacks", "simple pursuit"),
                progression = listOf("milestones", "difficulty increase", "unlockable improvement"),
                scenes = listOf("boot", "main", "gameplay", "pause", "game_over", "results"),
                ui = listOf("HUD", "pause menu", "settings", "results"),
                audio = listOf("music", "ui feedback", "action feedback", "victory/defeat"),
                saveSystem = listOf("versioned save", "safe defaults", "load validation"),
                performanceTargets = listOf("stable frame pacing", "bounded physics cost", "no repeated allocation hot paths"),
                polishPasses = listOf("controls", "camera", "feedback", "lighting", "UI spacing", "audio mix"),
                constraints = listOf(goal.take(2000))
            )
        }
    }
}

private fun JSONObject.array(name: String): List<String> = optJSONArray(name)?.let { a ->
    buildList {
        for (i in 0 until a.length()) add(a.optString(i))
    }.filter { it.isNotBlank() }
} ?: emptyList()
