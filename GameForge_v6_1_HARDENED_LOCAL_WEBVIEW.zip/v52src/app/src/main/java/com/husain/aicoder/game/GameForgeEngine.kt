package com.husain.aicoder.game

import com.husain.aicoder.agent.ToolExecutor
import com.husain.aicoder.mission.AutonomousCodingEngine
import com.husain.aicoder.mission.MissionState
import com.husain.aicoder.mission.GameBuildStore
import com.husain.aicoder.quality.GameQualityGate
import com.husain.aicoder.quality.AdaptivePlaytestEngine
import com.husain.aicoder.quality.VisualQualityAnalyzer
import com.arm.aichat.InferenceEngine
import com.husain.aicoder.quality.GameplayQualityJudge
import com.husain.aicoder.quality.PerformanceProfiler
import com.husain.aicoder.quality.PlaytestEngine
import com.husain.aicoder.project.ArchitectureGraph
import com.husain.aicoder.project.ChangeImpactAnalyzer
import com.husain.aicoder.skills.SkillLibrary
import com.husain.aicoder.ml.ContinuousLearningManager
import org.json.JSONObject

/**
 * Game-first autonomous loop: design -> scaffold -> architect/code -> playtest -> diagnose -> repair -> profile -> polish.
 * It deliberately keeps the Qwen base model immutable and stores every evidence-backed lesson.
 */
class GameForgeEngine(
    private val designEngine: GameDesignEngine,
    private val workspace: com.husain.aicoder.agent.CodingWorkspace,
    private val codingEngine: AutonomousCodingEngine,
    private val tools: ToolExecutor,
    private val continuous: ContinuousLearningManager,
    private val skills: SkillLibrary,
    private val inference: InferenceEngine? = null,
    private val actionGrammar: String? = null,
    private val buildStore: GameBuildStore? = null,
    private val onStatus: (String) -> Unit = {}
) {
    private val scaffolder = GameProjectScaffolder(workspace)
    private val graph = ArchitectureGraph(workspace)
    private val impact = ChangeImpactAnalyzer(workspace, graph)
    private val profiler = PerformanceProfiler(workspace)
    private val visual = VisualQualityAnalyzer(workspace)
    private val gate = GameQualityGate()
    private val gameplayJudge = GameplayQualityJudge()
    private val playtest = PlaytestEngine(tools)
    private val adaptivePlaytest = AdaptivePlaytestEngine(tools, inference, actionGrammar)

    suspend fun build(goal: String, maxCodingSteps: Int = 90, maxRepairPasses: Int = 4): GameForgeResult {
        val latest = buildStore?.latest()
        val canResume = latest != null && latest.optString("goal") == goal && latest.optString("stage") != "complete" && java.io.File(workspace.root, "GAME_SPEC.json").isFile
        val buildId = if (canResume) latest!!.optString("id") else "build_${System.currentTimeMillis()}"
        fun persist(stage: String, extra: JSONObject = JSONObject()) {
            buildStore?.save(buildId, JSONObject()
                .put("id", buildId)
                .put("goal", goal)
                .put("stage", stage)
                .put("updated_at_ms", System.currentTimeMillis())
                .put("extra", extra))
        }

        val spec = if (canResume) {
            onStatus("GameForge: resuming saved build ${buildId}")
            runCatching { GameSpec.fromJson(JSONObject(java.io.File(workspace.root, "GAME_SPEC.json").readText())) }
                .getOrElse {
                    persist("designing")
                    designEngine.design(goal)
                }
        } else {
            persist("designing")
            onStatus("GameForge: designing the game")
            designEngine.design(goal)
        }
        persist("designed", JSONObject().put("title", spec.title).put("genre", spec.genre).put("resumed", canResume))
        if (!canResume) scaffolder.scaffold(spec) else onStatus("GameForge: preserved existing workspace and GameSpec")
        graph.writeReport()
        onStatus("GameForge: ${spec.title} • ${spec.genre} • design locked")

        persist("implementing", JSONObject().put("title", spec.title))
        val implementationGoal = buildImplementationPrompt(goal, spec)
        var mission = if (canResume) {
            codingEngine.latestMission()?.let { saved ->
                if (!saved.completed) codingEngine.resumeLatest(maxCodingSteps) ?: saved else saved
            } ?: codingEngine.run(implementationGoal, maxCodingSteps)
        } else {
            codingEngine.run(implementationGoal, maxCodingSteps)
        }
        persist("implemented", JSONObject().put("mission_completed", mission.completed).put("mission_failures", mission.failures).put("resumed", canResume))
        var pass = 0
        var accepted = false
        var lastPlaytest = JSONObject()
        var lastProfile = JSONObject()
        var lastVerdict = gate.evaluate(JSONObject(), JSONObject(), mission.completed)

        while (pass <= maxRepairPasses && !accepted) {
            pass++
            onStatus("GameForge: playtest pass $pass")
            lastPlaytest = if (pass == 1 && inference != null) {
                adaptivePlaytest.run(iterations = 3, maxStepsPerRun = 18).report
            } else {
                playtest.run(if (pass == 1) 4 else 6)
            }
            lastProfile = profiler.profile()
            persist("playtesting", JSONObject().put("pass", pass).put("playtest_pass_rate", lastPlaytest.optDouble("pass_rate", 0.0)))
            profiler.writeReport()
            graph.writeReport()
            lastVerdict = gate.evaluate(lastPlaytest, lastProfile, mission.completed)
            workspace.write("gameforge/QUALITY_GATE_PASS_$pass.json", JSONObject()
                .put("playtest", lastPlaytest)
                .put("profile", lastProfile)
                .put("verdict_accepted", lastVerdict.accepted)
                .put("reasons", lastVerdict.reasons)
                .put("risk", lastVerdict.risk).toString(2))

            if (lastVerdict.accepted) {
                accepted = true
                persist("accepted", JSONObject().put("pass", pass).put("risk", lastVerdict.risk))
                break
            }

            if (pass > maxRepairPasses) break
            val hotspotPaths = buildList {
                val a = lastProfile.optJSONArray("hotspots")
                if (a != null) for (i in 0 until a.length()) a.optJSONObject(i)?.optString("file")?.takeIf { it.isNotBlank() }?.let { add(it) }
            }
            val impactReport = impact.analyze(hotspotPaths)
            val repairGoal = buildRepairPrompt(spec, mission, lastPlaytest, lastProfile, lastVerdict, impactReport)
            mission = codingEngine.run(repairGoal, maxCodingSteps)
            persist("repaired", JSONObject().put("pass", pass).put("mission_completed", mission.completed))
        }

        persist("finalizing", JSONObject().put("accepted", accepted).put("repair_passes", pass))
        val summary = "GameForge ${spec.title}: accepted=$accepted pass=$pass risk=${lastVerdict.risk} reasons=${lastVerdict.reasons.joinToString("; ")}"
        continuous.recordOutcome(goal, accepted, summary)
        if (accepted) {
            skills.upsert(
                name = "gameforge_${spec.genre}_${spec.title.hashCode()}",
                trigger = "Build and validate a ${spec.genre} game",
                procedure = listOf("design GameSpec", "scaffold contract", "implement", "playtest", "profile", "repair", "verify"),
                evidence = summary,
                failureModes = lastVerdict.reasons
            )
        }
        val gameplayReport = gameplayJudge.evaluate(lastPlaytest)
        val visualReport = visual.analyze()
        val finalReport = JSONObject()
            .put("goal", goal)
            .put("spec", spec.toJson())
            .put("mission", mission.summary)
            .put("accepted", accepted)
            .put("repair_passes", pass)
            .put("playtest", lastPlaytest)
            .put("gameplay_quality", gameplayReport)
            .put("profile", lastProfile)
            .put("quality_reasons", lastVerdict.reasons)
            .put("quality_risk", lastVerdict.risk)
            .put("visual_quality", visualReport)
        val reportPath = workspace.write("gameforge/FINAL_GAME_REPORT.json", finalReport.toString(2))
        persist("complete", JSONObject().put("accepted", accepted).put("report", reportPath))
        return GameForgeResult(spec, mission, accepted, pass, summary, reportPath)
    }

    private fun buildImplementationPrompt(goal: String, spec: GameSpec): String = buildString {
        appendLine("Build a complete, polished, playable Godot game from this mission.")
        appendLine("Original user goal: $goal")
        appendLine("GameSpec JSON:")
        appendLine(spec.toJson().toString(2))
        appendLine()
        appendLine("Implementation rules:")
        appendLine("- First inspect the existing workspace and preserve useful work.")
        appendLine("- Implement the core gameplay loop before cosmetic extras.")
        appendLine("- Create deterministic smoke-test paths for every major system.")
        appendLine("- Prefer procedural assets and reusable components when external assets are absent.")
        appendLine("- Add UI/audio/feedback after functionality, then perform a polish pass.")
        appendLine("- Run the game/test harness and use fresh evidence before declaring completion.")
        appendLine("- Treat GAME_SPEC.json as the source of truth; update it only when design changes are intentional.")
    }

    private fun buildRepairPrompt(
        spec: GameSpec,
        mission: MissionState,
        playtest: JSONObject,
        profile: JSONObject,
        verdict: GameQualityGate.Verdict,
        impactReport: JSONObject
    ): String = buildString {
        appendLine("Repair and polish the existing Godot game. Do not start over.")
        appendLine("Game: ${spec.title} (${spec.genre})")
        appendLine("Mission status: completed=${mission.completed}, failures=${mission.failures}")
        appendLine("Fresh playtest evidence:")
        appendLine(playtest.toString(2).take(12000))
        appendLine("Performance evidence:")
        appendLine(profile.toString(2).take(9000))
        appendLine("Quality gate failures:")
        appendLine(verdict.reasons.joinToString("\n- ", prefix = "- "))
        appendLine("Impact analysis:")
        appendLine(impactReport.toString(2).take(7000))
        appendLine("Fix the highest-impact causes first, then rerun tests and prove the result.")
    }
}

data class GameForgeResult(
    val spec: GameSpec,
    val mission: MissionState,
    val accepted: Boolean,
    val repairPasses: Int,
    val summary: String,
    val reportPath: String
)
