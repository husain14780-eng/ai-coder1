package com.husain.aicoder.mission

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.husain.aicoder.agent.CodingWorkspace
import com.husain.aicoder.agent.ToolExecutor
import com.husain.aicoder.core.AgentRoles
import com.husain.aicoder.core.DynamicReasoningPolicy
import com.husain.aicoder.memory.ContextLedger
import com.husain.aicoder.memory.MemoryRetriever
import com.husain.aicoder.ml.ContinuousLearningManager
import com.husain.aicoder.skills.SkillLibrary
import kotlinx.coroutines.flow.collect
import org.json.JSONObject

/** v6.1 HARDENED LOCAL-WEBVIEW MAX long-horizon game-development orchestrator with persistent evidence. */
class AutonomousCodingEngine(
    private val engine: InferenceEngine,
    private val workspace: CodingWorkspace,
    private val learning: ContinuousLearningManager,
    private val missions: MissionStore,
    private val memory: MemoryRetriever,
    private val skills: SkillLibrary,
    private val onStatus: (String) -> Unit = {}
) {
    private val policy = DynamicReasoningPolicy()
    private val verifier = VerificationEngine()
    private val reflection = ReflectionEngine(engine)
    private val ledger = ContextLedger(18000)
    private var executor: ToolExecutor? = null

    fun attachTools(toolExecutor: ToolExecutor) { executor = toolExecutor }

    suspend fun run(goal: String, maxSteps: Int = 60, resume: MissionState? = null): MissionState {
        val tool = executor ?: error("Tools not attached")
        var state = resume ?: missions.create(goal, maxSteps)
        state = state.copy(phase = "planning"); missions.save(state)
        ledger.add("goal", goal)

        tool.execute("checkpoint", JSONObject().put("label", "before_${state.id}"))

        val tasks = if (state.tasks.isNotEmpty()) state.tasks else plan(goal).mapIndexed { i, title -> MissionTask("t_${i + 1}", title, verification = "fresh tool/test evidence for: $title") }
        state = state.copy(tasks = tasks); missions.save(state)
        onStatus("MAX plan: ${tasks.size} tasks")

        var current = state
        val startIndex = tasks.indexOfFirst { it.status != "verified" }.let { if (it < 0) tasks.size else it }
        for (taskIndex in startIndex until tasks.size) {
            val title = tasks[taskIndex].title
            current = current.copy(phase = "implementation", step = current.step + 1,
                tasks = current.tasks.mapIndexed { i, t -> if (i == taskIndex) t.copy(status = "active", attempts = t.attempts + 1) else t })
            missions.save(current)
            ledger.add("task", "${taskIndex + 1}/${tasks.size}: $title")

            var taskDone = false
            var localAttempts = 0
            while (!taskDone && current.step < maxSteps) {
                localAttempts++
                val retrieved = memory.retrieve("$goal $title", 4)
                val skillText = skills.retrieve("$goal $title", 3).joinToString("\n") { it.toString() }
                val decision = policy.choose(current.phase, current.failures, current.toolCalls, verifiedTests = countVerified(), hasFreshEvidence = hasEvidence())
                val taskLower = title.lowercase()
                val role = when {
                    current.failures >= 2 -> AgentRoles.DEBUGGER
                    listOf("design", "loop", "mechanic", "progression").any { taskLower.contains(it) } -> AgentRoles.GAME_DESIGNER
                    listOf("architecture", "system", "dependency", "refactor").any { taskLower.contains(it) } -> AgentRoles.ARCHITECT
                    listOf("level", "scene", "layout", "map").any { taskLower.contains(it) } -> AgentRoles.LEVEL_DESIGNER
                    listOf("visual", "material", "lighting", "vfx", "asset").any { taskLower.contains(it) } -> AgentRoles.TECHNICAL_ARTIST
                    listOf("ui", "menu", "hud", "settings").any { taskLower.contains(it) } -> AgentRoles.UI_ENGINEER
                    listOf("performance", "fps", "optimization", "memory").any { taskLower.contains(it) } -> AgentRoles.PERFORMANCE
                    listOf("playtest", "qa", "quality", "edge case").any { taskLower.contains(it) } -> AgentRoles.QA
                    localAttempts > 2 -> AgentRoles.CRITIC
                    else -> AgentRoles.CODER
                }
                val prompt = buildPrompt(goal, title, current, role, retrieved, skillText)
                val output = generate(prompt, decision)
                learning.recordAgentTurn(goal, decision.mode.name, output)
                ledger.add("assistant", output.take(7000))
                onStatus("MAX ${role} ${decision.mode.name} step=${current.step} tools=${current.toolCalls} failures=${current.failures}: ${output.take(170)}")

                val call = parseToolCall(output)
                if (call != null) {
                    val result = tool.execute(call.first, call.second)
                    val ok = result.optBoolean("ok")
                    val evidence = result.optString("evidence")
                    current = current.copy(
                        step = current.step + 1,
                        toolCalls = current.toolCalls + 1,
                        failures = if (ok) (current.failures - 1).coerceAtLeast(0) else current.failures + 1,
                        evidence = (current.evidence + listOfNotNull(evidence.takeIf { it.isNotBlank() })).takeLast(30)
                    )
                    missions.save(current)
                    ledger.add("tool:${call.first}", result.toString().take(9000))
                    learning.recordExperience(goal, "$title\n${ledger.compact()}", call.first, result.toString(), ok)

                    if (call.first == "run_godot_test" || call.first == "run_generated_game" || call.first == "run_playtest" || call.first.startsWith("device_") || call.first == "run_command") {
                        val verdict = verifier.evaluate(listOf(result), current.failures)
                        if (verdict.accepted) {
                            taskDone = true
                            current = current.copy(tasks = current.tasks.mapIndexed { i, t -> if (i == taskIndex) t.copy(status = "verified") else t })
                            missions.save(current)
                            onStatus("Verified task ${taskIndex + 1}/${tasks.size}")
                        }
                    }
                    if (!ok) {
                        val ref = reflection.summarize(goal, ledger.compact())
                        learning.recordExperience(goal, ledger.compact(), "reflection", ref, false)
                        ledger.add("reflection", ref)
                        current = current.copy(phase = "debugging")
                        missions.save(current)
                    } else current = current.copy(phase = "implementation")
                } else if (output.contains("DONE", true)) {
                    // DONE is only meaningful when a fresh verification exists.
                    val verdict = verifier.evaluate(emptyList(), current.failures)
                    if (verdict.accepted) taskDone = true else current = current.copy(failures = current.failures + 1, phase = "verification")
                    missions.save(current)
                } else {
                    current = current.copy(failures = current.failures + 1, phase = "debugging", step = current.step + 1)
                    missions.save(current)
                }

                if (current.failures >= 5) {
                    onStatus("Too many failures; asking critic before continuing")
                    val critic = generate(buildPrompt(goal, title, current, AgentRoles.CRITIC, memory.retrieve(goal, 6), skills.retrieve(goal, 4).joinToString("\n")), DynamicReasoningPolicy().choose("critique", current.failures, current.toolCalls, countVerified(), hasEvidence()))
                    ledger.add("critic", critic); learning.recordAgentTurn(goal, "CRITIC", critic)
                    current = current.copy(failures = 0, phase = "debugging"); missions.save(current)
                }
            }

            if (!taskDone) {
                current = current.copy(completed = false, summary = "Stopped before verifying task: $title")
                missions.save(current)
                return current
            }
        }

        val finalCritique = generate(buildPrompt(goal, "final system review", current, AgentRoles.CRITIC, memory.retrieve(goal, 8), skills.retrieve(goal, 5).joinToString("\n")),
            DynamicReasoningPolicy().choose("critique", current.failures, current.toolCalls, countVerified(), hasEvidence()))
        ledger.add("final_critic", finalCritique)
        val finalReflection = reflection.summarize(goal, ledger.compact())
        learning.recordExperience(goal, ledger.compact(), "verified_mission", finalReflection, true)
        skills.upsert(
            name = "verified_${goal.take(48).replace(Regex("[^A-Za-z0-9_-]+"), "_")}",
            trigger = goal,
            procedure = current.tasks.map { it.title },
            evidence = current.evidence.takeLast(8).joinToString(" | "),
            failureModes = listOfNotNull(finalCritique.takeIf { it.contains("risk", true) }?.take(500))
        )
        current = current.copy(phase = "complete", completed = true, summary = finalReflection.take(5000))
        missions.save(current)
        learning.recordOutcome(goal, true, finalReflection)
        return current
    }

    private suspend fun plan(goal: String): List<String> {
        val prompt = """
            ${AgentRoles.instruction(AgentRoles.ARCHITECT)}
            Goal: $goal
            Return 5-14 numbered implementation tasks. Each line must begin with TASK:. Include a concise verification rule and optionally one role tag such as [GAMEPLAY], [LEVEL], [UI], [ART], [PERF], [QA], [ARCH]. Prioritize a functioning core loop before polish.
        """.trimIndent()
        val out = generate(prompt, DynamicReasoningPolicy().choose("planning", 0, 0, 0, false))
        val parsed = out.lines().mapNotNull { line ->
            val t = line.substringAfter("TASK:", "").trim()
            t.takeIf { it.isNotBlank() }
        }.take(10)
        return if (parsed.isEmpty()) listOf("Inspect the existing project", "Implement the requested change", "Run tests and verify the result") else parsed
    }

    private suspend fun generate(prompt: String, decision: DynamicReasoningPolicy.Decision): String {
        val out = StringBuilder()
        engine.sendUserPrompt(prompt, GenerationConfig(decision.mode, decision.maxTokens, decision.temperature,
            if (decision.mode.name == "THINKING") 0.95f else 0.8f, 20, 0f, 1.05f)).collect { out.append(it) }
        return out.toString().replace(Regex("</?think>"), "").trim()
    }

    private fun buildPrompt(goal: String, task: String, state: MissionState, role: String, memories: List<String>, skills: String): String = buildString {
        append("You are GameForge 6.1 HARDENED LOCAL-WEBVIEW MAX / GameForge Apex. Role: $role\n")
        append(AgentRoles.instruction(role)).append('\n')
        append("Mission goal: ").append(goal).append('\n')
        append("Current task: ").append(task).append('\n')
        append("Mission state: phase=${state.phase}, step=${state.step}/${state.maxSteps}, failures=${state.failures}, toolCalls=${state.toolCalls}\n")
        append("Verified evidence: ").append(state.evidence.takeLast(8).joinToString(" | ")).append('\n')
        append("Useful memories:\n").append(memories.joinToString("\n---\n")).append('\n')
        append("Useful skills:\n").append(skills.take(9000)).append('\n')
        append("Working ledger:\n").append(ledger.compact()).append('\n')
        append("Available tools: read_file, write_file, replace_text, append_file, list_files, search_text, hash_file, checkpoint, list_checkpoints, restore_checkpoint, get_last_observation, get_screen_observation, get_mission_context, inspect_project_graph, write_project_graph, write_project_index, analyze_change_impact, profile_project, write_profile_report, analyze_visual_quality, write_visual_quality_report, read_game_spec, package_game, run_generated_game, run_godot_test, run_playtest, run_command, game_action, device_tap, device_swipe, device_back, device_home, device_type, wait.\n")
        append("Choose exactly one next action. Use one <tool_call>{\"name\":...,\"arguments\":{...}}</tool_call> block, or explain why no tool is needed. Never claim success without fresh evidence.\n")
    }

    private fun parseToolCall(text: String): Pair<String, JSONObject>? {
        val s = text.indexOf("<tool_call>"); val e = text.indexOf("</tool_call>", s + 11)
        if (s < 0 || e <= s) return null
        val obj = runCatching { JSONObject(text.substring(s + 11, e).trim()) }.getOrNull() ?: return null
        val name = obj.optString("name").trim(); if (name.isBlank()) return null
        return name to (obj.optJSONObject("arguments") ?: JSONObject())
    }

    private fun countVerified(): Int = ledger.snapshot().lineSequence().count { it.contains("verified", true) }
    private fun hasEvidence(): Boolean = ledger.snapshot().contains("evidence", true)

    fun latestMission(): MissionState? = missions.list().firstOrNull()

    suspend fun resumeLatest(maxSteps: Int = 60): MissionState? = missions.latestIncomplete()?.let { run(it.goal, maxSteps, it) }
}
