package com.husain.aicoder.game

import org.json.JSONArray
import org.json.JSONObject

/** Creates an explicit asset budget so the coder knows what is needed before implementation. */
class AssetPlanner {
    fun manifest(spec: GameSpec): JSONObject {
        val rows = JSONArray()
        fun add(category: String, name: String, generator: String, priority: String) {
            rows.put(JSONObject().put("category", category).put("name", name).put("generator", generator).put("priority", priority))
        }
        add("player", "player_controller", "procedural_character", "P0")
        spec.enemies.take(8).forEachIndexed { i, e -> add("enemy", "enemy_${i + 1}", "procedural_enemy", if (i == 0) "P0" else "P1") }
        spec.scenes.take(12).forEach { add("scene", it, "godot_scene", "P0") }
        spec.ui.take(12).forEach { add("ui", it, "ui_scene", "P1") }
        spec.audio.take(12).forEach { add("audio", it, "placeholder_or_import", "P2") }
        add("vfx", "hit_feedback", "procedural_particles", "P1")
        add("vfx", "level_feedback", "procedural_particles", "P2")
        return JSONObject().put("generated_by", "GameForge 6.1 LOCAL-WEBVIEW MAX HARDENED").put("assets", rows)
    }
}
