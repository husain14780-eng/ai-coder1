package com.husain.aicoder.swarm

/** Semantic task router: select a specialist first, then let the verifier decide whether it was good enough. */
class SwarmTaskRouter(private val swarm: LocalModelSwarmManager, private val learning: SwarmLearningManager) {
    data class Decision(val task: String, val profile: LocalModelProfile, val reason: String)

    fun classify(prompt: String): String {
        val p = prompt.lowercase()
        return when {
            listOf("screenshot", "image", "visual", "ui layout", "pixel", "camera frame").any { it in p } -> "vision"
            listOf("compile", "compiler", "stack trace", "exception", "bug", "fix", "refactor", "gdscript", "c#", "code", "script", "function", "class").any { it in p } -> "coding"
            listOf("architecture", "plan", "strategy", "root cause", "why", "tradeoff", "design system", "balance", "difficulty", "quality gate").any { it in p } -> "reasoning"
            listOf("game design", "level", "mechanic", "core loop", "progression", "player experience").any { it in p } -> "design"
            else -> "general"
        }
    }

    fun decide(prompt: String): Decision {
        val task = classify(prompt)
        val role = when (task) {
            "coding" -> LocalModelProfile.Role.CODING
            "reasoning" -> LocalModelProfile.Role.REASONING
            "vision" -> LocalModelProfile.Role.VISION
            "design" -> LocalModelProfile.Role.GAME_DESIGN
            else -> LocalModelProfile.Role.GENERAL
        }
        val scores = swarm.installed().associate { it.profile.id to learning.score(it.profile.id, task) }
        val requestedRole = if (task == "vision") LocalModelProfile.Role.VISION else role
        val installed = if (task == "vision") {
            // Native v5 text bridge deliberately refuses to fake image inference.
            // Vision continues through the existing pixel/telemetry perception stack until mtmd/projector input is wired.
            swarm.bestInstalled(LocalModelProfile.Role.GENERAL, scores, allowHeavy = false)
        } else {
            swarm.bestInstalled(requestedRole, scores, allowHeavy = true)
                ?: swarm.bestInstalled(LocalModelProfile.Role.GENERAL, scores, allowHeavy = false)
        } ?: error("No installed local model can safely serve task=$task")
        val reason = "task=$task → role=$role → ${installed.profile.displayName}; learnedScore=${"%.3f".format(scores[installed.profile.id] ?: 0.0)}"
        return Decision(task, installed.profile, reason)
    }
}
