package com.husain.aicoder

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.FrameLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.husain.aicoder.agent.AgentController
import com.husain.aicoder.godot.AICoderGodotBridge
import com.husain.aicoder.web.GameForgeWebBridge
import com.husain.aicoder.vision.ScreenCaptureService
import org.godotengine.godot.Godot
import org.godotengine.godot.GodotFragment
import org.godotengine.godot.GodotHost
import org.godotengine.godot.plugin.GodotPlugin
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : AppCompatActivity(), GodotHost {
    private val scope = MainScope()
    private lateinit var webView: WebView
    private lateinit var godotContainer: FrameLayout
    private lateinit var agent: AgentController
    private var webBridge: GameForgeWebBridge? = null
    private var godotFragment: GodotFragment? = null
    private var bridge: AICoderGodotBridge? = null
    private var importedModel: String? = null
    private var importedAdapter: String? = null
    private var godotVisible = true

    private val captureScreen = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != RESULT_OK || result.data == null) { setStatus("Screen capture not granted"); return@registerForActivityResult }
        startForegroundService(Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
        })
        setStatus("Screen perception started")
    }

    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        scope.launch {
            runCatching {
                setStatus("Importing GGUF…")
                val mm = com.husain.aicoder.model.ModelManager(this@MainActivity)
                importedModel = mm.importModel(uri)
                agent.loadQwen(importedModel!!, mm.chooseDefaultContext())
                pushWebEvent("model", JSONObject().put("state", "loaded").put("path", importedModel!!).put("name", java.io.File(importedModel!!).name))
            }.onFailure { setStatus("Model error: ${it.message}") }
        }
    }

    private val pickAdapter = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        scope.launch {
            runCatching {
                requireNotNull(importedModel) { "Import a supported local GGUF first" }
                setStatus("Importing LoRA adapter…")
                val mm = com.husain.aicoder.model.ModelManager(this@MainActivity)
                importedAdapter = mm.importAdapter(uri)
                agent.loadAdapter(importedAdapter!!)
                pushWebEvent("adapter", JSONObject().put("state", "loaded").put("path", importedAdapter!!))
            }.onFailure { setStatus("Adapter error: ${it.message}") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        agent = AgentController(this)
        setupUi()
        setupGodot()
        webBridge = GameForgeWebBridge(this, agent)
        webView.addJavascriptInterface(webBridge!!, "GameForgeNative")
        webView.loadUrl("file:///android_asset/web/index.html")
    }

    private fun setupUi() {
        val root = FrameLayout(this)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.setSupportZoom(false)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    return !(uri.scheme == "file" && uri.host == "android_asset" && uri.path?.startsWith("/web/") == true)
                }

                @Suppress("DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                    return !url.startsWith("file:///android_asset/web/")
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: android.webkit.WebResourceError
                ) {
                    if (request.isForMainFrame) {
                        pushWebEvent("status", JSONObject().put("message", "Web UI error: ${error.description}"))
                    }
                }
            }
        }
        godotContainer = FrameLayout(this).apply { id = View.generateViewId() }
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        val godotLp = FrameLayout.LayoutParams(-1, (220 * resources.displayMetrics.density).toInt())
        godotLp.gravity = android.view.Gravity.BOTTOM
        root.addView(godotContainer, godotLp)
        setContentView(root)
    }

    private fun setupGodot() {
        val current = supportFragmentManager.findFragmentById(godotContainer.id)
        godotFragment = if (current is GodotFragment) current else GodotFragment().also {
            supportFragmentManager.beginTransaction().replace(godotContainer.id, it, "gameforge_godot").commitNowAllowingStateLoss()
        }
    }

    override fun getActivity() = this
    override fun getGodot(): Godot? = godotFragment?.godot
    override fun getHostPlugins(godot: Godot): Set<GodotPlugin> {
        if (bridge == null) { bridge = AICoderGodotBridge(godot); agent.attachGodot(bridge!!) }
        return setOf(bridge!!)
    }

    fun openModelPickerFromWeb() = pickModel.launch(arrayOf("application/octet-stream", "application/*", "*/*"))
    fun openAdapterPickerFromWeb() = pickAdapter.launch(arrayOf("application/octet-stream", "application/*", "*/*"))
    fun toggleGodotPanel() {
        godotVisible = !godotVisible
        godotContainer.visibility = if (godotVisible) View.VISIBLE else View.GONE
        pushWebEvent("godot", JSONObject().put("visible", godotVisible))
    }
    fun openVisionFromWeb() = captureScreen.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    fun stopVisionFromWeb() { startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP)); setStatus("Screen perception stopped") }
    fun startGameplayFromWeb() {
        val b = bridge ?: run { setStatus("Godot bridge not ready"); return }
        startForegroundService(Intent(this, AutonomousRunService::class.java))
        agent.start(b)
        setStatus("Autonomous gameplay started")
    }

    fun setStatus(message: String) {
        pushWebEvent("status", JSONObject().put("message", message.take(1200)))
    }
    fun pushWebEvent(type: String, payload: JSONObject) {
        if (!::webView.isInitialized || isFinishing || isDestroyed) return
        val event = JSONObject().put("type", type).put("payload", payload)
        runOnUiThread {
            if (!isFinishing && !isDestroyed) {
                webView.evaluateJavascript("window.GameForge && window.GameForge.receive(${JSONObject.quote(event.toString())})", null)
            }
        }
    }

    override fun onDestroy() {
        agent.shutdown(); webBridge?.shutdown(); webView.removeJavascriptInterface("GameForgeNative"); webView.destroy(); scope.cancel(); super.onDestroy()
    }
}
