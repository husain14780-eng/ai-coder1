package com.husain.aicoder.game

import com.arm.aichat.GenerationConfig
import com.arm.aichat.InferenceEngine
import com.arm.aichat.ReasoningMode
import kotlinx.coroutines.flow.collect
import org.json.JSONObject

/** Turns a vague game idea into a concrete, testable GameSpec. */
class GameDesignEngine(private val engine: InferenceEngine) {
    private val router = com.husain.aicoder.router.ModelRouter()
    suspend fun design(goal: String): GameSpec {
        val prompt = """
            You are GameForge MAX, an expert game designer and technical director.
            Convert the user's game idea into a build-ready JSON specification.
            Do not write implementation code yet. Make the design coherent, testable and achievable in Godot.
            Return JSON only with keys:
            title, genre, camera, core_loop, mechanics, player, enemies, progression, scenes, ui,
            audio, save_system, performance_targets, polish_passes, constraints.

            USER GAME IDEA:
            $goal
        """.trimIndent()
        val out = StringBuilder()
        val route = router.route(kind = "design", risk = 0.90, evidence = false, complexity = 9)
        engine.sendUserPrompt(
            prompt,
            GenerationConfig(route.mode, route.maxTokens, route.temperature, 0.92f, 30, 0f, 1.05f)
        ).collect { out.append(it) }
        val text = out.toString()
        val jsonText = extractJson(text)
        return runCatching { GameSpec.fromJson(JSONObject(jsonText)) }
            .getOrElse { GameSpec.fallback(goal) }
    }

    private fun extractJson(text: String): String {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        require(start >= 0 && end > start) { "Game design did not return JSON" }
        return text.substring(start, end + 1)
    }
}
