package com.husain.aicoder.web

import android.webkit.JavascriptInterface
import com.husain.aicoder.MainActivity
import com.husain.aicoder.agent.AgentController
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

/** JavaScript bridge for the local GameForge Web UI. No remote webpage is granted this bridge. */
class GameForgeWebBridge(
    private val activity: MainActivity,
    private val agent: AgentController,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val browser = LocalWebBrowser()
    private val exclusiveJobs = Mutex()
    private val nextJobId = AtomicLong(1L)

    @JavascriptInterface
    fun getState(): String = JSONObject()
        .put("version", "6.1-LOCAL-WEBVIEW-HARDENED")
        .put("workspace", agent.workspacePath())
        .put("models", JSONArray(agent.installedSwarmProfiles()))
        .put("swarm", agent.swarmStatus())
        .put("godotReady", agent.isGodotReady())
        .toString()

    @JavascriptInterface fun openModelPicker() = activity.openModelPickerFromWeb()
    @JavascriptInterface fun openAdapterPicker() = activity.openAdapterPickerFromWeb()
    @JavascriptInterface fun toggleGodot() = activity.toggleGodotPanel()
    @JavascriptInterface fun openVision() = activity.openVisionFromWeb()
    @JavascriptInterface fun stopVision() = activity.stopVisionFromWeb()
    @JavascriptInterface fun startGameplay() = activity.startGameplayFromWeb()

    @JavascriptInterface fun runCoding(goal: String) = exclusiveAsync("coding") { agent.runCodingMission(goal) { activity.setStatus(it) } }
    @JavascriptInterface fun buildGame(goal: String) = exclusiveAsync("build") { agent.buildGame(goal) { activity.setStatus(it) } }
    @JavascriptInterface fun buildApex(goal: String) = exclusiveAsync("apex") { agent.buildGameApex(goal) { activity.setStatus(it) } }
    @JavascriptInterface fun optimizeGame() = exclusiveAsync("optimize") { agent.optimizeGameApex { activity.setStatus(it) } }
    @JavascriptInterface fun verifyRelease() = exclusiveAsync("verify") { agent.verifyReleaseApex { activity.setStatus(it) } }
    @JavascriptInterface fun inspectGame() = exclusiveAsync("inspect") { agent.inspectGame { activity.setStatus(it) }.absolutePath }
    @JavascriptInterface fun benchmarkGame() = exclusiveAsync("benchmark") { agent.benchmarkGame { activity.setStatus(it) }.absolutePath }
    @JavascriptInterface fun benchmarkSwarm() = exclusiveAsync("swarm_benchmark") { agent.benchmarkLocalSwarm { activity.setStatus(it) } }
    @JavascriptInterface fun resumeMission() = exclusiveAsync("resume") { agent.resumeLatestMission { activity.setStatus(it) }; "resume requested" }

    @JavascriptInterface fun swarmStatus(): String = agent.swarmStatus()
    @JavascriptInterface fun swarmDiagnostics(): String = agent.swarmDiagnostics()
    @JavascriptInterface fun setSwarmModel(id: String) = agent.setManualSwarmModel(id.ifBlank { null })
    @JavascriptInterface fun clearSwarmModel() = agent.clearManualSwarmModel()

    @JavascriptInterface fun listFiles(): String = JSONArray(agent.listWorkspaceFiles()).toString()
    @JavascriptInterface fun readFile(path: String): String = runCatching { agent.readWorkspaceFile(path) }
        .getOrElse { JSONObject().put("error", it.message ?: "read failed").toString() }
    @JavascriptInterface fun writeFile(path: String, content: String): String = runCatching { agent.writeWorkspaceFile(path, content) }
        .getOrElse { JSONObject().put("error", it.message ?: "write failed").toString() }
    @JavascriptInterface fun checkpoint(label: String): String = runCatching { agent.checkpointWorkspace(label).name }
        .getOrElse { "ERROR: ${it.message}" }
    @JavascriptInterface fun listCheckpoints(): String = JSONArray(agent.listWorkspaceCheckpoints()).toString()
    @JavascriptInterface fun restoreCheckpoint(name: String): String = runCatching {
        agent.restoreWorkspaceCheckpoint(name).toString()
    }.getOrElse { "false" }

    @JavascriptInterface fun webSearch(query: String) = async("web_search") { browser.search(query).toString() }
    @JavascriptInterface fun webOpen(url: String) = async("web_open") { browser.open(url).toString() }

    private fun exclusiveAsync(kind: String, work: suspend () -> Any?) {
        async(kind) { exclusiveJobs.withLock { work() } }
    }

    private fun async(kind: String, work: suspend () -> Any?) {
        val id = nextJobId.getAndIncrement().toString()
        activity.setStatus("GameForge: $kind queued (#$id)")
        activity.pushWebEvent("job", JSONObject().put("id", id).put("kind", kind).put("state", "queued"))
        scope.launch {
            activity.pushWebEvent("job", JSONObject().put("id", id).put("kind", kind).put("state", "running"))
            runCatching { work() }
                .onSuccess { result ->
                    activity.pushWebEvent(
                        "job",
                        JSONObject()
                            .put("id", id)
                            .put("kind", kind)
                            .put("state", "done")
                            .put("result", result?.toString() ?: "")
                    )
                }
                .onFailure { error ->
                    activity.pushWebEvent(
                        "job",
                        JSONObject()
                            .put("id", id)
                            .put("kind", kind)
                            .put("state", "error")
                            .put("error", error.message ?: error.javaClass.simpleName)
                    )
                }
        }
    }

    fun shutdown() { scope.cancel() }
}
