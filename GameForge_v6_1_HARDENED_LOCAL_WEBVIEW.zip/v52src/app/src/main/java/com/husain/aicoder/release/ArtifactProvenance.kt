package com.husain.aicoder.release

import com.husain.aicoder.agent.CodingWorkspace
import com.husain.aicoder.game.GameSpec
import org.json.JSONArray
import org.json.JSONObject

/** Makes the final result auditable: goal -> design -> artifacts -> evidence -> release hashes. */
class ArtifactProvenance(private val workspace: CodingWorkspace) {
    private fun Boolean?.orFalse(): Boolean = this == true
    fun write(goal: String, spec: GameSpec, report: JSONObject): String {
        val required = listOf(
            "GAME_SPEC.json",
            "GAME_DESIGN.md",
            "ASSET_MANIFEST.json",
            "gameforge/GAMEPLAY_SCENARIOS.json",
            "gameforge/PROJECT_INDEX.json",
            "gameforge/GAME_BENCHMARK_V3.json",
            "gameforge/GAME_BENCHMARK_V4.json",
            "gameforge/FINAL_RELEASE_MANIFEST.json",
            "gameforge/ULTIMATE_BENCHMARK.json"
        )
        val artifacts = JSONArray()
        required.forEach { path ->
            val ok = runCatching { workspace.sha256(path); true }.getOrElse { false }
            artifacts.put(JSONObject().put("path", path).put("present", ok).apply {
                if (ok) put("sha256", workspace.sha256(path))
            })
        }
        val missing = (0 until artifacts.length()).count { !artifacts.optJSONObject(it)?.optBoolean("present", false).orFalse() }
        val out = JSONObject()
            .put("version", "1.0")
            .put("goal", goal)
            .put("game_title", spec.title)
            .put("artifacts", artifacts)
            .put("missing_count", missing)
            .put("quality_score", report.optDouble("score", 0.0))
            .put("generated_at_ms", System.currentTimeMillis())
        return workspace.write("gameforge/ARTIFACT_PROVENANCE.json", out.toString(2))
    }
}
