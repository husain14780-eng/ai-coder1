package com.husain.aicoder.game

import com.husain.aicoder.agent.CodingWorkspace

/** Writes durable design contracts and a deterministic Godot starter when the workspace is empty. */
class GameProjectScaffolder(private val workspace: CodingWorkspace, private val assetPlanner: AssetPlanner = AssetPlanner()) {
    fun scaffold(spec: GameSpec): List<String> {
        val written = mutableListOf<String>()
        written += workspace.write("GAME_SPEC.json", spec.toJson().toString(2))
        written += workspace.write("GAME_DESIGN.md", designMarkdown(spec))
        written += workspace.write("ASSET_MANIFEST.json", assetPlanner.manifest(spec).toString(2))
        written += workspace.write("GAMEFORGE_CONTRACT.md", contractMarkdown())
        written += workspace.write("gameforge/README.md", "This folder contains generated game architecture artifacts and verification reports.\n")
        written += workspace.write("gameforge/tests/SMOKE_TESTS.md", smokeTests(spec))
        written += workspace.write("gameforge/SHIPPING_CHECKLIST.md", shippingChecklist())
        written += workspace.write("gameforge/procedural_asset_factory.gd", ProceduralAssetScript)
        written += workspace.write("gameforge/ai_bridge.gd", AiBridgeScript)

        if (!java.io.File(workspace.root, "project.godot").isFile) {
            written += workspace.write("project.godot", starterProject())
        }
        if (!java.io.File(workspace.root, "main.tscn").isFile) {
            written += workspace.write("main.tscn", starterScene())
        }
        if (!java.io.File(workspace.root, "scripts/game_root.gd").isFile) {
            written += workspace.write("scripts/game_root.gd", starterRootScript())
        }
        return written
    }

    private fun designMarkdown(s: GameSpec): String = buildString {
        appendLine("# ${s.title}")
        appendLine()
        appendLine("Genre: ${s.genre}")
        appendLine("Camera: ${s.camera}")
        section("Core loop", s.coreLoop)
        section("Mechanics", s.mechanics)
        section("Player", s.player)
        section("Enemies", s.enemies)
        section("Progression", s.progression)
        section("Scenes", s.scenes)
        section("UI", s.ui)
        section("Audio", s.audio)
        section("Save system", s.saveSystem)
        section("Performance targets", s.performanceTargets)
        section("Polish passes", s.polishPasses)
        section("Constraints", s.constraints)
    }

    private fun section(title: String, rows: List<String>) {
        appendLine("## $title")
        rows.forEach { appendLine("- $it") }
        appendLine()
    }

    private fun contractMarkdown() = """
        # GameForge Contract

        Generated code must satisfy these invariants:
        1. Keep game specification and implementation aligned.
        2. Do not remove an existing feature without updating the spec or documenting the migration.
        3. Every gameplay system must expose a deterministic smoke-test path.
        4. Every high-risk change gets a fresh build/playtest observation.
        5. Performance regressions require evidence before acceptance.
        6. A successful build is not the same thing as a successful game.
    """.trimIndent() + "\n"

    private fun smokeTests(spec: GameSpec) = buildString {
        appendLine("# Smoke tests for ${spec.title}")
        appendLine("- Boot game without crash")
        appendLine("- Reach gameplay scene")
        appendLine("- Spawn player")
        appendLine("- Exercise core interaction")
        appendLine("- Trigger at least one progression event")
        appendLine("- Open and close pause/settings UI")
        appendLine("- Trigger game-over or restart path")
        appendLine("- Save then load a valid state")
        appendLine("- Check for missing resources / null references")
        appendLine("- Capture fresh final observation")
    }

    private fun shippingChecklist() = """
        # GameForge Shipping Checklist
        - [ ] Boot without a blocking error
        - [ ] Core loop is playable
        - [ ] Failure/restart path works
        - [ ] Main UI states work
        - [ ] Save/load is validated where used
        - [ ] Fresh playtest evidence exists
        - [ ] Architecture graph is current
        - [ ] Performance report reviewed
        - [ ] Final GameForge benchmark passes
    """.trimIndent() + "\n"

    private fun starterProject() = """
        [application]
        config/name="GameForge Starter"
        run/main_scene="res://main.tscn"
        config/features=PackedStringArray("4.7", "GL Compatibility")

        [display]
        window/size/viewport_width=960
        window/size/viewport_height=540

        [rendering]
        renderer/rendering_method="gl_compatibility"
        renderer/rendering_method.mobile="gl_compatibility"
    """.trimIndent() + "\n"

    private fun starterScene() = """
        [gd_scene load_steps=3 format=3]

        [ext_resource path="res://scripts/game_root.gd" type="Script" id="1"]
        [ext_resource path="res://gameforge/ai_bridge.gd" type="Script" id="2"]

        [node name="GameRoot" type="Node3D"]
        script = ExtResource("1")

        [node name="GameForgeBridge" type="Node" parent="."]
        script = ExtResource("2")
    """.trimIndent() + "\n"

    private fun starterRootScript() = """
        extends Node3D
        class_name GameForgeStarterRoot

        var player_position := Vector3(0, 1.2, 0)
        var velocity := Vector3.ZERO
        var finished := false
        var deaths := 0
        var last_action := ""
        var player: CharacterBody3D

        func _ready() -> void:
            _build_world()

        func _physics_process(delta: float) -> void:
            if player == null:
                return
            if not player.is_on_floor():
                player.velocity.y -= 20.0 * delta
            player.move_and_slide()
            if player.global_position.y < -5.0:
                deaths += 1
                reset_test()
            if player.global_position.z < -12.0:
                finished = true

        func _build_world() -> void:
            var light := DirectionalLight3D.new()
            light.rotation_degrees = Vector3(-50, -25, 0)
            light.light_energy = 1.2
            add_child(light)

            var camera := Camera3D.new()
            camera.position = Vector3(0, 5, 9)
            camera.look_at(Vector3(0, 1, -4))
            add_child(camera)

            var floor := StaticBody3D.new()
            floor.position = Vector3(0, -0.25, 0)
            add_child(floor)
            var floor_mesh := MeshInstance3D.new()
            var box := BoxMesh.new()
            box.size = Vector3(18, 0.5, 30)
            floor_mesh.mesh = box
            floor.add_child(floor_mesh)
            var floor_collision := CollisionShape3D.new()
            var shape := BoxShape3D.new()
            shape.size = box.size
            floor_collision.shape = shape
            floor.add_child(floor_collision)

            player = CharacterBody3D.new()
            player.name = "Player"
            player.position = player_position
            add_child(player)
            var mesh := MeshInstance3D.new()
            var capsule := CapsuleMesh.new()
            capsule.radius = 0.4
            capsule.height = 1.8
            mesh.mesh = capsule
            player.add_child(mesh)
            var collision := CollisionShape3D.new()
            var capsule_shape := CapsuleShape3D.new()
            capsule_shape.radius = 0.4
            capsule_shape.height = 1.8
            collision.shape = capsule_shape
            player.add_child(collision)

        func apply_action(action: Dictionary) -> void:
            last_action = JSON.stringify(action)
            var x := float(action.get("x", 0.0))
            var jump := bool(action.get("jump", false))
            player.velocity.x = clamp(x, -1.0, 1.0) * 4.5
            if jump and player.is_on_floor():
                player.velocity.y = 7.0

        func reset_test() -> void:
            finished = false
            if player != null:
                player.global_position = player_position
                player.velocity = Vector3.ZERO

        func get_observation() -> Dictionary:
            return {
                "player_position": [player.global_position.x, player.global_position.y, player.global_position.z] if player else [0,0,0],
                "velocity": [player.velocity.x, player.velocity.y, player.velocity.z] if player else [0,0,0],
                "grounded": player.is_on_floor() if player else false,
                "deaths": deaths,
                "finished": finished,
                "last_action": last_action,
                "errors": []
            }

        func get_gameforge_observation() -> Dictionary:
            var o := get_observation()
            o["fps"] = Performance.get_monitor(Performance.TIME_FPS)
            o["frame_ms"] = Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0
            o["physics_ms"] = Performance.get_monitor(Performance.TIME_PHYSICS_PROCESS) * 1000.0
            o["node_count"] = Performance.get_monitor(Performance.OBJECT_NODE_COUNT)
            o["player_state"] = "finished" if finished else "alive"
            return o
    """.trimIndent() + "\n"

    private companion object {
        const val AiBridgeScript = """
            extends Node

            var plugin = null
            var world = null

            func _ready():
                world = get_parent()
                plugin = Engine.get_singleton("AICoderGodotBridge")
                if plugin:
                    plugin.ai_action.connect(_on_ai_action)
                    plugin.request_observation.connect(_on_request_observation)
                    plugin.restart_test.connect(_on_restart_test)
                    plugin.load_workspace_pack.connect(_on_load_workspace_pack)
                    _send_observation()

            func _on_ai_action(action_json: String):
                var parsed = JSON.parse_string(action_json)
                if typeof(parsed) == TYPE_DICTIONARY and world.has_method("apply_action"):
                    world.apply_action(parsed)
                elif typeof(parsed) == TYPE_DICTIONARY:
                    plugin.postObservation(JSON.stringify({"errors":["world has no apply_action method"], "observation_version": Time.get_ticks_msec()}))
                    return
                _send_observation()

            func _on_request_observation():
                _send_observation()

            func _on_restart_test():
                if world.has_method("reset_test"):
                    world.reset_test()
                _send_observation()

            func _on_load_workspace_pack(path: String, target: String):
                var loaded := ProjectSettings.load_resource_pack(path, true)
                if not loaded:
                    plugin.postObservation(JSON.stringify({"errors":["resource_pack_load_failed", path], "observation_version": Time.get_ticks_msec()}))
                    return
                var scene_path := "res://" + target.trim_prefix("res://")
                var err := get_tree().change_scene_to_file(scene_path)
                if err != OK:
                    plugin.postObservation(JSON.stringify({"errors":["scene_load_failed", err, scene_path], "observation_version": Time.get_ticks_msec()}))

            func _send_observation():
                if plugin == null:
                    return
                var data: Dictionary
                if world.has_method("get_gameforge_observation"):
                    data = world.get_gameforge_observation()
                elif world.has_method("get_observation"):
                    data = world.get_observation()
                else:
                    data = {"errors": ["GameForge bridge: world has no observation method"]}
                data["screenshot_path"] = _capture_screenshot()
                data["observation_version"] = Time.get_ticks_msec()
                plugin.postObservation(JSON.stringify(data))

            func _capture_screenshot() -> String:
                var image := get_viewport().get_texture().get_image()
                var dir_path := OS.get_user_data_dir().path_join("observations")
                DirAccess.make_dir_recursive_absolute(dir_path)
                var file_path := dir_path.path_join("obs_%d.jpg" % Time.get_ticks_msec())
                image.save_jpg(file_path, 70)
                return file_path
        """

        const val ProceduralAssetScript = """
            extends Node
            class_name GameForgeProceduralAssetFactory

            static func box(parent: Node3D, size: Vector3, material: Material = null) -> MeshInstance3D:
                var mesh := MeshInstance3D.new()
                var primitive := BoxMesh.new()
                primitive.size = size
                mesh.mesh = primitive
                mesh.material_override = material
                parent.add_child(mesh)
                return mesh

            static func sphere(parent: Node3D, radius: float, material: Material = null) -> MeshInstance3D:
                var mesh := MeshInstance3D.new()
                var primitive := SphereMesh.new()
                primitive.radius = radius
                primitive.height = radius * 2.0
                mesh.mesh = primitive
                mesh.material_override = material
                parent.add_child(mesh)
                return mesh
        """
    }
}
