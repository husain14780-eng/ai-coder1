package com.husain.aicoder.game

import org.json.JSONArray
import org.json.JSONObject

/** Procedural asset/style contract shared by generated scenes so a game feels coherent. */
class AssetStyleSystem {
    fun styleBook(spec: GameSpec): JSONObject = JSONObject()
        .put("style_id", "gameforge_${spec.genre}_${spec.camera}")
        .put("palette", JSONArray(listOf("primary", "secondary", "accent", "warning", "background")))
        .put("material_rules", JSONArray(listOf("roughness range per material family", "consistent metallic semantics", "avoid random emissive colors")))
        .put("lighting_rules", JSONArray(listOf("key light direction is coherent", "player remains readable", "critical interactables receive contrast")))
        .put("ui_rules", JSONArray(listOf("consistent spacing", "clear hierarchy", "state feedback for every interactive control")))
        .put("generated_at_ms", System.currentTimeMillis())
}
