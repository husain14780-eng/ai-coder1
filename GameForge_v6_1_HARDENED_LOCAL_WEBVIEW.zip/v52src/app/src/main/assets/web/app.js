const GF = {
  jobs: new Map(),
  tab(id) {
    document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
    const el = document.getElementById(id);
    if (el) el.classList.add('active');
    localStorage.setItem('gf.activeTab', id);
  },
  goal() { return document.getElementById('goal').value.trim(); },
  run(fn) {
    const goal = this.goal();
    if (!goal) { this.log('Enter a goal first'); return; }
    try { GameForgeNative[fn](goal); } catch (e) { this.log(`Native call failed: ${e}`); }
  },
  build() { this.run('buildGame'); },
  apex() { this.run('buildApex'); },
  code() { this.run('runCoding'); },
  resume() { try { GameForgeNative.resumeMission(); } catch (e) { this.log(String(e)); } },
  optimize() { try { GameForgeNative.optimizeGame(); } catch (e) { this.log(String(e)); } },
  verify() { try { GameForgeNative.verifyRelease(); } catch (e) { this.log(String(e)); } },
  inspect() { try { GameForgeNative.inspectGame(); } catch (e) { this.log(String(e)); } },
  benchmark() { try { GameForgeNative.benchmarkGame(); } catch (e) { this.log(String(e)); } },
  log(x) {
    const text = String(x);
    document.getElementById('status').textContent = text;
    document.getElementById('buildlog').textContent = text;
  },
  files() {
    try {
      const value = JSON.parse(GameForgeNative.listFiles());
      const files = Array.isArray(value) ? value : [];
      document.getElementById('files').innerHTML = files.map(x => `<div>${String(x).replaceAll('&','&amp;').replaceAll('<','&lt;')}</div>`).join('') || '<div>Workspace is empty.</div>';
    } catch (e) { this.log(`File list failed: ${e}`); }
  },
  checkpoint() {
    try { this.log(`Checkpoint: ${GameForgeNative.checkpoint('manual')}`); } catch (e) { this.log(String(e)); }
  },
  checkpoints() {
    try { document.getElementById('checkpoints').textContent = GameForgeNative.listCheckpoints(); } catch (e) { this.log(String(e)); }
  },
  search() {
    const q = document.getElementById('query').value.trim();
    if (!q) { this.log('Enter a search query'); return; }
    try { GameForgeNative.webSearch(q); } catch (e) { this.log(String(e)); }
  },
  open() {
    const url = document.getElementById('url').value.trim();
    if (!/^https?:\/\//i.test(url)) { this.log('Use an http:// or https:// URL'); return; }
    try { GameForgeNative.webOpen(url); } catch (e) { this.log(String(e)); }
  },
  showState() {
    try {
      const state = JSON.parse(GameForgeNative.getState());
      document.getElementById('modelstate').textContent = JSON.stringify(state, null, 2);
    } catch (e) { this.log(`State unavailable: ${e}`); }
  },
  showSwarm() {
    try { document.getElementById('mlout').textContent = GameForgeNative.swarmStatus(); } catch (e) { this.log(String(e)); }
  }
};

window.GameForge = {
  receive(raw) {
    try {
      const e = typeof raw === 'string' ? JSON.parse(raw) : raw;
      if (e.type === 'status') {
        GF.log(e.payload.message);
      } else if (e.type === 'godot') {
        GF.log(`Godot preview: ${e.payload.visible ? 'visible' : 'hidden'}`);
      } else if (e.type === 'model' || e.type === 'adapter') {
        GF.showState();
      } else if (e.type === 'job') {
        const p = e.payload || {};
        GF.jobs.set(String(p.id), p);
        const lines = Array.from(GF.jobs.values()).slice(-12).map(j => `#${j.id} ${j.kind}: ${j.state}${j.error ? ' • ' + j.error : ''}`);
        document.getElementById('jobs').textContent = lines.join('\n');
        GF.log(`#${p.id} ${p.kind}: ${p.state}${p.error ? ' • ' + p.error : ''}`);
        if (p.result) {
          if (p.kind.startsWith('web_')) document.getElementById('webout').textContent = p.result;
          if (p.kind === 'swarm_benchmark' || p.kind === 'benchmark') document.getElementById('mlout').textContent = p.result;
          if (p.kind === 'inspect') document.getElementById('buildlog').textContent = p.result;
        }
      }
    } catch (err) {
      GF.log(String(err));
    }
  }
};

window.addEventListener('load', () => {
  const savedTab = localStorage.getItem('gf.activeTab');
  const savedGoal = localStorage.getItem('gf.goal');
  if (savedGoal) document.getElementById('goal').value = savedGoal;
  if (savedTab && document.getElementById(savedTab)) GF.tab(savedTab);
  try { GF.showState(); } catch (_) {}
  const goal = document.getElementById('goal');
  goal.addEventListener('input', () => localStorage.setItem('gf.goal', goal.value));
});
