# GameForge 6.1 release checks

## Static/source checks

- [x] V6.1 version and release manifest are aligned.
- [x] WebView navigation is confined to the bundled local asset page.
- [x] File/content and universal file-URL access are disabled.
- [x] Heavy AI/Godot bridge jobs are serialized and receive unique IDs.
- [x] Workspace writes, append/replace, checkpoint and restore mutations are serialized.
- [x] Workspace paths are canonicalized and confined.
- [x] Web search/page fetching has bounded query/response sizes.
- [x] WebView UI state persists through DOM storage.
- [x] JS/native API names match.
- [x] JSON manifests/configuration parse successfully.
- [x] No private keystore, signing key, PEM, or certificate secret is shipped in the source archive.

## Environment limits

- [ ] Final Android Gradle/NDK link in a full Android SDK/NDK environment.
- [ ] APK installation/execution on the target Galaxy device.
- [ ] Real GGUF inference on target hardware.
- [ ] Real native multimodal execution through an image-capable runtime.
- [ ] On-device Qwen gradient training.
