# Local model trust / provenance

GameForge accepts user-selected GGUF files; it does not silently download or trust arbitrary model URLs at runtime. v5.3 validates the GGUF magic and supported version (2-4), copies through a temporary file, atomically installs the result, and records the SHA-256 and detected catalog profile in the local model registry.

A production deployment may add a private trusted-manifest of exact SHA-256 hashes for the model files it intends to use. No private certificates, signing keys, or vendor credentials are bundled in this source release.
