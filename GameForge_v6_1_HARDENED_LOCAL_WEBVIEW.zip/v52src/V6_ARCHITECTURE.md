# GameForge V6.1 Architecture — local-first hardened WebView

V6.1 is local-first. The Android app is a thin WebView host. The bundled HTML/CSS/JS is loaded from APK assets. JavaScript communicates only with the native `GameForgeNative` bridge, and the bridge is attached only to the bundled local page.

Native services retained from V5.3:
- local GGUF model loading and swarm routing
- Qwen3 thinking planner and Qwen2.5-Coder 7B Q4 coding path
- LoRA adapters
- memory/experience/continuous-learning/evaluation systems
- GameForge and Apex generation/repair/verification
- embedded Godot Android runtime + AICoderGodotBridge
- screen vision and autonomous gameplay

V6/V6.1 surface:
- Web UI navigation with persisted active tab and goal
- native workspace file API with canonical-path confinement
- atomic text writes and serialized checkpoint/restore mutations
- job IDs and serialized heavy AI/Godot jobs
- local checkpoint listing
- explicit local web search/page fetch tool with response bounds
- model/adapter state events and long-running job events

Security boundary:
- the WebView loads only `file:///android_asset/web/index.html`
- file/content access is disabled
- universal file-URL access and mixed content are disabled
- non-local WebView navigation is blocked
- the JS bridge is not exposed to arbitrary web pages
- web requests are performed by native code only after an explicit UI action
- workspace paths are confined by `CodingWorkspace.resolve()`
