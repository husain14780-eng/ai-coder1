# GameForge changelog

## 6.1 — Hardened Local WebView
- Serialized heavy AI/Godot jobs with unique job IDs.
- Serialized workspace mutations and hardened checkpoint handling.
- Restricted WebView navigation to bundled local assets.
- Added bounded native web search/page fetching.
- Added persisted Web UI tab/goal state and checkpoint listing.
- Fixed GitHub Actions to build the checked-out V6 source directly instead of expecting a V5.3 ZIP.

## 6.0 — Local WebView
- Replaced the native workflow surface with a bundled local WebView.
- Preserved local model, ML, memory, vision, GameForge and Godot systems.
