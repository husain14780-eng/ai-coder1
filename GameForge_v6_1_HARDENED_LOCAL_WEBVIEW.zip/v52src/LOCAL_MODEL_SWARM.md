# GameForge v5 — Local Model Swarm MAX

GameForge v5 is local-only. There is no runtime dependency on a cloud API.

## Curated serious-model roster

| Role | Model | Preferred local quant | Notes |
|---|---|---|---|
| General / Director / Critic | Qwen3-4B-Instruct-2507 | Q6_K | Primary 4B instruction model |
| Deep reasoning / architecture | Qwen3-4B-Thinking-2507 | Q6_K | Dedicated thinking model |
| Coding specialist | Qwen2.5-Coder-7B-Instruct | Q4_K_M | Primary coding specialist; deliberate THINKING mode |
| Vision specialist | Qwen2.5-VL-3B-Instruct | Q6_K | Model cataloged as the vision specialist; the current v5 text-native runtime refuses to fake image inference |

We intentionally do **not** install 0.3B/0.5B/1B helper models. The model roster is deliberately biased toward the strongest serious models that fit the phone envelope or have a clearly documented heavy/experimental gate.

## Routing

Every prompt is classified into a task family and routed to the installed specialist:

- coding → Qwen2.5-Coder-7B specialist in deliberate THINKING mode
- reasoning/design/quality → Qwen3-4B-Thinking-2507
- general/director/critic → Qwen3-4B-Instruct-2507
- vision → Qwen2.5-VL-3B profile (native multimodal backend is required before image prompts are enabled)

The wrapper switches GGUFs before each generation. Existing GameForge agents keep using the same `InferenceEngine` interface.

## Five learning modes

1. **Supervised** — learns from verified success/failure labels.
2. **Unsupervised** — clusters observed model outcomes.
3. **Semi-supervised** — generates pseudo-labels only above a confidence threshold.
4. **Self-supervised** — shapes masked prediction / future adapter-training material.
5. **Reinforcement learning** — Q-learning updates routing rewards from successful and failed tool episodes.

These systems learn routing/experience. They do not mutate the base Qwen/DeepSeek weights after every task. Adapter promotion remains a separately gated training process.

## RAM policy

The device is treated as an 8 GB-class Android phone. 4B models are the dependable baseline. Qwen2.5-Coder-7B Q4_K_M is the primary coding specialist. The runtime still performs normal Android memory checks and model swapping, but the coder is no longer excluded by the old DeepSeek-specific heavy-model gate.

## Important multimodal boundary

The existing native bridge is a text-generation llama.cpp bridge. It is now model-agnostic at the prompt-template level, but it does not yet accept image tensors/projector inputs. The vision model is cataloged and future-ready, while pixel/telemetry QA remains active through the existing non-VLM vision systems. This avoids pretending a text-only backend is a real vision model.

## Automatic specialist benchmark

The app includes a local benchmark action that runs short coding/reasoning/general suites against each installed non-heavy specialist that passes the live RAM guard. Results are fed into the routing learner.
