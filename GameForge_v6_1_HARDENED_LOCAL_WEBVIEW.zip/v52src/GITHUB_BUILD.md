# Build GameForge 6.1 on GitHub

The repository workflow builds the checked-out V6.1 source directly.

1. Push the project to the `main` branch or manually run **Actions → Build GameForge V6.1 APK → Run workflow**.
2. The workflow installs JDK 17, Android API 36, NDK 29.0.13113456, CMake 3.31.6 and Gradle 8.13.
3. It runs `tools/check_v6_release.py` and `tools/audit_v6.py`.
4. It builds `app-debug.apk` and records its SHA-256.
5. The artifact is `gameforge-v6.1-hardened-debug-apk`.

No model weights or signing secrets are committed. Release signing remains environment/property driven.
