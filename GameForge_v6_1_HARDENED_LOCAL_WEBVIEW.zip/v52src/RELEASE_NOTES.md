# GameForge v6.1 — Hardened Local WebView

V6.1 keeps GameForge local-first while making the WebView control surface safer and more predictable.

### Workflow hardening
- Heavy AI/Godot jobs are serialized so overlapping builds cannot mutate the same model/workspace pipeline concurrently.
- Every queued job receives a unique ID and queued/running/done/error events.
- Workspace writes, append/replace, checkpoint and restore are serialized.
- Workspace text writes have a bounded size and atomic finalization.
- WebView navigation is restricted to the bundled local UI; mixed content and universal file-URL access are disabled.
- Native web fetch/search has bounded request/response sizes.
- Web UI tab/goal state persists through DOM storage.
- Model/adapter events refresh the Web UI immediately.

### Release workflow fix
The GitHub Actions workflow now builds the checked-out V6.1 source directly instead of looking for a legacy V5.3 source ZIP.

### Preserved systems
Local GGUF inference, Qwen2.5-Coder 7B Q4 coding, Qwen3 thinking planner, LoRA, memory/continuous learning/evaluation, GameForge/Apex generation, vision, autonomous gameplay, and the embedded Godot Android runtime remain part of the architecture.
