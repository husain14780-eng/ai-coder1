# Model integration — 5.3 VERIFIED LOCAL-SWARM

## Local model policy

GameForge is local-first. The app does **not** require a cloud model API and does not include a built-in model downloader. Import trusted local GGUF files through Android file selection. The importer validates a GGUF header, uses an atomic `.part` file, records provenance/SHA-256, and never executes model files as code.

The curated strong-on-device roster is:

- Qwen3-4B-Instruct-2507 — general/game director/coding/tool use.
- Qwen3-4B-Thinking-2507 — deeper reasoning, architecture and difficult debugging.
- Qwen2.5-Coder-7B-Instruct Q4_K_M — primary coding specialist, deliberate THINKING mode.
- Qwen2.5-VL-3B-Instruct — reserved vision specialist; the native llama text bridge does not pretend to support multimodal input.

Only one text model is intended to be resident at a time. Model selection is based on task role, benchmark history and live RAM.

## Advanced code knowledge

The language models already contain substantial general programming knowledge, including common engine/game-development patterns. That does not make their Godot API knowledge permanently current. For fresh engine APIs, the recommended learning source is an **offline copy/index of the official Godot documentation**, not mandatory internet search. A future optional LAN/web bridge can be exposed as an explicit user setting, but the core runtime remains fully local.

## Native runtime

The JNI layer is built around llama.cpp and is pinned to ref `b10976` for reproducibility. On Android `arm64-v8a`, CMake enables `GGML_CPU_KLEIDIAI=ON`.

The native adapter path uses llama.cpp's multi-adapter API and the app serializes load/generation/cleanup operations to avoid model-switch races.

## Training

The phone collects and curates experience continuously. LoRA/SFT candidates are evaluated outside the immutable base model before promotion. The release does not claim full on-device gradient training of the base Qwen model.

## What is and is not bundled

The source archive does **not** contain a standalone Godot editor executable or a prebuilt Godot engine binary. The Android app declares the official `org.godotengine:godot` dependency, so Gradle resolves the Godot Android library at build time. Generated games are packaged as Godot resource packs and loaded by the embedded Godot runtime.
