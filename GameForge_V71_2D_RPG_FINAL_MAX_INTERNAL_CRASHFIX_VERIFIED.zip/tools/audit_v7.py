#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
errors=[]; warnings=[]
def read(rel):
    p=ROOT/rel
    if not p.is_file(): errors.append(f"missing {rel}"); return ""
    return p.read_text(encoding='utf-8',errors='replace')

# Hard removal: these are source-level forbidden features, not merely disabled UI.
manifest=read('app/src/main/AndroidManifest.xml')
source_files=list((ROOT/'app/src/main').rglob('*.kt'))+list((ROOT/'app/src/main').rglob('*.xml'))
source='\n'.join(p.read_text(encoding='utf-8',errors='replace') for p in source_files if p.is_file())
for needle in ['BIND_ACCESSIBILITY_SERVICE','FOREGROUND_SERVICE_MEDIA_PROJECTION','AccessibilityService','ScreenCaptureService','DeviceInputBridge','mediaProjection','device_tap','device_swipe','device_back','device_home','device_type','get_device_screen_observation']:
    if needle in manifest or needle in source: errors.append(f'forbidden device-level feature remains: {needle}')
for rel in ['app/src/main/java/com/husain/aicoder/input/AICoderAccessibilityService.kt','app/src/main/java/com/husain/aicoder/input/DeviceInputBridge.kt','app/src/main/java/com/husain/aicoder/vision/ScreenCaptureService.kt','app/src/main/res/xml/accessibility_service_config.xml']:
    if (ROOT/rel).exists(): errors.append(f'obsolete device-capture file remains: {rel}')

required=[
 ('app/src/main/java/com/husain/aicoder/vision/LocalGameVisionEngine.kt',['LocalGameVisionEngine','embedding','motion_delta']),
 ('app/src/main/java/com/husain/aicoder/quality/MassiveQASuite.kt',['96','fuzz_replay','real_executed_case_count']),
 ('app/src/main/java/com/husain/aicoder/game/ProceduralMMORPGWorldPlanner.kt',['region_count','quests','world_events']),
 ('app/src/main/java/com/husain/aicoder/game/AssetQualityPipeline.kt',['missing_animation_frames','orphan_png_count','style_variants']),
 ('app/src/main/java/com/husain/aicoder/version/VersionCheckpointSystem.kt',['markStable','latestStable','restore']),
 ('app/src/main/java/com/husain/aicoder/quality/PerformanceOptimizationEngine.kt',['run_massive_qa','rolled_back','perf_stable']),
 ('app/src/main/java/com/husain/aicoder/router/AdaptiveModelRouter.kt',['route','research','performance']),
 ('app/src/main/java/com/husain/aicoder/web/MatureResearchAgent.kt',['multi_query','cache','trust_score']),
 ('app/src/main/java/com/husain/aicoder/mission/GameForgeApexEngine.kt',['autonomous repair/retest','performanceOptimizer','releaseSignature']),
 ('app/src/main/java/com/husain/aicoder/core/HeavyTaskCoordinator.kt',['Mutex','withLock','activeTask']),
 ('app/src/main/java/com/husain/aicoder/core/BoundedFileReader.kt',['tailLines','countLines']),
 ('app/src/main/java/com/husain/aicoder/ml/MLTrainingCoordinator.kt',['HeavyTaskCoordinator','ml:training']),
 ('app/src/main/java/com/husain/aicoder/swarm/SwarmInferenceEngine.kt',['HeavyTaskCoordinator','safeBatch','safeThreads']),
 ('app/src/main/java/com/husain/aicoder/memory/BotMemoryStore.kt',['maxStatsEntries','trimStats'])
]
for rel,needles in required:
    txt=read(rel)
    for n in needles:
        if n not in txt: errors.append(f'{rel} missing contract: {n}')

# Release index integrity. FILES.txt is a reproducible source inventory, not a generated guess.
files_index = ROOT / "FILES.txt"
if not files_index.is_file():
    errors.append("missing FILES.txt")
else:
    excluded = {".git", "build", ".gradle", "__pycache__"}
    actual = []
    for path in sorted(ROOT.rglob("*")):
        rel = path.relative_to(ROOT)
        if not path.is_file() or any(part in excluded for part in rel.parts):
            continue
        actual.append("./" + rel.as_posix())
    if files_index.read_text(encoding="utf-8").splitlines() != actual:
        errors.append("FILES.txt does not match the current source tree")

# Ensure manifest permission set is intentionally minimal.
permissions=re.findall(r'uses-permission[^>]+android:name="([^"]+)"',manifest)
allowed={'android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE','android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_SPECIAL_USE','android.permission.POST_NOTIFICATIONS'}
extra=[p for p in permissions if p not in allowed]
if extra: errors.append('unexpected Android permissions: '+', '.join(extra))

# Check JSON release metadata.
try:
    m=json.loads(read('RELEASE_MANIFEST.json'))
    if m.get('versionCode')!=71: errors.append('RELEASE_MANIFEST versionCode is not 71')
    if m.get('version')!='7.1-2D-RPG-FINAL-MAX-INTERNAL': errors.append('RELEASE_MANIFEST version mismatch')
except Exception as e: errors.append('invalid RELEASE_MANIFEST.json: '+str(e))

# Basic Kotlin structural checks for new feature files.
for rel,_ in required:
    txt=read(rel)
    if txt:
        # Remove comments/strings approximately for brace balance. This is deliberately conservative.
        if txt.count('{') != txt.count('}'):
            errors.append(f'brace imbalance in {rel}: {txt.count("{")} vs {txt.count("}")}')
        if txt.count('(') != txt.count(')'):
            errors.append(f'paren imbalance in {rel}: {txt.count("(")} vs {txt.count(")")}')

# No Gradle wrapper/APK is expected in the source archive; warn rather than fake a build claim.
if not any(ROOT.rglob('gradlew')): warnings.append('No Gradle wrapper shipped; CI provisions Gradle 8.13.')
if not any(ROOT.rglob('*.apk')): warnings.append('No APK bundled; Android build/device execution still requires CI/device evidence.')

print(f'GameForge V7 deep internal audit: errors={len(errors)} warnings={len(warnings)}')
for e in errors: print('ERROR:',e)
for w in warnings: print('WARN:',w)
if errors: raise SystemExit(1)
print('V7 DEEP AUDIT PASS')

if not errors:
    print('V7.1 DEEP AUDIT PASS')
