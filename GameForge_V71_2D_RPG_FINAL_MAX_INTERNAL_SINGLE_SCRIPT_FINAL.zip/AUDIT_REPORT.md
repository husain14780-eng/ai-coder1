# GameForge V7 Reliability Audit

This release is a **source audit and bug-fix release**. It does not claim that an Android APK was physically built in this environment. The original v5 source release did not contain an APK, release keystore, or bundled Godot editor binary.

## Confirmed fixes in v5.1

- Fixed the LoRA clear JNI export mismatch (`nativeClearAdapter`).
- Prevented native generation from decoding past the loaded context window.
- Serialized model load/adapter/cleanup/destroy against generation.
- Connected Godot observations to the actual production `ToolExecutor` (the original main path had a stale/null observation bug).
- Required fresh observations after game actions, restart, and generated-game loading.
- Made Godot playtest pass/fail depend on action evidence and reported runtime errors, not boot alone.
- Fixed the visual regression test from accepting any `visual` key to requiring `visual.available=true`.
- Changed runtime Godot packaging from the 500-file agent listing to a complete capped listing (20,000 files).
- Validated `project.godot` and the requested main scene before packaging.
- Preserved existing user-authored GameForge contracts on reruns instead of overwriting them.
- Made model/adapter imports validate temporary files before atomic replacement and record SHA-256/provenance.
- Added GGUF version validation (v2-v4).
- Added robust model filename matching for generic `Qwen3-4B-Q4_K_M.gguf`.
- Preserved a LoRA across model switching only when the adapter belongs to the active base model; incompatible switches no longer silently reuse it.
- Fixed JPEG data URI MIME handling in the optional localhost VLM adapter.
- Hardened command-tool policy against `find -exec`, arbitrary Git mutations, Gradle init/settings injection, shell-style operators, and outside-workspace paths.
- Added property/environment based release signing configuration without shipping any private key.
- Made release benchmark artifact checks validate JSON/content rather than only checking that files exist.
- Added atomic workspace writes for core code/contract edits.

## V6 fixes verified in the final pass

- Fixed a real Kotlin syntax defect in `EpisodeStore.kt`: the class was missing its final closing brace. A Kotlin compiler syntax pass then reported no `expecting`/`unexpected tokens`/`unclosed` diagnostics across the source set; remaining local compiler diagnostics were dependency/classpath related because the Android/Gradle environment is not installed here.
- Coding implementation roles are forced to `ReasoningMode.THINKING` at the agent layer, while the native engine still receives the explicit thinking flag.
- Qwen3-4B-Thinking is the only catalog entry assigned to the dedicated `GAME_DESIGN` role; Qwen3-4B-Instruct remains general/director/critic.
- A new V6 build creates a checkpoint and resets a prior generated workspace before scaffolding, preventing stale project files from being reused accidentally.
- Final acceptance is now `regression_gate && package_ok`, so packaging failures cannot be hidden by an otherwise passing test suite.
- The GitHub workflow uses current documented action majors and validates the exact V6 ZIP with `unzip -tq` before extraction.

## Godot status

Godot is **embedded as the Android library dependency** `org.godotengine:godot:4.7.2.stable`; the generated Godot project is under `app/src/main/assets`, and `MainActivity` hosts `GodotFragment` and registers `AICoderGodotBridge`. The source ZIP does **not** contain the Godot editor executable. Gradle resolves the Godot Android AAR when building the APK.

At runtime, GameForge packages the generated workspace as a resource-pack ZIP and loads it into the embedded Godot process. This supports generated scenes/scripts/assets, but it is not identical to launching a separately exported Godot application: project-level settings and autoload behavior remain constrained by the host Godot process. GameForge therefore uses a bootstrap/contract approach and should avoid depending on project.godot-only settings that cannot be changed safely at runtime.

## Certificates / signing

No production signing certificate or private keystore is shipped. That is intentional. A release build can use `RELEASE_STORE_FILE`, `RELEASE_STORE_PASSWORD`, `RELEASE_KEY_ALIAS`, and `RELEASE_KEY_PASSWORD` via Gradle properties or environment variables. An actual APK certificate can only be verified after an APK is built; this source release cannot truthfully claim an APK signature.

## Web search decision

Web search is **not a core dependency** of GameForge. The base local models already contain strong coding/tool-use knowledge, but current Godot APIs can change after model training. The preferred future enhancement is an **optional offline Godot documentation/index pack**; an opt-in web knowledge bridge can be added later without making the core agent cloud-dependent.

## V7.1 single-script coding/runtime hardening audit

The coding path was hardened so Qwen2.5-Coder does not juggle multiple GDScript files during one implementation cycle. A coding/debug task must claim exactly one `.gd` target. The workspace records the target and hashes it before editing; direct `.gd` writes/replacements/appends are rejected unless they match that active focus. The active focus persists through failures and retests and is released only after the task exits. Mission persistence records the target path, baseline/current hashes, and last runtime evidence for safe resume.

Runtime verification was strengthened so deterministic and adaptive playtests count only fully successful runs, a partial run cannot inflate the pass count, and a playtest is completion-grade only when every requested iteration passes. The final mission gate requires both a fresh Godot test and a fully passing playtest. Tool cancellation now propagates rather than being swallowed as a normal error. While a script is focused, checkpoint/version restores and non-read-only Git commands are blocked to prevent accidental multi-file mutation outside the coding cycle.

A static deep audit after these changes reports zero errors across the V7 source, memory-safety, native API, JVM target, Kotlin compatibility, Android resource, in-app-only, and single-script-focus checks. This environment still does not contain the Android Gradle/NDK toolchain, Godot runtime executable, or ADB, so the report does not claim an actual APK/device runtime execution.


## Final post-V7.1 hardening pass

The final pass added an additional mutation guard: while a `.gd` focus is active, the agent's generic file mutation tools cannot modify any other path. QLearning access is synchronized, bot-memory startup/payload sizes are bounded, and native generation-start failure paths release temporary sampler/token state immediately. Native cleanup now runs after an abort even when the Kotlin state is an error/loading state.

A pure-Kotlin QLearning runtime test inserted 5,000 states and confirmed the table remains capped at 4,096 states. A runtime test of the actual `CodingWorkspace` source confirmed that a second script cannot be focused, another script cannot be edited, and workspace checkpoint/reset/restore operations are rejected while focus is active; the same operations become available after focus release. JSON/XML parsing and all release/source static checks pass.

No Android/Gradle/Godot/ADB runtime was available in this container, so no APK build or physical-device Godot execution is claimed.
