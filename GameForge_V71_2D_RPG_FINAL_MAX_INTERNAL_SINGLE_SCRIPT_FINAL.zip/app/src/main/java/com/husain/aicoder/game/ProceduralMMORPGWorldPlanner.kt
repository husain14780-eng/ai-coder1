package com.husain.aicoder.game

import org.json.JSONArray
import org.json.JSONObject
import java.util.Random

/** Deterministic MMO-scale world planning contract used by generation, bots and QA. */
class ProceduralMMORPGWorldPlanner {
    fun validate(plan: JSONObject): JSONObject {
        val errors = JSONArray()
        val regionIds = linkedSetOf<String>()
        val cityIds = linkedSetOf<String>()
        val zoneIds = linkedSetOf<String>()
        val questIds = linkedSetOf<String>()
        val regions = plan.optJSONArray("regions") ?: JSONArray()
        for (i in 0 until regions.length()) {
            val region = regions.optJSONObject(i) ?: continue
            val rid = region.optString("id")
            if (rid.isBlank() || !regionIds.add(rid)) errors.put("duplicate_or_blank_region:$rid")
            region.optJSONObject("city")?.optString("id")?.takeIf { it.isNotBlank() }?.let { cityIds.add(it) }
            val zones = region.optJSONArray("zones") ?: JSONArray()
            for (j in 0 until zones.length()) {
                val zid = zones.optJSONObject(j)?.optString("id").orEmpty()
                if (zid.isBlank() || !zoneIds.add(zid)) errors.put("duplicate_or_blank_zone:$zid")
            }
        }
        val routes = plan.optJSONArray("routes") ?: JSONArray()
        for (i in 0 until routes.length()) {
            val route = routes.optJSONObject(i) ?: continue
            val from = route.optString("from")
            val to = route.optString("to")
            if (from !in cityIds || to !in cityIds) errors.put("route_endpoint_missing:${from}->${to}")
            val risk = route.optDouble("risk", -1.0)
            if (risk !in 0.0..1.0) errors.put("route_risk_out_of_range:${from}->${to}")
        }
        val quests = plan.optJSONArray("quests") ?: JSONArray()
        for (i in 0 until quests.length()) {
            val quest = quests.optJSONObject(i) ?: continue
            val qid = quest.optString("id")
            if (qid.isBlank() || !questIds.add(qid)) errors.put("duplicate_or_blank_quest:$qid")
        }
        for (i in 0 until quests.length()) {
            val deps = quests.optJSONObject(i)?.optJSONArray("dependencies") ?: continue
            for (j in 0 until deps.length()) {
                val dep = deps.optString(j)
                if (dep.isNotBlank() && dep !in questIds) errors.put("missing_quest_dependency:$dep")
            }
        }
        val valid = plan.optInt("region_count", 0) == regions.length() && regions.length() > 0 && errors.length() == 0
        return JSONObject().put("ok", valid).put("error_count", errors.length()).put("errors", errors).put("region_count", regions.length()).put("zone_count", zoneIds.size).put("quest_count", questIds.size)
    }

    fun plan(spec: GameSpec, seed: Long = stableSeed(spec)): JSONObject {
        val mmo = spec.genre.contains("mmorpg", true) || spec.genre.contains("rpg", true)
        val regionCount = if (mmo) 8 else 4
        val random = Random(seed)
        val regions = JSONArray()
        val worldRoutes = JSONArray()
        val factions = JSONArray()
        val biomePool = listOf("verdant", "coast", "highland", "desert", "swamp", "volcanic", "snow", "ruins")
        val factionPool = listOf("wardens", "merchant_guild", "free_clans", "arcane_circle", "iron_legion", "sun_order")

        for (i in 0 until regionCount) {
            val regionId = "region_${i + 1}"
            val biome = biomePool[i % biomePool.size]
            val minLevel = 1 + i * 5
            val maxLevel = minLevel + 8 + random.nextInt(5)
            val zoneCount = if (mmo) 4 + random.nextInt(2) else 3
            val zones = JSONArray()
            for (z in 0 until zoneCount) {
                val zoneId = "$regionId/zone_${z + 1}"
                val dungeon = z == zoneCount - 1 || random.nextDouble() < 0.24
                val levelLow = minLevel + z
                zones.put(JSONObject()
                    .put("id", zoneId)
                    .put("name", "${biome.replaceFirstChar { it.uppercase() }} Reach ${z + 1}")
                    .put("level_range", JSONArray(listOf(levelLow, minOf(maxLevel, levelLow + 6))))
                    .put("terrain_seed", random.nextLong())
                    .put("navigation_seed", random.nextLong())
                    .put("dungeon", dungeon)
                    .put("landmarks", landmarks(random, dungeon))
                    .put("resource_tables", resources(random, biome))
                    .put("spawn_tables", spawns(random, levelLow)))
            }
            val regionFactions = JSONArray().apply {
                repeat(2) { put(factionPool[(i + it) % factionPool.size]) }
            }
            regionFactions.forEachString { factions.put(it) }
            regions.put(JSONObject()
                .put("id", regionId)
                .put("name", "${biome.replaceFirstChar { it.uppercase() }} Frontier ${i + 1}")
                .put("biome", biome)
                .put("level_range", JSONArray(listOf(minLevel, maxLevel)))
                .put("city", JSONObject()
                    .put("id", "$regionId/city")
                    .put("name", "Haven ${i + 1}")
                    .put("population_band", if (mmo) "major" else "regional")
                    .put("services", JSONArray(listOf("merchant", "inn", "crafting", "quest_board", "bank", "teleport"))))
                .put("factions", regionFactions)
                .put("zones", zones)
                .put("world_event_seed", random.nextLong()))
        }
        for (i in 1 until regionCount) {
            worldRoutes.put(JSONObject()
                .put("from", "region_${i}/city")
                .put("to", "region_${i + 1}/city")
                .put("travel_type", if (i % 2 == 0) "road" else "wild_route")
                .put("risk", 0.25 + random.nextDouble() * 0.55)
                .put("fast_travel", i % 3 != 0))
        }
        if (regionCount > 3) {
            worldRoutes.put(JSONObject().put("from", "region_1/city").put("to", "region_$regionCount/city").put("travel_type", "teleport_hub").put("risk", 0.02).put("fast_travel", true))
        }
        val quests = questPlan(regions, random)
        val events = eventPlan(random, regionCount)
        val plan = JSONObject()
            .put("planner", "GameForge Procedural MMO World Planner 7.1")
            .put("seed", seed)
            .put("deterministic", true)
            .put("genre", spec.genre)
            .put("region_count", regionCount)
            .put("regions", regions)
            .put("routes", worldRoutes)
            .put("factions", factions.toString().let { JSONArray(it) }.let { uniqueArray(it) })
            .put("quests", quests)
            .put("world_events", events)
            .put("systems", JSONArray(listOf(
                "zone streaming contract",
                "seeded navigation",
                "spawn tables",
                "quest graph",
                "faction reputation",
                "fast travel graph",
                "dynamic world events",
                "save-safe world seeds"
            )))
        return plan.put("validation", validate(plan))
    }

    private fun landmarks(random: Random, dungeon: Boolean): JSONArray = JSONArray().apply {
        put(if (dungeon) "instance_gate" else "camp")
        put(if (random.nextBoolean()) "shrine" else "watchtower")
        put(if (random.nextBoolean()) "resource_node" else "hidden_path")
    }

    private fun resources(random: Random, biome: String): JSONArray = JSONArray(listOf(
        "$biome_ore_tier_${1 + random.nextInt(3)}",
        "$biome_herb_cluster_${1 + random.nextInt(4)}",
        "crafting_material_${1 + random.nextInt(6)}"
    ))

    private fun spawns(random: Random, level: Int): JSONArray = JSONArray(listOf(
        JSONObject().put("archetype", "melee").put("level", level + random.nextInt(3)).put("density", 2 + random.nextInt(3)),
        JSONObject().put("archetype", "ranged").put("level", level + 1 + random.nextInt(3)).put("density", 1 + random.nextInt(2)),
        JSONObject().put("archetype", "elite").put("level", level + 3 + random.nextInt(4)).put("density", 1)
    ))

    private fun questPlan(regions: JSONArray, random: Random): JSONArray = JSONArray().apply {
        for (i in 0 until regions.length()) {
            val region = regions.optJSONObject(i) ?: continue
            val regionId = region.optString("id")
            repeat(6) { q ->
                put(JSONObject()
                    .put("id", "$regionId/quest_${q + 1}")
                    .put("type", listOf("hunt", "escort", "gather", "defeat_elite", "explore", "story")[q % 6])
                    .put("difficulty", 1 + (i + q) % 5)
                    .put("seed", random.nextLong())
                    .put("dependencies", if (q == 0) JSONArray() else JSONArray(listOf("$regionId/quest_${q}"))))
            }
        }
    }

    private fun eventPlan(random: Random, regionCount: Int): JSONArray = JSONArray().apply {
        repeat(12) { e ->
            put(JSONObject()
                .put("id", "world_event_${e + 1}")
                .put("region_id", "region_${1 + random.nextInt(regionCount)}")
                .put("kind", listOf("invasion", "festival", "world_boss", "merchant_caravan", "storm", "resource_surge")[e % 6])
                .put("duration_minutes", 10 + random.nextInt(50))
                .put("cooldown_minutes", 30 + random.nextInt(120))
                .put("seed", random.nextLong()))
        }
    }

    private fun uniqueArray(source: JSONArray): JSONArray {
        val out = JSONArray()
        val seen = linkedSetOf<String>()
        for (i in 0 until source.length()) {
            val s = source.optString(i)
            if (s.isNotBlank() && seen.add(s)) out.put(s)
        }
        return out
    }

    private fun stableSeed(spec: GameSpec): Long {
        var x = 1469598103934665603L
        val text = "${spec.title}|${spec.genre}|${spec.coreLoop.joinToString("|")}"
        for (c in text) x = (x xor c.code.toLong()) * 1099511628211L
        return x
    }
}

private inline fun JSONArray.forEachString(block: (String) -> Unit) {
    for (i in 0 until length()) block(optString(i))
}
